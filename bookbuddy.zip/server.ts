import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import { createServer as createViteServer } from 'vite';
import { createServer as createExpressApp } from './server/src/server.js';
import { errorHandler } from './server/src/middleware/errorMiddleware.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

async function startServer() {
  // AI Studio environment routes port 3000 to the preview frame
  const port = 3000;
  const isProduction = process.env.NODE_ENV === 'production';

  const app = await createExpressApp();

  if (isProduction) {
    const distPath = path.resolve(__dirname, 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res, next) => {
      if (req.url.startsWith('/api')) {
        return next();
      }
      res.sendFile(path.join(distPath, 'index.html'));
    });
  } else {
    const vite = await createViteServer({
      server: {
        middlewareMode: true,
        hmr: false,
      },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  }

  // Central error handling for all API endpoints
  app.use(errorHandler);

  const server = app.listen(port, '0.0.0.0', () => {
    console.log(`🚀 BookBuddy Full-Stack Server listening on http://0.0.0.0:${port}`);
    console.log(`📚 REST API mounted at http://0.0.0.0:${port}/api`);
  });

  server.on('error', (err: NodeJS.ErrnoException) => {
    if (err.code === 'EADDRINUSE') {
      console.error(`Port ${port} is already in use.`);
    } else {
      console.error('Server error:', err);
    }
  });

  const shutdown = () => {
    server.close(() => {
      process.exit(0);
    });
  };

  process.on('SIGTERM', shutdown);
  process.on('SIGINT', shutdown);
}

startServer().catch((err) => {
  console.error('Fatal error starting BookBuddy server:', err);
  process.exit(1);
});
