# BookBuddy Backend REST API Server

Production-structured Node.js & Express REST API backend for the **BookBuddy: AI-Powered Physical Library & Social Reading Platform**.

## Architecture & Technology Stack

* **Runtime**: Node.js (v22.x) with Express.js (v4.21.x)
* **Language**: TypeScript & ECMAScript Modules (ESM)
* **Database & Persistence**: MongoDB & Mongoose schemas with an embedded high-performance document store fallback pre-seeded with all 42 books, users, borrowings, reservations, reviews, and categories.
* **Authentication**: JSON Web Tokens (JWT) + bcryptjs salted hashing with Role-Based Access Control (`STUDENT`, `TEACHER`, `LIBRARIAN`, `ADMIN`).
* **AI & Grounding**: Google Gemini LLM API via `@google/genai` with strict library domain filtering and verified physical catalog coordinate lookups.
* **File Ingestion**: Multer multipart upload with XLSX and PapaParse CSV validation and upsert logic.

---

## Folder Structure

```
server/
├── src/
│   ├── config/             # Environment, DB connection, Cloudinary
│   ├── controllers/        # Express route handlers
│   ├── middleware/         # Auth, RBAC, central error handler, Multer
│   ├── models/             # Mongoose schemas & indexing
│   ├── routes/             # Modular REST endpoint routes
│   ├── services/           # Business logic, inventory, AI & DB store
│   └── server.js           # Express app factory
├── uploads/                # Temporary file staging directory
├── data/                   # Persistent document collections (JSON)
├── postman_collection.json # Comprehensive Postman API test suite
├── .env.example            # Environment variables template
└── README.md
```

---

## API Endpoints Reference

### 1. Authentication (`/api/auth`)
* `POST /api/auth/login` — Sign in with `userId`/`studentId`/`username`/`email`, `password`, and optional `role`
* `POST /api/auth/register` — Register a student account with hashed password
* `GET  /api/auth/me` — Retrieve active authenticated user profile (Bearer token)
* `PUT  /api/auth/me` — Update reader profile (bio, interests, goal)
* `POST /api/auth/logout` — Revoke session

### 2. Books & Holdings (`/api/books`)
* `GET    /api/books` — Paginated catalog with search, filters (category, availability, rating), and sorting (popular, newest, title)
* `GET    /api/books/:id` — Detail view including physical rack, section, shelf, and spine position
* `POST   /api/books` — Add book (*Librarian/Admin only*)
* `PUT    /api/books/:id` — Edit book metadata or copies (*Librarian/Admin only*)
* `DELETE /api/books/:id` — Remove book (*Librarian/Admin only*)
* `GET    /api/books/categories` — Category list
* `GET    /api/books/authors` — Author directory

### 3. Borrowing Lifecycle (`/api/borrowings`)
* `GET  /api/borrowings/me` — Active and historical student loans
* `GET  /api/borrowings` — Full circulation loans register (*Librarian/Admin*)
* `POST /api/borrowings` — Checkout book (decrements inventory, enforces 5-book limit)
* `POST /api/borrowings/return` — Check-in book (increments inventory, advances reservation queue)
* `POST /api/borrowings/:id/renew` — Extend loan by 14 days (max 2 renewals)
* `GET  /api/overdue` — Real-time overdue audit with calculated fines

### 4. Reservations Queue (`/api/reservations`)
* `GET   /api/reservations/me` — Student active queue holds
* `POST  /api/reservations` — Place book reservation with queue position
* `PATCH /api/reservations/:id/cancel` — Cancel hold
* `PATCH /api/reservations/:id/status` — Process reservation (*Librarian/Admin*)

### 5. Social Reading & Lists (`/api/social`, `/api/lists`, `/api/reviews`)
* `GET    /api/social/activity` — Public reading activity stream
* `POST   /api/social/follow` — Follow reader
* `GET    /api/want-to-read` — Personal reading wishlist
* `GET    /api/history/me` — Letterboxd-style reading diary
* `GET    /api/lists` & `POST /api/lists` — Curated book lists
* `POST   /api/reviews` & `POST /api/reviews/:id/like` — 1-5 star ratings and reviews

### 6. AI Intelligence (`/api/ai`)
* `POST /api/ai/chat` — Library assistant domain-restricted chatbot with catalog coordinates
* `GET  /api/ai/recommendations` — Personalized suggestions based on borrowing & ratings
* `GET  /api/ai/search?q=` — Natural language semantic catalog matching
* `POST /api/ai/summary` — 3-bullet concise overview of book concepts
* `GET  /api/ai/learning-paths` — Structured multi-week skill roadmaps

### 7. Administration, Ingestion & Audit
* `GET  /api/analytics` — Real-time metrics (circulation, copies, active borrowers)
* `GET  /api/transactions` — Full audit trail of issues, returns, and catalog changes
* `POST /api/import/books` — Bulk import books from Excel (`.xlsx`) or CSV (`.csv`) with automatic row validation and upsert logic
