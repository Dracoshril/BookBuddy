import express from 'express';
import { analyticsController } from '../controllers/analyticsController.js';
import { authenticate, optionalAuth } from '../middleware/authMiddleware.js';

const router = express.Router();

router.get('/', optionalAuth, analyticsController.getOverviewMetrics);
router.get('/trends', optionalAuth, analyticsController.getMonthlyTrends);
router.get('/categories', optionalAuth, analyticsController.getCategories);
router.get('/popular', optionalAuth, analyticsController.getPopularBooks);
router.get('/insights', authenticate, analyticsController.getReaderInsights);
router.get('/insights/:userId', optionalAuth, analyticsController.getReaderInsights);

export default router;
