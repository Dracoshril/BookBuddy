import express from 'express';
import { socialController } from '../controllers/socialController.js';
import { authenticate } from '../middleware/authMiddleware.js';

const router = express.Router();

// Feeds & Follows
router.get('/activity', socialController.getActivities);
router.post('/activity', authenticate, (req, res, next) => {
  socialController.addActivity(req.body)
    .then((data) => res.json({ success: true, data }))
    .catch(next);
});
router.get('/following', authenticate, socialController.getFollowing);
router.post('/follow', authenticate, socialController.toggleFollow);
router.delete('/follow/:userId', authenticate, socialController.unfollowUser);

// Want to Read
router.get('/want-to-read', authenticate, socialController.getWantToRead);
router.post('/want-to-read', authenticate, socialController.toggleWantToRead);
router.delete('/want-to-read/:bookId', authenticate, socialController.removeFromWantToRead);

// Reading History & Diary
router.get('/history/me', authenticate, socialController.getReadingHistory);

// Lists
router.get('/lists', socialController.getLists);
router.get('/lists/:id', socialController.getListById);
router.post('/lists', authenticate, socialController.createList);
router.put('/lists/:id', authenticate, socialController.updateList);
router.delete('/lists/:id', authenticate, socialController.deleteList);
router.post('/lists/:id/books', authenticate, socialController.addBookToList);
router.delete('/lists/:id/books/:bookId', authenticate, socialController.removeBookFromList);

export default router;
