import express from 'express';
import { importController } from '../controllers/importController.js';
import { authenticate } from '../middleware/authMiddleware.js';
import { authorizeRoles } from '../middleware/roleMiddleware.js';
import { upload } from '../middleware/uploadMiddleware.js';

const router = express.Router();

router.post('/books', authenticate, authorizeRoles('LIBRARIAN', 'ADMIN'), upload.single('file'), importController.importBooks);
router.post('/preview', authenticate, authorizeRoles('LIBRARIAN', 'ADMIN'), upload.single('file'), importController.previewImport);

export default router;
