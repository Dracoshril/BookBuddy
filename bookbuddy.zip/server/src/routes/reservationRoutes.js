import express from 'express';
import { reservationController } from '../controllers/reservationController.js';
import { authenticate } from '../middleware/authMiddleware.js';
import { authorizeRoles } from '../middleware/roleMiddleware.js';

const router = express.Router();

router.get('/me', authenticate, reservationController.getMyReservations);
router.post('/', authenticate, reservationController.createReservation);
router.patch('/:id/cancel', authenticate, reservationController.cancelReservation);
router.patch('/:id/status', authenticate, authorizeRoles('LIBRARIAN', 'ADMIN'), reservationController.processReservation);
router.get('/', authenticate, reservationController.getAllReservations);

export default router;
