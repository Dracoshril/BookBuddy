import express from 'express';
import { userController } from '../controllers/userController.js';
import { authController } from '../controllers/authController.js';
import { authenticate } from '../middleware/authMiddleware.js';
import { authorizeRoles } from '../middleware/roleMiddleware.js';

const router = express.Router();

router.get('/me', authenticate, authController.getMe);
router.put('/me', authenticate, authController.updateMe);

router.get('/', authenticate, authorizeRoles('LIBRARIAN', 'ADMIN'), userController.getAllUsers);
router.get('/:id', authenticate, userController.getUserById);
router.patch('/:id/status', authenticate, authorizeRoles('LIBRARIAN', 'ADMIN'), userController.updateUserStatus);

export default router;
