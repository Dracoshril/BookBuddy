import express from 'express';
import { transactionController } from '../controllers/transactionController.js';
import { authenticate } from '../middleware/authMiddleware.js';
import { authorizeRoles } from '../middleware/roleMiddleware.js';

const router = express.Router();

router.get('/', authenticate, authorizeRoles('LIBRARIAN', 'ADMIN'), transactionController.getTransactions);

export default router;
