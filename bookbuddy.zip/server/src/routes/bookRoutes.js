import express from 'express';
import { bookController } from '../controllers/bookController.js';
import { authenticate, optionalAuth } from '../middleware/authMiddleware.js';
import { authorizeRoles } from '../middleware/roleMiddleware.js';

const router = express.Router();

router.get('/categories', bookController.getCategories);
router.get('/authors', bookController.getAuthors);
router.get('/', optionalAuth, bookController.getBooks);
router.get('/:id', optionalAuth, bookController.getBookById);

router.post('/', authenticate, authorizeRoles('LIBRARIAN', 'ADMIN'), bookController.createBook);
router.put('/:id', authenticate, authorizeRoles('LIBRARIAN', 'ADMIN'), bookController.updateBook);
router.delete('/:id', authenticate, authorizeRoles('LIBRARIAN', 'ADMIN'), bookController.deleteBook);

export default router;
