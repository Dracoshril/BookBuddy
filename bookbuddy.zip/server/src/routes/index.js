import express from 'express';
import authRoutes from './authRoutes.js';
import userRoutes from './userRoutes.js';
import bookRoutes from './bookRoutes.js';
import borrowingRoutes from './borrowingRoutes.js';
import reservationRoutes from './reservationRoutes.js';
import reviewRoutes from './reviewRoutes.js';
import socialRoutes from './socialRoutes.js';
import notificationRoutes from './notificationRoutes.js';
import analyticsRoutes from './analyticsRoutes.js';
import transactionRoutes from './transactionRoutes.js';
import importRoutes from './importRoutes.js';
import aiRoutes from './aiRoutes.js';
import { borrowingController } from '../controllers/borrowingController.js';
import { socialController } from '../controllers/socialController.js';
import { authenticate } from '../middleware/authMiddleware.js';

const router = express.Router();

// Health check
router.get('/health', (req, res) => {
  res.status(200).json({
    success: true,
    message: 'BookBuddy API Server is healthy and running',
    timestamp: new Date().toISOString(),
  });
});

// Mount modules
router.use('/auth', authRoutes);
router.use('/users', userRoutes);
router.use('/books', bookRoutes);
router.use('/borrowings', borrowingRoutes);
router.use('/reservations', reservationRoutes);
router.use('/reviews', reviewRoutes);
router.use('/social', socialRoutes);
router.use('/notifications', notificationRoutes);
router.use('/analytics', analyticsRoutes);
router.use('/transactions', transactionRoutes);
router.use('/import', importRoutes);
router.use('/ai', aiRoutes);

// Direct top-level endpoints requested in prompt
router.get('/overdue', authenticate, borrowingController.getOverdue);
router.get('/want-to-read', authenticate, socialController.getWantToRead);
router.post('/want-to-read', authenticate, socialController.toggleWantToRead);
router.delete('/want-to-read/:bookId', authenticate, socialController.removeFromWantToRead);
router.get('/history/me', authenticate, socialController.getReadingHistory);
router.get('/lists', socialController.getLists);
router.post('/lists', authenticate, socialController.createList);
router.get('/lists/:id', socialController.getListById);
router.put('/lists/:id', authenticate, socialController.updateList);
router.delete('/lists/:id', authenticate, socialController.deleteList);

export default router;
