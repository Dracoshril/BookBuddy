import express from 'express';
import { aiController } from '../controllers/aiController.js';
import { authenticate, optionalAuth } from '../middleware/authMiddleware.js';

const router = express.Router();

router.post('/chat', optionalAuth, aiController.chat);
router.get('/recommendations', optionalAuth, aiController.getRecommendations);
router.get('/search', optionalAuth, aiController.smartSearch);
router.post('/summary', optionalAuth, aiController.getBookSummary);
router.get('/summary/:bookId', optionalAuth, aiController.getBookSummary);
router.post('/learning-path', optionalAuth, aiController.getLearningRoadmaps);
router.get('/learning-paths', optionalAuth, aiController.getLearningRoadmaps);
router.get('/insights', optionalAuth, aiController.getInsights);

export default router;
