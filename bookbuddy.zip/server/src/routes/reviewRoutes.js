import express from 'express';
import { reviewController } from '../controllers/reviewController.js';
import { authenticate, optionalAuth } from '../middleware/authMiddleware.js';

const router = express.Router();

router.get('/', optionalAuth, reviewController.getAllReviews);
router.get('/me', authenticate, reviewController.getMyReviews);
router.get('/book/:bookId', optionalAuth, reviewController.getBookReviews);
router.post('/', authenticate, reviewController.createReview);
router.put('/:id', authenticate, reviewController.updateReview);
router.delete('/:id', authenticate, reviewController.deleteReview);
router.post('/:id/like', authenticate, reviewController.toggleLike);

export default router;
