import express from 'express';
import { borrowingController } from '../controllers/borrowingController.js';
import { authenticate } from '../middleware/authMiddleware.js';
import { authorizeRoles } from '../middleware/roleMiddleware.js';

const router = express.Router();

router.get('/me', authenticate, borrowingController.getMyBorrowings);
router.post('/return', authenticate, borrowingController.returnBook);
router.post('/:id/renew', authenticate, borrowingController.renewBook);

router.get('/', authenticate, borrowingController.getAllBorrowings);
router.post('/', authenticate, borrowingController.borrowBook);

export default router;
