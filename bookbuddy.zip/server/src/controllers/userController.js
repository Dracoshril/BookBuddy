import { db } from '../services/dbStore.js';

export const userController = {
  getAllUsers: async (req, res, next) => {
    try {
      const { role, status, search } = req.query;
      let users = db.users.find({}).results;

      if (role && role !== 'all') {
        users = users.filter((u) => (u.role || '').toUpperCase() === role.toUpperCase());
      }
      if (status && status !== 'all') {
        users = users.filter((u) => (u.status || '').toUpperCase() === status.toUpperCase());
      }
      if (search) {
        const q = search.toLowerCase();
        users = users.filter((u) =>
          (u.name || '').toLowerCase().includes(q) ||
          (u.email || '').toLowerCase().includes(q) ||
          (u.username || '').toLowerCase().includes(q) ||
          (u.studentId || '').toLowerCase().includes(q)
        );
      }

      const safeUsers = users.map((u) => {
        const copy = { ...u };
        delete copy.password;
        return copy;
      });

      res.status(200).json({
        success: true,
        message: 'Users retrieved',
        data: safeUsers,
      });
    } catch (err) {
      next(err);
    }
  },

  getUserById: async (req, res, next) => {
    try {
      const user = db.users.findById(req.params.id) || db.users.findOne({ id: req.params.id });
      if (!user) {
        return res.status(404).json({
          success: false,
          message: 'User not found',
          code: 'NOT_FOUND',
        });
      }
      const safe = { ...user };
      delete safe.password;
      res.status(200).json({
        success: true,
        message: 'User details retrieved',
        data: safe,
      });
    } catch (err) {
      next(err);
    }
  },

  updateUserStatus: async (req, res, next) => {
    try {
      const { status } = req.body;
      if (!['ACTIVE', 'SUSPENDED', 'INACTIVE'].includes(status)) {
        return res.status(400).json({
          success: false,
          message: 'Invalid status. Must be ACTIVE, SUSPENDED, or INACTIVE',
          code: 'VALIDATION_ERROR',
        });
      }

      const updated = db.users.findByIdAndUpdate(req.params.id, { status });
      if (!updated) {
        return res.status(404).json({
          success: false,
          message: 'User not found',
          code: 'NOT_FOUND',
        });
      }

      const safe = { ...updated };
      delete safe.password;
      res.status(200).json({
        success: true,
        message: `User status changed to ${status}`,
        data: safe,
      });
    } catch (err) {
      next(err);
    }
  },
};

export default userController;
