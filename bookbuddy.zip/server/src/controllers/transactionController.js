import { db } from '../services/dbStore.js';

export const transactionController = {
  getTransactions: async (req, res, next) => {
    try {
      const { action, actorId, targetId, limit = 50 } = req.query;
      let txs = db.transactions.find({}).sort({ timestamp: -1 }).results;

      if (action) {
        txs = txs.filter((t) => t.action === action);
      }
      if (actorId) {
        txs = txs.filter((t) => t.actorId === actorId);
      }
      if (targetId) {
        txs = txs.filter((t) => t.targetId === targetId);
      }

      res.status(200).json({
        success: true,
        message: 'Transactions retrieved',
        data: txs.slice(0, parseInt(limit, 10) || 50),
      });
    } catch (err) {
      next(err);
    }
  },
};

export default transactionController;
