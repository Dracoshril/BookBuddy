import { borrowingService } from '../services/borrowingService.js';

export const borrowingController = {
  getAllBorrowings: async (req, res, next) => {
    try {
      const borrowings = await borrowingService.getAllBorrowings(req.query);
      res.status(200).json({
        success: true,
        message: 'Borrowings retrieved',
        data: borrowings,
      });
    } catch (err) {
      next(err);
    }
  },

  getMyBorrowings: async (req, res, next) => {
    try {
      const borrowings = await borrowingService.getUserBorrowings(req.user.id);
      res.status(200).json({
        success: true,
        message: 'User borrowings retrieved',
        data: borrowings,
      });
    } catch (err) {
      next(err);
    }
  },

  borrowBook: async (req, res, next) => {
    try {
      const { bookId, userId, days } = req.body;
      const targetUserId = userId || req.user?.id;

      const borrowing = await borrowingService.borrowBook(
        {
          bookId,
          userId: targetUserId,
          days,
        },
        req.user
      );

      res.status(201).json({
        success: true,
        message: 'Book borrowed successfully',
        data: borrowing,
      });
    } catch (err) {
      next(err);
    }
  },

  returnBook: async (req, res, next) => {
    try {
      const { borrowingId } = req.body;
      const id = borrowingId || req.params?.id;

      const result = await borrowingService.returnBook(id, req.user);
      res.status(200).json({
        success: true,
        message: 'Book returned successfully',
        data: result,
      });
    } catch (err) {
      next(err);
    }
  },

  renewBook: async (req, res, next) => {
    try {
      const result = await borrowingService.renewBook(req.params.id);
      res.status(200).json({
        success: true,
        message: 'Loan renewed successfully for 14 additional days',
        data: result,
      });
    } catch (err) {
      next(err);
    }
  },

  getOverdue: async (req, res, next) => {
    try {
      const overdue = await borrowingService.getOverdueLoans();
      res.status(200).json({
        success: true,
        message: 'Overdue loans retrieved',
        data: overdue,
      });
    } catch (err) {
      next(err);
    }
  },
};

export default borrowingController;
