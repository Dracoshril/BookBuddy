import { reservationService } from '../services/reservationService.js';

export const reservationController = {
  getAllReservations: async (req, res, next) => {
    try {
      const reservations = await reservationService.getAllReservations(req.query);
      res.status(200).json({
        success: true,
        message: 'Reservations retrieved',
        data: reservations,
      });
    } catch (err) {
      next(err);
    }
  },

  getMyReservations: async (req, res, next) => {
    try {
      const reservations = await reservationService.getUserReservations(req.user.id);
      res.status(200).json({
        success: true,
        message: 'User reservations retrieved',
        data: reservations,
      });
    } catch (err) {
      next(err);
    }
  },

  createReservation: async (req, res, next) => {
    try {
      const { bookId, userId } = req.body;
      const targetUserId = userId || req.user?.id;

      const reservation = await reservationService.reserveBook({
        bookId,
        userId: targetUserId,
      });

      res.status(201).json({
        success: true,
        message: 'Reservation placed successfully',
        data: reservation,
      });
    } catch (err) {
      next(err);
    }
  },

  cancelReservation: async (req, res, next) => {
    try {
      const result = await reservationService.cancelReservation(req.params.id, req.user);
      res.status(200).json({
        success: true,
        message: 'Reservation cancelled',
        data: result,
      });
    } catch (err) {
      next(err);
    }
  },

  processReservation: async (req, res, next) => {
    try {
      const { status } = req.body;
      const result = await reservationService.processReservation(req.params.id, status, req.user);
      res.status(200).json({
        success: true,
        message: `Reservation status updated to ${status}`,
        data: result,
      });
    } catch (err) {
      next(err);
    }
  },
};

export default reservationController;
