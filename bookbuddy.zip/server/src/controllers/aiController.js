import { aiService } from '../services/aiService.js';

export const aiController = {
  chat: async (req, res, next) => {
    try {
      const { prompt, messages, message } = req.body;
      const query = prompt || message;
      const history = Array.isArray(messages) ? messages : [];

      const response = await aiService.chat(query, history, req.user);
      res.status(200).json({
        success: true,
        message: 'AI response generated',
        data: response,
      });
    } catch (err) {
      next(err);
    }
  },

  getRecommendations: async (req, res, next) => {
    try {
      const recommendations = await aiService.getRecommendations(req.user);
      res.status(200).json({
        success: true,
        message: 'Personalized recommendations generated',
        data: recommendations,
      });
    } catch (err) {
      next(err);
    }
  },

  smartSearch: async (req, res, next) => {
    try {
      const query = req.query.q || req.query.query || '';
      const result = await aiService.smartSearch(query);
      res.status(200).json({
        success: true,
        message: 'Smart search completed',
        data: result,
      });
    } catch (err) {
      next(err);
    }
  },

  getBookSummary: async (req, res, next) => {
    try {
      const { bookId } = req.body;
      const id = bookId || req.params.bookId || req.query.bookId;
      const summary = await aiService.getBookSummary(id);
      res.status(200).json({
        success: true,
        message: 'Book summary generated',
        data: summary,
      });
    } catch (err) {
      next(err);
    }
  },

  getLearningRoadmaps: async (req, res, next) => {
    try {
      const { goal } = req.body || {};
      const roadmaps = await aiService.getLearningRoadmaps(goal);
      res.status(200).json({
        success: true,
        message: 'Learning paths generated',
        data: roadmaps,
      });
    } catch (err) {
      next(err);
    }
  },

  getInsights: async (req, res, next) => {
    try {
      const userId = req.user?.id || 'student-1';
      const insights = await aiService.getInsights(userId);
      res.status(200).json({
        success: true,
        message: 'Reading insights retrieved',
        data: insights,
      });
    } catch (err) {
      next(err);
    }
  },
};

export default aiController;
