import { analyticsService } from '../services/analyticsService.js';

export const analyticsController = {
  getOverviewMetrics: async (req, res, next) => {
    try {
      const metrics = await analyticsService.getOverviewMetrics();
      res.status(200).json({
        success: true,
        message: 'Overview metrics retrieved',
        data: metrics,
      });
    } catch (err) {
      next(err);
    }
  },

  getMonthlyTrends: async (req, res, next) => {
    try {
      const trends = await analyticsService.getMonthlyBorrowingTrends();
      res.status(200).json({
        success: true,
        message: 'Monthly trends retrieved',
        data: trends,
      });
    } catch (err) {
      next(err);
    }
  },

  getCategories: async (req, res, next) => {
    try {
      const distribution = await analyticsService.getCategoryDistribution();
      res.status(200).json({
        success: true,
        message: 'Category distribution retrieved',
        data: distribution,
      });
    } catch (err) {
      next(err);
    }
  },

  getPopularBooks: async (req, res, next) => {
    try {
      const popular = await analyticsService.getPopularBooks();
      res.status(200).json({
        success: true,
        message: 'Popular books retrieved',
        data: popular,
      });
    } catch (err) {
      next(err);
    }
  },

  getReaderInsights: async (req, res, next) => {
    try {
      const targetUserId = req.params.userId || req.user?.id || 'student-1';
      const insights = await analyticsService.getReaderReadingInsights(targetUserId);
      res.status(200).json({
        success: true,
        message: 'Reader insights retrieved',
        data: insights,
      });
    } catch (err) {
      next(err);
    }
  },
};

export default analyticsController;
