import { authService } from '../services/authService.js';

export const authController = {
  login: async (req, res, next) => {
    try {
      const { username, userId, studentId, email, password, role } = req.body;
      const identifier = username || userId || studentId || email;

      const result = await authService.login({
        identifier,
        password,
        role,
      });

      res.status(200).json({
        success: true,
        message: 'Login successful',
        data: result,
      });
    } catch (err) {
      next(err);
    }
  },

  register: async (req, res, next) => {
    try {
      const result = await authService.register(req.body);
      res.status(201).json({
        success: true,
        message: 'User registered successfully',
        data: result,
      });
    } catch (err) {
      next(err);
    }
  },

  getMe: async (req, res, next) => {
    try {
      const user = await authService.getCurrentUser(req.user.id);
      res.status(200).json({
        success: true,
        message: 'User profile retrieved',
        data: user,
      });
    } catch (err) {
      next(err);
    }
  },

  updateMe: async (req, res, next) => {
    try {
      const updated = await authService.updateProfile(req.user.id, req.body);
      res.status(200).json({
        success: true,
        message: 'Profile updated successfully',
        data: updated,
      });
    } catch (err) {
      next(err);
    }
  },

  logout: async (req, res, next) => {
    try {
      res.status(200).json({
        success: true,
        message: 'Logged out successfully',
        data: null,
      });
    } catch (err) {
      next(err);
    }
  },
};

export default authController;
