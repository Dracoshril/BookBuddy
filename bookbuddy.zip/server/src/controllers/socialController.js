import { socialService } from '../services/socialService.js';

export const socialController = {
  getActivities: async (req, res, next) => {
    try {
      const activities = await socialService.getActivities();
      res.status(200).json({
        success: true,
        message: 'Social activity feed retrieved',
        data: activities,
      });
    } catch (err) {
      next(err);
    }
  },

  getFollowing: async (req, res, next) => {
    try {
      const following = await socialService.getFollowing(req.user.id);
      res.status(200).json({
        success: true,
        message: 'Following list retrieved',
        data: following,
      });
    } catch (err) {
      next(err);
    }
  },

  toggleFollow: async (req, res, next) => {
    try {
      const targetUserId = req.body.targetUserId || req.params.userId;
      const result = await socialService.toggleFollow(req.user.id, targetUserId);
      res.status(200).json({
        success: true,
        message: result.isFollowing ? 'Followed reader' : 'Unfollowed reader',
        data: result,
      });
    } catch (err) {
      next(err);
    }
  },

  unfollowUser: async (req, res, next) => {
    try {
      const targetUserId = req.params.userId;
      const result = await socialService.toggleFollow(req.user.id, targetUserId);
      res.status(200).json({
        success: true,
        message: 'Unfollowed reader',
        data: result,
      });
    } catch (err) {
      next(err);
    }
  },

  getWantToRead: async (req, res, next) => {
    try {
      const books = await socialService.getWantToRead(req.user.id);
      res.status(200).json({
        success: true,
        message: 'Want-to-read list retrieved',
        data: books,
      });
    } catch (err) {
      next(err);
    }
  },

  toggleWantToRead: async (req, res, next) => {
    try {
      const { bookId } = req.body;
      const result = await socialService.toggleWantToRead(req.user.id, bookId);
      res.status(200).json({
        success: true,
        message: result.inWantToRead ? 'Added to Want to Read' : 'Removed from Want to Read',
        data: result,
      });
    } catch (err) {
      next(err);
    }
  },

  removeFromWantToRead: async (req, res, next) => {
    try {
      const { bookId } = req.params;
      const result = await socialService.removeFromWantToRead(req.user.id, bookId);
      res.status(200).json({
        success: true,
        message: 'Removed from Want to Read',
        data: result,
      });
    } catch (err) {
      next(err);
    }
  },

  getReadingHistory: async (req, res, next) => {
    try {
      const history = await socialService.getReadingHistory(req.user.id);
      res.status(200).json({
        success: true,
        message: 'Reading history and diary retrieved',
        data: history,
      });
    } catch (err) {
      next(err);
    }
  },

  // Lists
  getLists: async (req, res, next) => {
    try {
      const lists = await socialService.getAllLists(req.query);
      res.status(200).json({
        success: true,
        message: 'Lists retrieved',
        data: lists,
      });
    } catch (err) {
      next(err);
    }
  },

  getListById: async (req, res, next) => {
    try {
      const list = await socialService.getListById(req.params.id);
      res.status(200).json({
        success: true,
        message: 'List details retrieved',
        data: list,
      });
    } catch (err) {
      next(err);
    }
  },

  createList: async (req, res, next) => {
    try {
      const list = await socialService.createList(req.body, req.user);
      res.status(201).json({
        success: true,
        message: 'Reading list created successfully',
        data: list,
      });
    } catch (err) {
      next(err);
    }
  },

  updateList: async (req, res, next) => {
    try {
      const updated = await socialService.updateList(req.params.id, req.body, req.user);
      res.status(200).json({
        success: true,
        message: 'List updated successfully',
        data: updated,
      });
    } catch (err) {
      next(err);
    }
  },

  deleteList: async (req, res, next) => {
    try {
      const result = await socialService.deleteList(req.params.id, req.user);
      res.status(200).json({
        success: true,
        message: 'List deleted successfully',
        data: result,
      });
    } catch (err) {
      next(err);
    }
  },

  addBookToList: async (req, res, next) => {
    try {
      const { bookId } = req.body;
      const result = await socialService.addBookToList(req.params.id, bookId, req.user);
      res.status(200).json({
        success: true,
        message: 'Book added to list',
        data: result,
      });
    } catch (err) {
      next(err);
    }
  },

  removeBookFromList: async (req, res, next) => {
    try {
      const result = await socialService.removeBookFromList(req.params.id, req.params.bookId, req.user);
      res.status(200).json({
        success: true,
        message: 'Book removed from list',
        data: result,
      });
    } catch (err) {
      next(err);
    }
  },
};

export default socialController;
