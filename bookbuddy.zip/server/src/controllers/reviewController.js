import { reviewService } from '../services/reviewService.js';

export const reviewController = {
  getAllReviews: async (req, res, next) => {
    try {
      const { bookId, userId } = req.query;
      let reviews;
      if (bookId) {
        reviews = await reviewService.getBookReviews(bookId);
      } else if (userId) {
        reviews = await reviewService.getUserReviews(userId);
      } else {
        reviews = await reviewService.getAllReviews();
      }

      res.status(200).json({
        success: true,
        message: 'Reviews retrieved',
        data: reviews,
      });
    } catch (err) {
      next(err);
    }
  },

  getBookReviews: async (req, res, next) => {
    try {
      const reviews = await reviewService.getBookReviews(req.params.bookId || req.params.id);
      res.status(200).json({
        success: true,
        message: 'Book reviews retrieved',
        data: reviews,
      });
    } catch (err) {
      next(err);
    }
  },

  getMyReviews: async (req, res, next) => {
    try {
      const reviews = await reviewService.getUserReviews(req.user.id);
      res.status(200).json({
        success: true,
        message: 'My reviews retrieved',
        data: reviews,
      });
    } catch (err) {
      next(err);
    }
  },

  createReview: async (req, res, next) => {
    try {
      const review = await reviewService.createReview(req.body, req.user);
      res.status(201).json({
        success: true,
        message: 'Review posted successfully',
        data: review,
      });
    } catch (err) {
      next(err);
    }
  },

  updateReview: async (req, res, next) => {
    try {
      const updated = await reviewService.updateReview(req.params.id, req.body, req.user);
      res.status(200).json({
        success: true,
        message: 'Review updated successfully',
        data: updated,
      });
    } catch (err) {
      next(err);
    }
  },

  deleteReview: async (req, res, next) => {
    try {
      const result = await reviewService.deleteReview(req.params.id, req.user);
      res.status(200).json({
        success: true,
        message: 'Review deleted successfully',
        data: result,
      });
    } catch (err) {
      next(err);
    }
  },

  toggleLike: async (req, res, next) => {
    try {
      const result = await reviewService.toggleLike(req.params.id, req.user.id);
      res.status(200).json({
        success: true,
        message: result.isLiked ? 'Review liked' : 'Review unliked',
        data: result,
      });
    } catch (err) {
      next(err);
    }
  },
};

export default reviewController;
