import { importService } from '../services/importService.js';
import fs from 'fs';

export const importController = {
  importBooks: async (req, res, next) => {
    try {
      if (!req.file) {
        return res.status(400).json({
          success: false,
          message: 'Please attach a valid .csv or .xlsx spreadsheet file',
          code: 'FILE_REQUIRED',
        });
      }

      const filePath = req.file.path;
      const validationResult = importService.parseAndValidate(filePath);

      // Auto-commit valid rows
      const commitResult = await importService.commitImport(validationResult.validRows, req.user);

      // Clean up uploaded temp file
      try {
        if (fs.existsSync(filePath)) fs.unlinkSync(filePath);
      } catch (e) {
        // Ignore unlink error
      }

      res.status(200).json({
        success: true,
        message: `Successfully processed ${validationResult.totalRows} rows: ${commitResult.createdCount} new books cataloged, ${commitResult.updatedCount} existing books updated.`,
        data: {
          totalRows: validationResult.totalRows,
          validRows: validationResult.validRowsCount,
          invalidRows: validationResult.invalidRowsCount,
          errors: validationResult.errors,
          createdCount: commitResult.createdCount,
          updatedCount: commitResult.updatedCount,
        },
      });
    } catch (err) {
      next(err);
    }
  },

  previewImport: async (req, res, next) => {
    try {
      if (!req.file) {
        return res.status(400).json({
          success: false,
          message: 'Please attach a .csv or .xlsx file to preview',
          code: 'FILE_REQUIRED',
        });
      }

      const filePath = req.file.path;
      const validationResult = importService.parseAndValidate(filePath);

      try {
        if (fs.existsSync(filePath)) fs.unlinkSync(filePath);
      } catch (e) {
        // Ignore unlink error
      }

      res.status(200).json({
        success: true,
        message: 'Import preview generated',
        data: {
          totalRows: validationResult.totalRows,
          validRows: validationResult.validRowsCount,
          invalidRows: validationResult.invalidRowsCount,
          errors: validationResult.errors,
          preview: validationResult.validRows.slice(0, 10),
        },
      });
    } catch (err) {
      next(err);
    }
  },
};

export default importController;
