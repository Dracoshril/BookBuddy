import { db } from '../services/dbStore.js';

export const notificationController = {
  getNotifications: async (req, res, next) => {
    try {
      const notifications = db.notifications.find({ userId: req.user.id }).sort({ createdAt: -1 }).results;
      res.status(200).json({
        success: true,
        message: 'Notifications retrieved',
        data: notifications,
      });
    } catch (err) {
      next(err);
    }
  },

  markAsRead: async (req, res, next) => {
    try {
      const updated = db.notifications.findByIdAndUpdate(req.params.id, { isRead: true });
      res.status(200).json({
        success: true,
        message: 'Notification marked as read',
        data: updated,
      });
    } catch (err) {
      next(err);
    }
  },

  markAllAsRead: async (req, res, next) => {
    try {
      const userNotifs = db.notifications.find({ userId: req.user.id }).results;
      userNotifs.forEach((n) => {
        db.notifications.findByIdAndUpdate(n.id, { isRead: true });
      });
      const updated = db.notifications.find({ userId: req.user.id }).sort({ createdAt: -1 }).results;
      res.status(200).json({
        success: true,
        message: 'All notifications marked as read',
        data: updated,
      });
    } catch (err) {
      next(err);
    }
  },

  createNotification: async (req, res, next) => {
    try {
      const { title, message, type = 'SYSTEM', userId, link } = req.body;
      const targetUserId = userId || req.user.id;
      const newNotif = db.notifications.create({
        id: `notif-${Date.now()}`,
        userId: targetUserId,
        title,
        message,
        type,
        link: link || '',
        isRead: false,
      });
      res.status(201).json({
        success: true,
        message: 'Notification sent',
        data: newNotif,
      });
    } catch (err) {
      next(err);
    }
  },
};

export default notificationController;
