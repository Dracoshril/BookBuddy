import { bookService } from '../services/bookService.js';
import { db } from '../services/dbStore.js';

export const bookController = {
  getBooks: async (req, res, next) => {
    try {
      const result = await bookService.getBooks(req.query);
      res.status(200).json({
        success: true,
        message: 'Books retrieved successfully',
        data: result,
      });
    } catch (err) {
      next(err);
    }
  },

  getBookById: async (req, res, next) => {
    try {
      const book = await bookService.getBookById(req.params.id);
      res.status(200).json({
        success: true,
        message: 'Book retrieved successfully',
        data: book,
      });
    } catch (err) {
      next(err);
    }
  },

  createBook: async (req, res, next) => {
    try {
      const book = await bookService.createBook(req.body, req.user);
      res.status(201).json({
        success: true,
        message: 'Book created successfully',
        data: book,
      });
    } catch (err) {
      next(err);
    }
  },

  updateBook: async (req, res, next) => {
    try {
      const updated = await bookService.updateBook(req.params.id, req.body, req.user);
      res.status(200).json({
        success: true,
        message: 'Book updated successfully',
        data: updated,
      });
    } catch (err) {
      next(err);
    }
  },

  deleteBook: async (req, res, next) => {
    try {
      const result = await bookService.deleteBook(req.params.id, req.user);
      res.status(200).json({
        success: true,
        message: 'Book deleted successfully',
        data: result,
      });
    } catch (err) {
      next(err);
    }
  },

  getCategories: async (req, res, next) => {
    try {
      const categories = db.categories.find({}).results;
      res.status(200).json({
        success: true,
        message: 'Categories retrieved',
        data: categories,
      });
    } catch (err) {
      next(err);
    }
  },

  getAuthors: async (req, res, next) => {
    try {
      const authors = db.authors.find({}).results;
      res.status(200).json({
        success: true,
        message: 'Authors retrieved',
        data: authors,
      });
    } catch (err) {
      next(err);
    }
  },
};

export default bookController;
