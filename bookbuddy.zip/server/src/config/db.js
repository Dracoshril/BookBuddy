import mongoose from 'mongoose';
import { config } from './env.js';

export const connectDB = async () => {
  const uri = (config.mongodbUri || '').trim();
  if (!uri || (!uri.startsWith('mongodb://') && !uri.startsWith('mongodb+srv://'))) {
    console.log('ℹ️ MONGODB_URI not configured or invalid scheme. Using embedded high-performance document store with persistent JSON storage.');
    return false;
  }

  try {
    await mongoose.connect(uri, {
      serverSelectionTimeoutMS: 5000,
    });
    console.log('✅ Connected to MongoDB via Mongoose successfully.');
    return true;
  } catch (err) {
    console.warn(`⚠️ MongoDB connection attempt failed: ${err.message}. Seamlessly falling back to embedded document store.`);
    return false;
  }
};

export default connectDB;
