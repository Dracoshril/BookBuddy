import { db } from './dbStore.js';

export const reservationService = {
  getUserReservations: async (userId) => {
    return db.reservations.find({ userId }).results;
  },

  getAllReservations: async (query = {}) => {
    let list = db.reservations.find({}).results;
    if (query.status) {
      list = list.filter((r) => r.status === query.status);
    }
    if (query.bookId) {
      list = list.filter((r) => r.bookId === query.bookId);
    }
    return list;
  },

  reserveBook: async ({ userId, bookId }) => {
    if (!userId || !bookId) {
      const error = new Error('User ID and Book ID are required to place a reservation');
      error.statusCode = 400;
      error.code = 'VALIDATION_ERROR';
      throw error;
    }

    const user = db.users.findById(userId) || db.users.findOne({ $or: [{ studentId: userId }, { username: userId }] });
    if (!user) {
      const error = new Error(`User "${userId}" not found`);
      error.statusCode = 404;
      error.code = 'USER_NOT_FOUND';
      throw error;
    }

    const book = db.books.findById(bookId) || db.books.findOne({ $or: [{ bookNumber: bookId }, { isbn: bookId }] });
    if (!book) {
      const error = new Error(`Book "${bookId}" not found`);
      error.statusCode = 404;
      error.code = 'BOOK_NOT_FOUND';
      throw error;
    }

    // Check if user already has an active reservation for this book
    const existing = db.reservations.findOne({
      userId: user.id,
      bookId: book.id,
      status: { $in: ['WAITING', 'RESERVED', 'AVAILABLE'] },
    });
    if (existing) {
      const error = new Error('You already have an active reservation in place for this book');
      error.statusCode = 409;
      error.code = 'ALREADY_RESERVED';
      throw error;
    }

    // Calculate queue position
    const activeReservations = db.reservations.find({
      bookId: book.id,
      status: { $in: ['WAITING', 'RESERVED', 'AVAILABLE'] },
    }).results;

    const queuePosition = activeReservations.length + 1;
    const isImmediateAvailable = book.availableCopies > 0 && activeReservations.length === 0;

    const id = `res-${Date.now()}`;
    const newReservation = db.reservations.create({
      id,
      _id: id,
      userId: user.id,
      userName: user.name,
      bookId: book.id,
      bookTitle: book.title,
      reservationDate: new Date().toISOString(),
      queuePosition,
      status: isImmediateAvailable ? 'AVAILABLE' : 'WAITING',
      availableDate: isImmediateAvailable ? new Date().toISOString() : null,
      completedDate: null,
    });

    // Notify user
    db.notifications.create({
      userId: user.id,
      title: isImmediateAvailable ? 'Reservation Ready' : 'Reservation Placed in Queue',
      message: isImmediateAvailable
        ? `"${book.title}" is reserved and ready for pickup at Circulation Desk 1.`
        : `Your reservation for "${book.title}" is confirmed. Queue Position: #${queuePosition}.`,
      type: 'RESERVATION',
      isRead: false,
    });

    // Transaction
    db.transactions.create({
      actorId: user.id,
      actorName: user.name,
      actorRole: user.role || 'STUDENT',
      action: 'RESERVE',
      targetId: id,
      targetType: 'RESERVATION',
      metadata: { bookTitle: book.title, queuePosition },
    });

    return newReservation;
  },

  cancelReservation: async (id, actor = null) => {
    const reservation = db.reservations.findById(id);
    if (!reservation) {
      const error = new Error(`Reservation "${id}" not found`);
      error.statusCode = 404;
      error.code = 'NOT_FOUND';
      throw error;
    }

    const updated = db.reservations.findByIdAndUpdate(id, {
      status: 'CANCELLED',
      completedDate: new Date().toISOString(),
    });

    db.transactions.create({
      actorId: actor?.id || reservation.userId,
      actorName: actor?.name || reservation.userName,
      actorRole: actor?.role || 'STUDENT',
      action: 'CANCEL_RESERVE',
      targetId: id,
      targetType: 'RESERVATION',
      metadata: { bookTitle: reservation.bookTitle },
    });

    return updated;
  },

  processReservation: async (id, status, actor = null) => {
    const reservation = db.reservations.findById(id);
    if (!reservation) {
      const error = new Error(`Reservation "${id}" not found`);
      error.statusCode = 404;
      error.code = 'NOT_FOUND';
      throw error;
    }

    const updated = db.reservations.findByIdAndUpdate(id, {
      status,
      completedDate: status === 'COMPLETED' ? new Date().toISOString() : reservation.completedDate,
      availableDate: status === 'AVAILABLE' ? new Date().toISOString() : reservation.availableDate,
    });

    return updated;
  },
};

export default reservationService;
