import { db } from './dbStore.js';

export const socialService = {
  // Activity Feed
  getActivities: async () => {
    return db.activities.find({}).sort({ timestamp: -1 }).limit(30).results;
  },

  addActivity: async (activity) => {
    const newAct = db.activities.create({
      ...activity,
      timestamp: new Date().toISOString(),
    });
    return newAct;
  },

  // Following / Followers
  getFollowing: async (userId) => {
    const follows = db.follows.find({ followerId: userId }).results;
    return follows.map((f) => f.followingId);
  },

  toggleFollow: async (followerId, targetUserId) => {
    if (followerId === targetUserId) {
      const error = new Error('You cannot follow yourself');
      error.statusCode = 400;
      throw error;
    }

    const existing = db.follows.findOne({ followerId, followingId: targetUserId });
    let isFollowing = false;

    if (existing) {
      db.follows.deleteOne({ followerId, followingId: targetUserId });
      isFollowing = false;
      db.users.findByIdAndUpdate(targetUserId, { $inc: { followersCount: -1 } });
      db.users.findByIdAndUpdate(followerId, { $inc: { followingCount: -1 } });
    } else {
      db.follows.create({
        followerId,
        followingId: targetUserId,
        createdAt: new Date().toISOString(),
      });
      isFollowing = true;
      db.users.findByIdAndUpdate(targetUserId, { $inc: { followersCount: 1 } });
      db.users.findByIdAndUpdate(followerId, { $inc: { followingCount: 1 } });

      // Notify followed user
      const follower = db.users.findById(followerId);
      db.notifications.create({
        userId: targetUserId,
        title: 'New Follower',
        message: `${follower?.name || 'A reader'} is now following your reading activities and lists.`,
        type: 'SOCIAL',
        isRead: false,
      });
    }

    const updatedFollowing = db.follows.find({ followerId }).results.map((f) => f.followingId);
    return { targetUserId, isFollowing, following: updatedFollowing };
  },

  // Want to Read List
  getWantToRead: async (userId) => {
    const entries = db.wantToRead.find({ userId }).results;
    const bookIds = entries.map((e) => e.bookId);
    return db.books.find({ id: { $in: bookIds } }).results;
  },

  toggleWantToRead: async (userId, bookId) => {
    const existing = db.wantToRead.findOne({ userId, bookId });
    if (existing) {
      db.wantToRead.deleteOne({ userId, bookId });
      return { bookId, inWantToRead: false };
    } else {
      db.wantToRead.create({
        userId,
        bookId,
        addedAt: new Date().toISOString(),
      });
      return { bookId, inWantToRead: true };
    }
  },

  addToWantToRead: async (userId, bookId) => {
    const existing = db.wantToRead.findOne({ userId, bookId });
    if (!existing) {
      db.wantToRead.create({
        userId,
        bookId,
        addedAt: new Date().toISOString(),
      });
    }
    return { bookId, success: true };
  },

  removeFromWantToRead: async (userId, bookId) => {
    db.wantToRead.deleteOne({ userId, bookId });
    return { bookId, success: true };
  },

  // Reading History & Diary
  getReadingHistory: async (userId) => {
    const loans = db.borrowings.find({ userId }).sort({ borrowDate: -1 }).results;
    const reviews = db.reviews.find({ userId }).results;

    const history = loans.map((loan) => {
      const book = db.books.findById(loan.bookId);
      const review = reviews.find((r) => r.bookId === loan.bookId);
      return {
        id: loan.id,
        bookId: loan.bookId,
        bookTitle: loan.bookTitle || book?.title,
        author: book?.author,
        category: book?.category,
        coverImage: book?.coverImage,
        borrowDate: loan.borrowDate,
        returnDate: loan.returnDate,
        dueDate: loan.dueDate,
        status: loan.status,
        rating: review?.rating || null,
        review: review?.review || null,
      };
    });

    return history;
  },

  // Book Lists
  getAllLists: async (query = {}) => {
    let lists = db.lists.find({}).sort({ createdAt: -1 }).results;
    if (query.userId) {
      lists = lists.filter((l) => l.userId === query.userId);
    }
    return lists;
  },

  getUserLists: async (userId) => {
    return db.lists.find({ userId }).sort({ createdAt: -1 }).results;
  },

  getListById: async (id) => {
    const list = db.lists.findById(id);
    if (!list) {
      const error = new Error(`List "${id}" not found`);
      error.statusCode = 404;
      error.code = 'NOT_FOUND';
      throw error;
    }
    const bookObjects = db.books.find({ id: { $in: list.books || [] } }).results;
    return { ...list, bookObjects };
  },

  createList: async (listData, user) => {
    const { name, description = '', visibility = 'PUBLIC', books = [] } = listData;
    if (!name) {
      const error = new Error('List name is required');
      error.statusCode = 400;
      throw error;
    }

    const id = `list-${Date.now()}`;
    const newList = db.lists.create({
      id,
      _id: id,
      userId: user.id,
      userName: user.name,
      name,
      description,
      visibility,
      books: Array.isArray(books) ? books : [],
      likesCount: 0,
    });

    db.users.findByIdAndUpdate(user.id, { $inc: { listsCount: 1 } });

    // Activity
    db.activities.create({
      userId: user.id,
      userName: user.name,
      type: 'list',
      action: 'created a curated reading list',
      target: name,
    });

    return newList;
  },

  updateList: async (id, data, user) => {
    const list = db.lists.findById(id);
    if (!list) {
      const error = new Error(`List "${id}" not found`);
      error.statusCode = 404;
      throw error;
    }
    if (list.userId !== user.id && user.role !== 'ADMIN') {
      const error = new Error('You can only edit your own lists');
      error.statusCode = 403;
      throw error;
    }

    const allowed = ['name', 'description', 'visibility', 'books'];
    const updates = {};
    for (const k of allowed) {
      if (data[k] !== undefined) updates[k] = data[k];
    }

    return db.lists.findByIdAndUpdate(id, updates);
  },

  deleteList: async (id, user) => {
    const list = db.lists.findById(id);
    if (!list) {
      const error = new Error(`List "${id}" not found`);
      error.statusCode = 404;
      throw error;
    }
    if (list.userId !== user.id && user.role !== 'ADMIN') {
      const error = new Error('You can only delete your own lists');
      error.statusCode = 403;
      throw error;
    }
    db.lists.findByIdAndDelete(id);
    db.users.findByIdAndUpdate(user.id, { $inc: { listsCount: -1 } });
    return { id, success: true };
  },

  addBookToList: async (listId, bookId, user) => {
    const list = db.lists.findById(listId);
    if (!list) {
      const error = new Error('List not found');
      error.statusCode = 404;
      throw error;
    }
    const current = Array.isArray(list.books) ? list.books : [];
    if (!current.includes(bookId)) {
      current.push(bookId);
      db.lists.findByIdAndUpdate(listId, { books: current });
    }
    return db.lists.findById(listId);
  },

  removeBookFromList: async (listId, bookId, user) => {
    const list = db.lists.findById(listId);
    if (!list) {
      const error = new Error('List not found');
      error.statusCode = 404;
      throw error;
    }
    const current = Array.isArray(list.books) ? list.books : [];
    const updated = current.filter((b) => b !== bookId);
    return db.lists.findByIdAndUpdate(listId, { books: updated });
  },
};

export default socialService;
