import { db } from './dbStore.js';

export const borrowingService = {
  getUserBorrowings: async (userId) => {
    const borrowings = db.borrowings.find({ userId }).results;
    const now = new Date();

    // Check and update overdue statuses dynamically
    return borrowings.map((b) => {
      if (b.status === 'CURRENT' && new Date(b.dueDate) < now) {
        return { ...b, status: 'OVERDUE' };
      }
      return b;
    });
  },

  getAllBorrowings: async (query = {}) => {
    let borrowings = db.borrowings.find({}).results;
    const now = new Date();

    if (query.status) {
      borrowings = borrowings.filter((b) => b.status === query.status);
    }
    if (query.userId) {
      borrowings = borrowings.filter((b) => b.userId === query.userId);
    }
    if (query.bookId) {
      borrowings = borrowings.filter((b) => b.bookId === query.bookId);
    }

    return borrowings.map((b) => {
      if (b.status === 'CURRENT' && new Date(b.dueDate) < now) {
        return { ...b, status: 'OVERDUE' };
      }
      return b;
    });
  },

  borrowBook: async ({ userId, bookId, days = 14 }, actor = null) => {
    if (!userId || !bookId) {
      const error = new Error('User ID and Book ID are required to issue a book');
      error.statusCode = 400;
      error.code = 'VALIDATION_ERROR';
      throw error;
    }

    // 1. Verify reader
    const user = db.users.findById(userId) || db.users.findOne({ $or: [{ studentId: userId }, { username: userId }] });
    if (!user) {
      const error = new Error(`Reader account "${userId}" not found`);
      error.statusCode = 404;
      error.code = 'USER_NOT_FOUND';
      throw error;
    }

    // 2. Check active loans limit (max 5 books per student)
    const activeLoans = db.borrowings.find({
      userId: user.id,
      status: { $in: ['CURRENT', 'OVERDUE', 'DUE_SOON'] },
    }).results;

    if (activeLoans.length >= 5) {
      const error = new Error('Borrowing limit reached: Maximum 5 concurrent physical loans permitted per student');
      error.statusCode = 409;
      error.code = 'LIMIT_REACHED';
      throw error;
    }

    // 3. Check if user already borrowed this exact book
    const alreadyBorrowed = activeLoans.find((b) => b.bookId === bookId);
    if (alreadyBorrowed) {
      const error = new Error('You already have an active loan for this book');
      error.statusCode = 409;
      error.code = 'ALREADY_BORROWED';
      throw error;
    }

    // 4. Verify book & inventory availability
    const book = db.books.findById(bookId) || db.books.findOne({ $or: [{ bookNumber: bookId }, { isbn: bookId }] });
    if (!book) {
      const error = new Error(`Book "${bookId}" not found in catalog`);
      error.statusCode = 404;
      error.code = 'BOOK_NOT_FOUND';
      throw error;
    }

    if (book.availableCopies <= 0) {
      const error = new Error(`All copies of "${book.title}" are currently issued. Please reserve a copy.`);
      error.statusCode = 409;
      error.code = 'NO_COPIES_AVAILABLE';
      throw error;
    }

    // 5. Decrement inventory safely & update book status
    const newAvailable = book.availableCopies - 1;
    const newStatus = newAvailable === 0 ? 'ISSUED' : 'AVAILABLE';
    db.books.findByIdAndUpdate(book.id, {
      availableCopies: newAvailable,
      status: newStatus,
      $inc: { borrowCount: 1 },
    });

    // 6. Create borrowing record
    const borrowDate = new Date();
    const dueDate = new Date();
    dueDate.setDate(dueDate.getDate() + (parseInt(days, 10) || 14));

    const borrowingId = `brw-${Date.now()}`;
    const newBorrowing = db.borrowings.create({
      id: borrowingId,
      _id: borrowingId,
      userId: user.id,
      readerName: user.name,
      bookId: book.id,
      bookTitle: book.title,
      borrowDate: borrowDate.toISOString(),
      dueDate: dueDate.toISOString(),
      returnDate: null,
      status: 'CURRENT',
      renewalCount: 0,
      fineAmount: 0,
    });

    // 7. Update User reading stats
    db.users.findByIdAndUpdate(user.id, {
      $inc: { booksReadCount: 1 },
    });

    // 8. Create Notification for Student
    db.notifications.create({
      userId: user.id,
      title: 'Book Borrowed Successfully',
      message: `"${book.title}" is checked out. Due date is ${dueDate.toLocaleDateString()}. Location: Rack ${book.location?.rack || 1}, Shelf ${book.location?.shelf || 1}.`,
      type: 'BORROW',
      isRead: false,
    });

    // 9. Record Transaction
    db.transactions.create({
      actorId: actor?.id || user.id,
      actorName: actor?.name || user.name,
      actorRole: actor?.role || 'STUDENT',
      action: 'ISSUE',
      targetId: newBorrowing.id,
      targetType: 'BORROWING',
      metadata: { bookTitle: book.title, readerName: user.name, dueDate: dueDate.toISOString() },
    });

    // 10. Record Activity in feed
    db.activities.create({
      userId: user.id,
      userName: user.name,
      type: 'reading',
      action: 'borrowed',
      target: book.title,
      bookId: book.id,
      details: { dueDate: dueDate.toISOString() },
    });

    return newBorrowing;
  },

  returnBook: async (borrowingId, actor = null) => {
    const borrowing = db.borrowings.findById(borrowingId);
    if (!borrowing) {
      const error = new Error(`Borrowing record "${borrowingId}" not found`);
      error.statusCode = 404;
      error.code = 'BORROWING_NOT_FOUND';
      throw error;
    }

    if (borrowing.status === 'RETURNED') {
      const error = new Error('This book has already been marked as returned');
      error.statusCode = 400;
      error.code = 'ALREADY_RETURNED';
      throw error;
    }

    const returnDate = new Date();

    // 1. Mark borrowing as RETURNED
    const updatedBorrowing = db.borrowings.findByIdAndUpdate(borrowingId, {
      status: 'RETURNED',
      returnDate: returnDate.toISOString(),
    });

    // 2. Increment book availableCopies
    const book = db.books.findById(borrowing.bookId);
    if (book) {
      const newAvailable = Math.min(book.totalCopies, book.availableCopies + 1);
      db.books.findByIdAndUpdate(book.id, {
        availableCopies: newAvailable,
        status: 'AVAILABLE',
      });

      // 3. Process Reservation Queue: Check if anyone is waiting
      const waitingReservation = db.reservations.find({
        bookId: book.id,
        status: 'WAITING',
      }).results[0];

      if (waitingReservation) {
        db.reservations.findByIdAndUpdate(waitingReservation.id, {
          status: 'AVAILABLE',
          availableDate: new Date().toISOString(),
        });

        // Notify next reader in queue
        db.notifications.create({
          userId: waitingReservation.userId,
          title: 'Reserved Book Ready for Pickup',
          message: `Your reserved book "${book.title}" has been returned and is waiting at Circulation Desk 1. Pickup within 48 hours.`,
          type: 'RESERVATION',
          isRead: false,
        });
      }
    }

    // 4. Record Transaction
    db.transactions.create({
      actorId: actor?.id || borrowing.userId,
      actorName: actor?.name || borrowing.readerName,
      actorRole: actor?.role || 'LIBRARIAN',
      action: 'RETURN',
      targetId: borrowingId,
      targetType: 'BORROWING',
      metadata: { bookTitle: borrowing.bookTitle, returnDate: returnDate.toISOString() },
    });

    // 5. Record Activity in feed
    db.activities.create({
      userId: borrowing.userId,
      userName: borrowing.readerName,
      type: 'reading',
      action: 'returned',
      target: borrowing.bookTitle,
      bookId: borrowing.bookId,
    });

    return updatedBorrowing;
  },

  renewBook: async (borrowingId) => {
    const borrowing = db.borrowings.findById(borrowingId);
    if (!borrowing) {
      const error = new Error(`Loan record "${borrowingId}" not found`);
      error.statusCode = 404;
      error.code = 'NOT_FOUND';
      throw error;
    }

    if (borrowing.status === 'RETURNED') {
      const error = new Error('Cannot renew a returned loan');
      error.statusCode = 400;
      throw error;
    }

    if ((borrowing.renewalCount || 0) >= 2) {
      const error = new Error('Renewal limit reached (Maximum 2 renewals permitted per checkout)');
      error.statusCode = 409;
      error.code = 'RENEWAL_LIMIT';
      throw error;
    }

    // Extend due date by 14 days
    const currentDue = new Date(borrowing.dueDate);
    currentDue.setDate(currentDue.getDate() + 14);

    const updated = db.borrowings.findByIdAndUpdate(borrowingId, {
      dueDate: currentDue.toISOString(),
      status: 'CURRENT',
      $inc: { renewalCount: 1 },
    });

    return updated;
  },

  getOverdueLoans: async () => {
    const now = new Date();
    const borrowings = db.borrowings.find({
      status: { $in: ['CURRENT', 'OVERDUE', 'DUE_SOON'] },
    }).results;

    const overdue = [];
    for (const b of borrowings) {
      const due = new Date(b.dueDate);
      if (due < now) {
        const daysOverdue = Math.ceil((now.getTime() - due.getTime()) / (1000 * 3600 * 24));
        overdue.push({
          ...b,
          status: 'OVERDUE',
          daysOverdue,
          fineAmount: daysOverdue * 5, // $5/day
        });
      }
    }
    return overdue;
  },
};

export default borrowingService;
