import fs from 'fs';
import path from 'path';
import { initialBooks } from '../../../src/data/books.js';
import { initialUsers } from '../../../src/data/users.js';
import { initialBorrowings } from '../../../src/data/borrowings.js';
import { initialReservations } from '../../../src/data/reservations.js';
import { initialReviews } from '../../../src/data/reviews.js';
import { initialCategories } from '../../../src/data/categories.js';
import { initialAuthors } from '../../../src/data/authors.js';
import { initialActivities } from '../../../src/data/activities.js';
import bcrypt from 'bcryptjs';

const DATA_DIR = path.resolve(process.cwd(), 'server', 'data');

if (!fs.existsSync(DATA_DIR)) {
  fs.mkdirSync(DATA_DIR, { recursive: true });
}

class Collection {
  constructor(name, initialData = []) {
    this.name = name;
    this.filePath = path.join(DATA_DIR, `${name}.json`);
    this.data = this.load(initialData);
  }

  load(defaultData) {
    try {
      if (fs.existsSync(this.filePath)) {
        const content = fs.readFileSync(this.filePath, 'utf-8');
        return JSON.parse(content);
      }
    } catch (e) {
      console.warn(`Error loading collection ${this.name}, using initial seed:`, e.message);
    }
    this.save(defaultData);
    return defaultData;
  }

  save(data = this.data) {
    try {
      fs.writeFileSync(this.filePath, JSON.stringify(data, null, 2), 'utf-8');
    } catch (e) {
      console.warn(`Error writing collection ${this.name}:`, e.message);
    }
  }

  _matchesQuery(item, query = {}) {
    if (!query || Object.keys(query).length === 0) return true;
    for (const [key, val] of Object.entries(query)) {
      if (key === '$or' && Array.isArray(val)) {
        const matchesAny = val.some((subQuery) => this._matchesQuery(item, subQuery));
        if (!matchesAny) return false;
        continue;
      }
      if (key === '$and' && Array.isArray(val)) {
        const matchesAll = val.every((subQuery) => this._matchesQuery(item, subQuery));
        if (!matchesAll) return false;
        continue;
      }

      const itemVal = item[key];
      if (val instanceof RegExp) {
        if (!val.test(String(itemVal || ''))) return false;
      } else if (typeof val === 'object' && val !== null) {
        if (val.$regex) {
          const re = new RegExp(val.$regex, val.$options || 'i');
          if (!re.test(String(itemVal || ''))) return false;
        }
        if (val.$in && Array.isArray(val.$in)) {
          if (!val.$in.includes(itemVal)) return false;
        }
        if (val.$nin && Array.isArray(val.$nin)) {
          if (val.$nin.includes(itemVal)) return false;
        }
        if (val.$ne !== undefined) {
          if (itemVal === val.$ne) return false;
        }
        if (val.$gt !== undefined) {
          if (!(itemVal > val.$gt)) return false;
        }
        if (val.$gte !== undefined) {
          if (!(itemVal >= val.$gte)) return false;
        }
        if (val.$lt !== undefined) {
          if (!(itemVal < val.$lt)) return false;
        }
        if (val.$lte !== undefined) {
          if (!(itemVal <= val.$lte)) return false;
        }
      } else {
        if (String(itemVal).toLowerCase() !== String(val).toLowerCase()) {
          return false;
        }
      }
    }
    return true;
  }

  find(query = {}) {
    const results = this.data.filter((item) => this._matchesQuery(item, query));
    return new QueryCursor(results, this);
  }

  findOne(query = {}) {
    const item = this.data.find((item) => this._matchesQuery(item, query));
    return item ? { ...item } : null;
  }

  findById(id) {
    if (!id) return null;
    const item = this.data.find((item) => String(item.id || item._id) === String(id));
    return item ? { ...item } : null;
  }

  countDocuments(query = {}) {
    return this.data.filter((item) => this._matchesQuery(item, query)).length;
  }

  create(doc) {
    const id = doc.id || doc._id || `id-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`;
    const newDoc = {
      ...doc,
      id,
      _id: id,
      createdAt: doc.createdAt || new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    this.data.unshift(newDoc);
    this.save();
    return { ...newDoc };
  }

  insertMany(docs) {
    const inserted = docs.map((doc) => {
      const id = doc.id || doc._id || `id-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`;
      return {
        ...doc,
        id,
        _id: id,
        createdAt: doc.createdAt || new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      };
    });
    this.data.unshift(...inserted);
    this.save();
    return inserted;
  }

  updateOne(query, update) {
    const index = this.data.findIndex((item) => this._matchesQuery(item, query));
    if (index === -1) return { matchedCount: 0, modifiedCount: 0 };
    const current = this.data[index];
    const updateData = update.$set ? { ...update.$set } : { ...update };
    if (update.$inc) {
      for (const [k, v] of Object.entries(update.$inc)) {
        updateData[k] = (current[k] || 0) + v;
      }
    }
    if (update.$push) {
      for (const [k, v] of Object.entries(update.$push)) {
        const arr = Array.isArray(current[k]) ? [...current[k]] : [];
        arr.push(v);
        updateData[k] = arr;
      }
    }
    if (update.$pull) {
      for (const [k, v] of Object.entries(update.$pull)) {
        const arr = Array.isArray(current[k]) ? [...current[k]] : [];
        updateData[k] = arr.filter((x) => x !== v);
      }
    }

    const updated = {
      ...current,
      ...updateData,
      updatedAt: new Date().toISOString(),
    };
    this.data[index] = updated;
    this.save();
    return { matchedCount: 1, modifiedCount: 1, doc: updated };
  }

  findByIdAndUpdate(id, update, options = { new: true }) {
    this.updateOne({ $or: [{ id }, { _id: id }] }, update);
    return this.findById(id);
  }

  deleteOne(query) {
    const index = this.data.findIndex((item) => this._matchesQuery(item, query));
    if (index === -1) return { deletedCount: 0 };
    this.data.splice(index, 1);
    this.save();
    return { deletedCount: 1 };
  }

  findByIdAndDelete(id) {
    const doc = this.findById(id);
    if (!doc) return null;
    this.deleteOne({ $or: [{ id }, { _id: id }] });
    return doc;
  }

  deleteMany(query) {
    const initialCount = this.data.length;
    this.data = this.data.filter((item) => !this._matchesQuery(item, query));
    const deletedCount = initialCount - this.data.length;
    if (deletedCount > 0) this.save();
    return { deletedCount };
  }
}

class QueryCursor {
  constructor(results, collection) {
    this.results = [...results];
    this.collection = collection;
  }

  sort(sortCriteria) {
    if (!sortCriteria) return this;
    const entries = typeof sortCriteria === 'object' ? Object.entries(sortCriteria) : [];
    if (entries.length === 0) return this;

    this.results.sort((a, b) => {
      for (const [key, order] of entries) {
        const aVal = a[key];
        const bVal = b[key];
        const numOrder = order === 'asc' || order === 1 ? 1 : -1;
        if (aVal < bVal) return -1 * numOrder;
        if (aVal > bVal) return 1 * numOrder;
      }
      return 0;
    });
    return this;
  }

  skip(count) {
    if (typeof count === 'number' && count > 0) {
      this.results = this.results.slice(count);
    }
    return this;
  }

  limit(count) {
    if (typeof count === 'number' && count > 0) {
      this.results = this.results.slice(0, count);
    }
    return this;
  }

  lean() {
    return this;
  }

  exec() {
    return Promise.resolve(this.results);
  }

  then(resolve, reject) {
    return Promise.resolve(this.results).then(resolve, reject);
  }
}

// Prepare Seed Data with Hashed Passwords
const defaultHashedPassword = bcrypt.hashSync('password123', 10);

const seededUsers = initialUsers.map((user) => ({
  ...user,
  _id: user.id,
  password: defaultHashedPassword,
  role: (user.role || 'student').toUpperCase(),
  status: user.status || 'ACTIVE',
  createdAt: user.joinedDate || new Date().toISOString(),
  updatedAt: new Date().toISOString(),
}));

const seededBooks = initialBooks.map((b) => ({
  ...b,
  _id: b.id,
  bookNumber: b.bookNumber || b.bookId || b.id,
  availableCopies: typeof b.availableCopies === 'number' ? b.availableCopies : b.totalCopies || 5,
  totalCopies: b.totalCopies || 5,
  status: b.status || (b.availableCopies > 0 ? 'AVAILABLE' : 'ISSUED'),
  createdAt: b.createdAt || new Date().toISOString(),
  updatedAt: new Date().toISOString(),
}));

// Collections
export const db = {
  users: new Collection('users', seededUsers),
  books: new Collection('books', seededBooks),
  borrowings: new Collection('borrowings', initialBorrowings),
  reservations: new Collection('reservations', initialReservations),
  reviews: new Collection('reviews', initialReviews),
  categories: new Collection('categories', initialCategories),
  authors: new Collection('authors', initialAuthors),
  activities: new Collection('activities', initialActivities),
  notifications: new Collection('notifications', [
    {
      id: 'notif-1',
      _id: 'notif-1',
      userId: 'student-1',
      title: 'Welcome to BookBuddy',
      message: 'Your university library profile has been activated with access to physical holdings and AI learning paths.',
      type: 'SYSTEM',
      isRead: false,
      createdAt: new Date().toISOString(),
    },
  ]),
  wantToRead: new Collection('wantToRead', [
    { id: 'wtr-1', _id: 'wtr-1', userId: 'student-1', bookId: 'book-1', addedAt: new Date().toISOString() },
    { id: 'wtr-2', _id: 'wtr-2', userId: 'student-1', bookId: 'book-4', addedAt: new Date().toISOString() },
  ]),
  follows: new Collection('follows', [
    { id: 'fol-1', _id: 'fol-1', followerId: 'student-1', followingId: 'student-2', createdAt: new Date().toISOString() },
  ]),
  lists: new Collection('lists', [
    {
      id: 'list-1',
      _id: 'list-1',
      userId: 'student-1',
      userName: 'Vishal Gayathri',
      name: 'Essential Distributed Systems',
      description: 'Foundational books for distributed databases, consensus, and fault tolerance.',
      visibility: 'PUBLIC',
      books: ['book-1', 'book-4', 'book-9'],
      likesCount: 14,
      createdAt: new Date().toISOString(),
    },
  ]),
  transactions: new Collection('transactions', [
    {
      id: 'tx-1',
      _id: 'tx-1',
      actorId: 'student-1',
      actorName: 'Vishal Gayathri',
      actorRole: 'STUDENT',
      action: 'BORROW',
      targetId: 'book-1',
      targetType: 'BOOK',
      metadata: { bookTitle: 'Clean Code: A Handbook of Agile Software Craftsmanship' },
      timestamp: new Date().toISOString(),
    },
  ]),
};

export default db;
