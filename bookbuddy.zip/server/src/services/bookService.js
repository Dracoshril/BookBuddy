import { db } from './dbStore.js';

export const bookService = {
  getBooks: async (params = {}) => {
    let {
      search,
      category,
      author,
      availability,
      language,
      year,
      rating,
      sort = 'popular',
      sortBy,
      page = 1,
      limit = 20,
    } = params;

    page = Math.max(1, parseInt(page, 10) || 1);
    limit = Math.max(1, parseInt(limit, 10) || 20);

    let books = db.books.find({}).results;

    // Search filter
    if (search && String(search).trim()) {
      const q = String(search).toLowerCase().trim();
      books = books.filter((b) => {
        const title = (b.title || '').toLowerCase();
        const aut = (b.author || '').toLowerCase();
        const isbn = (b.isbn || '').toLowerCase();
        const bookNum = (b.bookNumber || b.bookId || '').toLowerCase();
        const cat = (b.category || '').toLowerCase();
        const desc = (b.description || '').toLowerCase();
        const section = (b.location?.section || '').toLowerCase();
        return (
          title.includes(q) ||
          aut.includes(q) ||
          isbn.includes(q) ||
          bookNum.includes(q) ||
          cat.includes(q) ||
          desc.includes(q) ||
          section.includes(q)
        );
      });
    }

    // Category filter
    if (category && category !== 'all') {
      const catClean = String(category).toLowerCase();
      books = books.filter((b) => (b.category || '').toLowerCase() === catClean);
    }

    // Author filter
    if (author && author !== 'all') {
      const authorClean = String(author).toLowerCase();
      books = books.filter((b) => (b.author || '').toLowerCase().includes(authorClean));
    }

    // Availability filter
    if (availability && availability !== 'all') {
      const availClean = String(availability).toUpperCase();
      books = books.filter((b) => {
        if (availClean === 'AVAILABLE') return b.availableCopies > 0;
        if (availClean === 'ISSUED') return b.availableCopies === 0;
        return b.status === availClean;
      });
    }

    // Language filter
    if (language && language !== 'all') {
      const langClean = String(language).toLowerCase();
      books = books.filter((b) => (b.language || 'english').toLowerCase() === langClean);
    }

    // Year filter
    if (year) {
      books = books.filter((b) => String(b.publicationYear) === String(year));
    }

    // Rating filter
    if (rating) {
      const minRating = parseFloat(rating);
      if (!isNaN(minRating)) {
        books = books.filter((b) => (b.rating || 0) >= minRating);
      }
    }

    // Sorting
    const sortField = sortBy || sort;
    if (sortField === 'highest-rated' || sortField === 'rating') {
      books.sort((a, b) => (b.rating || 0) - (a.rating || 0));
    } else if (sortField === 'most-borrowed' || sortField === 'popular') {
      books.sort((a, b) => (b.borrowCount || 0) - (a.borrowCount || 0));
    } else if (sortField === 'alphabetical' || sortField === 'title') {
      books.sort((a, b) => (a.title || '').localeCompare(b.title || ''));
    } else if (sortField === 'recently-added' || sortField === 'newest') {
      books.sort((a, b) => new Date(b.createdAt || 0) - new Date(a.createdAt || 0));
    }

    const total = books.length;
    const startIndex = (page - 1) * limit;
    const paginatedBooks = books.slice(startIndex, startIndex + limit);

    return {
      books: paginatedBooks,
      total,
      page,
      totalPages: Math.ceil(total / limit) || 1,
    };
  },

  getBookById: async (id) => {
    const book = db.books.findById(id) || db.books.findOne({ $or: [{ id }, { bookNumber: id }, { isbn: id }] });
    if (!book) {
      const error = new Error(`Book with identifier "${id}" not found`);
      error.statusCode = 404;
      error.code = 'BOOK_NOT_FOUND';
      throw error;
    }
    return book;
  },

  createBook: async (data, actor = {}) => {
    const { title, author, category, isbn, bookNumber, totalCopies = 1 } = data;

    if (!title || !author || !category) {
      const error = new Error('Title, Author, and Category are required');
      error.statusCode = 400;
      error.code = 'VALIDATION_ERROR';
      throw error;
    }

    const copies = parseInt(totalCopies, 10) || 1;
    const bookNum = bookNumber || `BK-${String(db.books.data.length + 1).padStart(4, '0')}`;
    const generatedIsbn = isbn || `978-0-${Date.now().toString().slice(-9)}`;

    // Check duplicate
    const existing = db.books.findOne({
      $or: [{ bookNumber: bookNum }, { isbn: generatedIsbn }],
    });
    if (existing) {
      const error = new Error(`A book with number "${bookNum}" or ISBN "${generatedIsbn}" already exists`);
      error.statusCode = 409;
      error.code = 'BOOK_EXISTS';
      throw error;
    }

    const id = `book-${Date.now()}`;
    const newBook = db.books.create({
      id,
      _id: id,
      bookNumber: bookNum,
      isbn: generatedIsbn,
      title,
      author,
      category,
      description: data.description || '',
      publisher: data.publisher || 'Academic Press',
      publicationYear: data.publicationYear || String(new Date().getFullYear()),
      language: data.language || 'English',
      totalCopies: copies,
      availableCopies: copies,
      borrowCount: 0,
      rating: 4.5,
      reviewCount: 0,
      status: copies > 0 ? 'AVAILABLE' : 'UNAVAILABLE',
      location: data.location || {
        rack: data.rack || '1',
        section: data.section || category,
        shelf: data.shelf || '1',
        position: data.position || '1',
        floor: data.floor || '1st Floor',
      },
      coverImage: data.coverImage || '',
      tags: data.tags || [category],
    });

    // Record Transaction
    db.transactions.create({
      actorId: actor.id || 'system',
      actorName: actor.name || 'Librarian/Admin',
      actorRole: actor.role || 'LIBRARIAN',
      action: 'BOOK_CREATE',
      targetId: newBook.id,
      targetType: 'BOOK',
      metadata: { title: newBook.title, bookNumber: newBook.bookNumber },
    });

    return newBook;
  },

  updateBook: async (id, data, actor = {}) => {
    const existing = db.books.findById(id);
    if (!existing) {
      const error = new Error(`Book "${id}" not found`);
      error.statusCode = 404;
      error.code = 'BOOK_NOT_FOUND';
      throw error;
    }

    const updates = { ...data };

    // Inventory bounds checking
    if (updates.totalCopies !== undefined) {
      const total = parseInt(updates.totalCopies, 10);
      if (total < 0) {
        const error = new Error('Total copies cannot be negative');
        error.statusCode = 400;
        throw error;
      }
      updates.totalCopies = total;
      // Adjust available copies if greater
      if (existing.availableCopies > total) {
        updates.availableCopies = total;
      }
    }

    if (updates.availableCopies !== undefined) {
      const avail = parseInt(updates.availableCopies, 10);
      const total = updates.totalCopies !== undefined ? updates.totalCopies : existing.totalCopies;
      if (avail < 0 || avail > total) {
        const error = new Error(`Available copies must be between 0 and total copies (${total})`);
        error.statusCode = 400;
        throw error;
      }
      updates.availableCopies = avail;
      updates.status = avail > 0 ? 'AVAILABLE' : 'ISSUED';
    }

    const updated = db.books.findByIdAndUpdate(id, updates);

    // Record Transaction
    db.transactions.create({
      actorId: actor.id || 'system',
      actorName: actor.name || 'Librarian/Admin',
      actorRole: actor.role || 'LIBRARIAN',
      action: 'BOOK_UPDATE',
      targetId: id,
      targetType: 'BOOK',
      metadata: { updates },
    });

    return updated;
  },

  deleteBook: async (id, actor = {}) => {
    const book = db.books.findById(id);
    if (!book) {
      const error = new Error(`Book "${id}" not found`);
      error.statusCode = 404;
      error.code = 'BOOK_NOT_FOUND';
      throw error;
    }

    // Check if currently borrowed
    const activeBorrow = db.borrowings.findOne({ bookId: id, status: { $ne: 'RETURNED' } });
    if (activeBorrow) {
      const error = new Error('Cannot delete book while copies are currently issued to students');
      error.statusCode = 409;
      error.code = 'BOOK_ISSUED';
      throw error;
    }

    db.books.findByIdAndDelete(id);

    // Record Transaction
    db.transactions.create({
      actorId: actor.id || 'system',
      actorName: actor.name || 'Librarian/Admin',
      actorRole: actor.role || 'LIBRARIAN',
      action: 'BOOK_DELETE',
      targetId: id,
      targetType: 'BOOK',
      metadata: { title: book.title },
    });

    return { id, success: true };
  },
};

export default bookService;
