import { db } from './dbStore.js';

export const reviewService = {
  getAllReviews: async () => {
    return db.reviews.find({}).sort({ createdAt: -1 }).results;
  },

  getBookReviews: async (bookId) => {
    return db.reviews.find({ bookId }).sort({ createdAt: -1 }).results;
  },

  getUserReviews: async (userId) => {
    return db.reviews.find({ userId }).sort({ createdAt: -1 }).results;
  },

  createReview: async ({ bookId, rating, review, tags = [] }, user) => {
    if (!bookId || !rating || !review) {
      const error = new Error('Book ID, rating (1-5), and review text are required');
      error.statusCode = 400;
      error.code = 'VALIDATION_ERROR';
      throw error;
    }

    const numRating = parseFloat(rating);
    if (isNaN(numRating) || numRating < 1 || numRating > 5) {
      const error = new Error('Rating must be an integer or decimal between 1 and 5');
      error.statusCode = 400;
      error.code = 'INVALID_RATING';
      throw error;
    }

    const book = db.books.findById(bookId);
    if (!book) {
      const error = new Error(`Book "${bookId}" not found`);
      error.statusCode = 404;
      error.code = 'BOOK_NOT_FOUND';
      throw error;
    }

    const id = `rev-${Date.now()}`;
    const newReview = db.reviews.create({
      id,
      _id: id,
      bookId,
      userId: user.id,
      userName: user.name,
      userAvatar: user.avatar || '',
      userRole: user.role === 'STUDENT' ? 'Student' : 'Librarian',
      rating: numRating,
      review,
      tags: Array.isArray(tags) ? tags : [],
      likesCount: 0,
      likedBy: [],
    });

    // Recalculate Book Average Rating
    const allBookReviews = db.reviews.find({ bookId }).results;
    const avg = allBookReviews.reduce((sum, r) => sum + r.rating, 0) / (allBookReviews.length || 1);
    db.books.findByIdAndUpdate(bookId, {
      rating: Math.round(avg * 10) / 10,
      reviewCount: allBookReviews.length,
    });

    // Update user stats
    db.users.findByIdAndUpdate(user.id, {
      $inc: { reviewsCount: 1 },
    });

    // Record Activity
    db.activities.create({
      userId: user.id,
      userName: user.name,
      type: 'review',
      action: `rated ${numRating}★ and reviewed`,
      target: book.title,
      bookId,
      details: { rating: numRating, reviewSnippet: review.slice(0, 100) },
    });

    return newReview;
  },

  updateReview: async (id, data, user) => {
    const existing = db.reviews.findById(id);
    if (!existing) {
      const error = new Error(`Review "${id}" not found`);
      error.statusCode = 404;
      error.code = 'NOT_FOUND';
      throw error;
    }

    // Permission check
    if (existing.userId !== user.id && user.role !== 'ADMIN') {
      const error = new Error('You can only edit your own reviews');
      error.statusCode = 403;
      error.code = 'FORBIDDEN';
      throw error;
    }

    const updates = {};
    if (data.rating !== undefined) {
      const num = parseFloat(data.rating);
      if (num >= 1 && num <= 5) updates.rating = num;
    }
    if (data.review !== undefined) updates.review = data.review;
    if (data.tags !== undefined) updates.tags = data.tags;

    const updated = db.reviews.findByIdAndUpdate(id, updates);

    // Recalculate book rating
    const allBookReviews = db.reviews.find({ bookId: existing.bookId }).results;
    const avg = allBookReviews.reduce((sum, r) => sum + r.rating, 0) / (allBookReviews.length || 1);
    db.books.findByIdAndUpdate(existing.bookId, {
      rating: Math.round(avg * 10) / 10,
    });

    return updated;
  },

  deleteReview: async (id, user) => {
    const existing = db.reviews.findById(id);
    if (!existing) {
      const error = new Error(`Review "${id}" not found`);
      error.statusCode = 404;
      error.code = 'NOT_FOUND';
      throw error;
    }

    if (existing.userId !== user.id && user.role !== 'ADMIN') {
      const error = new Error('You can only delete your own reviews');
      error.statusCode = 403;
      error.code = 'FORBIDDEN';
      throw error;
    }

    db.reviews.findByIdAndDelete(id);

    // Recalculate book rating
    const allBookReviews = db.reviews.find({ bookId: existing.bookId }).results;
    const avg = allBookReviews.length > 0
      ? allBookReviews.reduce((sum, r) => sum + r.rating, 0) / allBookReviews.length
      : 4.5;
    db.books.findByIdAndUpdate(existing.bookId, {
      rating: Math.round(avg * 10) / 10,
      reviewCount: allBookReviews.length,
    });

    return { id, success: true };
  },

  toggleLike: async (id, userId) => {
    const review = db.reviews.findById(id);
    if (!review) {
      const error = new Error(`Review "${id}" not found`);
      error.statusCode = 404;
      error.code = 'NOT_FOUND';
      throw error;
    }

    const likedBy = Array.isArray(review.likedBy) ? [...review.likedBy] : [];
    const isLiked = likedBy.includes(userId);
    let updatedLikedBy;

    if (isLiked) {
      updatedLikedBy = likedBy.filter((u) => u !== userId);
    } else {
      updatedLikedBy = [...likedBy, userId];
    }

    const updated = db.reviews.findByIdAndUpdate(id, {
      likedBy: updatedLikedBy,
      likesCount: updatedLikedBy.length,
    });

    return { id, isLiked: !isLiked, likesCount: updatedLikedBy.length };
  },
};

export default reviewService;
