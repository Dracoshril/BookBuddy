import fs from 'fs';
import * as xlsx from 'xlsx';
import Papa from 'papaparse';
import { db } from './dbStore.js';

export const importService = {
  parseAndValidate: (filePath) => {
    let rows = [];
    if (filePath.endsWith('.csv')) {
      const csvContent = fs.readFileSync(filePath, 'utf-8');
      const parsed = Papa.parse(csvContent, { header: true, skipEmptyLines: true });
      rows = parsed.data;
    } else {
      const workbook = xlsx.readFile(filePath);
      const sheetName = workbook.SheetNames[0];
      const sheet = workbook.Sheets[sheetName];
      rows = xlsx.utils.sheet_to_json(sheet, { defval: '' });
    }

    const totalRows = rows.length;
    const validRows = [];
    const errors = [];

    const normalizeKey = (obj, keys) => {
      for (const k of keys) {
        for (const [rowKey, val] of Object.entries(obj)) {
          if (rowKey.trim().toLowerCase().replace(/[^a-z0-9]/g, '') === k.toLowerCase().replace(/[^a-z0-9]/g, '')) {
            return val;
          }
        }
      }
      return '';
    };

    rows.forEach((row, index) => {
      const rowNum = index + 2; // header is 1
      const title = normalizeKey(row, ['Title', 'Book Title', 'book_title']);
      const author = normalizeKey(row, ['Author', 'Author Name', 'author_name']);
      const category = normalizeKey(row, ['Category', 'Subject', 'Genre']);
      const bookNumber = normalizeKey(row, ['Book No', 'BookNo', 'Book Number', 'Call Number', 'bookNumber']);
      const isbn = normalizeKey(row, ['ISBN', 'isbn13', 'isbn10']);
      const totalCopiesRaw = normalizeKey(row, ['Total Copies', 'TotalCopies', 'Copies', 'total_copies']);
      const availableCopiesRaw = normalizeKey(row, ['Available Copies', 'AvailableCopies', 'available_copies']);
      const rack = normalizeKey(row, ['Rack No', 'Rack', 'RackNo']);
      const section = normalizeKey(row, ['Section', 'Department']);
      const shelf = normalizeKey(row, ['Shelf No', 'Shelf', 'ShelfNo']);
      const position = normalizeKey(row, ['Position', 'Spine Position']);
      const year = normalizeKey(row, ['Publication Year', 'Year', 'publicationYear']);
      const publisher = normalizeKey(row, ['Publisher', 'publisher']);
      const description = normalizeKey(row, ['Description', 'Summary']);

      // Validations
      const rowErrors = [];
      if (!title || !String(title).trim()) rowErrors.push('Missing Title');
      if (!author || !String(author).trim()) rowErrors.push('Missing Author');
      if (!category || !String(category).trim()) rowErrors.push('Missing Category');

      const totalCopies = totalCopiesRaw !== '' ? parseInt(totalCopiesRaw, 10) : 5;
      const availableCopies = availableCopiesRaw !== '' ? parseInt(availableCopiesRaw, 10) : totalCopies;

      if (isNaN(totalCopies) || totalCopies < 0) {
        rowErrors.push('Total Copies must be a non-negative number');
      }
      if (isNaN(availableCopies) || availableCopies < 0) {
        rowErrors.push('Available Copies must be a non-negative number');
      }
      if (availableCopies > totalCopies) {
        rowErrors.push(`Available Copies (${availableCopies}) cannot exceed Total Copies (${totalCopies})`);
      }

      if (rowErrors.length > 0) {
        errors.push({
          row: rowNum,
          bookNumber: bookNumber || `Row #${rowNum}`,
          title: title || 'N/A',
          reasons: rowErrors,
        });
      } else {
        validRows.push({
          title: String(title).trim(),
          author: String(author).trim(),
          category: String(category).trim(),
          bookNumber: bookNumber ? String(bookNumber).trim() : `BK-IMP-${Date.now().toString().slice(-4)}-${index + 1}`,
          isbn: isbn ? String(isbn).trim() : `978-0-${Date.now().toString().slice(-6)}-${index}`,
          totalCopies: totalCopies || 1,
          availableCopies: availableCopies !== undefined ? availableCopies : totalCopies || 1,
          rack: rack || '1',
          section: section || category,
          shelf: shelf || '1',
          position: position || String(index + 1),
          publicationYear: year || String(new Date().getFullYear()),
          publisher: publisher || 'University Press',
          description: description || '',
        });
      }
    });

    return {
      totalRows,
      validRowsCount: validRows.length,
      invalidRowsCount: errors.length,
      errors,
      validRows,
    };
  },

  commitImport: async (validRows, actor = null) => {
    let createdCount = 0;
    let updatedCount = 0;

    for (const item of validRows) {
      const existing = db.books.findOne({
        $or: [{ bookNumber: item.bookNumber }, { isbn: item.isbn }],
      });

      if (existing) {
        // UPDATE existing book
        db.books.findByIdAndUpdate(existing.id, {
          title: item.title,
          author: item.author,
          category: item.category,
          totalCopies: item.totalCopies,
          availableCopies: Math.min(item.availableCopies, item.totalCopies),
          status: item.availableCopies > 0 ? 'AVAILABLE' : 'ISSUED',
          location: {
            rack: item.rack,
            section: item.section,
            shelf: item.shelf,
            position: item.position,
            floor: '1st Floor',
          },
          publisher: item.publisher,
          publicationYear: item.publicationYear,
          description: item.description || existing.description,
        });
        updatedCount += 1;
      } else {
        // CREATE new book
        const id = `book-imp-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`;
        db.books.create({
          id,
          _id: id,
          bookNumber: item.bookNumber,
          isbn: item.isbn,
          title: item.title,
          author: item.author,
          category: item.category,
          description: item.description,
          publisher: item.publisher,
          publicationYear: item.publicationYear,
          language: 'English',
          totalCopies: item.totalCopies,
          availableCopies: item.availableCopies,
          borrowCount: 0,
          rating: 4.5,
          reviewCount: 0,
          status: item.availableCopies > 0 ? 'AVAILABLE' : 'UNAVAILABLE',
          location: {
            rack: item.rack,
            section: item.section,
            shelf: item.shelf,
            position: item.position,
            floor: '1st Floor',
          },
          coverImage: '',
          tags: [item.category],
        });
        createdCount += 1;
      }
    }

    // Record Transaction
    db.transactions.create({
      actorId: actor?.id || 'admin',
      actorName: actor?.name || 'Administrator',
      actorRole: actor?.role || 'ADMIN',
      action: 'IMPORT',
      targetId: 'catalog',
      targetType: 'SYSTEM',
      metadata: { createdCount, updatedCount, totalProcessed: validRows.length },
    });

    return {
      success: true,
      createdCount,
      updatedCount,
      totalImported: createdCount + updatedCount,
    };
  },
};

export default importService;
