export const authorizeRoles = (...allowedRoles) => {
  const normalizedAllowed = allowedRoles.map((r) => r.toUpperCase());
  return (req, res, next) => {
    if (!req.user) {
      return res.status(401).json({
        success: false,
        message: 'Authentication required for this operation',
        code: 'UNAUTHORIZED',
      });
    }

    const userRole = (req.user.role || '').toUpperCase();
    if (!normalizedAllowed.includes(userRole) && userRole !== 'ADMIN') {
      return res.status(403).json({
        success: false,
        message: `Forbidden: Access requires ${normalizedAllowed.join(' or ')} privileges`,
        code: 'FORBIDDEN',
      });
    }

    next();
  };
};

export default authorizeRoles;
