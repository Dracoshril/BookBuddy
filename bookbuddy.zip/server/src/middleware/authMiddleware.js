import jwt from 'jsonwebtoken';
import { config } from '../config/env.js';
import { db } from '../services/dbStore.js';

export const authenticate = (req, res, next) => {
  try {
    const authHeader = req.headers.authorization;
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      return res.status(401).json({
        success: false,
        message: 'Authentication token missing or invalid format',
        code: 'UNAUTHORIZED',
      });
    }

    const token = authHeader.split(' ')[1];
    if (!token) {
      return res.status(401).json({
        success: false,
        message: 'Token not provided',
        code: 'UNAUTHORIZED',
      });
    }

    // Support mock dev tokens for quick demos (e.g., "mock-jwt-student-1-...")
    if (token.startsWith('mock-jwt-')) {
      const parts = token.split('-');
      const userId = `${parts[2]}-${parts[3]}`;
      const user = db.users.findById(userId) || db.users.findOne({ id: userId });
      if (user) {
        req.user = {
          id: user.id || user._id,
          userId: user.userId || user.studentId || user.id,
          name: user.name,
          email: user.email,
          role: (user.role || 'STUDENT').toUpperCase(),
        };
        return next();
      }
    }

    const decoded = jwt.verify(token, config.jwtSecret);
    const user = db.users.findById(decoded.id) || db.users.findOne({ id: decoded.id });
    if (!user) {
      return res.status(401).json({
        success: false,
        message: 'Account associated with token no longer exists',
        code: 'USER_NOT_FOUND',
      });
    }

    req.user = {
      id: user.id || user._id,
      userId: user.userId || user.studentId || user.id,
      name: user.name,
      email: user.email,
      role: (user.role || 'STUDENT').toUpperCase(),
    };
    next();
  } catch (err) {
    return res.status(401).json({
      success: false,
      message: 'Invalid or expired authentication session',
      code: 'INVALID_TOKEN',
    });
  }
};

export const optionalAuth = (req, res, next) => {
  try {
    const authHeader = req.headers.authorization;
    if (authHeader && authHeader.startsWith('Bearer ')) {
      const token = authHeader.split(' ')[1];
      if (token.startsWith('mock-jwt-')) {
        const parts = token.split('-');
        const userId = `${parts[2]}-${parts[3]}`;
        const user = db.users.findById(userId) || db.users.findOne({ id: userId });
        if (user) {
          req.user = {
            id: user.id || user._id,
            userId: user.userId || user.studentId || user.id,
            name: user.name,
            email: user.email,
            role: (user.role || 'STUDENT').toUpperCase(),
          };
        }
      } else {
        const decoded = jwt.verify(token, config.jwtSecret);
        const user = db.users.findById(decoded.id) || db.users.findOne({ id: decoded.id });
        if (user) {
          req.user = {
            id: user.id || user._id,
            userId: user.userId || user.studentId || user.id,
            name: user.name,
            email: user.email,
            role: (user.role || 'STUDENT').toUpperCase(),
          };
        }
      }
    }
  } catch (e) {
    // Ignore optional auth errors
  }
  next();
};

export default authenticate;
