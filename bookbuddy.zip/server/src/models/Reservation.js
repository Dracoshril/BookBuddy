import mongoose from 'mongoose';

const reservationSchema = new mongoose.Schema(
  {
    userId: { type: String, required: true, index: true },
    userName: { type: String, default: '' },
    bookId: { type: String, required: true, index: true },
    bookTitle: { type: String, default: '' },
    reservationDate: { type: Date, default: Date.now },
    queuePosition: { type: Number, default: 1 },
    status: {
      type: String,
      enum: ['WAITING', 'RESERVED', 'AVAILABLE', 'COMPLETED', 'CANCELLED'],
      default: 'WAITING',
      index: true,
    },
    availableDate: { type: Date, default: null },
    completedDate: { type: Date, default: null },
  },
  { timestamps: true }
);

export const Reservation = mongoose.models.Reservation || mongoose.model('Reservation', reservationSchema);
export default Reservation;
