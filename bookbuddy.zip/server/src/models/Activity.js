import mongoose from 'mongoose';

const activitySchema = new mongoose.Schema(
  {
    userId: { type: String, required: true, index: true },
    userName: { type: String, default: '' },
    type: { type: String, default: 'reading' },
    action: { type: String, required: true },
    target: { type: String, default: '' },
    bookId: { type: String, default: '' },
    timestamp: { type: Date, default: Date.now },
    details: { type: Object, default: {} },
  },
  { timestamps: true }
);

export const Activity = mongoose.models.Activity || mongoose.model('Activity', activitySchema);
export default Activity;
