import mongoose from 'mongoose';

const bookSchema = new mongoose.Schema(
  {
    bookNumber: { type: String, required: true, unique: true, index: true },
    title: { type: String, required: true, index: true },
    author: { type: String, required: true, index: true },
    isbn: { type: String, required: true, unique: true, index: true },
    category: { type: String, required: true, index: true },
    description: { type: String, default: '' },
    publisher: { type: String, default: '' },
    publicationYear: { type: String, default: '' },
    language: { type: String, default: 'English' },
    totalCopies: { type: Number, required: true, min: 0, default: 1 },
    availableCopies: { type: Number, required: true, min: 0, default: 1 },
    borrowCount: { type: Number, default: 0 },
    rating: { type: Number, default: 4.5 },
    reviewCount: { type: Number, default: 0 },
    status: {
      type: String,
      enum: ['AVAILABLE', 'ISSUED', 'RESERVED', 'UNAVAILABLE'],
      default: 'AVAILABLE',
      index: true,
    },
    location: {
      rack: { type: String, default: '1' },
      section: { type: String, default: 'General' },
      shelf: { type: String, default: '1' },
      position: { type: String, default: '1' },
      floor: { type: String, default: '1st Floor' },
    },
    coverImage: { type: String, default: '' },
    tags: [{ type: String }],
  },
  { timestamps: true }
);

bookSchema.index({ title: 'text', author: 'text', description: 'text', category: 'text' });

export const Book = mongoose.models.Book || mongoose.model('Book', bookSchema);
export default Book;
