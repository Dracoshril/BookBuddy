import mongoose from 'mongoose';

const transactionSchema = new mongoose.Schema(
  {
    actorId: { type: String, required: true },
    actorName: { type: String, default: '' },
    actorRole: { type: String, default: '' },
    action: {
      type: String,
      enum: ['ISSUE', 'RETURN', 'RESERVE', 'CANCEL_RESERVE', 'IMPORT', 'BOOK_CREATE', 'BOOK_UPDATE', 'SETTINGS_UPDATE'],
      required: true,
      index: true,
    },
    targetId: { type: String, default: '' },
    targetType: { type: String, default: 'BOOK' },
    timestamp: { type: Date, default: Date.now },
    metadata: { type: Object, default: {} },
  },
  { timestamps: true }
);

export const Transaction = mongoose.models.Transaction || mongoose.model('Transaction', transactionSchema);
export default Transaction;
