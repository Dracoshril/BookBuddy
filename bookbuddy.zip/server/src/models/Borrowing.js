import mongoose from 'mongoose';

const borrowingSchema = new mongoose.Schema(
  {
    userId: { type: String, required: true, index: true },
    readerName: { type: String, default: '' },
    bookId: { type: String, required: true, index: true },
    bookTitle: { type: String, default: '' },
    borrowDate: { type: Date, default: Date.now },
    dueDate: { type: Date, required: true, index: true },
    returnDate: { type: Date, default: null },
    status: {
      type: String,
      enum: ['CURRENT', 'DUE_SOON', 'OVERDUE', 'RETURNED'],
      default: 'CURRENT',
      index: true,
    },
    renewalCount: { type: Number, default: 0 },
    fineAmount: { type: Number, default: 0 },
  },
  { timestamps: true }
);

export const Borrowing = mongoose.models.Borrowing || mongoose.model('Borrowing', borrowingSchema);
export default Borrowing;
