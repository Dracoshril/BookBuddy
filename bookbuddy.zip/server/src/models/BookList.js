import mongoose from 'mongoose';

const bookListSchema = new mongoose.Schema(
  {
    userId: { type: String, required: true, index: true },
    userName: { type: String, default: '' },
    name: { type: String, required: true },
    description: { type: String, default: '' },
    visibility: {
      type: String,
      enum: ['PUBLIC', 'FOLLOWERS', 'PRIVATE'],
      default: 'PUBLIC',
      index: true,
    },
    books: [{ type: String }],
    likesCount: { type: Number, default: 0 },
  },
  { timestamps: true }
);

export const BookList = mongoose.models.BookList || mongoose.model('BookList', bookListSchema);
export default BookList;
