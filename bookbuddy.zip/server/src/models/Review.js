import mongoose from 'mongoose';

const reviewSchema = new mongoose.Schema(
  {
    bookId: { type: String, required: true, index: true },
    userId: { type: String, required: true, index: true },
    userName: { type: String, required: true },
    userAvatar: { type: String, default: '' },
    userRole: { type: String, default: 'Student' },
    rating: { type: Number, required: true, min: 1, max: 5 },
    review: { type: String, required: true },
    tags: [{ type: String }],
    likesCount: { type: Number, default: 0 },
    likedBy: [{ type: String }],
  },
  { timestamps: true }
);

export const Review = mongoose.models.Review || mongoose.model('Review', reviewSchema);
export default Review;
