import mongoose from 'mongoose';

const userSchema = new mongoose.Schema(
  {
    userId: { type: String, required: true, unique: true, index: true },
    username: { type: String, required: true, unique: true, index: true },
    name: { type: String, required: true },
    email: { type: String, required: true, unique: true, index: true },
    password: { type: String, required: true },
    role: {
      type: String,
      enum: ['STUDENT', 'TEACHER', 'LIBRARIAN', 'ADMIN'],
      default: 'STUDENT',
      index: true,
    },
    department: { type: String, default: '' },
    semester: { type: String, default: '' },
    studentId: { type: String, default: '' },
    avatar: { type: String, default: '' },
    bio: { type: String, default: '' },
    phone: { type: String, default: '' },
    status: {
      type: String,
      enum: ['ACTIVE', 'SUSPENDED', 'INACTIVE'],
      default: 'ACTIVE',
      index: true,
    },
    interests: [{ type: String }],
    learningGoal: { type: String, default: '' },
    booksReadCount: { type: Number, default: 0 },
    averageRating: { type: Number, default: 0 },
    reviewsCount: { type: Number, default: 0 },
    listsCount: { type: Number, default: 0 },
    followersCount: { type: Number, default: 0 },
    followingCount: { type: Number, default: 0 },
  },
  { timestamps: true }
);

userSchema.index({ username: 1, email: 1 });

export const User = mongoose.models.User || mongoose.model('User', userSchema);
export default User;
