import express from 'express';
import cors from 'cors';
import path from 'path';
import apiRouter from './routes/index.js';
import { errorHandler, notFoundHandler } from './middleware/errorMiddleware.js';
import { connectDB } from './config/db.js';

export const createServer = async () => {
  const app = express();

  // Connect to DB (real MongoDB if MONGODB_URI is provided, or embedded JSON store)
  await connectDB();

  // Global Middlewares
  app.use(cors({
    origin: true,
    credentials: true,
    methods: ['GET', 'POST', 'PUT', 'PATCH', 'DELETE', 'OPTIONS'],
    allowedHeaders: ['Content-Type', 'Authorization', 'Accept'],
  }));

  app.use(express.json({ limit: '10mb' }));
  app.use(express.urlencoded({ extended: true, limit: '10mb' }));

  // Request logger for API calls
  app.use((req, res, next) => {
    if (req.url.startsWith('/api')) {
      const start = Date.now();
      res.on('finish', () => {
        const duration = Date.now() - start;
        console.log(`[API] ${req.method} ${req.originalUrl} -> ${res.statusCode} (${duration}ms)`);
      });
    }
    next();
  });

  // Serve static uploads if any
  const uploadsDir = path.resolve(process.cwd(), 'server', 'uploads');
  app.use('/uploads', express.static(uploadsDir));

  // Mount API router
  app.use('/api', apiRouter);

  return app;
};

export default createServer;
