import React, { useState } from 'react';
import { Outlet, Link, useLocation, useNavigate } from 'react-router-dom';
import { ThemeToggle } from '../components/common/ThemeToggle';
import { CommandPalette } from '../components/navigation/CommandPalette';
import { BorrowBookModal } from '../components/modals/BorrowBookModal';
import { ReserveBookModal } from '../components/modals/ReserveBookModal';
import { ReviewModal } from '../components/modals/ReviewModal';
import { Menu, X, Sparkles, BookOpen, LogOut, ArrowRight, User } from 'lucide-react';
import { useAuth } from '../hooks/useAuth';
import { toast } from 'sonner';

export const PublicLayout = () => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const location = useLocation();
  const navigate = useNavigate();
  const { user, isAuthenticated, role, logout } = useAuth();

  const navLinks = [
    { label: 'Explore Catalog', path: '/catalog' },
    { label: 'AI Assistant', path: '/ai-assistant' },
    { label: 'Learning Paths', path: '/learning-paths' },
    { label: 'About', path: '/about' },
    { label: 'Library Rules', path: '/library-rules' },
  ];

  const handleLogout = async () => {
    await logout();
    toast.success('Signed out of BookBuddy.');
    navigate('/');
  };

  return (
    <div className="min-h-screen flex flex-col bg-neutral-50 dark:bg-neutral-950 text-neutral-900 dark:text-neutral-100 transition-colors">
      <CommandPalette />
      <BorrowBookModal />
      <ReserveBookModal />
      <ReviewModal />

      {/* Public Top Navbar */}
      <header className="sticky top-0 z-40 w-full border-b border-neutral-200/80 dark:border-neutral-800 bg-white/95 dark:bg-neutral-950/95 backdrop-blur-md">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 h-16 flex items-center justify-between gap-4">
          {/* LEFT: BookBuddy Official Logo */}
          <Link
            to="/"
            className="flex items-center py-1 outline-none focus-visible:ring-2 focus-visible:ring-amber-500 rounded shrink-0"
            title="BookBuddy — Return to Home"
          >
            <img
              src="/assets/images/bookbuddy-logo.svg"
              alt="BookBuddy"
              className="h-8 sm:h-9 w-auto max-w-[170px] object-contain hidden dark:block"
            />
            <img
              src="/assets/images/bookbuddy-logo-light.svg"
              alt="BookBuddy"
              className="h-8 sm:h-9 w-auto max-w-[170px] object-contain block dark:hidden"
            />
          </Link>

          {/* CENTER: Public Navigation Links */}
          <nav className="hidden md:flex items-center gap-6 lg:gap-8 text-xs font-semibold text-neutral-600 dark:text-neutral-400">
            {navLinks.map((link) => {
              const isActive = location.pathname === link.path;
              return (
                <Link
                  key={link.path}
                  to={link.path}
                  className={`transition-colors hover:text-neutral-900 dark:hover:text-white py-1 ${
                    isActive
                      ? 'text-neutral-900 dark:text-white font-bold border-b-2 border-neutral-900 dark:border-white'
                      : ''
                  }`}
                >
                  {link.label}
                </Link>
              );
            })}
          </nav>

          {/* RIGHT: Theme Toggle & Sign In */}
          <div className="flex items-center gap-3">
            <ThemeToggle className="h-9 w-9 flex items-center justify-center rounded-lg border border-neutral-200 dark:border-neutral-800 bg-neutral-100/70 hover:bg-neutral-200/70 dark:bg-neutral-900/60 dark:hover:bg-neutral-800 text-neutral-600 dark:text-neutral-300 transition-colors" />

            {/* Authentication State */}
            {isAuthenticated ? (
              <div className="flex items-center gap-2">
                <Link
                  to={role === 'librarian' ? '/librarian/dashboard' : '/student/dashboard'}
                  className="px-3.5 py-2 text-xs font-semibold rounded-lg bg-neutral-900 text-white hover:bg-neutral-800 dark:bg-white dark:text-neutral-900 dark:hover:bg-neutral-100 transition-colors whitespace-nowrap shadow-xs"
                >
                  {role === 'librarian' ? 'Librarian' : 'Student'}
                </Link>
                <Link
                  to={role === 'librarian' ? '/librarian/settings' : '/student/profile'}
                  className="px-2.5 py-1.5 text-xs font-medium text-neutral-600 dark:text-neutral-300 hover:text-neutral-900 dark:hover:text-white transition-colors"
                >
                  Profile
                </Link>
                <button
                  onClick={handleLogout}
                  className="px-2.5 py-1.5 text-xs font-medium text-neutral-500 hover:text-rose-600 transition-colors cursor-pointer"
                  title="Sign Out"
                >
                  Logout
                </button>
              </div>
            ) : (
              <Link
                to="/auth"
                className="px-4 py-2 text-xs font-semibold rounded-lg bg-neutral-900 text-white hover:bg-neutral-800 dark:bg-white dark:text-neutral-900 dark:hover:bg-neutral-100 transition-colors whitespace-nowrap shadow-xs"
              >
                Sign In
              </Link>
            )}

            {/* Mobile menu toggle */}
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="md:hidden p-2 rounded-lg text-neutral-600 hover:bg-neutral-100 dark:text-neutral-300 dark:hover:bg-neutral-800"
              aria-label="Toggle navigation menu"
            >
              {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
          </div>
        </div>

        {/* Mobile menu */}
        {mobileMenuOpen && (
          <div className="md:hidden border-b border-neutral-200 dark:border-neutral-800 bg-white dark:bg-neutral-900 px-4 py-3 space-y-2">
            {navLinks.map((link) => (
              <Link
                key={link.path}
                to={link.path}
                onClick={() => setMobileMenuOpen(false)}
                className="block py-2 text-xs font-semibold text-neutral-700 dark:text-neutral-300 hover:text-neutral-900 dark:hover:text-white"
              >
                {link.label}
              </Link>
            ))}
            <div className="pt-2 border-t border-neutral-100 dark:border-neutral-800 flex items-center justify-between">
              {isAuthenticated ? (
                <div className="flex items-center justify-between w-full">
                  <Link
                    to={role === 'librarian' ? '/librarian/dashboard' : '/student/dashboard'}
                    className="text-xs font-bold text-amber-600"
                    onClick={() => setMobileMenuOpen(false)}
                  >
                    Open {role === 'librarian' ? 'Librarian Dashboard' : 'Student Dashboard'} →
                  </Link>
                  <button onClick={handleLogout} className="text-xs text-rose-500 font-medium">
                    Sign Out
                  </button>
                </div>
              ) : (
                <Link
                  to="/auth"
                  onClick={() => setMobileMenuOpen(false)}
                  className="w-full text-center py-2 text-xs font-bold bg-neutral-900 text-white rounded-lg block"
                >
                  Sign In to BookBuddy
                </Link>
              )}
            </div>
          </div>
        )}
      </header>

      {/* Main Public Body */}
      <main className="flex-1">
        <Outlet />
      </main>

      {/* Clean Academic Footer */}
      <footer className="border-t border-neutral-200/80 dark:border-neutral-800 bg-white dark:bg-neutral-950 py-10 px-4 sm:px-6">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-6 text-xs text-neutral-500 dark:text-neutral-400">
          <div className="flex items-center gap-3">
            <span className="font-bold text-neutral-900 dark:text-neutral-100 text-sm">BookBuddy</span>
            <span aria-hidden="true">·</span>
            <span>Central University Library & Knowledge Commons</span>
          </div>

          <div className="flex items-center gap-6">
            <Link to="/catalog" className="hover:text-neutral-900 dark:hover:text-white">Catalog</Link>
            <Link to="/ai-assistant" className="hover:text-neutral-900 dark:hover:text-white">AI Assistant</Link>
            <Link to="/learning-paths" className="hover:text-neutral-900 dark:hover:text-white">Learning Paths</Link>
            <Link to="/about" className="hover:text-neutral-900 dark:hover:text-white">About</Link>
            <Link to="/library-rules" className="hover:text-neutral-900 dark:hover:text-white">Library Rules</Link>
            <Link to="/auth" className="hover:text-neutral-900 dark:hover:text-white font-semibold">Sign In</Link>
          </div>

          <div>
            <span>© 2026 BookBuddy. Physical holdings and AI learning systems.</span>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default PublicLayout;
