import React, { useState } from 'react';
import { Outlet, Link, useLocation, useNavigate } from 'react-router-dom';
import { useAuth } from '../hooks/useAuth';
import { ThemeToggle } from '../components/common/ThemeToggle';
import { RoleSwitcher } from '../components/navigation/RoleSwitcher';
import { CommandPalette } from '../components/navigation/CommandPalette';
import { Avatar } from '../components/common/Avatar';
import {
  LayoutDashboard,
  BookOpen,
  PlusCircle,
  FileSpreadsheet,
  Users,
  FolderTree,
  UserCheck,
  ArrowUpRight,
  ArrowDownLeft,
  Clock,
  AlertTriangle,
  History,
  BarChart3,
  Settings,
  LogOut,
  Menu,
  X,
  ChevronRight,
  Shield,
} from 'lucide-react';

export const AdminLayout = () => {
  const { user, logout, role } = useAuth();
  const location = useLocation();
  const navigate = useNavigate();
  const [mobileSidebarOpen, setMobileSidebarOpen] = useState(false);

  const adminNav = [
    {
      group: 'Overview',
      items: [
        { label: 'Admin Dashboard', path: '/admin/dashboard', icon: LayoutDashboard },
        { label: 'Circulation Analytics', path: '/admin/analytics', icon: BarChart3 },
      ],
    },
    {
      group: 'Circulation Desk',
      items: [
        { label: 'Issue Book (Loan)', path: '/admin/issue', icon: ArrowUpRight },
        { label: 'Return Book (Checkin)', path: '/admin/return', icon: ArrowDownLeft },
        { label: 'Manage Reservations', path: '/admin/reservations', icon: Clock },
        { label: 'Overdue Monitoring', path: '/admin/overdue', icon: AlertTriangle },
        { label: 'Audit Transactions', path: '/admin/transactions', icon: History },
      ],
    },
    {
      group: 'Catalog & Holdings',
      items: [
        { label: 'Manage Books', path: '/admin/books', icon: BookOpen },
        { label: 'Add New Book', path: '/admin/books/new', icon: PlusCircle },
        { label: 'Import CSV / Excel', path: '/admin/import', icon: FileSpreadsheet },
        { label: 'Authors Directory', path: '/admin/authors', icon: Users },
        { label: 'Subject Categories', path: '/admin/categories', icon: FolderTree },
      ],
    },
    {
      group: 'Patrons & System',
      items: [
        { label: 'Reader Directory', path: '/admin/readers', icon: UserCheck },
        { label: 'Library Settings', path: '/admin/settings', icon: Settings },
      ],
    },
  ];

  const handleLogout = async () => {
    await logout();
    navigate('/');
  };

  return (
    <div className="min-h-screen flex bg-neutral-50 dark:bg-neutral-950 text-neutral-900 dark:text-neutral-100">
      <CommandPalette />

      {/* Desktop Admin Sidebar */}
      <aside className="hidden lg:flex w-64 flex-col fixed inset-y-0 left-0 z-30 border-r border-neutral-200/80 bg-white dark:border-neutral-800 dark:bg-neutral-900">
        <div className="h-16 px-6 flex items-center justify-between border-b border-neutral-100 dark:border-neutral-800 shrink-0">
          <Link to="/admin/dashboard" className="flex items-center gap-2.5 font-bold tracking-tight text-base text-neutral-900 dark:text-white">
            <div className="w-7 h-7 rounded-lg bg-amber-600 text-white flex items-center justify-center font-serif text-sm font-bold shadow-xs">
              <Shield className="w-4 h-4" />
            </div>
            <span>Library Staff</span>
          </Link>
          <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-amber-50 text-amber-700 dark:bg-amber-950/50 dark:text-amber-300 font-semibold border border-amber-200/60 dark:border-amber-900/60">
            {role}
          </span>
        </div>

        <div className="flex-1 overflow-y-auto px-4 py-4 space-y-6">
          {adminNav.map((sec, i) => (
            <div key={i} className="space-y-1">
              <h5 className="px-2.5 text-[10px] font-mono uppercase tracking-wider text-neutral-400">
                {sec.group}
              </h5>
              {sec.items.map((item) => {
                const Icon = item.icon;
                const isActive = location.pathname === item.path;
                return (
                  <Link
                    key={item.path}
                    to={item.path}
                    className={`flex items-center gap-2.5 px-2.5 py-1.5 rounded-lg text-xs font-medium transition-colors ${
                      isActive
                        ? 'bg-neutral-900 text-white dark:bg-white dark:text-neutral-900 shadow-xs'
                        : 'text-neutral-600 hover:text-neutral-900 hover:bg-neutral-100 dark:text-neutral-400 dark:hover:text-white dark:hover:bg-neutral-800'
                    }`}
                  >
                    <Icon className="w-4 h-4 shrink-0" />
                    <span className="truncate">{item.label}</span>
                  </Link>
                );
              })}
            </div>
          ))}
        </div>

        <div className="p-3 border-t border-neutral-100 dark:border-neutral-800 shrink-0 flex items-center justify-between">
          <div className="flex items-center gap-2.5 min-w-0 flex-1">
            <Avatar name={user?.name || 'Admin'} size="sm" />
            <div className="min-w-0 flex-1">
              <p className="text-xs font-semibold text-neutral-900 dark:text-neutral-100 truncate">
                {user?.name || 'Staff User'}
              </p>
              <p className="text-[10px] text-neutral-400 truncate">{user?.email}</p>
            </div>
          </div>
          <button
            onClick={handleLogout}
            className="p-1.5 rounded-lg text-neutral-400 hover:text-rose-600 hover:bg-neutral-100 dark:hover:bg-neutral-800 transition-colors"
            title="Sign Out"
          >
            <LogOut className="w-4 h-4" />
          </button>
        </div>
      </aside>

      {/* Main Admin Area */}
      <div className="flex-1 lg:pl-64 flex flex-col min-w-0">
        <header className="sticky top-0 z-20 h-16 border-b border-neutral-200/80 bg-white/90 dark:border-neutral-800 dark:bg-neutral-950/90 backdrop-blur-md px-4 sm:px-6 flex items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <button
              onClick={() => setMobileSidebarOpen(true)}
              className="lg:hidden p-2 rounded-lg text-neutral-600 hover:bg-neutral-100 dark:text-neutral-300 dark:hover:bg-neutral-800"
            >
              <Menu className="w-5 h-5" />
            </button>
            <div className="flex items-center gap-2 text-xs text-neutral-500">
              <Link to="/admin/dashboard" className="hover:text-neutral-900 dark:hover:text-white">
                Admin Console
              </Link>
              <ChevronRight className="w-3 h-3 text-neutral-400" />
              <span className="font-semibold text-neutral-900 dark:text-neutral-100">
                Management System
              </span>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <RoleSwitcher />
            <ThemeToggle />
            <Link
              to="/reader/dashboard"
              className="px-3 py-1.5 text-xs font-medium rounded-lg border border-neutral-300 dark:border-neutral-700 text-neutral-700 dark:text-neutral-200 hover:bg-neutral-100 dark:hover:bg-neutral-800 transition-colors"
            >
              View Reader UI
            </Link>
          </div>
        </header>

        <main className="flex-1 p-4 sm:p-6 lg:p-8 max-w-7xl w-full mx-auto">
          <Outlet />
        </main>
      </div>
    </div>
  );
};

export default AdminLayout;
