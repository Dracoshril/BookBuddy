import React, { useState } from 'react';
import { Outlet, Link, useLocation, useNavigate } from 'react-router-dom';
import { useDispatch } from 'react-redux';
import { useAuth } from '../hooks/useAuth';
import { ThemeToggle } from '../components/common/ThemeToggle';
import { CommandPalette } from '../components/navigation/CommandPalette';
import { Avatar } from '../components/common/Avatar';
import { setCommandPaletteOpen } from '../store/slices/uiSlice';
import {
  LayoutDashboard,
  BookOpen,
  PlusCircle,
  Boxes,
  ArrowUpRight,
  ArrowDownLeft,
  Clock,
  Users,
  BarChart3,
  Bell,
  Settings,
  LogOut,
  Menu,
  X,
  Search,
  ChevronRight,
  Shield,
  Layers,
  Bookmark,
} from 'lucide-react';
import { toast } from 'sonner';

export const LibrarianLayout = () => {
  const { user, logout } = useAuth();
  const location = useLocation();
  const navigate = useNavigate();
  const dispatch = useDispatch();
  const [mobileSidebarOpen, setMobileSidebarOpen] = useState(false);

  const librarianNav = [
    {
      group: 'Overview',
      items: [
        { label: 'Dashboard', path: '/librarian/dashboard', icon: LayoutDashboard },
        { label: 'Reports & Analytics', path: '/librarian/reports', icon: BarChart3 },
      ],
    },
    {
      group: 'Library Management',
      items: [
        { label: 'Books', path: '/librarian/books', icon: BookOpen },
        { label: 'Add New Book', path: '/librarian/books/add', icon: PlusCircle },
        { label: 'Inventory & Stock', path: '/librarian/inventory', icon: Boxes },
        { label: 'Categories', path: '/librarian/categories', icon: Bookmark },
      ],
    },
    {
      group: 'Circulation',
      items: [
        { label: 'Circulation Desk', path: '/librarian/circulation', icon: Layers },
        { label: 'Borrowing Loans', path: '/librarian/borrowings', icon: ArrowUpRight },
        { label: 'Return / Check-In', path: '/librarian/returns', icon: ArrowDownLeft },
        { label: 'Hold Reservations', path: '/librarian/reservations', icon: Clock },
      ],
    },
    {
      group: 'Administration',
      items: [
        { label: 'Students', path: '/librarian/students', icon: Users },
        { label: 'Notifications', path: '/librarian/notifications', icon: Bell },
        { label: 'Settings', path: '/librarian/settings', icon: Settings },
      ],
    },
  ];

  const handleLogout = async () => {
    await logout();
    toast.success('Signed out of Librarian Console.');
    navigate('/');
  };

  const getBreadcrumb = () => {
    const p = location.pathname;
    if (p.includes('/circulation')) return 'Circulation Desk';
    if (p.includes('/books/add')) return 'Add New Book';
    if (p.includes('/books')) return 'Book Management';
    if (p.includes('/inventory')) return 'Inventory & Stock';
    if (p.includes('/categories')) return 'Categories';
    if (p.includes('/borrowings')) return 'Borrowing Loans';
    if (p.includes('/returns')) return 'Return / Check-In';
    if (p.includes('/reservations')) return 'Hold Reservations';
    if (p.includes('/students')) return 'Students';
    if (p.includes('/reports')) return 'Reports & Analytics';
    if (p.includes('/notifications')) return 'Notifications';
    if (p.includes('/settings')) return 'Settings';
    return 'Dashboard';
  };

  return (
    <div className="min-h-screen flex bg-neutral-50 text-neutral-900 dark:bg-neutral-950 dark:text-neutral-100">
      <CommandPalette />

      {/* Desktop Sidebar */}
      <aside className="hidden lg:flex w-64 flex-col fixed inset-y-0 left-0 z-30 border-r border-neutral-200 bg-white/95 dark:border-neutral-800 dark:bg-neutral-900/90 backdrop-blur-md">
        {/* Header */}
        <div className="h-16 px-5 flex items-center justify-between border-b border-neutral-200 dark:border-neutral-800 shrink-0">
          <Link to="/librarian/dashboard" className="flex items-center py-1 outline-none focus-visible:ring-1 focus-visible:ring-emerald-500 rounded" title="BookBuddy Librarian Console">
            <img
              src="/assets/images/bookbuddy-logo.svg"
              alt="BookBuddy"
              className="h-7 w-auto max-h-7 max-w-[136px] object-contain hidden dark:block"
            />
            <img
              src="/assets/images/bookbuddy-logo-light.svg"
              alt="BookBuddy"
              className="h-7 w-auto max-h-7 max-w-[136px] object-contain block dark:hidden"
            />
          </Link>
          <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-emerald-50 text-emerald-700 dark:bg-emerald-500/10 dark:text-emerald-400 font-semibold border border-emerald-200 dark:border-emerald-500/20 shrink-0">
            Librarian
          </span>
        </div>

        {/* Navigation list */}
        <div className="flex-1 overflow-y-auto px-4 py-4 space-y-6">
          {librarianNav.map((sec, i) => (
            <div key={i} className="space-y-1">
              <h5 className="px-2.5 text-[10px] font-mono uppercase tracking-wider text-neutral-400 dark:text-neutral-500 font-semibold">
                {sec.group}
              </h5>
              {sec.items.map((item) => {
                const Icon = item.icon;
                const isActive = location.pathname === item.path;
                return (
                  <Link
                    key={item.path}
                    to={item.path}
                    className={`flex items-center gap-2.5 px-2.5 py-1.5 rounded-lg text-xs font-medium transition-colors ${
                      isActive
                        ? 'bg-emerald-600 text-white dark:bg-emerald-500 dark:text-neutral-950 font-bold shadow-xs'
                        : 'text-neutral-600 hover:text-neutral-900 hover:bg-neutral-100 dark:text-neutral-400 dark:hover:text-white dark:hover:bg-neutral-800'
                    }`}
                  >
                    <Icon className="w-4 h-4 shrink-0" />
                    <span className="truncate">{item.label}</span>
                  </Link>
                );
              })}
            </div>
          ))}
        </div>

        {/* User Footer */}
        <div className="p-3 border-t border-neutral-200 dark:border-neutral-800 shrink-0 flex items-center justify-between">
          <div className="flex items-center gap-2.5 min-w-0 flex-1">
            <Avatar name={user?.name || 'Sarah'} size="sm" />
            <div className="min-w-0 flex-1">
              <p className="text-xs font-semibold text-neutral-900 dark:text-white truncate">
                {user?.name || 'Sarah Jenkins'}
              </p>
              <p className="text-[10px] text-neutral-500 dark:text-neutral-400 truncate">{user?.email}</p>
            </div>
          </div>
          <button
            onClick={handleLogout}
            className="p-1.5 rounded-lg text-neutral-500 hover:text-rose-600 hover:bg-neutral-100 dark:text-neutral-400 dark:hover:text-rose-400 dark:hover:bg-neutral-800 transition-colors cursor-pointer"
            title="Sign Out"
          >
            <LogOut className="w-4 h-4" />
          </button>
        </div>
      </aside>

      {/* Main Content Area */}
      <div className="flex-1 lg:pl-64 flex flex-col min-w-0">
        <header className="sticky top-0 z-20 h-16 border-b border-neutral-200 bg-white/90 dark:border-neutral-800 dark:bg-neutral-950/90 backdrop-blur-md px-4 sm:px-6 flex items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <button
              onClick={() => setMobileSidebarOpen(true)}
              className="lg:hidden p-2 rounded-lg text-neutral-600 hover:bg-neutral-100 dark:text-neutral-400 dark:hover:bg-neutral-800 cursor-pointer"
            >
              <Menu className="w-5 h-5" />
            </button>
            <div className="flex items-center gap-2 text-xs text-neutral-500 dark:text-neutral-400">
              <Link to="/librarian/dashboard" className="hover:text-neutral-900 dark:hover:text-white font-semibold text-neutral-700 dark:text-neutral-200">
                Dashboard
              </Link>
              <ChevronRight className="w-3 h-3 text-neutral-400 dark:text-neutral-600" />
              <span className="font-medium text-neutral-500 dark:text-neutral-400">
                {getBreadcrumb()}
              </span>
            </div>
          </div>

          <div className="flex items-center gap-3">
            {/* Quick Search Shortcut */}
            <button
              onClick={() => dispatch(setCommandPaletteOpen(true))}
              className="flex items-center gap-2 px-3 py-1.5 rounded-lg border border-neutral-200 bg-neutral-100/60 dark:border-neutral-800 dark:bg-transparent text-xs text-neutral-600 hover:text-neutral-900 hover:border-neutral-300 dark:text-neutral-400 dark:hover:text-white dark:hover:border-neutral-700 transition-colors cursor-pointer"
            >
              <Search className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Search library...</span>
              <kbd className="hidden sm:inline px-1.5 py-0.5 rounded bg-neutral-200 dark:bg-neutral-800 text-[10px] font-mono">⌘K</kbd>
            </button>

            {/* Staff Notifications Link */}
            <Link
              to="/librarian/notifications"
              className="p-2 rounded-lg border border-neutral-200 text-neutral-600 hover:text-neutral-900 hover:border-neutral-300 dark:border-neutral-800 dark:text-neutral-400 dark:hover:text-white dark:hover:border-neutral-700 transition-colors relative"
              title="Staff Notifications"
            >
              <Bell className="w-4 h-4" />
              <span className="absolute top-1 right-1 w-2 h-2 rounded-full bg-emerald-500" />
            </Link>

            <ThemeToggle />

            {/* Profile & Logout */}
            <div className="flex items-center gap-2 pl-2 border-l border-neutral-200 dark:border-neutral-800">
              <Link
                to="/librarian/settings"
                className="flex items-center gap-2 text-xs font-semibold text-neutral-700 hover:text-neutral-900 dark:text-neutral-300 dark:hover:text-white transition-colors"
                title="Staff Settings & Profile"
              >
                <Avatar name={user?.name || 'Sarah'} size="sm" />
                <span className="hidden sm:inline">Profile</span>
              </Link>
              <button
                onClick={handleLogout}
                className="hidden sm:inline-flex items-center gap-1.5 text-xs font-medium text-neutral-500 hover:text-rose-600 dark:text-neutral-400 dark:hover:text-rose-400 px-2 py-1 rounded-lg hover:bg-neutral-100 dark:hover:bg-neutral-900 transition-colors cursor-pointer"
              >
                <LogOut className="w-3.5 h-3.5" />
                <span>Logout</span>
              </button>
            </div>
          </div>
        </header>

        <main className="flex-1 p-4 sm:p-6 lg:p-8 max-w-7xl w-full mx-auto">
          <Outlet />
        </main>
      </div>
    </div>
  );
};

export default LibrarianLayout;
