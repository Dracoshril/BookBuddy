import React, { useState } from 'react';
import { Outlet, Link, useLocation, useNavigate } from 'react-router-dom';
import { useAuth } from '../hooks/useAuth';
import { useDispatch, useSelector } from 'react-redux';
import { ThemeToggle } from '../components/common/ThemeToggle';
import { RoleSwitcher } from '../components/navigation/RoleSwitcher';
import { CommandPalette } from '../components/navigation/CommandPalette';
import { BorrowBookModal } from '../components/modals/BorrowBookModal';
import { ReserveBookModal } from '../components/modals/ReserveBookModal';
import { ReviewModal } from '../components/modals/ReviewModal';
import { Avatar } from '../components/common/Avatar';
import { setCommandPaletteOpen } from '../store/slices/uiSlice';
import {
  LayoutDashboard,
  Compass,
  BookMarked,
  Clock,
  History,
  CalendarDays,
  Bookmark,
  Star,
  MessageSquare,
  ListOrdered,
  Users,
  Radio,
  Sparkles,
  TrendingUp,
  MapPin,
  Bell,
  User,
  LogOut,
  Menu,
  X,
  Search,
  ChevronRight,
} from 'lucide-react';

export const ReaderLayout = () => {
  const { user, logout, role } = useAuth();
  const location = useLocation();
  const navigate = useNavigate();
  const dispatch = useDispatch();
  const [mobileSidebarOpen, setMobileSidebarOpen] = useState(false);
  const unreadCount = useSelector((state) => state.notifications.unreadCount);

  const navSections = [
    {
      title: 'Library',
      items: [
        { label: 'Dashboard', path: '/reader/dashboard', icon: LayoutDashboard },
        { label: 'Browse Catalog', path: '/explore', icon: Compass },
        { label: 'Reservations', path: '/reader/reservations', icon: Clock },
      ],
    },
    {
      title: 'Reading Journey',
      items: [
        { label: 'Reading Diary', path: '/reader/diary', icon: CalendarDays },
        { label: 'Reading History', path: '/reader/history', icon: History },
        { label: 'Want to Read', path: '/reader/want-to-read', icon: Bookmark },
        { label: 'Ratings', path: '/reader/ratings', icon: Star },
        { label: 'Reviews', path: '/reader/reviews', icon: MessageSquare },
        { label: 'Custom Lists', path: '/reader/lists', icon: ListOrdered },
      ],
    },
    {
      title: 'AI Intelligence',
      items: [
        { label: 'AI Assistant', path: '/ai/assistant', icon: Sparkles },
        { label: 'Recommendations', path: '/ai/recommendations', icon: Compass },
        { label: 'Smart Search', path: '/ai/search', icon: Search },
        { label: 'Learning Paths', path: '/ai/learning-path', icon: TrendingUp },
        { label: 'Reading Insights', path: '/ai/insights', icon: Radio },
      ],
    },
    {
      title: 'Social & Account',
      items: [
        { label: 'Activity Feed', path: '/reader/activity', icon: Radio },
        { label: 'Following', path: '/reader/following', icon: Users },
        { label: 'Notifications', path: '/reader/notifications', icon: Bell, badge: unreadCount },
        { label: 'Profile', path: '/reader/profile', icon: User },
      ],
    },
  ];

  const handleLogout = async () => {
    await logout();
    navigate('/');
  };

  const getBreadcrumb = () => {
    const p = location.pathname;
    if (p.includes('/reservations')) return 'Reservations';
    if (p.includes('/diary')) return 'Reading Diary';
    if (p.includes('/history')) return 'Reading History';
    if (p.includes('/want-to-read')) return 'Want to Read Shelf';
    if (p.includes('/ratings')) return 'My Ratings';
    if (p.includes('/reviews')) return 'My Reviews';
    if (p.includes('/lists')) return 'Custom Lists';
    if (p.includes('/following')) return 'Reader Community';
    if (p.includes('/activity')) return 'Social Activity Feed';
    if (p.includes('/notifications')) return 'Notifications Center';
    if (p.includes('/profile')) return 'Reader Profile';
    if (p.includes('/ai/assistant')) return 'AI Assistant';
    if (p.includes('/ai/recommendations')) return 'AI Recommendations';
    if (p.includes('/ai/search')) return 'AI Smart Search';
    if (p.includes('/ai/learning-path')) return 'Learning Paths';
    if (p.includes('/ai/insights')) return 'Reading Insights';
    return 'Dashboard';
  };

  return (
    <div className="min-h-screen flex bg-neutral-50 dark:bg-neutral-950 text-neutral-900 dark:text-neutral-100">
      <CommandPalette />
      <BorrowBookModal />
      <ReserveBookModal />
      <ReviewModal />

      {/* Desktop Sidebar (260px wide, single elevation) */}
      <aside className="hidden lg:flex w-64 flex-col fixed inset-y-0 left-0 z-30 border-r border-neutral-200/80 bg-white dark:border-neutral-800 dark:bg-neutral-900">
        {/* Brand */}
        <div className="h-16 px-6 flex items-center justify-between border-b border-neutral-100 dark:border-neutral-800 shrink-0">
          <Link to="/" className="flex items-center gap-2.5 py-1" title="BookBuddy Library">
            <img
              src="/assets/images/bookbuddy-logo.svg"
              alt="BookBuddy"
              className="h-8 w-auto object-contain hidden dark:block"
            />
            <img
              src="/assets/images/bookbuddy-logo-light.svg"
              alt="BookBuddy"
              className="h-8 w-auto object-contain block dark:hidden"
            />
          </Link>
          <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-neutral-100 text-neutral-600 dark:bg-neutral-800 dark:text-neutral-400 capitalize">
            {role}
          </span>
        </div>

        {/* Navigation list */}
        <div className="flex-1 overflow-y-auto px-4 py-4 space-y-6">
          {navSections.map((section, idx) => (
            <div key={idx} className="space-y-1">
              <h5 className="px-2.5 text-[10px] font-mono uppercase tracking-wider text-neutral-400">
                {section.title}
              </h5>
              {section.items.map((item) => {
                const Icon = item.icon;
                const isActive = location.pathname === item.path;
                return (
                  <Link
                    key={item.path}
                    to={item.path}
                    className={`flex items-center justify-between px-2.5 py-1.5 rounded-lg text-xs font-medium transition-colors ${
                      isActive
                        ? 'bg-neutral-900 text-white dark:bg-white dark:text-neutral-900 shadow-xs'
                        : 'text-neutral-600 hover:text-neutral-900 hover:bg-neutral-100 dark:text-neutral-400 dark:hover:text-white dark:hover:bg-neutral-800'
                    }`}
                  >
                    <div className="flex items-center gap-2.5">
                      <Icon className="w-4 h-4 shrink-0" />
                      <span>{item.label}</span>
                    </div>
                    {item.badge > 0 && (
                      <span className="px-1.5 py-0.2 rounded-full text-[10px] font-bold bg-amber-500 text-white">
                        {item.badge}
                      </span>
                    )}
                  </Link>
                );
              })}
            </div>
          ))}
        </div>

        {/* Sidebar Footer User Info */}
        <div className="p-3 border-t border-neutral-100 dark:border-neutral-800 shrink-0 flex items-center justify-between">
          <Link to="/reader/profile" className="flex items-center gap-2.5 min-w-0 flex-1 hover:opacity-80 transition-opacity">
            <Avatar name={user?.name || 'Reader'} size="sm" />
            <div className="min-w-0 flex-1">
              <p className="text-xs font-semibold text-neutral-900 dark:text-neutral-100 truncate">
                {user?.name || 'Student Reader'}
              </p>
              <p className="text-[10px] text-neutral-400 truncate">{user?.studentId || user?.email}</p>
            </div>
          </Link>
          <button
            onClick={handleLogout}
            className="p-1.5 rounded-lg text-neutral-400 hover:text-rose-600 hover:bg-neutral-100 dark:hover:bg-neutral-800 transition-colors"
            title="Sign Out"
          >
            <LogOut className="w-4 h-4" />
          </button>
        </div>
      </aside>

      {/* Mobile Drawer */}
      {mobileSidebarOpen && (
        <div className="fixed inset-0 z-50 lg:hidden flex">
          <div
            className="fixed inset-0 bg-black/60 backdrop-blur-xs transition-opacity"
            onClick={() => setMobileSidebarOpen(false)}
          />
          <div className="relative w-72 max-w-[85%] bg-white dark:bg-neutral-900 h-full flex flex-col p-4 z-10 overflow-y-auto">
            <div className="flex items-center justify-between pb-4 border-b border-neutral-100 dark:border-neutral-800 mb-4">
              <span className="font-bold text-base">BookBuddy</span>
              <button onClick={() => setMobileSidebarOpen(false)} className="p-1 text-neutral-500">
                <X className="w-5 h-5" />
              </button>
            </div>
            <div className="space-y-4 flex-1">
              {navSections.map((sec, i) => (
                <div key={i} className="space-y-1">
                  <div className="text-[10px] font-mono text-neutral-400 uppercase">{sec.title}</div>
                  {sec.items.map((item) => (
                    <Link
                      key={item.path}
                      to={item.path}
                      onClick={() => setMobileSidebarOpen(false)}
                      className={`flex items-center justify-between px-3 py-2 rounded-lg text-xs font-medium ${
                        location.pathname === item.path
                          ? 'bg-neutral-900 text-white dark:bg-white dark:text-neutral-900'
                          : 'text-neutral-600 hover:bg-neutral-100 dark:text-neutral-300 dark:hover:bg-neutral-800'
                      }`}
                    >
                      <div className="flex items-center gap-2.5">
                        <item.icon className="w-4 h-4" />
                        <span>{item.label}</span>
                      </div>
                      {item.badge > 0 && (
                        <span className="px-1.5 py-0.5 rounded-full text-[10px] bg-amber-500 text-white">
                          {item.badge}
                        </span>
                      )}
                    </Link>
                  ))}
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Main Content Area */}
      <div className="flex-1 lg:pl-64 flex flex-col min-w-0">
        {/* Top Header */}
        <header className="sticky top-0 z-20 h-16 border-b border-neutral-200/80 bg-white/90 dark:border-neutral-800 dark:bg-neutral-950/90 backdrop-blur-md px-4 sm:px-6 flex items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <button
              onClick={() => setMobileSidebarOpen(true)}
              className="lg:hidden p-2 rounded-lg text-neutral-600 hover:bg-neutral-100 dark:text-neutral-300 dark:hover:bg-neutral-800"
            >
              <Menu className="w-5 h-5" />
            </button>

            {/* Breadcrumb Trail */}
            <div className="flex items-center gap-1.5 text-xs text-neutral-500">
              <Link to="/reader/dashboard" className="hover:text-neutral-900 dark:hover:text-white">
                Reader
              </Link>
              <ChevronRight className="w-3 h-3 text-neutral-400" />
              <span className="font-semibold text-neutral-900 dark:text-neutral-100">
                {getBreadcrumb()}
              </span>
            </div>
          </div>

          <div className="flex items-center gap-3">
            {/* Instant Role Switcher */}
            <RoleSwitcher />

            {/* Global Search Shortcut */}
            <button
              onClick={() => dispatch(setCommandPaletteOpen(true))}
              className="hidden sm:flex items-center gap-2 px-3 py-1.5 rounded-lg border border-neutral-200 dark:border-neutral-800 text-xs text-neutral-500 hover:text-neutral-900 dark:hover:text-white hover:border-neutral-300 transition-colors"
            >
              <Search className="w-3.5 h-3.5" />
              <span className="hidden md:inline">Quick Jump...</span>
              <kbd className="px-1.5 py-0.5 rounded bg-neutral-100 dark:bg-neutral-800 text-[10px] font-mono">⌘K</kbd>
            </button>

            <Link
              to="/reader/notifications"
              className="relative p-2 rounded-lg text-neutral-500 hover:text-neutral-900 hover:bg-neutral-100 dark:hover:text-white dark:hover:bg-neutral-800 transition-colors"
              title="Notifications"
            >
              <Bell className="w-4 h-4" />
              {unreadCount > 0 && (
                <span className="absolute top-1.5 right-1.5 w-2 h-2 rounded-full bg-amber-500" />
              )}
            </Link>

            <ThemeToggle />

            <Link to="/reader/profile" className="shrink-0">
              <Avatar name={user?.name || 'Reader'} size="sm" />
            </Link>
          </div>
        </header>

        {/* Viewport Content */}
        <main className="flex-1 p-4 sm:p-6 lg:p-8 max-w-7xl w-full mx-auto">
          <Outlet />
        </main>
      </div>
    </div>
  );
};

export default ReaderLayout;
