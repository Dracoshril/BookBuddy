import React, { useState, useRef, useEffect } from 'react';
import { Outlet, Link, useLocation, useNavigate } from 'react-router-dom';
import { useAuth } from '../hooks/useAuth';
import { useDispatch, useSelector } from 'react-redux';
import { ThemeToggle } from '../components/common/ThemeToggle';
import { CommandPalette } from '../components/navigation/CommandPalette';
import { BorrowBookModal } from '../components/modals/BorrowBookModal';
import { ReserveBookModal } from '../components/modals/ReserveBookModal';
import { ReviewModal } from '../components/modals/ReviewModal';
import { setCommandPaletteOpen } from '../store/slices/uiSlice';
import {
  LayoutGrid,
  BookOpen,
  Clock,
  Calendar,
  History,
  Bookmark,
  Star,
  MessageSquare,
  List,
  Sparkles,
  TrendingUp,
  Bell,
  LogOut,
  Menu,
  X,
  ChevronRight,
  ChevronDown,
  Home,
  User,
  Heart,
} from 'lucide-react';
import { toast } from 'sonner';

export const StudentLayout = () => {
  const { user, logout } = useAuth();
  const location = useLocation();
  const navigate = useNavigate();
  const dispatch = useDispatch();
  const [mobileSidebarOpen, setMobileSidebarOpen] = useState(false);
  const [userDropdownOpen, setUserDropdownOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const userDropdownRef = useRef(null);

  const unreadCount = useSelector((state) => state.notifications.unreadCount);

  // Close dropdown on outside click
  useEffect(() => {
    const handleClickOutside = (e) => {
      if (userDropdownRef.current && !userDropdownRef.current.contains(e.target)) {
        setUserDropdownOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const studentNav = [
    {
      group: 'LIBRARY SERVICES',
      items: [
        { label: 'Dashboard', path: '/student/dashboard', icon: LayoutGrid },
        { label: 'Browse Catalog', path: '/student/catalog', icon: BookOpen },
        { label: 'Reservations', path: '/student/reservations', icon: Clock },
      ],
    },
    {
      group: 'READING JOURNEY',
      items: [
        { label: 'Reading Diary', path: '/student/reading-diary', icon: Calendar },
        { label: 'Reading History', path: '/student/history', icon: History },
        { label: 'Want to Read', path: '/student/want-to-read', icon: Bookmark },
        { label: 'Ratings & Reading Stats', path: '/student/ratings', icon: Star },
        { label: 'Reviews', path: '/student/reviews', icon: MessageSquare },
        { label: 'Custom Lists', path: '/student/custom-lists', icon: List },
      ],
    },
    {
      group: 'AI LEARNING TOOLS',
      items: [
        { label: 'AI Assistant', path: '/student/ai-assistant', icon: Sparkles },
        { label: 'Learning Paths', path: '/student/learning-paths', icon: TrendingUp },
      ],
    },
  ];

  const handleLogout = async () => {
    await logout();
    toast.success('Logged out successfully.');
    navigate('/');
  };

  const getBreadcrumb = () => {
    const p = location.pathname;
    if (p.includes('/catalog')) return 'Browse Catalog';
    if (p.includes('/books/')) return 'Book Details';
    if (p.includes('/reservations')) return 'Reservations';
    if (p.includes('/reading-diary')) return 'Reading Diary';
    if (p.includes('/history')) return 'Reading History';
    if (p.includes('/want-to-read')) return 'Want to Read';
    if (p.includes('/ratings')) return 'Ratings';
    if (p.includes('/reviews')) return 'Reviews';
    if (p.includes('/custom-lists')) return 'Custom Lists';
    if (p.includes('/ai-assistant')) return 'AI Assistant';
    if (p.includes('/learning-paths')) return 'Learning Paths';
    if (p.includes('/notifications')) return 'Notifications';
    if (p.includes('/profile')) return 'Profile';
    return 'Dashboard';
  };

  const handleSearchSubmit = (e) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      navigate(`/student/catalog?search=${encodeURIComponent(searchQuery.trim())}`);
    } else {
      dispatch(setCommandPaletteOpen(true));
    }
  };

  return (
    <div className="min-h-screen flex bg-slate-50 text-slate-900 dark:bg-[#050B18] dark:text-[#F5F7FA]">
      <CommandPalette />
      <BorrowBookModal />
      <ReserveBookModal />
      <ReviewModal />

      {/* Desktop Persistent Sidebar (Navy #081426 in dark, Crisp White in light) */}
      <aside className="hidden lg:flex w-64 flex-col fixed inset-y-0 left-0 z-30 border-r border-slate-200 bg-white dark:border-white/[0.06] dark:bg-[#081426] select-none transition-colors">
        {/* Brand Header */}
        <div className="h-16 px-5 flex items-center border-b border-slate-200 dark:border-white/[0.06] shrink-0">
          <Link
            to="/student/dashboard"
            className="flex items-center gap-2 outline-none focus-visible:ring-1 focus-visible:ring-blue-500 rounded"
            title="BookBuddy"
          >
            {/* Dark mode logo */}
            <img
              src="/assets/images/bookbuddy-logo.svg"
              alt="BookBuddy"
              className="h-8 w-auto max-h-8 object-contain hidden dark:block"
            />
            {/* Light mode logo */}
            <img
              src="/assets/images/bookbuddy-logo-light.svg"
              alt="BookBuddy"
              className="h-8 w-auto max-h-8 object-contain block dark:hidden"
            />
          </Link>
        </div>

        {/* Navigation list */}
        <div className="flex-1 overflow-y-auto px-3.5 py-4 space-y-6">
          {studentNav.map((sec, i) => (
            <div key={i} className="space-y-1">
              <h5 className="px-3 text-[10px] font-mono uppercase tracking-wider text-slate-400 dark:text-[#4b6182] font-semibold">
                {sec.group}
              </h5>
              <div className="space-y-0.5 pt-1">
                {sec.items.map((item) => {
                  const Icon = item.icon;
                  const isActive =
                    location.pathname === item.path ||
                    (item.path === '/student/catalog' && location.pathname.startsWith('/student/books/'));
                  return (
                    <Link
                      key={item.path}
                      to={item.path}
                      className={`flex items-center gap-3 px-3 py-2.5 rounded-xl text-xs font-medium transition-all duration-150 ${
                        isActive
                          ? 'bg-[#1677FF] text-white shadow-md shadow-blue-600/25 font-semibold'
                          : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100 dark:text-[#7e8ea7] dark:hover:text-white dark:hover:bg-white/[0.04]'
                      }`}
                    >
                      <Icon className={`w-4 h-4 shrink-0 ${isActive ? 'text-white' : 'text-slate-400 dark:text-[#7e8ea7]'}`} />
                      <span className="truncate">{item.label}</span>
                    </Link>
                  );
                })}
              </div>
            </div>
          ))}
        </div>

        {/* Bottom Card (Read More / Grow More) */}
        <div className="p-3.5 border-t border-slate-200 dark:border-white/[0.06] shrink-0">
          <div className="p-3 rounded-2xl bg-slate-100 dark:bg-[#0c1c36] border border-slate-200 dark:border-white/[0.06] flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-xl bg-blue-500/10 text-blue-600 dark:bg-sky-500/20 dark:text-sky-400 flex items-center justify-center shrink-0">
                <BookOpen className="w-4 h-4" />
              </div>
              <div className="min-w-0">
                <p className="text-[10px] text-slate-500 dark:text-slate-400 font-medium">Read More</p>
                <p className="text-xs font-semibold text-slate-800 dark:text-white truncate">Grow More</p>
              </div>
            </div>
            <button
              type="button"
              className="p-1 rounded-lg text-slate-400 hover:text-rose-500 transition-colors"
              title="Add to favorites"
            >
              <Heart className="w-4 h-4" />
            </button>
          </div>
        </div>
      </aside>

      {/* Mobile Sidebar Drawer */}
      {mobileSidebarOpen && (
        <div className="fixed inset-0 z-50 lg:hidden flex">
          <div
            className="fixed inset-0 bg-black/70 backdrop-blur-xs transition-opacity"
            onClick={() => setMobileSidebarOpen(false)}
          />
          <div className="relative w-72 max-w-[85%] bg-white dark:bg-[#081426] border-r border-slate-200 dark:border-white/[0.06] h-full flex flex-col p-4 z-10 overflow-y-auto">
            <div className="flex items-center justify-between pb-4 border-b border-slate-200 dark:border-white/[0.06] mb-4">
              <div className="flex items-center gap-2">
                <img
                  src="/assets/images/bookbuddy-logo.svg"
                  alt="BookBuddy"
                  className="h-7 w-auto object-contain hidden dark:block"
                />
                <img
                  src="/assets/images/bookbuddy-logo-light.svg"
                  alt="BookBuddy"
                  className="h-7 w-auto object-contain block dark:hidden"
                />
              </div>
              <button
                onClick={() => setMobileSidebarOpen(false)}
                className="p-1.5 text-slate-400 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            <div className="space-y-4 flex-1">
              {studentNav.map((sec, i) => (
                <div key={i} className="space-y-1">
                  <div className="text-[10px] font-mono text-slate-400 dark:text-[#4b6182] uppercase px-2 font-semibold">
                    {sec.group}
                  </div>
                  {sec.items.map((item) => (
                    <Link
                      key={item.path}
                      to={item.path}
                      onClick={() => setMobileSidebarOpen(false)}
                      className={`flex items-center gap-2.5 px-3 py-2 rounded-xl text-xs font-medium ${
                        location.pathname === item.path
                          ? 'bg-[#1677FF] text-white font-semibold'
                          : 'text-slate-600 hover:bg-slate-100 dark:text-[#7e8ea7] dark:hover:bg-white/[0.04] dark:hover:text-white'
                      }`}
                    >
                      <item.icon className="w-4 h-4" />
                      <span>{item.label}</span>
                    </Link>
                  ))}
                </div>
              ))}
            </div>
            <div className="pt-4 border-t border-slate-200 dark:border-white/[0.06]">
              <button
                onClick={handleLogout}
                className="w-full py-2.5 text-xs font-semibold text-rose-500 hover:bg-rose-500/10 rounded-xl flex items-center justify-center gap-2 cursor-pointer transition-colors"
              >
                <LogOut className="w-4 h-4" />
                <span>Sign Out</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Main Viewport Content Area */}
      <div className="flex-1 lg:pl-64 flex flex-col min-w-0">
        {/* Top Header */}
        <header className="sticky top-0 z-20 h-16 border-b border-slate-200 bg-white/90 dark:border-white/[0.06] dark:bg-[#050B18]/90 backdrop-blur-md px-4 sm:px-6 lg:px-8 flex items-center justify-between gap-3 transition-colors">
          <div className="flex items-center gap-2 shrink-0">
            <button
              onClick={() => setMobileSidebarOpen(true)}
              className="lg:hidden p-2 rounded-xl text-slate-600 hover:bg-slate-100 dark:text-slate-400 dark:hover:bg-white/[0.05] cursor-pointer"
            >
              <Menu className="w-5 h-5" />
            </button>
          </div>

          {/* Global Search / Breadcrumb Bar (Matching Reference Image) */}
          <div className="flex-1 max-w-xl">
            <form
              onSubmit={handleSearchSubmit}
              className="flex items-center gap-2 h-10 px-3.5 rounded-xl bg-slate-100 dark:bg-[#0D1F38] border border-slate-200 dark:border-white/[0.08] focus-within:border-blue-500 dark:focus-within:border-blue-500/80 transition-all text-xs"
            >
              <Link
                to="/student/dashboard"
                className="flex items-center gap-1.5 text-slate-400 dark:text-slate-400 hover:text-blue-500 dark:hover:text-sky-400 shrink-0"
                title="Home / Dashboard"
              >
                <Home className="w-3.5 h-3.5 text-blue-500 dark:text-sky-400" />
                <ChevronRight className="w-3 h-3 text-slate-400 dark:text-slate-600" />
                <span className="font-medium text-slate-700 dark:text-slate-300 hidden sm:inline">
                  {getBreadcrumb()}
                </span>
                <ChevronRight className="w-3 h-3 text-slate-400 dark:text-slate-600 hidden sm:inline" />
              </Link>
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search books, authors, categories..."
                className="w-full bg-transparent border-none outline-none text-slate-900 dark:text-white placeholder:text-slate-400 dark:placeholder:text-slate-500 text-xs min-w-0"
              />
              <button
                type="button"
                onClick={() => dispatch(setCommandPaletteOpen(true))}
                className="hidden md:flex items-center px-1.5 py-0.5 rounded text-[10px] font-mono text-slate-400 dark:text-slate-500 bg-slate-200/60 dark:bg-white/[0.06] border border-slate-300/40 dark:border-white/[0.08] shrink-0"
                title="Search Command Palette (⌘K)"
              >
                ⌘K
              </button>
            </form>
          </div>

          {/* Right Header Controls (Notification, Theme, Profile) */}
          <div className="flex items-center gap-2 sm:gap-3 shrink-0">
            {/* Notifications Button */}
            <Link
              to="/student/notifications"
              className="flex items-center justify-center h-10 w-10 rounded-full bg-slate-100 dark:bg-[#0D1F38] border border-slate-200 dark:border-white/[0.08] text-slate-600 hover:text-blue-600 dark:text-slate-300 dark:hover:text-white transition-colors relative"
              title="Notifications"
            >
              <Bell className="w-4 h-4" />
              {unreadCount > 0 && (
                <span className="absolute top-2 right-2 w-2 h-2 rounded-full bg-[#1677FF] ring-2 ring-white dark:ring-[#0D1F38]" />
              )}
            </Link>

            {/* Theme Toggle Button */}
            <ThemeToggle className="h-10 w-10 rounded-full bg-slate-100 dark:bg-[#0D1F38] border border-slate-200 dark:border-white/[0.08] flex items-center justify-center text-slate-600 hover:text-blue-600 dark:text-slate-300 dark:hover:text-white transition-colors" />

            {/* User Profile with Dropdown */}
            <div className="relative" ref={userDropdownRef}>
              <button
                type="button"
                onClick={() => setUserDropdownOpen(!userDropdownOpen)}
                className="flex items-center gap-2.5 p-1 rounded-xl hover:bg-slate-100 dark:hover:bg-white/[0.04] transition-colors cursor-pointer outline-none"
              >
                {/* Circular Avatar VG */}
                <div className="w-8 h-8 rounded-full bg-[#F59E0B] text-white font-bold text-xs flex items-center justify-center shrink-0 shadow-sm">
                  VG
                </div>
                <div className="text-left hidden md:block">
                  <p className="text-xs font-semibold text-slate-800 dark:text-white leading-tight">
                    {user?.name || 'Vishal Gayathri'}
                  </p>
                  <p className="text-[10px] text-slate-500 dark:text-slate-400 leading-tight">
                    Student
                  </p>
                </div>
                <ChevronDown className="w-3.5 h-3.5 text-slate-400 hidden sm:block" />
              </button>

              {/* Profile Dropdown Menu */}
              {userDropdownOpen && (
                <div className="absolute right-0 mt-2 w-52 rounded-2xl bg-white dark:bg-[#0D1B31] border border-slate-200 dark:border-white/[0.08] shadow-xl shadow-black/20 py-2 z-50 animate-in fade-in zoom-in-95 duration-100">
                  <div className="px-4 py-2 border-b border-slate-100 dark:border-white/[0.06]">
                    <p className="text-xs font-semibold text-slate-900 dark:text-white">
                      {user?.name || 'Vishal Gayathri'}
                    </p>
                    <p className="text-[11px] text-slate-500 dark:text-slate-400">
                      ID: {user?.studentId || 'CS2023-8891'}
                    </p>
                  </div>

                  <div className="py-1">
                    <Link
                      to="/student/profile"
                      onClick={() => setUserDropdownOpen(false)}
                      className="flex items-center gap-2.5 px-4 py-2 text-xs text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-white/[0.05]"
                    >
                      <User className="w-4 h-4 text-slate-400" />
                      <span>View Profile</span>
                    </Link>
                    <Link
                      to="/student/reservations"
                      onClick={() => setUserDropdownOpen(false)}
                      className="flex items-center gap-2.5 px-4 py-2 text-xs text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-white/[0.05]"
                    >
                      <Clock className="w-4 h-4 text-slate-400" />
                      <span>Hold Queue</span>
                    </Link>
                    <Link
                      to="/student/reading-diary"
                      onClick={() => setUserDropdownOpen(false)}
                      className="flex items-center gap-2.5 px-4 py-2 text-xs text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-white/[0.05]"
                    >
                      <Calendar className="w-4 h-4 text-slate-400" />
                      <span>Reading Diary</span>
                    </Link>
                  </div>

                  <div className="pt-1 border-t border-slate-100 dark:border-white/[0.06]">
                    <button
                      onClick={() => {
                        setUserDropdownOpen(false);
                        handleLogout();
                      }}
                      className="w-full flex items-center gap-2.5 px-4 py-2 text-xs text-rose-500 hover:bg-rose-500/10 cursor-pointer transition-colors"
                    >
                      <LogOut className="w-4 h-4" />
                      <span>Sign Out</span>
                    </button>
                  </div>
                </div>
              )}
            </div>
          </div>
        </header>

        {/* Content Body */}
        <main className="flex-1 p-4 sm:p-6 lg:p-8 max-w-7xl w-full mx-auto">
          <Outlet />
        </main>
      </div>
    </div>
  );
};

export default StudentLayout;
