import React from 'react';
import { Routes, Route, Navigate, useParams } from 'react-router-dom';
import { useAuth } from '../hooks/useAuth';

// Layouts
import { PublicLayout } from '../layouts/PublicLayout';
import { StudentLayout } from '../layouts/StudentLayout';
import { LibrarianLayout } from '../layouts/LibrarianLayout';

// Guards
import { StudentRoute } from './StudentRoute';
import { LibrarianRoute } from './LibrarianRoute';

// Public Pages
import { HomePage } from '../pages/public/HomePage';
import { AboutPage } from '../pages/public/AboutPage';
import { ExplorePage } from '../pages/public/ExplorePage';
import { BookDetailPage } from '../pages/public/BookDetailPage';
import { HelpPage } from '../pages/public/HelpPage';
import { PublicAIAssistantPage } from '../pages/public/PublicAIAssistantPage';
import { PublicLearningPathsPage } from '../pages/public/PublicLearningPathsPage';
import { NotFoundPage } from '../pages/public/NotFoundPage';

// Auth Pages (Only Student & Librarian)
import { LoginSelectPage } from '../pages/auth/LoginSelectPage';
import { StudentLoginPage } from '../pages/auth/StudentLoginPage';
import { LibrarianLoginPage } from '../pages/auth/LibrarianLoginPage';

// Student Pages
import { ReaderDashboardPage } from '../pages/reader/ReaderDashboardPage';
import { ReservationsPage } from '../pages/reader/ReservationsPage';
import { ReadingDiaryPage } from '../pages/reader/ReadingDiaryPage';
import { ReadingHistoryPage } from '../pages/reader/ReadingHistoryPage';
import { WantToReadPage } from '../pages/reader/WantToReadPage';
import { RatingsPage } from '../pages/reader/RatingsPage';
import { ReviewsPage } from '../pages/reader/ReviewsPage';
import { NewReviewPage } from '../pages/reader/NewReviewPage';
import { MyListsPage } from '../pages/reader/MyListsPage';
import { ListDetailPage } from '../pages/reader/ListDetailPage';
import { AIAssistantPage } from '../pages/ai/AIAssistantPage';
import { AILearningPathPage } from '../pages/ai/AILearningPathPage';
import { NotificationsPage } from '../pages/reader/NotificationsPage';
import { ProfilePage } from '../pages/reader/ProfilePage';

// Librarian Pages
import { LibrarianDashboardPage } from '../pages/librarian/LibrarianDashboardPage';
import { ManageBooksPage } from '../pages/admin/ManageBooksPage';
import { AddEditBookPage } from '../pages/admin/AddEditBookPage';
import { LibrarianInventoryPage } from '../pages/librarian/LibrarianInventoryPage';
import { LibrarianBorrowingsPage } from '../pages/librarian/LibrarianBorrowingsPage';
import { CirculationDeskPage } from '../pages/librarian/CirculationDeskPage';
import { ReturnBookPage } from '../pages/admin/ReturnBookPage';
import { AdminReservationsPage } from '../pages/admin/AdminReservationsPage';
import { StudentManagementPage } from '../pages/librarian/StudentManagementPage';
import { AdminAnalyticsPage } from '../pages/admin/AdminAnalyticsPage';
import { StaffNotificationsPage } from '../pages/librarian/StaffNotificationsPage';
import { AdminSettingsPage } from '../pages/admin/AdminSettingsPage';
import { CategoriesPage } from '../pages/admin/CategoriesPage';
import { AuthorsPage } from '../pages/admin/AuthorsPage';

const PublicCatalogRoute = () => {
  const { isAuthenticated, role } = useAuth();
  if (isAuthenticated) {
    return <Navigate to={role === 'librarian' ? '/librarian/catalog' : '/student/catalog'} replace />;
  }
  return <ExplorePage />;
};

const PublicBookDetailRoute = () => {
  const { isAuthenticated, role } = useAuth();
  const { id, bookId } = useParams();
  const targetId = id || bookId;
  if (isAuthenticated) {
    return <Navigate to={role === 'librarian' ? `/librarian/books/${targetId}` : `/student/books/${targetId}`} replace />;
  }
  return <BookDetailPage />;
};

const PublicAIRoute = () => {
  const { isAuthenticated, role } = useAuth();
  if (isAuthenticated && role === 'student') {
    return <Navigate to="/student/ai-assistant" replace />;
  }
  return <PublicAIAssistantPage />;
};

const PublicLearningRoute = () => {
  const { isAuthenticated, role } = useAuth();
  if (isAuthenticated && role === 'student') {
    return <Navigate to="/student/learning-paths" replace />;
  }
  return <PublicLearningPathsPage />;
};

export const AppRoutes = () => {
  return (
    <Routes>
      {/* Public Pages */}
      <Route element={<PublicLayout />}>
        <Route path="/" element={<HomePage />} />
        <Route path="/catalog" element={<PublicCatalogRoute />} />
        <Route path="/explore" element={<Navigate to="/catalog" replace />} />
        <Route path="/ai-assistant" element={<PublicAIRoute />} />
        <Route path="/learning-paths" element={<PublicLearningRoute />} />
        <Route path="/about" element={<AboutPage />} />
        <Route path="/library-rules" element={<HelpPage />} />
        <Route path="/help" element={<Navigate to="/library-rules" replace />} />

        {/* Public Book Details */}
        <Route path="/books/:id" element={<PublicBookDetailRoute />} />
        <Route path="/books/:bookId" element={<PublicBookDetailRoute />} />

        {/* Authentication Routes (Only 2 Roles: Student and Librarian) */}
        <Route path="/auth" element={<LoginSelectPage />} />
        <Route path="/auth/student" element={<StudentLoginPage />} />
        <Route path="/auth/librarian" element={<LibrarianLoginPage />} />
      </Route>

      {/* Student Portal (Only Student Role Allowed) */}
      <Route
        path="/student"
        element={
          <StudentRoute>
            <StudentLayout />
          </StudentRoute>
        }
      >
        <Route index element={<Navigate to="/student/dashboard" replace />} />
        <Route path="dashboard" element={<ReaderDashboardPage />} />
        <Route path="catalog" element={<ExplorePage />} />
        <Route path="books/:id" element={<BookDetailPage />} />
        <Route path="books/:bookId" element={<BookDetailPage />} />
        <Route path="borrowings" element={<Navigate to="/student/dashboard" replace />} />
        <Route path="reservations" element={<ReservationsPage />} />
        <Route path="reading-diary" element={<ReadingDiaryPage />} />
        <Route path="history" element={<ReadingHistoryPage />} />
        <Route path="want-to-read" element={<WantToReadPage />} />
        <Route path="ratings" element={<RatingsPage />} />
        <Route path="reviews" element={<ReviewsPage />} />
        <Route path="reviews/new" element={<NewReviewPage />} />
        <Route path="custom-lists" element={<MyListsPage />} />
        <Route path="custom-lists/:id" element={<ListDetailPage />} />
        <Route path="ai-assistant" element={<AIAssistantPage />} />
        <Route path="learning-paths" element={<AILearningPathPage />} />
        <Route path="notifications" element={<NotificationsPage />} />
        <Route path="profile" element={<ProfilePage />} />
      </Route>

      {/* Librarian Portal (Only Librarian Role Allowed) */}
      <Route
        path="/librarian"
        element={
          <LibrarianRoute>
            <LibrarianLayout />
          </LibrarianRoute>
        }
      >
        <Route index element={<Navigate to="/librarian/dashboard" replace />} />
        <Route path="dashboard" element={<LibrarianDashboardPage />} />
        <Route path="catalog" element={<ExplorePage />} />
        <Route path="books" element={<ManageBooksPage />} />
        <Route path="books/add" element={<AddEditBookPage />} />
        <Route path="books/:id/edit" element={<AddEditBookPage />} />
        <Route path="books/:id" element={<BookDetailPage />} />
        <Route path="books/:bookId" element={<BookDetailPage />} />
        <Route path="inventory" element={<LibrarianInventoryPage />} />
        <Route path="borrowings" element={<LibrarianBorrowingsPage />} />
        <Route path="circulation" element={<CirculationDeskPage />} />
        <Route path="returns" element={<CirculationDeskPage />} />
        <Route path="reservations" element={<AdminReservationsPage />} />
        <Route path="students" element={<StudentManagementPage />} />
        <Route path="reports" element={<AdminAnalyticsPage />} />
        <Route path="notifications" element={<StaffNotificationsPage />} />
        <Route path="settings" element={<AdminSettingsPage />} />
        <Route path="categories" element={<CategoriesPage />} />
        <Route path="authors" element={<AuthorsPage />} />
      </Route>

      {/* Legacy / Helper Redirects */}
      <Route path="/reader/*" element={<Navigate to="/student/dashboard" replace />} />
      <Route path="/admin/*" element={<Navigate to="/librarian/dashboard" replace />} />

      {/* 404 Fallback */}
      <Route element={<PublicLayout />}>
        <Route path="*" element={<NotFoundPage />} />
      </Route>
    </Routes>
  );
};

export default AppRoutes;
