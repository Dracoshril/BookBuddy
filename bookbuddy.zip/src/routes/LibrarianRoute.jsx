import React from 'react';
import { Navigate, useLocation } from 'react-router-dom';
import { useAuth } from '../hooks/useAuth';

export const LibrarianRoute = ({ children }) => {
  const { isAuthenticated, role } = useAuth();
  const location = useLocation();

  if (!isAuthenticated) {
    return <Navigate to="/auth" state={{ from: location }} replace />;
  }

  if (role !== 'librarian') {
    // If a student attempts to access librarian routes, redirect to student dashboard
    return <Navigate to="/student/dashboard" replace />;
  }

  return children;
};

export default LibrarianRoute;
