import React from 'react';
import { Navigate, useLocation } from 'react-router-dom';
import { useAuth } from '../hooks/useAuth';

export const StudentRoute = ({ children }) => {
  const { isAuthenticated, role } = useAuth();
  const location = useLocation();

  if (!isAuthenticated) {
    return <Navigate to="/auth" state={{ from: location }} replace />;
  }

  if (role !== 'student') {
    // If a librarian attempts to access student routes, redirect to librarian dashboard
    return <Navigate to="/librarian/dashboard" replace />;
  }

  return children;
};

export default StudentRoute;
