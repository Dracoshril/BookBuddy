import apiClient from './axios';

export const notificationApi = {
  getNotifications: async () => {
    const res = await apiClient.get('/notifications');
    return res.data.data;
  },

  markAsRead: async (id) => {
    const res = await apiClient.patch(`/notifications/${id}/read`);
    return res.data.data;
  },

  markAllAsRead: async () => {
    const res = await apiClient.patch('/notifications/read-all');
    return res.data.data;
  },

  addNotification: async (item) => {
    const res = await apiClient.post('/notifications', item);
    return res.data.data;
  },
};

export default notificationApi;
