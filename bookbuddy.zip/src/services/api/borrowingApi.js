import apiClient from './axios';

export const borrowingApi = {
  getAllBorrowings: async (params = {}) => {
    const res = await apiClient.get('/borrowings', { params });
    return res.data.data;
  },

  getUserBorrowings: async (userId) => {
    const res = await apiClient.get('/borrowings/me', { params: { userId } });
    return res.data.data;
  },

  borrowBook: async (data) => {
    const res = await apiClient.post('/borrowings', data);
    return res.data.data;
  },

  returnBook: async (borrowingId) => {
    const res = await apiClient.post('/borrowings/return', { borrowingId });
    return res.data.data;
  },

  renewBook: async (borrowingId) => {
    const res = await apiClient.post(`/borrowings/${borrowingId}/renew`);
    return res.data.data;
  },

  getOverdue: async () => {
    const res = await apiClient.get('/overdue');
    return res.data.data;
  },
};

export default borrowingApi;
