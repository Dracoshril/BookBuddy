import apiClient from './axios';

export const reservationApi = {
  getAllReservations: async (params = {}) => {
    const res = await apiClient.get('/reservations', { params });
    return res.data.data;
  },

  getUserReservations: async (userId) => {
    const res = await apiClient.get('/reservations/me', { params: { userId } });
    return res.data.data;
  },

  reserveBook: async (data) => {
    const res = await apiClient.post('/reservations', data);
    return res.data.data;
  },

  cancelReservation: async (id) => {
    const res = await apiClient.patch(`/reservations/${id}/cancel`);
    return res.data.data;
  },

  processReservation: async (id, status) => {
    const res = await apiClient.patch(`/reservations/${id}/status`, { status });
    return res.data.data;
  },
};

export default reservationApi;
