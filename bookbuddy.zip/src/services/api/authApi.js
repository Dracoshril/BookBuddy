import apiClient from './axios';
import { storage } from '../../utils/storage';
import { STORAGE_KEYS } from '../../utils/constants';

export const authApi = {
  login: async (identifier, password, role) => {
    const res = await apiClient.post('/auth/login', {
      username: identifier,
      password,
      role,
    });
    const { token, user } = res.data.data;
    storage.set(STORAGE_KEYS.USER, user);
    storage.set(STORAGE_KEYS.AUTH, { token });
    return { token, user };
  },

  register: async (userData) => {
    const res = await apiClient.post('/auth/register', userData);
    const { token, user } = res.data.data;
    storage.set(STORAGE_KEYS.USER, user);
    storage.set(STORAGE_KEYS.AUTH, { token });
    return { token, user };
  },

  getCurrentUser: async () => {
    try {
      const res = await apiClient.get('/auth/me');
      return res.data.data;
    } catch (e) {
      return storage.get(STORAGE_KEYS.USER, null);
    }
  },

  updateProfile: async (data) => {
    const res = await apiClient.put('/auth/me', data);
    const updated = res.data.data;
    storage.set(STORAGE_KEYS.USER, updated);
    return updated;
  },

  logout: async () => {
    try {
      await apiClient.post('/auth/logout');
    } catch (e) {
      // Ignore network logout error
    } finally {
      storage.remove(STORAGE_KEYS.USER);
      storage.remove(STORAGE_KEYS.AUTH);
    }
    return { success: true };
  },
};

export default authApi;
