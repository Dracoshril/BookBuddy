import apiClient from './axios';

export const analyticsApi = {
  getOverviewMetrics: async () => {
    const res = await apiClient.get('/analytics');
    return res.data.data;
  },

  getMonthlyBorrowingTrends: async () => {
    const res = await apiClient.get('/analytics/trends');
    return res.data.data;
  },

  getCategoryDistribution: async () => {
    const res = await apiClient.get('/analytics/categories');
    return res.data.data;
  },

  getPopularBooks: async () => {
    const res = await apiClient.get('/analytics/popular');
    return res.data.data;
  },

  getReaderReadingInsights: async (userId) => {
    const url = userId ? `/analytics/insights/${userId}` : '/analytics/insights';
    const res = await apiClient.get(url);
    return res.data.data;
  },
};

export default analyticsApi;
