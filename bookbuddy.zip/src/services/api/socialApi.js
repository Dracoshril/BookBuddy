import apiClient from './axios';

export const socialApi = {
  getActivities: async () => {
    const res = await apiClient.get('/social/activity');
    return res.data.data;
  },

  addActivity: async (activity) => {
    const res = await apiClient.post('/social/activity', activity);
    return res.data.data;
  },

  getUsers: async (params = {}) => {
    const res = await apiClient.get('/users', { params });
    return res.data.data;
  },

  getFollowing: async () => {
    const res = await apiClient.get('/social/following');
    return res.data.data;
  },

  toggleFollow: async (targetUserId) => {
    const res = await apiClient.post('/social/follow', { targetUserId });
    return res.data.data;
  },

  // Lists
  getLists: async (params = {}) => {
    const res = await apiClient.get('/lists', { params });
    return res.data.data;
  },

  getUserLists: async (userId) => {
    const res = await apiClient.get('/lists', { params: { userId } });
    return res.data.data;
  },

  getListById: async (id) => {
    const res = await apiClient.get(`/lists/${id}`);
    return res.data.data;
  },

  createList: async (data) => {
    const res = await apiClient.post('/lists', data);
    return res.data.data;
  },

  updateList: async (id, data) => {
    const res = await apiClient.put(`/lists/${id}`, data);
    return res.data.data;
  },

  deleteList: async (id) => {
    const res = await apiClient.delete(`/lists/${id}`);
    return res.data.data;
  },

  addBookToList: async (listId, bookId) => {
    const res = await apiClient.post(`/lists/${listId}/books`, { bookId });
    return res.data.data;
  },

  removeBookFromList: async (listId, bookId) => {
    const res = await apiClient.delete(`/lists/${listId}/books/${bookId}`);
    return res.data.data;
  },

  // Want to Read
  getWantToRead: async () => {
    const res = await apiClient.get('/want-to-read');
    return res.data.data;
  },

  toggleWantToRead: async (bookId) => {
    const res = await apiClient.post('/want-to-read', { bookId });
    return res.data.data;
  },

  getReadingHistory: async () => {
    const res = await apiClient.get('/history/me');
    return res.data.data;
  },
};

export default socialApi;
