import axios from 'axios';
import { storage } from '../../utils/storage';
import { STORAGE_KEYS } from '../../utils/constants';

const baseURL = import.meta.env.VITE_API_BASE_URL || '/api';

const apiClient = axios.create({
  baseURL,
  timeout: 15000,
  headers: {
    'Content-Type': 'application/json',
    Accept: 'application/json',
  },
});

apiClient.interceptors.request.use(
  (config) => {
    const auth = storage.get(STORAGE_KEYS.AUTH);
    if (auth && auth.token) {
      config.headers.Authorization = `Bearer ${auth.token}`;
    }
    return config;
  },
  (error) => Promise.reject(error)
);

apiClient.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.response && error.response.status === 401) {
      storage.remove(STORAGE_KEYS.AUTH);
      storage.remove(STORAGE_KEYS.USER);
    }
    return Promise.reject(error);
  }
);

export default apiClient;
