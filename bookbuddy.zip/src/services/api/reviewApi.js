import apiClient from './axios';

export const reviewApi = {
  getAllReviews: async () => {
    const res = await apiClient.get('/reviews');
    return res.data.data;
  },

  getBookReviews: async (bookId) => {
    const res = await apiClient.get(`/reviews?bookId=${bookId}`);
    return res.data.data;
  },

  getUserReviews: async (userId) => {
    const res = await apiClient.get('/reviews/me');
    return res.data.data;
  },

  createReview: async (reviewData) => {
    const res = await apiClient.post('/reviews', reviewData);
    return res.data.data;
  },

  updateReview: async (id, data) => {
    const res = await apiClient.put(`/reviews/${id}`, data);
    return res.data.data;
  },

  deleteReview: async (id) => {
    const res = await apiClient.delete(`/reviews/${id}`);
    return res.data.data;
  },

  toggleLike: async (id, userId) => {
    const res = await apiClient.post(`/reviews/${id}/like`, { userId });
    return res.data.data;
  },
};

export default reviewApi;
