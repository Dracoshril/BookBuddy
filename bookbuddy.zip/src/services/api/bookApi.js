import apiClient from './axios';

export const bookApi = {
  getBooks: async (params = {}) => {
    const res = await apiClient.get('/books', { params });
    return res.data.data;
  },

  getBookById: async (id) => {
    const res = await apiClient.get(`/books/${id}`);
    return res.data.data;
  },

  createBook: async (data) => {
    const res = await apiClient.post('/books', data);
    return res.data.data;
  },

  updateBook: async (id, data) => {
    const res = await apiClient.put(`/books/${id}`, data);
    return res.data.data;
  },

  deleteBook: async (id) => {
    const res = await apiClient.delete(`/books/${id}`);
    return res.data.data;
  },

  getCategories: async () => {
    const res = await apiClient.get('/books/categories');
    return res.data.data;
  },

  getAuthors: async () => {
    const res = await apiClient.get('/books/authors');
    return res.data.data;
  },
};

export default bookApi;
