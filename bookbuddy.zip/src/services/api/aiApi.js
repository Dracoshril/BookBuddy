import apiClient from './axios';

export const aiApi = {
  askAssistant: async (prompt, chatHistory = []) => {
    const res = await apiClient.post('/ai/chat', {
      prompt,
      messages: chatHistory,
    });
    return res.data.data;
  },

  getRecommendations: async () => {
    const res = await apiClient.get('/ai/recommendations');
    return res.data.data;
  },

  smartSearch: async (query) => {
    const res = await apiClient.get('/ai/search', {
      params: { q: query },
    });
    return res.data.data;
  },

  getBookSummary: async (bookId) => {
    const res = await apiClient.post('/ai/summary', { bookId });
    return res.data.data.summary;
  },

  getLearningRoadmaps: async (goal = '') => {
    const res = await apiClient.get('/ai/learning-paths', {
      params: { goal },
    });
    return res.data.data;
  },

  getInsights: async () => {
    const res = await apiClient.get('/ai/insights');
    return res.data.data;
  },
};

export default aiApi;
