import { initialUsers } from '../../data/users';
import { storage } from '../../utils/storage';
import { STORAGE_KEYS } from '../../utils/constants';

export const mockAuthService = {
  login: async (identifier, password, requiredRole) => {
    await new Promise((r) => setTimeout(r, 200));

    const idClean = identifier.trim().toLowerCase();
    const user = initialUsers.find(
      (u) =>
        u.username.toLowerCase() === idClean ||
        u.email.toLowerCase() === idClean ||
        (u.studentId && u.studentId.toLowerCase() === idClean)
    );

    if (!user) {
      throw new Error(`Account not found for "${identifier}". Please use demo credentials.`);
    }

    if (password !== 'password123') {
      throw new Error('Incorrect password. Demo password is "password123".');
    }

    if (requiredRole && user.role !== requiredRole) {
      throw new Error(
        `This account is registered as a ${user.role}. Please sign in through the ${user.role === 'student' ? 'Student' : 'Librarian'} portal.`
      );
    }

    const authData = {
      token: `mock-jwt-${user.id}-${Date.now()}`,
      expiresAt: new Date(Date.now() + 7 * 24 * 3600 * 1000).toISOString(),
    };

    storage.set(STORAGE_KEYS.USER, user);
    storage.set(STORAGE_KEYS.AUTH, authData);

    return { user, ...authData };
  },

  getCurrentUser: () => {
    return storage.get(STORAGE_KEYS.USER, null);
  },

  logout: async () => {
    await new Promise((r) => setTimeout(r, 100));
    storage.remove(STORAGE_KEYS.USER);
    storage.remove(STORAGE_KEYS.AUTH);
    return { success: true };
  },
};
