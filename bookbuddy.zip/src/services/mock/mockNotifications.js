import { subMinutes, subHours, subDays } from 'date-fns';
import { storage } from '../../utils/storage';
import { STORAGE_KEYS } from '../../utils/constants';

const now = new Date();

const defaultNotifications = [
  {
    id: "notif-1",
    userId: "user-1",
    type: "BOOK_DUE_SOON",
    title: "Loan Due in 2 Days",
    message: "System Design Interview – Volume 1 is due on " + new Date(now.getTime() + 2 * 86400000).toLocaleDateString() + ". You can renew online or return it at the circulation desk.",
    isRead: false,
    link: "/student/dashboard",
    createdAt: subHours(now, 2).toISOString()
  },
  {
    id: "notif-2",
    userId: "user-1",
    type: "RESERVED_BOOK_AVAILABLE",
    title: "Reserved Book Ready for Pickup",
    message: "Database Internals is now on Hold Shelf B. Please collect within 48 hours.",
    isRead: false,
    link: "/reader/reservations",
    createdAt: subHours(now, 5).toISOString()
  },
  {
    id: "notif-3",
    userId: "user-1",
    type: "REVIEW_LIKE",
    title: "New Review Appreciation",
    message: "Dr. Priya Sharma liked your review of Clean Code.",
    isRead: true,
    link: "/reader/reviews",
    createdAt: subDays(now, 1).toISOString()
  },
  {
    id: "notif-4",
    userId: "user-1",
    type: "NEW_FOLLOWER",
    title: "New Reader Follower",
    message: "Elena Rostova started following your reading diary.",
    isRead: true,
    link: "/reader/following",
    createdAt: subDays(now, 2).toISOString()
  }
];

export const getStoredNotifications = () => {
  return storage.get(STORAGE_KEYS.NOTIFICATIONS, defaultNotifications);
};

export const saveNotifications = (notifications) => {
  storage.set(STORAGE_KEYS.NOTIFICATIONS, notifications);
};
