import { initialBorrowings } from '../../data/borrowings';
import { storage } from '../../utils/storage';
import { STORAGE_KEYS } from '../../utils/constants';
import { addDays } from 'date-fns';
import { mockBookService } from './mockBooks';

export const getStoredBorrowings = () => {
  return storage.get(STORAGE_KEYS.BORROWINGS, initialBorrowings);
};

export const saveBorrowings = (borrowings) => {
  storage.set(STORAGE_KEYS.BORROWINGS, borrowings);
};

export const mockBorrowingService = {
  getAll: async () => {
    await new Promise((r) => setTimeout(r, 150));
    return getStoredBorrowings();
  },

  getByUserId: async (userId) => {
    await new Promise((r) => setTimeout(r, 120));
    const borrowings = getStoredBorrowings();
    return borrowings.filter((b) => b.userId === userId);
  },

  borrow: async ({ userId, bookId, dueDate, notes }) => {
    await new Promise((r) => setTimeout(r, 200));
    const book = await mockBookService.getById(bookId);
    if (book.availableCopies <= 0) {
      throw new Error('This book is currently out of stock.');
    }

    // Decrement physical copy
    await mockBookService.decrementAvailableCopies(bookId);

    const borrowings = getStoredBorrowings();
    const newBorrowing = {
      id: `bor-${Date.now()}`,
      userId,
      bookId: String(book.id),
      bookNumber: book.bookNumber,
      title: book.title,
      author: book.author,
      category: book.category,
      borrowDate: new Date().toISOString(),
      dueDate: dueDate || addDays(new Date(), 14).toISOString(),
      returnDate: null,
      status: 'CURRENT',
      renewalCount: 0,
      fineAmount: 0,
      notes: notes || ''
    };

    const updated = [newBorrowing, ...borrowings];
    saveBorrowings(updated);
    return newBorrowing;
  },

  returnBook: async (borrowingId) => {
    await new Promise((r) => setTimeout(r, 200));
    const borrowings = getStoredBorrowings();
    const index = borrowings.findIndex((b) => b.id === borrowingId);
    if (index === -1) throw new Error('Borrowing record not found');

    const borrowing = borrowings[index];
    if (borrowing.status === 'RETURNED') {
      throw new Error('This book has already been returned.');
    }

    borrowing.status = 'RETURNED';
    borrowing.returnDate = new Date().toISOString();

    // Increment physical copy back
    await mockBookService.incrementAvailableCopies(borrowing.bookId);

    saveBorrowings([...borrowings]);
    return borrowing;
  },

  renewBook: async (borrowingId) => {
    await new Promise((r) => setTimeout(r, 150));
    const borrowings = getStoredBorrowings();
    const index = borrowings.findIndex((b) => b.id === borrowingId);
    if (index === -1) throw new Error('Borrowing record not found');

    const borrowing = borrowings[index];
    if (borrowing.renewalCount >= 2) {
      throw new Error('Maximum renewal limit (2 times) reached for this loan.');
    }

    borrowing.renewalCount += 1;
    borrowing.dueDate = addDays(new Date(borrowing.dueDate), 14).toISOString();
    borrowing.status = 'CURRENT';

    saveBorrowings([...borrowings]);
    return borrowing;
  }
};
