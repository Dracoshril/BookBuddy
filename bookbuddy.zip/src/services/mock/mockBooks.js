import { initialBooks } from '../../data/books';
import { storage } from '../../utils/storage';
import { STORAGE_KEYS } from '../../utils/constants';

export const getStoredBooks = () => {
  return storage.get(STORAGE_KEYS.BOOKS, initialBooks);
};

export const saveBooks = (books) => {
  storage.set(STORAGE_KEYS.BOOKS, books);
};

export const mockBookService = {
  getAll: async () => {
    await new Promise((r) => setTimeout(r, 150));
    return getStoredBooks();
  },

  getById: async (id) => {
    await new Promise((r) => setTimeout(r, 100));
    const books = getStoredBooks();
    const found = books.find((b) => String(b.id) === String(id));
    if (!found) throw new Error('Book not found in library catalog');
    return found;
  },

  create: async (bookData) => {
    await new Promise((r) => setTimeout(r, 200));
    const books = getStoredBooks();
    const newBook = {
      ...bookData,
      id: String(books.length + 1),
      bookNumber: bookData.bookNumber || `BK-${String(books.length + 1).padStart(4, '0')}`,
      rating: 0,
      reviewCount: 0,
      borrowCount: 0,
      status: Number(bookData.availableCopies) > 0 ? 'AVAILABLE' : 'ISSUED',
      createdAt: new Date().toISOString(),
    };
    const updated = [newBook, ...books];
    saveBooks(updated);
    return newBook;
  },

  update: async (id, updates) => {
    await new Promise((r) => setTimeout(r, 200));
    const books = getStoredBooks();
    const index = books.findIndex((b) => String(b.id) === String(id));
    if (index === -1) throw new Error('Book not found to update');

    const updatedBook = {
      ...books[index],
      ...updates,
      status: Number(updates.availableCopies !== undefined ? updates.availableCopies : books[index].availableCopies) > 0 ? 'AVAILABLE' : 'ISSUED'
    };
    books[index] = updatedBook;
    saveBooks([...books]);
    return updatedBook;
  },

  delete: async (id) => {
    await new Promise((r) => setTimeout(r, 150));
    const books = getStoredBooks();
    const filtered = books.filter((b) => String(b.id) !== String(id));
    saveBooks(filtered);
    return { success: true };
  },

  decrementAvailableCopies: async (bookId) => {
    const books = getStoredBooks();
    const index = books.findIndex((b) => String(b.id) === String(bookId));
    if (index === -1) throw new Error('Book not found');
    const book = books[index];
    if (book.availableCopies <= 0) {
      throw new Error('No physical copies currently available for issue');
    }
    const newAvail = book.availableCopies - 1;
    book.availableCopies = newAvail;
    book.borrowCount = (book.borrowCount || 0) + 1;
    book.status = newAvail > 0 ? 'AVAILABLE' : 'ISSUED';
    saveBooks([...books]);
    return book;
  },

  incrementAvailableCopies: async (bookId) => {
    const books = getStoredBooks();
    const index = books.findIndex((b) => String(b.id) === String(bookId));
    if (index === -1) throw new Error('Book not found');
    const book = books[index];
    const newAvail = Math.min(book.totalCopies, book.availableCopies + 1);
    book.availableCopies = newAvail;
    book.status = newAvail > 0 ? 'AVAILABLE' : 'ISSUED';
    saveBooks([...books]);
    return book;
  }
};
