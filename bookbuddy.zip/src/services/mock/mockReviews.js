import { initialReviews } from '../../data/reviews';
import { storage } from '../../utils/storage';
import { STORAGE_KEYS } from '../../utils/constants';

export const getStoredReviews = () => {
  return storage.get(STORAGE_KEYS.REVIEWS, initialReviews);
};

export const saveReviews = (reviews) => {
  storage.set(STORAGE_KEYS.REVIEWS, reviews);
};

export const mockReviewService = {
  getAll: async () => {
    await new Promise((r) => setTimeout(r, 120));
    return getStoredReviews();
  },

  getByBookId: async (bookId) => {
    await new Promise((r) => setTimeout(r, 100));
    const reviews = getStoredReviews();
    return reviews.filter((r) => String(r.bookId) === String(bookId));
  },

  getByUserId: async (userId) => {
    await new Promise((r) => setTimeout(r, 100));
    const reviews = getStoredReviews();
    return reviews.filter((r) => r.userId === userId);
  },

  create: async ({ bookId, bookTitle, userId, userName, userRole, rating, title, content }) => {
    await new Promise((r) => setTimeout(r, 200));
    const reviews = getStoredReviews();
    const newReview = {
      id: `rev-${Date.now()}`,
      bookId: String(bookId),
      bookTitle,
      userId,
      userName,
      userRole: userRole || 'STUDENT',
      rating: Number(rating),
      title: title || 'Reader Review',
      content,
      likesCount: 0,
      likedBy: [],
      comments: [],
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };

    const updated = [newReview, ...reviews];
    saveReviews(updated);
    return newReview;
  },

  update: async (id, { rating, title, content }) => {
    await new Promise((r) => setTimeout(r, 150));
    const reviews = getStoredReviews();
    const index = reviews.findIndex((r) => r.id === id);
    if (index === -1) throw new Error('Review not found');

    reviews[index] = {
      ...reviews[index],
      rating: Number(rating),
      title,
      content,
      updatedAt: new Date().toISOString()
    };
    saveReviews([...reviews]);
    return reviews[index];
  },

  delete: async (id) => {
    await new Promise((r) => setTimeout(r, 150));
    const reviews = getStoredReviews();
    const filtered = reviews.filter((r) => r.id !== id);
    saveReviews(filtered);
    return { success: true };
  },

  toggleLike: async (id, userId) => {
    await new Promise((r) => setTimeout(r, 100));
    const reviews = getStoredReviews();
    const index = reviews.findIndex((r) => r.id === id);
    if (index === -1) throw new Error('Review not found');

    const review = reviews[index];
    const isLiked = review.likedBy.includes(userId);
    if (isLiked) {
      review.likedBy = review.likedBy.filter((u) => u !== userId);
      review.likesCount = Math.max(0, review.likesCount - 1);
    } else {
      review.likedBy.push(userId);
      review.likesCount += 1;
    }

    saveReviews([...reviews]);
    return review;
  }
};
