import { initialReservations } from '../../data/reservations';
import { storage } from '../../utils/storage';
import { STORAGE_KEYS } from '../../utils/constants';
import { addDays } from 'date-fns';
import { mockBookService } from './mockBooks';

export const getStoredReservations = () => {
  return storage.get(STORAGE_KEYS.RESERVATIONS, initialReservations);
};

export const saveReservations = (reservations) => {
  storage.set(STORAGE_KEYS.RESERVATIONS, reservations);
};

export const mockReservationService = {
  getAll: async () => {
    await new Promise((r) => setTimeout(r, 150));
    return getStoredReservations();
  },

  getByUserId: async (userId) => {
    await new Promise((r) => setTimeout(r, 120));
    const reservations = getStoredReservations();
    return reservations.filter((r) => r.userId === userId);
  },

  reserve: async ({ userId, bookId }) => {
    await new Promise((r) => setTimeout(r, 200));
    const book = await mockBookService.getById(bookId);
    const reservations = getStoredReservations();

    const existing = reservations.find(
      (r) => r.userId === userId && r.bookId === String(bookId) && (r.status === 'WAITING' || r.status === 'AVAILABLE' || r.status === 'RESERVED')
    );
    if (existing) {
      throw new Error('You already have an active hold / reservation for this book.');
    }

    const currentBookReservations = reservations.filter(
      (r) => r.bookId === String(bookId) && (r.status === 'WAITING' || r.status === 'RESERVED')
    );

    const isDirectlyAvailable = book.availableCopies > 0;
    const newReservation = {
      id: `res-${Date.now()}`,
      userId,
      bookId: String(book.id),
      bookNumber: book.bookNumber,
      title: book.title,
      author: book.author,
      category: book.category,
      reservationDate: new Date().toISOString(),
      queuePosition: isDirectlyAvailable ? 1 : currentBookReservations.length + 1,
      status: isDirectlyAvailable ? 'AVAILABLE' : 'WAITING',
      expiryDate: addDays(new Date(), 2).toISOString(),
      notes: isDirectlyAvailable
        ? 'Reserved and ready for pickup at Main Circulation Desk.'
        : `Hold placed. Queue position #${currentBookReservations.length + 1}.`
    };

    const updated = [newReservation, ...reservations];
    saveReservations(updated);
    return newReservation;
  },

  cancel: async (reservationId) => {
    await new Promise((r) => setTimeout(r, 150));
    const reservations = getStoredReservations();
    const index = reservations.findIndex((r) => r.id === reservationId);
    if (index === -1) throw new Error('Reservation not found');

    reservations[index].status = 'CANCELLED';
    saveReservations([...reservations]);
    return reservations[index];
  },

  processAdmin: async (reservationId, status) => {
    await new Promise((r) => setTimeout(r, 150));
    const reservations = getStoredReservations();
    const index = reservations.findIndex((r) => r.id === reservationId);
    if (index === -1) throw new Error('Reservation not found');

    reservations[index].status = status;
    saveReservations([...reservations]);
    return reservations[index];
  }
};
