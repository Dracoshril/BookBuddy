import { initialLists } from '../../data/activities';
import { storage } from '../../utils/storage';
import { STORAGE_KEYS } from '../../utils/constants';

export const getStoredLists = () => {
  return storage.get(STORAGE_KEYS.LISTS, initialLists);
};

export const saveLists = (lists) => {
  storage.set(STORAGE_KEYS.LISTS, lists);
};

export const getStoredWantToRead = () => {
  return storage.get(STORAGE_KEYS.WANT_TO_READ, ['2', '6', '11', '16']); // default seeded want to read book IDs
};

export const saveWantToRead = (bookIds) => {
  storage.set(STORAGE_KEYS.WANT_TO_READ, bookIds);
};

export const mockListService = {
  getAll: async () => {
    await new Promise((r) => setTimeout(r, 120));
    return getStoredLists();
  },

  getByUserId: async (userId) => {
    await new Promise((r) => setTimeout(r, 100));
    const lists = getStoredLists();
    return lists.filter((l) => l.userId === userId);
  },

  getById: async (id) => {
    await new Promise((r) => setTimeout(r, 100));
    const lists = getStoredLists();
    const found = lists.find((l) => l.id === id);
    if (!found) throw new Error('List not found');
    return found;
  },

  create: async ({ userId, title, description, isPublic = true, books = [] }) => {
    await new Promise((r) => setTimeout(r, 150));
    const lists = getStoredLists();
    const newList = {
      id: `list-${Date.now()}`,
      userId,
      title,
      description: description || '',
      isPublic,
      books,
      createdAt: new Date().toISOString(),
      likesCount: 0
    };
    const updated = [newList, ...lists];
    saveLists(updated);
    return newList;
  },

  update: async (id, updates) => {
    await new Promise((r) => setTimeout(r, 150));
    const lists = getStoredLists();
    const index = lists.findIndex((l) => l.id === id);
    if (index === -1) throw new Error('List not found');

    lists[index] = { ...lists[index], ...updates };
    saveLists([...lists]);
    return lists[index];
  },

  delete: async (id) => {
    await new Promise((r) => setTimeout(r, 150));
    const lists = getStoredLists();
    const filtered = lists.filter((l) => l.id !== id);
    saveLists(filtered);
    return { success: true };
  },

  addBook: async (listId, bookId) => {
    const lists = getStoredLists();
    const index = lists.findIndex((l) => l.id === listId);
    if (index === -1) throw new Error('List not found');

    if (!lists[index].books.includes(String(bookId))) {
      lists[index].books.push(String(bookId));
      saveLists([...lists]);
    }
    return lists[index];
  },

  removeBook: async (listId, bookId) => {
    const lists = getStoredLists();
    const index = lists.findIndex((l) => l.id === listId);
    if (index === -1) throw new Error('List not found');

    lists[index].books = lists[index].books.filter((id) => id !== String(bookId));
    saveLists([...lists]);
    return lists[index];
  },

  // Want to Read Helpers
  getWantToRead: async () => {
    await new Promise((r) => setTimeout(r, 100));
    return getStoredWantToRead();
  },

  toggleWantToRead: async (bookId) => {
    await new Promise((r) => setTimeout(r, 100));
    const ids = getStoredWantToRead();
    const bId = String(bookId);
    let updated;
    const exists = ids.includes(bId);
    if (exists) {
      updated = ids.filter((id) => id !== bId);
    } else {
      updated = [bId, ...ids];
    }
    saveWantToRead(updated);
    return { bookId: bId, isSaved: !exists, items: updated };
  }
};
