export const appConfig = {
  appName: 'BookBuddy',
  version: '1.0.0',
  description: 'AI-Powered Physical Library, Social Reading & Personalized Learning Platform',
  apiBaseUrl: import.meta.env.VITE_API_BASE_URL || '/api',
  supportEmail: 'library@university.edu',
  libraryLocation: 'Central University Campus, Building 4, Knowledge Commons',
  defaultTheme: 'light',
  demoCredentials: [
    { role: 'STUDENT', id: 'student001', name: 'Vishal Gayathri', password: 'password123', label: 'Student Demo' },
    { role: 'TEACHER', id: 'teacher001', name: 'Dr. Priya Sharma', password: 'password123', label: 'Faculty Demo' },
    { role: 'LIBRARIAN', id: 'librarian001', name: 'Sarah Jenkins', password: 'password123', label: 'Librarian Demo' },
    { role: 'ADMIN', id: 'admin001', name: 'Marcus Vance', password: 'password123', label: 'Admin Demo' },
  ],
};
