export const initialCategories = [
  { id: 'cat-1', name: 'Programming', slug: 'programming', description: 'Software engineering, language syntaxes, best practices and paradigms.', bookCount: 12 },
  { id: 'cat-2', name: 'DSA', slug: 'dsa', description: 'Data structures, algorithmic analysis, complexity, and problem solving.', bookCount: 8 },
  { id: 'cat-3', name: 'Artificial Intelligence', slug: 'ai', description: 'Machine learning, deep learning, NLP, LLMs, and computer vision.', bookCount: 7 },
  { id: 'cat-4', name: 'Database', slug: 'database', description: 'Relational databases, SQL, NoSQL, storage engines, and indexing.', bookCount: 5 },
  { id: 'cat-5', name: 'System Design', slug: 'system-design', description: 'Distributed systems, microservices, scalability, and cloud architecture.', bookCount: 6 },
  { id: 'cat-6', name: 'Science', slug: 'science', description: 'Physics, computational biology, neuroscience, and quantum computing.', bookCount: 4 },
  { id: 'cat-7', name: 'Business', slug: 'business', description: 'Product management, technology entrepreneurship, and economics.', bookCount: 5 },
  { id: 'cat-8', name: 'Mathematics', slug: 'mathematics', description: 'Linear algebra, discrete math, calculus, and probability.', bookCount: 4 },
  { id: 'cat-9', name: 'Fiction', slug: 'fiction', description: 'Hard science fiction, speculative futures, and classic literature.', bookCount: 4 },
  { id: 'cat-10', name: 'Self Development', slug: 'self-development', description: 'Focus, habit formation, deep work, and learning methodologies.', bookCount: 5 },
  { id: 'cat-11', name: 'E-Book', slug: 'e-book', description: 'Digital books, interactive guides, and downloadable e-publications.', bookCount: 3 },
];
