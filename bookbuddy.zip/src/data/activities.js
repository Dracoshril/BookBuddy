import { subHours, subDays } from 'date-fns';

const now = new Date();

export const initialActivities = [
  {
    id: "act-1",
    type: "BOOK_FINISHED",
    userId: "user-1",
    userName: "Vishal Gayathri",
    userRole: "STUDENT",
    bookId: "1",
    bookTitle: "Clean Code",
    bookCoverGradient: "from-sky-700 to-indigo-900",
    rating: 5,
    timestamp: subHours(now, 3).toISOString(),
    details: "Finished reading and added to personal diary."
  },
  {
    id: "act-2",
    type: "REVIEW_POSTED",
    userId: "user-2",
    userName: "Priya Sharma",
    userRole: "STUDENT",
    bookId: "2",
    bookTitle: "Designing Data-Intensive Applications",
    bookCoverGradient: "from-rose-800 to-red-950",
    rating: 5,
    timestamp: subHours(now, 8).toISOString(),
    details: "Posted a 5-star review: 'The modern holy grail of distributed databases'"
  },
  {
    id: "act-3",
    type: "LIST_CREATED",
    userId: "user-6",
    userName: "Elena Rostova",
    userRole: "STUDENT",
    listTitle: "AI & Multimodal Foundations 2026",
    bookCount: 6,
    timestamp: subDays(now, 1).toISOString(),
    details: "Curated a new public reading list for senior year researchers."
  },
  {
    id: "act-4",
    type: "BOOK_RATED",
    userId: "user-5",
    userName: "Arun Patel",
    userRole: "STUDENT",
    bookId: "7",
    bookTitle: "Atomic Habits",
    bookCoverGradient: "from-yellow-700 to-amber-900",
    rating: 4,
    timestamp: subDays(now, 2).toISOString(),
    details: "Rated 4 out of 5 stars."
  },
  {
    id: "act-5",
    type: "FOLLOW_EVENT",
    userId: "user-1",
    userName: "Vishal Gayathri",
    targetUserName: "Priya Sharma",
    timestamp: subDays(now, 3).toISOString(),
    details: "Started following Priya Sharma."
  }
];

export const initialLists = [
  {
    id: "list-1",
    userId: "user-1",
    title: "Java Backend Mastery Roadmap",
    description: "Crucial books for understanding Java internals, concurrency, Spring framework, and enterprise patterns.",
    isPublic: true,
    books: ["4", "1", "40", "5", "2"],
    createdAt: subDays(now, 15).toISOString(),
    likesCount: 38
  },
  {
    id: "list-2",
    userId: "user-1",
    title: "Semester Placement Preparation (DSA)",
    description: "Core algorithms, data structures, and problem-solving strategies for engineering tech rounds.",
    isPublic: true,
    books: ["12", "15", "3", "5"],
    createdAt: subDays(now, 22).toISOString(),
    likesCount: 56
  },
  {
    id: "list-3",
    userId: "user-2",
    title: "Distributed Systems & Cloud Architecture (Curated by Tech Leads)",
    description: "Recommended reading list for CS 412 Distributed Systems course.",
    isPublic: true,
    books: ["2", "17", "18", "19", "36"],
    createdAt: subDays(now, 30).toISOString(),
    likesCount: 112
  },
  {
    id: "list-4",
    userId: "user-6",
    title: "Generative AI & LLM Systems",
    description: "From classic deep learning textbooks to hands-on foundation model deployment.",
    isPublic: true,
    books: ["6", "13", "20", "42"],
    createdAt: subDays(now, 10).toISOString(),
    likesCount: 74
  }
];
