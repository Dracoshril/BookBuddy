export const initialAuthors = [
  { id: 'auth-1', name: 'Robert C. Martin', bio: 'Renowned software craftsman, author of Clean Code and Clean Architecture.', bookCount: 3 },
  { id: 'auth-2', name: 'Martin Kleppmann', bio: 'Researcher in distributed systems and security at the University of Cambridge.', bookCount: 2 },
  { id: 'auth-3', name: 'Thomas H. Cormen', bio: 'Professor of Computer Science Emeritus at Dartmouth College.', bookCount: 1 },
  { id: 'auth-4', name: 'Joshua Bloch', bio: 'Former Chief Java Architect at Google and author of Effective Java.', bookCount: 1 },
  { id: 'auth-5', name: 'Alex Xu', bio: 'Software engineer and author of System Design Interview series.', bookCount: 2 },
  { id: 'auth-6', name: 'Stuart Russell', bio: 'Professor of Computer Science at UC Berkeley, pioneer in AI research.', bookCount: 1 },
  { id: 'auth-7', name: 'James Clear', bio: 'Author of the #1 New York Times bestseller Atomic Habits.', bookCount: 1 },
  { id: 'auth-8', name: 'Cal Newport', bio: 'Associate Professor of Computer Science at Georgetown University.', bookCount: 2 },
  { id: 'auth-9', name: 'Eric Evans', bio: 'Thought leader in software design and creator of Domain-Driven Design.', bookCount: 1 },
  { id: 'auth-10', name: 'Andrew Ng', bio: 'Founder of DeepLearning.AI and Adjunct Professor at Stanford.', bookCount: 1 },
  { id: 'auth-11', name: 'Kyle Simpson', bio: 'Passionate JavaScript evangelist and author of You Don’t Know JS.', bookCount: 2 },
  { id: 'auth-12', name: 'Gilbert Strang', bio: 'Professor of Mathematics at MIT, renowned linear algebra educator.', bookCount: 1 },
];
