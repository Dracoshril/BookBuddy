import { addDays, subDays } from 'date-fns';

const now = new Date();

export const initialBorrowings = [
  {
    id: "bor-1",
    userId: "user-1",
    bookId: "1", // Clean Code
    borrowDate: subDays(now, 7).toISOString(),
    dueDate: addDays(now, 7).toISOString(),
    returnDate: null,
    status: "CURRENT",
    renewalCount: 0,
    fineAmount: 0,
    bookNumber: "BK-0001",
    title: "Clean Code: A Handbook of Agile Software Craftsmanship",
    author: "Robert C. Martin",
    category: "Programming"
  },
  {
    id: "bor-2",
    userId: "user-1",
    bookId: "5", // System Design Interview
    borrowDate: subDays(now, 12).toISOString(),
    dueDate: addDays(now, 2).toISOString(),
    returnDate: null,
    status: "DUE_SOON",
    renewalCount: 1,
    fineAmount: 0,
    bookNumber: "BK-0005",
    title: "System Design Interview – An Insider's Guide (Volume 1)",
    author: "Alex Xu",
    category: "System Design"
  },
  {
    id: "bor-3",
    userId: "user-1",
    bookId: "3", // CLRS Algorithms
    borrowDate: subDays(now, 20).toISOString(),
    dueDate: subDays(now, 6).toISOString(),
    returnDate: null,
    status: "OVERDUE",
    renewalCount: 2,
    fineAmount: 6.0,
    bookNumber: "BK-0003",
    title: "Introduction to Algorithms (CLRS)",
    author: "Thomas H. Cormen",
    category: "DSA"
  },
  {
    id: "bor-4",
    userId: "user-1",
    bookId: "7", // Atomic Habits
    borrowDate: subDays(now, 45).toISOString(),
    dueDate: subDays(now, 31).toISOString(),
    returnDate: subDays(now, 33).toISOString(),
    status: "RETURNED",
    renewalCount: 0,
    fineAmount: 0,
    bookNumber: "BK-0007",
    title: "Atomic Habits: An Easy & Proven Way to Build Good Habits",
    author: "James Clear",
    category: "Self Development"
  },
  {
    id: "bor-5",
    userId: "user-1",
    bookId: "2", // Designing Data-Intensive Applications
    borrowDate: subDays(now, 70).toISOString(),
    dueDate: subDays(now, 56).toISOString(),
    returnDate: subDays(now, 55).toISOString(),
    status: "RETURNED",
    renewalCount: 1,
    fineAmount: 0,
    bookNumber: "BK-0002",
    title: "Designing Data-Intensive Applications",
    author: "Martin Kleppmann",
    category: "Database"
  },
  {
    id: "bor-6",
    userId: "user-5", // Arun
    bookId: "27", // Dune
    borrowDate: subDays(now, 10).toISOString(),
    dueDate: addDays(now, 4).toISOString(),
    returnDate: null,
    status: "CURRENT",
    renewalCount: 0,
    fineAmount: 0,
    bookNumber: "BK-0027",
    title: "Dune",
    author: "Frank Herbert",
    category: "Fiction"
  },
  {
    id: "bor-7",
    userId: "user-6", // Elena
    bookId: "20", // Hands-on ML
    borrowDate: subDays(now, 18).toISOString(),
    dueDate: subDays(now, 4).toISOString(),
    returnDate: null,
    status: "OVERDUE",
    renewalCount: 1,
    fineAmount: 4.0,
    bookNumber: "BK-0020",
    title: "Hands-On Machine Learning with Scikit-Learn, Keras, and TensorFlow",
    author: "Aurélien Géron",
    category: "Artificial Intelligence"
  }
];
