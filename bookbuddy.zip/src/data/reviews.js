import { subDays } from 'date-fns';

const now = new Date();

export const initialReviews = [
  {
    id: "rev-1",
    bookId: "1",
    bookTitle: "Clean Code",
    userId: "user-1",
    userName: "Vishal Gayathri",
    userRole: "STUDENT",
    rating: 5,
    title: "Essential for every serious student engineer",
    content: "Reading Clean Code completely changed how I name variables and structure functions. The chapters on error handling, meaningful naming, and unit tests should be required reading in second-year CS labs.",
    likesCount: 24,
    likedBy: ["user-2", "user-5", "user-6"],
    comments: [
      { id: "c-1", userName: "Dr. Priya Sharma", text: "Spot on! We emphasize the Single Responsibility Principle directly from Chapter 3 in our advanced design labs.", createdAt: subDays(now, 2).toISOString() }
    ],
    createdAt: subDays(now, 4).toISOString(),
    updatedAt: subDays(now, 4).toISOString()
  },
  {
    id: "rev-2",
    bookId: "2",
    bookTitle: "Designing Data-Intensive Applications",
    userId: "user-2",
    userName: "Priya Sharma",
    userRole: "STUDENT",
    rating: 5,
    title: "The modern holy grail of distributed databases",
    content: "Martin Kleppmann delivers a masterclass. The balance between theory (consensus, linearizability) and practical storage engine trade-offs (LSM vs B-Tree) is unmatched anywhere in academic literature.",
    likesCount: 42,
    likedBy: ["user-1", "user-4", "user-6"],
    comments: [],
    createdAt: subDays(now, 10).toISOString(),
    updatedAt: subDays(now, 10).toISOString()
  },
  {
    id: "rev-3",
    bookId: "7",
    bookTitle: "Atomic Habits",
    userId: "user-5",
    userName: "Arun Patel",
    userRole: "STUDENT",
    rating: 4,
    title: "Practical systems over vague motivation",
    content: "Atomic Habits helped me establish an uninterrupted 2-hour morning coding block before lectures. The 2-minute rule really prevents procrastination.",
    likesCount: 15,
    likedBy: ["user-1"],
    comments: [],
    createdAt: subDays(now, 8).toISOString(),
    updatedAt: subDays(now, 8).toISOString()
  },
  {
    id: "rev-4",
    bookId: "5",
    bookTitle: "System Design Interview – Volume 1",
    userId: "user-6",
    userName: "Elena Rostova",
    userRole: "STUDENT",
    rating: 5,
    title: "Brilliant visual blueprints for campus placements",
    content: "The diagrams for consistent hashing, rate limiters, and message queues make high-level architecture digestible in a single weekend.",
    likesCount: 19,
    likedBy: ["user-1", "user-2"],
    comments: [],
    createdAt: subDays(now, 14).toISOString(),
    updatedAt: subDays(now, 14).toISOString()
  },
  {
    id: "rev-5",
    bookId: "27",
    bookTitle: "Dune",
    userId: "user-3",
    userName: "Sarah Jenkins",
    userRole: "LIBRARIAN",
    rating: 5,
    title: "Ecological and political masterpiece",
    content: "Re-reading Dune in our university book club reminded me of Herbert's astounding foresight regarding ecology, water scarcity, and political messianism.",
    likesCount: 31,
    likedBy: ["user-1", "user-5"],
    comments: [],
    createdAt: subDays(now, 20).toISOString(),
    updatedAt: subDays(now, 20).toISOString()
  }
];
