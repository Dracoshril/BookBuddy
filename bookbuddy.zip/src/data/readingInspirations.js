export const readingInspirations = [
  {
    id: 1,
    text: "Every book opens a door to another world.",
    attribution: "— BookBuddy Reading Inspiration",
    author: "BookBuddy Reading Inspiration"
  },
  {
    id: 2,
    text: "Reading is a journey that begins with a single page.",
    attribution: "— BookBuddy Reading Inspiration",
    author: "BookBuddy Reading Inspiration"
  },
  {
    id: 3,
    text: "A library is where stories come alive.",
    attribution: "— BookBuddy Reading Inspiration",
    author: "BookBuddy Reading Inspiration"
  },
  {
    id: 4,
    text: "One book can change the way you see the world.",
    attribution: "— BookBuddy Reading Inspiration",
    author: "BookBuddy Reading Inspiration"
  },
  {
    id: 5,
    text: "Books are the quietest and most powerful companions.",
    attribution: "— BookBuddy Reading Inspiration",
    author: "BookBuddy Reading Inspiration"
  },
  {
    id: 6,
    text: "Every page is a new place to explore.",
    attribution: "— BookBuddy Reading Inspiration",
    author: "BookBuddy Reading Inspiration"
  },
  {
    id: 7,
    text: "A reader lives a thousand lives before he dies.",
    attribution: "— George R.R. Martin",
    author: "George R.R. Martin"
  },
  {
    id: 8,
    text: "A library is not a luxury, but one of the necessities of life.",
    attribution: "— Henry Ward Beecher",
    author: "Henry Ward Beecher"
  },
  {
    id: 9,
    text: "The more that you read, the more things you will know.",
    attribution: "— Dr. Seuss",
    author: "Dr. Seuss"
  },
  {
    id: 10,
    text: "Books are a uniquely portable magic.",
    attribution: "— Stephen King",
    author: "Stephen King"
  }
];

/**
 * Returns a randomly selected English reading quote,
 * avoiding repeating the exact same item consecutively where possible.
 */
export const getRandomReadingInspiration = () => {
  if (!readingInspirations || readingInspirations.length === 0) return null;

  let lastIndex = -1;
  try {
    const saved = sessionStorage.getItem('bookbuddy_last_inspiration_idx');
    if (saved !== null) {
      lastIndex = parseInt(saved, 10);
    }
  } catch {
    // Ignore sessionStorage errors
  }

  let nextIndex = Math.floor(Math.random() * readingInspirations.length);
  if (nextIndex === lastIndex && readingInspirations.length > 1) {
    nextIndex = (nextIndex + 1 + Math.floor(Math.random() * (readingInspirations.length - 1))) % readingInspirations.length;
  }

  try {
    sessionStorage.setItem('bookbuddy_last_inspiration_idx', String(nextIndex));
  } catch {
    // Ignore sessionStorage errors
  }

  return readingInspirations[nextIndex];
};
