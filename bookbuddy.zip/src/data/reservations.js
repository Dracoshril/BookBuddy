import { subDays, addDays } from 'date-fns';

const now = new Date();

export const initialReservations = [
  {
    id: "res-1",
    userId: "user-1",
    bookId: "3", // CLRS
    bookNumber: "BK-0003",
    title: "Introduction to Algorithms (CLRS)",
    author: "Thomas H. Cormen",
    category: "DSA",
    reservationDate: subDays(now, 3).toISOString(),
    queuePosition: 1,
    status: "WAITING",
    expiryDate: addDays(now, 5).toISOString(),
    notes: "Awaiting return of loan copy."
  },
  {
    id: "res-2",
    userId: "user-1",
    bookId: "17", // Database Internals
    bookNumber: "BK-0017",
    title: "Database Internals: A Deep Dive into How Distributed Systems Store Data",
    author: "Alex Petrov",
    category: "Database",
    reservationDate: subDays(now, 1).toISOString(),
    queuePosition: 1,
    status: "AVAILABLE",
    expiryDate: addDays(now, 2).toISOString(),
    notes: "Ready for pickup at Central Circulation Desk (Hold Shelf B)."
  },
  {
    id: "res-3",
    userId: "user-5",
    bookId: "28", // Three-Body Problem
    bookNumber: "BK-0028",
    title: "The Three-Body Problem",
    author: "Cixin Liu",
    category: "Fiction",
    reservationDate: subDays(now, 5).toISOString(),
    queuePosition: 2,
    status: "WAITING",
    expiryDate: addDays(now, 7).toISOString(),
    notes: "Queue order: #2"
  },
  {
    id: "res-4",
    userId: "user-1",
    bookId: "25", // Zero to One
    bookNumber: "BK-0025",
    title: "Zero to One: Notes on Startups",
    author: "Peter Thiel",
    category: "Business",
    reservationDate: subDays(now, 40).toISOString(),
    queuePosition: 0,
    status: "COMPLETED",
    expiryDate: null,
    notes: "Checked out successfully on Jan 24."
  }
];
