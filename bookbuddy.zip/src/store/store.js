import { configureStore } from '@reduxjs/toolkit';
import authReducer from './slices/authSlice';
import booksReducer from './slices/booksSlice';
import borrowingsReducer from './slices/borrowingsSlice';
import reservationReducer from './slices/reservationSlice';
import notificationReducer from './slices/notificationSlice';
import socialReducer from './slices/socialSlice';
import aiReducer from './slices/aiSlice';
import analyticsReducer from './slices/analyticsSlice';
import listReducer from './slices/listSlice';
import uiReducer from './slices/uiSlice';

export const store = configureStore({
  reducer: {
    auth: authReducer,
    books: booksReducer,
    borrowings: borrowingsReducer,
    reservations: reservationReducer,
    notifications: notificationReducer,
    social: socialReducer,
    ai: aiReducer,
    analytics: analyticsReducer,
    lists: listReducer,
    ui: uiReducer,
  },
  middleware: (getDefaultMiddleware) =>
    getDefaultMiddleware({
      serializableCheck: false,
    }),
});

export default store;
