import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import { aiApi } from '../../services/api/aiApi';

export const sendChatMessage = createAsyncThunk(
  'ai/sendMessage',
  async (prompt, { getState }) => {
    const { ai } = getState();
    return await aiApi.askAssistant(prompt, ai.messages);
  }
);

export const fetchAIRecommendations = createAsyncThunk(
  'ai/fetchRecommendations',
  async () => {
    return await aiApi.getRecommendations();
  }
);

export const performSmartSearch = createAsyncThunk(
  'ai/smartSearch',
  async (query) => {
    return await aiApi.smartSearch(query);
  }
);

export const fetchLearningRoadmaps = createAsyncThunk(
  'ai/fetchLearningRoadmaps',
  async () => {
    return await aiApi.getLearningRoadmaps();
  }
);

const initialMessages = [
  {
    role: 'assistant',
    content: `Welcome to **BookBuddy AI Assistant**! I am connected to our campus library catalog, physical rack locators, and academic course paths.

Ask me anything like:
* *"Find beginner Java books and where they are placed"*
* *"Where is Clean Code located?"*
* *"Create an algorithms and data structures learning path"*
* *"Explain binary search vs hash tables"*`,
  },
];

const aiSlice = createSlice({
  name: 'ai',
  initialState: {
    messages: initialMessages,
    recommendations: [],
    roadmaps: [],
    smartSearchResult: null,
    isThinking: false,
    error: null,
  },
  reducers: {
    clearChat: (state) => {
      state.messages = initialMessages;
    },
    addLocalUserMessage: (state, action) => {
      state.messages.push({ role: 'user', content: action.payload });
    },
  },
  extraReducers: (builder) => {
    builder
      .addCase(sendChatMessage.pending, (state) => {
        state.isThinking = true;
      })
      .addCase(sendChatMessage.fulfilled, (state, action) => {
        state.isThinking = false;
        state.messages.push(action.payload);
      })
      .addCase(sendChatMessage.rejected, (state, action) => {
        state.isThinking = false;
        state.error = action.error.message;
      })
      .addCase(fetchAIRecommendations.fulfilled, (state, action) => {
        state.recommendations = action.payload;
      })
      .addCase(performSmartSearch.fulfilled, (state, action) => {
        state.smartSearchResult = action.payload;
      })
      .addCase(fetchLearningRoadmaps.fulfilled, (state, action) => {
        state.roadmaps = action.payload;
      });
  },
});

export const { clearChat, addLocalUserMessage } = aiSlice.actions;
export default aiSlice.reducer;
