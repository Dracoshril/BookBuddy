import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import { analyticsApi } from '../../services/api/analyticsApi';

export const fetchOverviewMetrics = createAsyncThunk(
  'analytics/fetchOverview',
  async () => {
    return await analyticsApi.getOverviewMetrics();
  }
);

export const fetchBorrowingTrends = createAsyncThunk(
  'analytics/fetchTrends',
  async () => {
    return await analyticsApi.getMonthlyBorrowingTrends();
  }
);

export const fetchCategoryDistribution = createAsyncThunk(
  'analytics/fetchCategoryDist',
  async () => {
    return await analyticsApi.getCategoryDistribution();
  }
);

export const fetchPopularBooks = createAsyncThunk(
  'analytics/fetchPopularBooks',
  async () => {
    return await analyticsApi.getPopularBooks();
  }
);

export const fetchReaderInsights = createAsyncThunk(
  'analytics/fetchReaderInsights',
  async (userId) => {
    return await analyticsApi.getReaderReadingInsights(userId);
  }
);

const analyticsSlice = createSlice({
  name: 'analytics',
  initialState: {
    overview: null,
    borrowingTrends: [],
    categories: [],
    popularBooks: [],
    readerInsights: null,
    isLoading: false,
  },
  reducers: {},
  extraReducers: (builder) => {
    builder
      .addCase(fetchOverviewMetrics.fulfilled, (state, action) => {
        state.overview = action.payload;
      })
      .addCase(fetchBorrowingTrends.fulfilled, (state, action) => {
        state.borrowingTrends = action.payload;
      })
      .addCase(fetchCategoryDistribution.fulfilled, (state, action) => {
        state.categories = action.payload;
      })
      .addCase(fetchPopularBooks.fulfilled, (state, action) => {
        state.popularBooks = action.payload;
      })
      .addCase(fetchReaderInsights.fulfilled, (state, action) => {
        state.readerInsights = action.payload;
      });
  },
});

export default analyticsSlice.reducer;
