import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import { socialApi } from '../../services/api/socialApi';
import { reviewApi } from '../../services/api/reviewApi';

export const fetchActivities = createAsyncThunk('social/fetchActivities', async () => {
  return await socialApi.getActivities();
});

export const fetchFollowing = createAsyncThunk('social/fetchFollowing', async () => {
  return await socialApi.getFollowing();
});

export const toggleFollowUser = createAsyncThunk('social/toggleFollow', async (targetUserId) => {
  return await socialApi.toggleFollow(targetUserId);
});

export const fetchAllReviews = createAsyncThunk('social/fetchAllReviews', async () => {
  return await reviewApi.getAllReviews();
});

export const addReview = createAsyncThunk('social/addReview', async (data) => {
  return await reviewApi.createReview(data);
});

export const toggleReviewLike = createAsyncThunk('social/toggleLike', async ({ id, userId }) => {
  return await reviewApi.toggleLike(id, userId);
});

const socialSlice = createSlice({
  name: 'social',
  initialState: {
    activities: [],
    following: [],
    reviews: [],
    isLoading: false,
    error: null,
  },
  reducers: {},
  extraReducers: (builder) => {
    builder
      .addCase(fetchActivities.fulfilled, (state, action) => {
        state.activities = action.payload;
      })
      .addCase(fetchFollowing.fulfilled, (state, action) => {
        state.following = action.payload;
      })
      .addCase(toggleFollowUser.fulfilled, (state, action) => {
        state.following = action.payload.following;
      })
      .addCase(fetchAllReviews.fulfilled, (state, action) => {
        state.reviews = action.payload;
      })
      .addCase(addReview.fulfilled, (state, action) => {
        state.reviews.unshift(action.payload);
      })
      .addCase(toggleReviewLike.fulfilled, (state, action) => {
        const index = state.reviews.findIndex((r) => r.id === action.payload.id);
        if (index !== -1) {
          state.reviews[index] = action.payload;
        }
      });
  },
});

export default socialSlice.reducer;
