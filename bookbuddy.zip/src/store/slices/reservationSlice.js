import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import { reservationApi } from '../../services/api/reservationApi';

export const fetchUserReservations = createAsyncThunk(
  'reservations/fetchUserReservations',
  async (userId) => {
    return await reservationApi.getUserReservations(userId);
  }
);

export const fetchAllReservations = createAsyncThunk(
  'reservations/fetchAllReservations',
  async () => {
    return await reservationApi.getAllReservations();
  }
);

export const createReservation = createAsyncThunk(
  'reservations/createReservation',
  async (data) => {
    return await reservationApi.reserveBook(data);
  }
);

export const cancelReservationAction = createAsyncThunk(
  'reservations/cancelReservation',
  async (id) => {
    return await reservationApi.cancelReservation(id);
  }
);

export const processReservationAction = createAsyncThunk(
  'reservations/processReservation',
  async ({ id, status }) => {
    return await reservationApi.processReservation(id, status);
  }
);

const reservationSlice = createSlice({
  name: 'reservations',
  initialState: {
    items: [],
    allAdminReservations: [],
    isLoading: false,
    error: null,
  },
  reducers: {},
  extraReducers: (builder) => {
    builder
      .addCase(fetchUserReservations.pending, (state) => {
        state.isLoading = true;
      })
      .addCase(fetchUserReservations.fulfilled, (state, action) => {
        state.isLoading = false;
        state.items = action.payload;
      })
      .addCase(fetchUserReservations.rejected, (state, action) => {
        state.isLoading = false;
        state.error = action.error.message;
      })
      .addCase(fetchAllReservations.fulfilled, (state, action) => {
        state.allAdminReservations = action.payload;
      })
      .addCase(createReservation.fulfilled, (state, action) => {
        state.items.unshift(action.payload);
        state.allAdminReservations.unshift(action.payload);
      })
      .addCase(cancelReservationAction.fulfilled, (state, action) => {
        const index = state.items.findIndex((r) => r.id === action.payload.id);
        if (index !== -1) {
          state.items[index] = action.payload;
        }
      })
      .addCase(processReservationAction.fulfilled, (state, action) => {
        const adminIndex = state.allAdminReservations.findIndex((r) => r.id === action.payload.id);
        if (adminIndex !== -1) {
          state.allAdminReservations[adminIndex] = action.payload;
        }
      });
  },
});

export default reservationSlice.reducer;
