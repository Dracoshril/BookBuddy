import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import { borrowingApi } from '../../services/api/borrowingApi';

export const fetchUserBorrowings = createAsyncThunk(
  'borrowings/fetchUserBorrowings',
  async (userId) => {
    return await borrowingApi.getUserBorrowings(userId);
  }
);

export const fetchAllBorrowings = createAsyncThunk(
  'borrowings/fetchAllBorrowings',
  async () => {
    return await borrowingApi.getAllBorrowings();
  }
);

export const borrowBookAction = createAsyncThunk(
  'borrowings/borrowBook',
  async (data) => {
    return await borrowingApi.borrowBook(data);
  }
);

export const returnBookAction = createAsyncThunk(
  'borrowings/returnBook',
  async (borrowingId) => {
    return await borrowingApi.returnBook(borrowingId);
  }
);

export const renewBookAction = createAsyncThunk(
  'borrowings/renewBook',
  async (borrowingId) => {
    return await borrowingApi.renewBook(borrowingId);
  }
);

const borrowingsSlice = createSlice({
  name: 'borrowings',
  initialState: {
    items: [],
    allAdminBorrowings: [],
    isLoading: false,
    error: null,
  },
  reducers: {},
  extraReducers: (builder) => {
    builder
      .addCase(fetchUserBorrowings.pending, (state) => {
        state.isLoading = true;
      })
      .addCase(fetchUserBorrowings.fulfilled, (state, action) => {
        state.isLoading = false;
        state.items = action.payload;
      })
      .addCase(fetchUserBorrowings.rejected, (state, action) => {
        state.isLoading = false;
        state.error = action.error.message;
      })
      .addCase(fetchAllBorrowings.fulfilled, (state, action) => {
        state.allAdminBorrowings = action.payload;
      })
      .addCase(borrowBookAction.fulfilled, (state, action) => {
        state.items.unshift(action.payload);
        state.allAdminBorrowings.unshift(action.payload);
      })
      .addCase(returnBookAction.fulfilled, (state, action) => {
        const index = state.items.findIndex((b) => b.id === action.payload.id);
        if (index !== -1) {
          state.items[index] = action.payload;
        }
        const adminIndex = state.allAdminBorrowings.findIndex((b) => b.id === action.payload.id);
        if (adminIndex !== -1) {
          state.allAdminBorrowings[adminIndex] = action.payload;
        }
      })
      .addCase(renewBookAction.fulfilled, (state, action) => {
        const index = state.items.findIndex((b) => b.id === action.payload.id);
        if (index !== -1) {
          state.items[index] = action.payload;
        }
      });
  },
});

export default borrowingsSlice.reducer;
