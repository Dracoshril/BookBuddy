import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import { bookApi } from '../../services/api/bookApi';

export const fetchBooks = createAsyncThunk('books/fetchBooks', async (params) => {
  return await bookApi.getBooks(params);
});

export const fetchBookById = createAsyncThunk('books/fetchBookById', async (id) => {
  return await bookApi.getBookById(id);
});

export const addNewBook = createAsyncThunk('books/addNewBook', async (data) => {
  return await bookApi.createBook(data);
});

export const updateExistingBook = createAsyncThunk('books/updateBook', async ({ id, data }) => {
  return await bookApi.updateBook(id, data);
});

export const removeBook = createAsyncThunk('books/removeBook', async (id) => {
  await bookApi.deleteBook(id);
  return id;
});

const booksSlice = createSlice({
  name: 'books',
  initialState: {
    items: [],
    total: 0,
    currentPage: 1,
    totalPages: 1,
    selectedBook: null,
    isLoading: false,
    error: null,
    filters: {
      category: 'all',
      search: '',
      availability: 'all',
      sortBy: 'popular',
    },
  },
  reducers: {
    setFilters: (state, action) => {
      state.filters = { ...state.filters, ...action.payload };
    },
    resetFilters: (state) => {
      state.filters = {
        category: 'all',
        search: '',
        availability: 'all',
        sortBy: 'popular',
      };
    },
    setSelectedBook: (state, action) => {
      state.selectedBook = action.payload;
    },
  },
  extraReducers: (builder) => {
    builder
      .addCase(fetchBooks.pending, (state) => {
        state.isLoading = true;
      })
      .addCase(fetchBooks.fulfilled, (state, action) => {
        state.isLoading = false;
        state.items = action.payload.books;
        state.total = action.payload.total;
        state.currentPage = action.payload.page;
        state.totalPages = action.payload.totalPages;
      })
      .addCase(fetchBooks.rejected, (state, action) => {
        state.isLoading = false;
        state.error = action.error.message;
      })
      .addCase(fetchBookById.fulfilled, (state, action) => {
        state.selectedBook = action.payload;
      })
      .addCase(addNewBook.fulfilled, (state, action) => {
        state.items.unshift(action.payload);
        state.total += 1;
      })
      .addCase(updateExistingBook.fulfilled, (state, action) => {
        const index = state.items.findIndex((b) => b.id === action.payload.id);
        if (index !== -1) {
          state.items[index] = action.payload;
        }
        if (state.selectedBook?.id === action.payload.id) {
          state.selectedBook = action.payload;
        }
      })
      .addCase(removeBook.fulfilled, (state, action) => {
        state.items = state.items.filter((b) => b.id !== action.payload);
        state.total = Math.max(0, state.total - 1);
      });
  },
});

export const { setFilters, resetFilters, setSelectedBook } = booksSlice.actions;
export default booksSlice.reducer;
