import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import { authApi } from '../../services/api/authApi';
import { storage } from '../../utils/storage';
import { STORAGE_KEYS } from '../../utils/constants';

const storedUser = storage.get(STORAGE_KEYS.USER, null);
const storedAuth = storage.get(STORAGE_KEYS.AUTH, null);

export const loginUser = createAsyncThunk(
  'auth/login',
  async ({ username, password, role }, { rejectWithValue }) => {
    try {
      const response = await authApi.login(username, password, role);
      return response;
    } catch (error) {
      return rejectWithValue(error.message || 'Login failed');
    }
  }
);

export const logoutUser = createAsyncThunk('auth/logout', async () => {
  await authApi.logout();
  return null;
});

const authSlice = createSlice({
  name: 'auth',
  initialState: {
    user: storedUser,
    token: storedAuth?.token || null,
    isAuthenticated: Boolean(storedUser && storedAuth?.token),
    isLoading: false,
    error: null,
  },
  reducers: {
    setAuthUser: (state, action) => {
      const { user, token } = action.payload;
      state.user = user;
      state.token = token || `token-${Date.now()}`;
      state.isAuthenticated = true;
      storage.set(STORAGE_KEYS.USER, user);
      storage.set(STORAGE_KEYS.AUTH, { token: state.token });
    },
    clearError: (state) => {
      state.error = null;
    },
    updateProfile: (state, action) => {
      if (state.user) {
        state.user = { ...state.user, ...action.payload };
        storage.set(STORAGE_KEYS.USER, state.user);
      }
    },
  },
  extraReducers: (builder) => {
    builder
      .addCase(loginUser.pending, (state) => {
        state.isLoading = true;
        state.error = null;
      })
      .addCase(loginUser.fulfilled, (state, action) => {
        state.isLoading = false;
        state.isAuthenticated = true;
        state.user = action.payload.user;
        state.token = action.payload.token;
      })
      .addCase(loginUser.rejected, (state, action) => {
        state.isLoading = false;
        state.error = action.payload;
      })
      .addCase(logoutUser.fulfilled, (state) => {
        state.user = null;
        state.token = null;
        state.isAuthenticated = false;
        state.error = null;
      });
  },
});

export const { setAuthUser, clearError, updateProfile } = authSlice.actions;
export default authSlice.reducer;
