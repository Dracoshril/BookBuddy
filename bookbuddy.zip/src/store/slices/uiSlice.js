import { createSlice } from '@reduxjs/toolkit';
import { storage } from '../../utils/storage';
import { STORAGE_KEYS } from '../../utils/constants';

const applyThemeToDOM = (theme) => {
  if (typeof document === 'undefined') return;
  const root = document.documentElement;
  if (theme === 'dark') {
    root.classList.add('dark');
    root.setAttribute('data-theme', 'dark');
    root.style.colorScheme = 'dark';
  } else {
    root.classList.remove('dark');
    root.setAttribute('data-theme', 'light');
    root.style.colorScheme = 'light';
  }
};

const storedTheme = storage.get(STORAGE_KEYS.THEME, 'dark');
applyThemeToDOM(storedTheme);

const uiSlice = createSlice({
  name: 'ui',
  initialState: {
    theme: storedTheme,
    sidebarCollapsed: false,
    mobileMenuOpen: false,
    commandPaletteOpen: false,
    activeModal: null, // { type: 'BORROW' | 'RESERVE' | 'PREVIEW' | 'REVIEW', data: any }
  },
  reducers: {
    toggleTheme: (state) => {
      state.theme = state.theme === 'light' ? 'dark' : 'light';
      storage.set(STORAGE_KEYS.THEME, state.theme);
      applyThemeToDOM(state.theme);
    },
    setTheme: (state, action) => {
      state.theme = action.payload;
      storage.set(STORAGE_KEYS.THEME, action.payload);
      applyThemeToDOM(state.theme);
    },
    toggleSidebar: (state) => {
      state.sidebarCollapsed = !state.sidebarCollapsed;
    },
    setMobileMenuOpen: (state, action) => {
      state.mobileMenuOpen = action.payload;
    },
    setCommandPaletteOpen: (state, action) => {
      state.commandPaletteOpen = action.payload;
    },
    openModal: (state, action) => {
      state.activeModal = action.payload;
    },
    closeModal: (state) => {
      state.activeModal = null;
    },
  },
});

export const {
  toggleTheme,
  setTheme,
  toggleSidebar,
  setMobileMenuOpen,
  setCommandPaletteOpen,
  openModal,
  closeModal,
} = uiSlice.actions;

export default uiSlice.reducer;
