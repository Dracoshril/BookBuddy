import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import { socialApi } from '../../services/api/socialApi';

export const fetchLists = createAsyncThunk('lists/fetchLists', async () => {
  return await socialApi.getLists();
});

export const fetchWantToRead = createAsyncThunk('lists/fetchWantToRead', async () => {
  return await socialApi.getWantToRead();
});

export const toggleWantToReadBook = createAsyncThunk('lists/toggleWantToRead', async (bookId) => {
  return await socialApi.toggleWantToRead(bookId);
});

export const createNewList = createAsyncThunk('lists/createNewList', async (data) => {
  return await socialApi.createList(data);
});

export const deleteUserList = createAsyncThunk('lists/deleteUserList', async (id) => {
  await socialApi.deleteList(id);
  return id;
});

const listSlice = createSlice({
  name: 'lists',
  initialState: {
    lists: [],
    wantToReadBookIds: ['2', '6', '11', '16'],
    isLoading: false,
  },
  reducers: {},
  extraReducers: (builder) => {
    builder
      .addCase(fetchLists.fulfilled, (state, action) => {
        state.lists = action.payload;
      })
      .addCase(fetchWantToRead.fulfilled, (state, action) => {
        state.wantToReadBookIds = action.payload;
      })
      .addCase(toggleWantToReadBook.fulfilled, (state, action) => {
        state.wantToReadBookIds = action.payload.items;
      })
      .addCase(createNewList.fulfilled, (state, action) => {
        state.lists.unshift(action.payload);
      })
      .addCase(deleteUserList.fulfilled, (state, action) => {
        state.lists = state.lists.filter((l) => l.id !== action.payload);
      });
  },
});

export default listSlice.reducer;
