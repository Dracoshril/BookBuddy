import React from 'react';
import { cn } from '../../utils/helpers';

export const Avatar = ({ name = '', src = '', size = 'md', className, role = '' }) => {
  const sizes = {
    sm: 'w-7 h-7 text-xs',
    md: 'w-9 h-9 text-sm',
    lg: 'w-12 h-12 text-base font-semibold',
    xl: 'w-16 h-16 text-xl font-bold',
  };

  const getInitials = (n) => {
    if (!n) return '?';
    return n
      .split(' ')
      .map((part) => part[0])
      .join('')
      .toUpperCase()
      .slice(0, 2);
  };

  // Consistent background color based on name string
  const colors = [
    'bg-sky-600',
    'bg-emerald-600',
    'bg-amber-600',
    'bg-indigo-600',
    'bg-rose-600',
    'bg-violet-600',
    'bg-teal-600',
  ];
  const colorIndex = (name.charCodeAt(0) || 0) % colors.length;
  const bgColor = colors[colorIndex];

  return (
    <div
      className={cn(
        'relative rounded-full flex items-center justify-center font-medium text-white shrink-0 overflow-hidden select-none border border-neutral-200 dark:border-neutral-800',
        bgColor,
        sizes[size],
        className
      )}
      title={name}
    >
      {src ? (
        <img
          src={src}
          alt={name}
          referrerPolicy="no-referrer"
          className="w-full h-full object-cover"
          onError={(e) => {
            e.currentTarget.style.display = 'none';
          }}
        />
      ) : (
        <span>{getInitials(name)}</span>
      )}
    </div>
  );
};

export default Avatar;
