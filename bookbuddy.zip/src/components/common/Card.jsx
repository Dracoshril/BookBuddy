import React from 'react';
import { cn } from '../../utils/helpers';

export const Card = ({ children, className, hoverEffect = false, ...props }) => {
  return (
    <div
      className={cn(
        'rounded-2xl border border-slate-200 dark:border-white/[0.08] bg-white dark:bg-[#0D1B31] p-5 sm:p-6 text-slate-900 dark:text-[#F5F7FA] shadow-xs transition-all duration-200',
        hoverEffect && 'hover:border-blue-500/40 dark:hover:border-blue-500/40 hover:shadow-lg dark:hover:shadow-blue-950/20',
        className
      )}
      {...props}
    >
      {children}
    </div>
  );
};

export const CardHeader = ({ title, subtitle, action, className }) => {
  return (
    <div className={cn('flex items-start justify-between gap-4 mb-4', className)}>
      <div>
        <h3 className="font-semibold text-base text-slate-900 dark:text-white tracking-tight">
          {title}
        </h3>
        {subtitle && (
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">{subtitle}</p>
        )}
      </div>
      {action && <div className="shrink-0">{action}</div>}
    </div>
  );
};

export default Card;
