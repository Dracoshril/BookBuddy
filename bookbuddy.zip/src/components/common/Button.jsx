import React from 'react';
import { cn } from '../../utils/helpers';
import { Loader2 } from 'lucide-react';

export const Button = React.forwardRef(
  (
    {
      children,
      className,
      variant = 'primary',
      size = 'md',
      isLoading = false,
      disabled = false,
      type = 'button',
      leftIcon,
      rightIcon,
      ...props
    },
    ref
  ) => {
    const baseStyles =
      'inline-flex items-center justify-center font-medium transition-all focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-500 focus-visible:ring-offset-2 disabled:opacity-50 disabled:pointer-events-none whitespace-nowrap shrink-0 rounded-xl select-none cursor-pointer';

    const variants = {
      primary:
        'bg-[#1677FF] text-white hover:bg-[#238BFF] shadow-md shadow-blue-600/25 active:scale-[0.99] font-semibold',
      secondary:
        'bg-slate-100 text-slate-900 hover:bg-slate-200 dark:bg-[#0D1F38] dark:text-slate-100 dark:hover:bg-[#13243F] border border-slate-200 dark:border-white/[0.08]',
      outline:
        'border border-slate-300 bg-transparent text-slate-800 hover:bg-slate-100 dark:border-white/[0.12] dark:text-slate-200 dark:hover:bg-white/[0.05]',
      ghost:
        'bg-transparent text-slate-700 hover:bg-slate-100 hover:text-slate-900 dark:text-slate-300 dark:hover:bg-white/[0.05] dark:hover:text-white',
      danger:
        'bg-rose-600 text-white hover:bg-rose-700 shadow-md shadow-rose-600/20 active:scale-[0.99]',
      accent:
        'bg-sky-500 text-white hover:bg-sky-600 shadow-md shadow-sky-500/25 active:scale-[0.99]',
    };

    const sizes = {
      sm: 'text-xs py-1.5 px-3 gap-1.5',
      md: 'text-sm py-2 px-4 gap-2',
      lg: 'text-base py-2.5 px-5 gap-2.5',
      icon: 'p-2',
    };

    return (
      <button
        ref={ref}
        type={type}
        disabled={disabled || isLoading}
        className={cn(baseStyles, variants[variant], sizes[size], className)}
        {...props}
      >
        {isLoading && <Loader2 className="w-4 h-4 animate-spin shrink-0" />}
        {!isLoading && leftIcon && <span className="shrink-0">{leftIcon}</span>}
        <span className="truncate">{children}</span>
        {!isLoading && rightIcon && <span className="shrink-0">{rightIcon}</span>}
      </button>
    );
  }
);

Button.displayName = 'Button';
export default Button;
