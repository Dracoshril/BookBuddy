import React from 'react';
import { BookOpen } from 'lucide-react';
import { Button } from './Button';
import { cn } from '../../utils/helpers';

export const EmptyState = ({
  icon: Icon = BookOpen,
  title = 'No items found',
  description = 'There is currently no data matching your query or selection.',
  actionLabel,
  onAction,
  className,
}) => {
  return (
    <div
      className={cn(
        'flex flex-col items-center justify-center p-8 sm:p-12 text-center rounded-xl border border-dashed border-neutral-300 dark:border-neutral-800 bg-neutral-50/50 dark:bg-neutral-900/30',
        className
      )}
    >
      <div className="p-3.5 rounded-full bg-neutral-100 text-neutral-500 dark:bg-neutral-800 dark:text-neutral-400 mb-4">
        <Icon className="w-6 h-6" />
      </div>
      <h4 className="text-base font-semibold text-neutral-900 dark:text-neutral-100 mb-1">
        {title}
      </h4>
      <p className="text-xs text-neutral-500 dark:text-neutral-400 max-w-sm mb-6 leading-relaxed">
        {description}
      </p>
      {actionLabel && onAction && (
        <Button variant="primary" size="sm" onClick={onAction}>
          {actionLabel}
        </Button>
      )}
    </div>
  );
};

export default EmptyState;
