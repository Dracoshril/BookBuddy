import React from 'react';

export const SkeletonCard = () => {
  return (
    <div className="rounded-xl border border-neutral-200/80 bg-white p-4 dark:border-neutral-800 dark:bg-neutral-900 animate-pulse">
      <div className="aspect-[3/4] w-full rounded-lg bg-neutral-200 dark:bg-neutral-800 mb-3" />
      <div className="h-4 bg-neutral-200 dark:bg-neutral-800 rounded w-3/4 mb-2" />
      <div className="h-3 bg-neutral-200 dark:bg-neutral-800 rounded w-1/2 mb-4" />
      <div className="flex items-center justify-between pt-2 border-t border-neutral-100 dark:border-neutral-800">
        <div className="h-3 bg-neutral-200 dark:bg-neutral-800 rounded w-16" />
        <div className="h-3 bg-neutral-200 dark:bg-neutral-800 rounded w-12" />
      </div>
    </div>
  );
};

export const SkeletonTable = ({ rows = 5 }) => {
  return (
    <div className="w-full space-y-3 animate-pulse">
      <div className="h-10 bg-neutral-100 dark:bg-neutral-800 rounded-lg w-full" />
      {Array.from({ length: rows }).map((_, i) => (
        <div key={i} className="h-14 bg-neutral-50 dark:bg-neutral-900/60 rounded-lg w-full flex items-center px-4 gap-4">
          <div className="h-4 bg-neutral-200 dark:bg-neutral-800 rounded w-12" />
          <div className="h-4 bg-neutral-200 dark:bg-neutral-800 rounded w-1/3" />
          <div className="h-4 bg-neutral-200 dark:bg-neutral-800 rounded w-1/4" />
          <div className="h-4 bg-neutral-200 dark:bg-neutral-800 rounded w-16 ml-auto" />
        </div>
      ))}
    </div>
  );
};
