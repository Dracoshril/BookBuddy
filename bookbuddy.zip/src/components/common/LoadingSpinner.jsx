import React from 'react';
import { Loader2 } from 'lucide-react';
import { cn } from '../../utils/helpers';

export const LoadingSpinner = ({ size = 'md', text = 'Loading data...', className }) => {
  const sizes = {
    sm: 'w-4 h-4',
    md: 'w-6 h-6',
    lg: 'w-8 h-8',
  };

  return (
    <div className={cn('flex flex-col items-center justify-center py-12 gap-3', className)}>
      <Loader2 className={cn('animate-spin text-neutral-800 dark:text-neutral-200', sizes[size])} />
      {text && <p className="text-xs text-neutral-500 dark:text-neutral-400 font-medium">{text}</p>}
    </div>
  );
};

export default LoadingSpinner;
