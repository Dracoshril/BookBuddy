import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useDispatch, useSelector } from 'react-redux';
import { setCommandPaletteOpen } from '../../store/slices/uiSlice';
import { Search, Book, Sparkles, User, Bell, LayoutDashboard, Bookmark, Compass, X } from 'lucide-react';
import { initialBooks } from '../../data/books';

export const CommandPalette = () => {
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const isOpen = useSelector((state) => state.ui.commandPaletteOpen);
  const [query, setQuery] = useState('');

  // Keyboard shortcut listener (Cmd/Ctrl + K)
  useEffect(() => {
    const handleKeyDown = (e) => {
      if ((e.metaKey || e.ctrlKey) && e.key === 'k') {
        e.preventDefault();
        dispatch(setCommandPaletteOpen(!isOpen));
      } else if (e.key === 'Escape' && isOpen) {
        dispatch(setCommandPaletteOpen(false));
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [dispatch, isOpen]);

  if (!isOpen) return null;

  const quickNav = [
    { label: 'Explore All Books', path: '/explore', icon: Compass, category: 'Navigation' },
    { label: 'Reader Dashboard', path: '/reader/dashboard', icon: LayoutDashboard, category: 'Navigation' },
    { label: 'AI Assistant & Roadmap Builder', path: '/ai/assistant', icon: Sparkles, category: 'AI Tools' },
    { label: 'AI Smart Catalog Search', path: '/ai/search', icon: Search, category: 'AI Tools' },
    { label: 'Want-to-Read Shelf', path: '/reader/want-to-read', icon: Bookmark, category: 'Personal' },
    { label: 'Notifications Center', path: '/reader/notifications', icon: Bell, category: 'Personal' },
    { label: 'My Reader Profile', path: '/reader/profile', icon: User, category: 'Account' },
    { label: 'Admin & Librarian Console', path: '/admin/dashboard', icon: LayoutDashboard, category: 'Admin' },
  ];

  const filteredBooks = query.trim()
    ? initialBooks
        .filter(
          (b) =>
            b.title.toLowerCase().includes(query.toLowerCase()) ||
            b.author.toLowerCase().includes(query.toLowerCase()) ||
            b.category.toLowerCase().includes(query.toLowerCase())
        )
        .slice(0, 5)
    : [];

  const handleSelect = (path) => {
    navigate(path);
    dispatch(setCommandPaletteOpen(false));
    setQuery('');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-start justify-center pt-20 p-4 overflow-y-auto">
      <div
        className="fixed inset-0 bg-black/60 backdrop-blur-xs transition-opacity"
        onClick={() => dispatch(setCommandPaletteOpen(false))}
      />

      <div className="relative z-10 w-full max-w-xl rounded-2xl border border-neutral-200 bg-white shadow-2xl dark:border-neutral-800 dark:bg-neutral-900 overflow-hidden animate-in zoom-in-95 duration-150">
        {/* Search Input */}
        <div className="flex items-center px-4 py-3.5 border-b border-neutral-100 dark:border-neutral-800">
          <Search className="w-4 h-4 text-neutral-400 shrink-0 mr-3" />
          <input
            autoFocus
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Type a book, command, or shelf query... (e.g. 'Clean Code')"
            className="w-full bg-transparent text-sm text-neutral-900 dark:text-neutral-100 placeholder:text-neutral-400 focus:outline-none"
          />
          <kbd className="hidden sm:inline-block px-1.5 py-0.5 text-[10px] font-mono font-medium rounded border border-neutral-200 dark:border-neutral-700 text-neutral-400">
            ESC
          </kbd>
        </div>

        <div className="max-h-80 overflow-y-auto p-2 space-y-4">
          {/* Books matched */}
          {filteredBooks.length > 0 && (
            <div>
              <div className="px-3 py-1 text-[10px] font-mono uppercase text-neutral-400 tracking-wider">
                Matching Books
              </div>
              {filteredBooks.map((book) => (
                <button
                  key={book.id}
                  onClick={() => handleSelect(`/books/${book.id}`)}
                  className="w-full flex items-center justify-between px-3 py-2 rounded-lg hover:bg-neutral-100 dark:hover:bg-neutral-800 text-left transition-colors cursor-pointer group"
                >
                  <div className="truncate pr-3">
                    <span className="text-xs font-semibold text-neutral-900 dark:text-neutral-100 group-hover:text-amber-600 block truncate">
                      {book.title}
                    </span>
                    <span className="text-[11px] text-neutral-500 truncate block">
                      {book.author} · Rack {book.rackNumber}, Shelf {book.shelfNumber}
                    </span>
                  </div>
                  <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-neutral-100 dark:bg-neutral-800 text-neutral-600 dark:text-neutral-300 shrink-0">
                    {book.status}
                  </span>
                </button>
              ))}
            </div>
          )}

          {/* Quick Actions */}
          <div>
            <div className="px-3 py-1 text-[10px] font-mono uppercase text-neutral-400 tracking-wider">
              System Actions
            </div>
            {quickNav.map((action, idx) => {
              const Icon = action.icon;
              return (
                <button
                  key={idx}
                  onClick={() => handleSelect(action.path)}
                  className="w-full flex items-center gap-3 px-3 py-2 rounded-lg hover:bg-neutral-100 dark:hover:bg-neutral-800 text-left transition-colors cursor-pointer text-xs font-medium text-neutral-700 dark:text-neutral-300"
                >
                  <Icon className="w-4 h-4 text-neutral-400 shrink-0" />
                  <span className="truncate">{action.label}</span>
                </button>
              );
            })}
          </div>
        </div>

        <div className="px-4 py-2 bg-neutral-50 dark:bg-neutral-900/50 border-t border-neutral-100 dark:border-neutral-800 text-[11px] text-neutral-400 flex items-center justify-between">
          <span>Use ⌘K to open anytime</span>
          <span>BookBuddy Global Search</span>
        </div>
      </div>
    </div>
  );
};

export default CommandPalette;
