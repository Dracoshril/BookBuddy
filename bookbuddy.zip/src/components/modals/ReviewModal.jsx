import React, { useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { Modal } from '../common/Modal';
import { Button } from '../common/Button';
import { Input } from '../common/Input';
import { closeModal } from '../../store/slices/uiSlice';
import { addReview } from '../../store/slices/socialSlice';
import { Star } from 'lucide-react';
import { toast } from 'sonner';

export const ReviewModal = () => {
  const dispatch = useDispatch();
  const { activeModal } = useSelector((state) => state.ui);
  const { user } = useSelector((state) => state.auth);

  const [rating, setRating] = useState(5);
  const [hoverRating, setHoverRating] = useState(0);
  const [title, setTitle] = useState('');
  const [content, setContent] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  const isOpen = activeModal?.type === 'REVIEW';
  const book = activeModal?.data;

  if (!isOpen || !book) return null;

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!content.trim()) {
      toast.error('Please provide your review thoughts or notes.');
      return;
    }

    setIsSubmitting(true);
    try {
      await dispatch(
        addReview({
          bookId: book.id,
          bookTitle: book.title,
          userId: user?.id || 'user-1',
          userName: user?.name || 'Vishal Gayathri',
          userRole: user?.role || 'STUDENT',
          rating,
          title: title.trim() || 'Reader Review',
          content: content.trim(),
        })
      ).unwrap();

      toast.success('Your review was posted to the BookBuddy community!');
      dispatch(closeModal());
      setTitle('');
      setContent('');
      setRating(5);
    } catch (err) {
      toast.error(err.message || 'Failed to post review');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <Modal
      isOpen={isOpen}
      onClose={() => dispatch(closeModal())}
      title="Write a Community Review"
      description={`Share your thoughts on "${book.title}"`}
    >
      <form onSubmit={handleSubmit} className="space-y-4">
        {/* Rating Stars */}
        <div>
          <label className="block text-xs font-semibold text-neutral-700 dark:text-neutral-300 mb-2">
            Your Rating
          </label>
          <div className="flex items-center gap-1.5">
            {[1, 2, 3, 4, 5].map((star) => (
              <button
                key={star}
                type="button"
                onClick={() => setRating(star)}
                onMouseEnter={() => setHoverRating(star)}
                onMouseLeave={() => setHoverRating(0)}
                className="p-1 rounded-md hover:bg-neutral-100 dark:hover:bg-neutral-800 transition-colors cursor-pointer"
              >
                <Star
                  className={`w-6 h-6 transition-colors ${
                    (hoverRating || rating) >= star
                      ? 'fill-amber-400 text-amber-400'
                      : 'text-neutral-300 dark:text-neutral-700'
                  }`}
                />
              </button>
            ))}
            <span className="text-xs font-semibold text-neutral-600 dark:text-neutral-400 ml-2">
              {rating} of 5 Stars
            </span>
          </div>
        </div>

        {/* Title */}
        <Input
          label="Headline"
          placeholder="e.g. Masterclass in distributed databases"
          value={title}
          onChange={(e) => setTitle(e.target.value)}
        />

        {/* Content */}
        <div>
          <label className="block text-xs font-semibold text-neutral-700 dark:text-neutral-300 mb-1.5">
            Detailed Review & Study Notes
          </label>
          <textarea
            rows={4}
            required
            value={content}
            onChange={(e) => setContent(e.target.value)}
            placeholder="What were the key insights? How does it help with course labs or placement prep?"
            className="w-full rounded-lg border border-neutral-300 bg-white p-3 text-sm text-neutral-900 placeholder:text-neutral-400 focus:outline-none focus:ring-2 focus:ring-neutral-900 dark:border-neutral-800 dark:bg-neutral-900 dark:text-neutral-100 dark:placeholder:text-neutral-500 dark:focus:ring-neutral-400"
          />
        </div>

        {/* Actions */}
        <div className="flex items-center justify-end gap-3 pt-3 border-t border-neutral-100 dark:border-neutral-800">
          <Button
            variant="outline"
            size="sm"
            onClick={() => dispatch(closeModal())}
            disabled={isSubmitting}
          >
            Cancel
          </Button>
          <Button type="submit" variant="primary" size="sm" isLoading={isSubmitting}>
            Post Review
          </Button>
        </div>
      </form>
    </Modal>
  );
};

export default ReviewModal;
