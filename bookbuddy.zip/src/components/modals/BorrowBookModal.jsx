import React, { useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { Modal } from '../common/Modal';
import { Button } from '../common/Button';
import { closeModal } from '../../store/slices/uiSlice';
import { borrowBookAction } from '../../store/slices/borrowingsSlice';
import { fetchBooks } from '../../store/slices/booksSlice';
import { BookCover } from '../books/BookCover';
import { Calendar, AlertCircle, CheckCircle2 } from 'lucide-react';
import { addDays, format } from 'date-fns';
import { toast } from 'sonner';

export const BorrowBookModal = () => {
  const dispatch = useDispatch();
  const { activeModal } = useSelector((state) => state.ui);
  const { user } = useSelector((state) => state.auth);
  const [durationDays, setDurationDays] = useState(14);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const isOpen = activeModal?.type === 'BORROW';
  const book = activeModal?.data;

  if (!isOpen || !book) return null;

  const dueDate = addDays(new Date(), Number(durationDays));

  const handleConfirmBorrow = async () => {
    setIsSubmitting(true);
    try {
      await dispatch(
        borrowBookAction({
          userId: user?.id || 'user-1',
          bookId: book.id,
          dueDate: dueDate.toISOString(),
        })
      ).unwrap();

      // Refresh catalog book copies
      dispatch(fetchBooks());

      toast.success(`Successfully checked out "${book.title}"! Due date: ${format(dueDate, 'MMM dd, yyyy')}`);
      dispatch(closeModal());
    } catch (err) {
      toast.error(err.message || 'Failed to borrow book');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <Modal
      isOpen={isOpen}
      onClose={() => dispatch(closeModal())}
      title="Confirm Book Checkout"
      description="Borrow physical copy from the university library catalog"
    >
      <div className="space-y-4">
        {/* Book Preview */}
        <div className="flex gap-4 p-3 rounded-xl bg-neutral-50 dark:bg-neutral-800/50 border border-neutral-200/80 dark:border-neutral-700/60 items-center">
          <div className="w-14 shrink-0">
            <BookCover
              title={book.title}
              author={book.author}
              category={book.category}
              coverGradient={book.coverGradient}
            />
          </div>
          <div>
            <h4 className="font-semibold text-sm text-neutral-900 dark:text-neutral-100">{book.title}</h4>
            <p className="text-xs text-neutral-500">{book.author}</p>
            <div className="flex items-center gap-2 text-xs text-neutral-600 dark:text-neutral-400 mt-1 font-mono">
              <span>Rack {book.rackNumber}</span>
              <span aria-hidden="true">·</span>
              <span>Shelf {book.shelfNumber}</span>
              <span aria-hidden="true">·</span>
              <span className="text-emerald-600 font-semibold">{book.availableCopies} available</span>
            </div>
          </div>
        </div>

        {/* Loan Duration Selector */}
        <div className="space-y-2">
          <label className="block text-xs font-semibold text-neutral-700 dark:text-neutral-300">
            Loan Period
          </label>
          <div className="grid grid-cols-3 gap-2">
            {[7, 14, 28].map((days) => (
              <button
                key={days}
                type="button"
                onClick={() => setDurationDays(days)}
                className={`py-2 px-3 text-xs font-medium rounded-lg border transition-all cursor-pointer ${
                  durationDays === days
                    ? 'border-neutral-900 bg-neutral-900 text-white dark:border-white dark:bg-white dark:text-neutral-900'
                    : 'border-neutral-300 text-neutral-700 dark:border-neutral-700 dark:text-neutral-300 hover:bg-neutral-100 dark:hover:bg-neutral-800'
                }`}
              >
                {days} Days
              </button>
            ))}
          </div>
        </div>

        {/* Summary Info */}
        <div className="p-3 rounded-lg bg-amber-500/10 border border-amber-500/20 text-xs text-amber-800 dark:text-amber-300 flex items-start gap-2.5">
          <Calendar className="w-4 h-4 shrink-0 mt-0.5" />
          <div>
            <span className="font-semibold">Return Due Date: </span>
            <span className="font-mono">{format(dueDate, 'EEEE, MMMM dd, yyyy')}</span>
            <p className="text-[11px] text-amber-700/80 dark:text-amber-400/80 mt-0.5">
              Self-service renewals allowed up to 2 times before due date unless reserved by another reader.
            </p>
          </div>
        </div>

        {/* Actions */}
        <div className="flex items-center justify-end gap-3 pt-3 border-t border-neutral-100 dark:border-neutral-800">
          <Button
            variant="outline"
            size="sm"
            onClick={() => dispatch(closeModal())}
            disabled={isSubmitting}
          >
            Cancel
          </Button>
          <Button
            variant="primary"
            size="sm"
            onClick={handleConfirmBorrow}
            isLoading={isSubmitting}
          >
            Confirm Checkout
          </Button>
        </div>
      </div>
    </Modal>
  );
};

export default BorrowBookModal;
