import React, { useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { Modal } from '../common/Modal';
import { Button } from '../common/Button';
import { closeModal } from '../../store/slices/uiSlice';
import { createReservation } from '../../store/slices/reservationSlice';
import { BookCover } from '../books/BookCover';
import { Clock, ShieldCheck } from 'lucide-react';
import { toast } from 'sonner';

export const ReserveBookModal = () => {
  const dispatch = useDispatch();
  const { activeModal } = useSelector((state) => state.ui);
  const { user } = useSelector((state) => state.auth);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const isOpen = activeModal?.type === 'RESERVE';
  const book = activeModal?.data;

  if (!isOpen || !book) return null;

  const handleConfirmReservation = async () => {
    setIsSubmitting(true);
    try {
      await dispatch(
        createReservation({
          userId: user?.id || 'user-1',
          bookId: book.id,
        })
      ).unwrap();

      toast.success(`Hold placed on "${book.title}"! You will be notified when it arrives at the desk.`);
      dispatch(closeModal());
    } catch (err) {
      toast.error(err.message || 'Failed to place reservation hold');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <Modal
      isOpen={isOpen}
      onClose={() => dispatch(closeModal())}
      title="Place Book Hold / Reservation"
      description="Reserve this physical copy when current loans are returned"
    >
      <div className="space-y-4">
        {/* Book Preview */}
        <div className="flex gap-4 p-3 rounded-xl bg-neutral-50 dark:bg-neutral-800/50 border border-neutral-200/80 dark:border-neutral-700/60 items-center">
          <div className="w-14 shrink-0">
            <BookCover
              title={book.title}
              author={book.author}
              category={book.category}
              coverGradient={book.coverGradient}
            />
          </div>
          <div>
            <h4 className="font-semibold text-sm text-neutral-900 dark:text-neutral-100">{book.title}</h4>
            <p className="text-xs text-neutral-500">{book.author}</p>
            <div className="flex items-center gap-2 text-xs text-neutral-500 mt-1">
              <span>All copies currently checked out</span>
            </div>
          </div>
        </div>

        {/* Hold Policy Notice */}
        <div className="p-3.5 rounded-xl border border-neutral-200 dark:border-neutral-800 bg-neutral-50/50 dark:bg-neutral-900/50 text-xs space-y-2">
          <div className="flex items-center gap-2 font-semibold text-neutral-800 dark:text-neutral-200">
            <Clock className="w-4 h-4 text-amber-600" />
            <span>Reservation & Pickup Rules</span>
          </div>
          <ul className="list-disc pl-5 space-y-1 text-neutral-600 dark:text-neutral-400">
            <li>You will be placed next in the prioritized checkout queue.</li>
            <li>Once returned, the book will be held for 48 hours at Circulation Desk 1.</li>
            <li>You will receive an in-app and email alert immediately when ready.</li>
          </ul>
        </div>

        {/* Actions */}
        <div className="flex items-center justify-end gap-3 pt-3 border-t border-neutral-100 dark:border-neutral-800">
          <Button
            variant="outline"
            size="sm"
            onClick={() => dispatch(closeModal())}
            disabled={isSubmitting}
          >
            Cancel
          </Button>
          <Button
            variant="accent"
            size="sm"
            onClick={handleConfirmReservation}
            isLoading={isSubmitting}
          >
            Confirm Hold
          </Button>
        </div>
      </div>
    </Modal>
  );
};

export default ReserveBookModal;
