import React from 'react';
import { cn } from '../../utils/helpers';
import { BookMarked } from 'lucide-react';

export const BookCover = ({
  title = 'Book Title',
  author = 'Author',
  coverImage,
  coverGradient = 'from-slate-800 to-zinc-950',
  category = 'Catalog',
  bookNumber = '',
  aspectRatio = 'aspect-[2/3]',
  className,
  size = 'md',
}) => {
  const gradients = [
    'from-slate-800 via-neutral-900 to-zinc-950',
    'from-indigo-900 via-slate-900 to-neutral-950',
    'from-sky-900 via-blue-950 to-slate-950',
    'from-emerald-900 via-teal-950 to-neutral-950',
    'from-rose-900 via-red-950 to-stone-950',
    'from-amber-900 via-orange-950 to-stone-950',
  ];

  const charCode = (title.charCodeAt(0) || 0) + (title.charCodeAt(title.length - 1) || 0);
  const selectedGradient = coverGradient ? `bg-gradient-to-br ${coverGradient}` : `bg-gradient-to-br ${gradients[charCode % gradients.length]}`;

  return (
    <div
      className={cn(
        'relative rounded-lg overflow-hidden shadow-md book-shadow select-none group shrink-0 transition-transform duration-200',
        aspectRatio,
        selectedGradient,
        className
      )}
    >
      {/* Book Spine Shadow Left */}
      <div className="absolute inset-y-0 left-0 w-3 bg-gradient-to-r from-black/40 via-white/10 to-transparent pointer-events-none z-10" />

      {/* Decorative Foil Line */}
      <div className="absolute inset-x-0 top-3 h-[1px] bg-white/20 pointer-events-none" />
      <div className="absolute inset-x-0 bottom-3 h-[1px] bg-white/20 pointer-events-none" />

      {/* Inner Content */}
      <div className="relative z-0 h-full w-full p-3.5 flex flex-col justify-between text-white">
        <div className="space-y-1">
          <div className="flex items-center justify-between text-[9px] font-mono tracking-wider uppercase text-white/60">
            <span>{category}</span>
            {bookNumber && <span>{bookNumber}</span>}
          </div>
          <h4 className="font-serif font-bold text-xs sm:text-sm text-balance line-clamp-3 text-white leading-snug pt-1">
            {title}
          </h4>
        </div>

        <div className="pt-2">
          <div className="h-0.5 w-6 bg-amber-400/80 mb-1.5" />
          <p className="text-[10px] text-white/80 font-medium truncate">{author}</p>
        </div>
      </div>

      {/* Glossy Overlay Highlight */}
      <div className="absolute inset-0 bg-gradient-to-tr from-transparent via-white/5 to-white/15 pointer-events-none opacity-80" />
    </div>
  );
};

export default BookCover;
