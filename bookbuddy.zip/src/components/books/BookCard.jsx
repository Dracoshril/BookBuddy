import React from 'react';
import { Link } from 'react-router-dom';
import { BookCover } from './BookCover';
import { Star, Bookmark, Sparkles, MapPin, Download } from 'lucide-react';
import { getBookFormatAvailability } from '../../utils/helpers';
import { useDispatch, useSelector } from 'react-redux';
import { toggleWantToReadBook } from '../../store/slices/listSlice';
import { openModal } from '../../store/slices/uiSlice';
import { useAuth } from '../../hooks/useAuth';
import { toast } from 'sonner';

export const BookCard = ({ book, aiMatchScore, showLocation = true }) => {
  const dispatch = useDispatch();
  const { isAuthenticated, role } = useAuth();
  const wantToReadIds = useSelector((state) => state.lists.wantToReadBookIds);
  const isSaved = wantToReadIds.includes(String(book.id));

  const {
    hasEbook,
    ebookAvailable,
    hasPhysical,
    physicalAvailableCopies,
    physicalTotalCopies,
  } = getBookFormatAvailability(book);

  const bookDetailUrl = isAuthenticated
    ? (role === 'librarian' ? `/librarian/books/${book.id}` : `/student/books/${book.id}`)
    : `/books/${book.id}`;

  const handleToggleWantToRead = (e) => {
    e.preventDefault();
    e.stopPropagation();
    dispatch(toggleWantToReadBook(book.id));
    toast.success(isSaved ? `Removed "${book.title}" from Want to Read` : `Saved "${book.title}" to Want to Read`);
  };

  const handleBorrowClick = (e) => {
    e.preventDefault();
    e.stopPropagation();
    if (physicalAvailableCopies <= 0) return;
    dispatch(openModal({ type: 'BORROW', data: book }));
  };

  const formatLabels = [];
  if (hasEbook) formatLabels.push('E-Book');
  if (hasPhysical) formatLabels.push('Physical');
  const formatString = formatLabels.length > 0 ? formatLabels.join(' · ') : 'Physical';

  return (
    <div className="group relative rounded-xl border border-neutral-200/80 bg-white p-4 shadow-xs hover:border-neutral-300 hover:shadow-md dark:border-neutral-800 dark:bg-neutral-900 transition-all flex flex-col justify-between h-full">
      {/* Top Cover and Details */}
      <div className="flex-1 flex flex-col">
        {/* Cover with bookmark and AI match */}
        <div className="relative mb-3.5">
          <Link to={bookDetailUrl} className="block">
            <BookCover
              title={book.title}
              author={book.author}
              category={book.category}
              bookNumber={book.bookNumber}
              coverGradient={book.coverGradient}
            />
          </Link>

          {/* Want to Read Bookmark Button */}
          <button
            onClick={handleToggleWantToRead}
            className={`absolute top-2 right-2 p-1.5 rounded-full backdrop-blur-md shadow-xs transition-colors cursor-pointer ${
              isSaved
                ? 'bg-amber-500 text-white hover:bg-amber-600'
                : 'bg-black/40 text-white/90 hover:bg-black/60 hover:text-white'
            }`}
            title={isSaved ? 'In your Want-to-Read shelf' : 'Add to Want to Read'}
          >
            <Bookmark className={`w-3.5 h-3.5 ${isSaved ? 'fill-current' : ''}`} />
          </button>

          {/* AI Match percentage (Relevance to user learning goal) */}
          {aiMatchScore && (
            <div
              className="absolute bottom-2 left-2 inline-flex items-center gap-1 px-2 py-0.5 rounded-md bg-neutral-900/90 text-amber-300 text-[10px] font-medium backdrop-blur-xs shadow-xs"
              title="Relevance match based on your interests and reading path"
            >
              <Sparkles className="w-3 h-3 text-amber-400 shrink-0" />
              <span>{aiMatchScore}% Match</span>
            </div>
          )}
        </div>

        {/* Clean Unboxed Metadata: Format · Year */}
        <div className="flex items-center gap-1.5 text-xs text-neutral-500 dark:text-neutral-400 mb-1.5">
          <span className="font-medium text-neutral-700 dark:text-neutral-300">{formatString}</span>
          <span aria-hidden="true">·</span>
          <span>{book.publicationYear}</span>
        </div>

        {/* Title & Author */}
        <Link to={bookDetailUrl} className="block group-hover:text-amber-600 transition-colors">
          <h3 className="font-semibold text-sm text-neutral-900 dark:text-neutral-100 line-clamp-1 leading-snug">
            {book.title}
          </h3>
        </Link>
        <p className="text-xs text-neutral-500 dark:text-neutral-400 truncate mt-0.5">
          {book.author}
        </p>

        {/* Rating Row */}
        <div className="flex items-center gap-1 text-amber-600 dark:text-amber-400 font-semibold font-mono tabular-nums text-xs mt-2.5">
          <Star className="w-3.5 h-3.5 fill-current" />
          <span>{book.rating ? Number(book.rating).toFixed(1) : 'New'}</span>
          <span className="text-neutral-400 dark:text-neutral-500 font-normal">({book.reviewCount})</span>
        </div>

        {/* Separate Availability Display: E-Book and Physical */}
        <div className="mt-3 pt-2.5 border-t border-neutral-100 dark:border-neutral-800 text-xs space-y-1.5">
          {hasEbook && (
            <div className="flex items-center justify-between text-[11px]">
              <span className="text-neutral-500 dark:text-neutral-400 font-medium">E-Book:</span>
              <span className="inline-flex items-center gap-1.5 font-medium">
                <span className={`w-1.5 h-1.5 rounded-full ${ebookAvailable ? 'bg-emerald-500' : 'bg-rose-500'}`} />
                <span className={ebookAvailable ? 'text-emerald-600 dark:text-emerald-400' : 'text-rose-500 dark:text-rose-400'}>
                  {ebookAvailable ? 'Available' : 'Unavailable'}
                </span>
              </span>
            </div>
          )}

          {hasPhysical && (
            <div className="flex items-center justify-between text-[11px]">
              <span className="text-neutral-500 dark:text-neutral-400 font-medium">Physical:</span>
              <span className="inline-flex items-center gap-1.5 font-medium">
                <span className={`w-1.5 h-1.5 rounded-full ${physicalAvailableCopies > 0 ? 'bg-emerald-500' : 'bg-rose-500'}`} />
                <span className={physicalAvailableCopies > 0 ? 'text-neutral-700 dark:text-neutral-300' : 'text-rose-500 dark:text-rose-400'}>
                  {physicalAvailableCopies}/{physicalTotalCopies} Available
                </span>
              </span>
            </div>
          )}
        </div>

        {/* Shelf location (if physical book has location) */}
        {showLocation && hasPhysical && book.rackNumber > 0 && (
          <div className="flex items-center gap-1 text-[10px] font-mono text-neutral-400 mt-2 truncate">
            <MapPin className="w-3 h-3 text-amber-500 shrink-0" />
            <span>Rack {book.rackNumber} · Shelf {book.shelfNumber}</span>
          </div>
        )}
      </div>

      {/* Action Buttons Section */}
      <div className="book-actions mt-3.5 pt-2.5 border-t border-neutral-100 dark:border-neutral-800/80 flex flex-col gap-2">
        {/* Row 1: Full-width Download Button (shown only when book has E-Book edition) */}
        {hasEbook && (
          ebookAvailable ? (
            <a
              href={book.downloadUrl || '/ebooks/clean-architecture.pdf'}
              download
              className="w-full py-1.5 px-3 text-center text-xs font-semibold rounded-lg bg-neutral-900 text-white dark:bg-white dark:text-neutral-900 hover:bg-neutral-800 dark:hover:bg-neutral-100 transition-colors inline-flex items-center justify-center gap-1.5 cursor-pointer shadow-xs"
            >
              <Download className="w-3.5 h-3.5 shrink-0" />
              <span>Download</span>
            </a>
          ) : (
            <button
              type="button"
              disabled
              aria-disabled="true"
              className="w-full py-1.5 px-3 text-center text-xs font-semibold rounded-lg border border-neutral-200 dark:border-neutral-800 bg-neutral-100 text-neutral-400 dark:bg-neutral-800/60 dark:text-neutral-500 inline-flex items-center justify-center gap-1.5 cursor-not-allowed opacity-60"
              title="E-Book edition currently unavailable"
            >
              <Download className="w-3.5 h-3.5 shrink-0" />
              <span>Download</span>
            </button>
          )
        )}

        {/* Row 2: Secondary Actions - View (bottom-left) and Borrow (bottom-right) */}
        <div className="secondary-actions flex items-center gap-2 w-full">
          {/* View Button - ALWAYS shown on bottom-left */}
          <Link
            to={bookDetailUrl}
            className={`${hasPhysical ? 'flex-1' : 'w-full'} py-1.5 px-3 text-center text-xs font-medium rounded-lg border border-neutral-300 dark:border-neutral-700 text-neutral-700 dark:text-neutral-200 hover:bg-neutral-100 dark:hover:bg-neutral-800 transition-colors inline-flex items-center justify-center`}
          >
            View
          </Link>

          {/* Borrow Button - shown only when book has Physical Book edition, on bottom-right */}
          {hasPhysical && (
            physicalAvailableCopies > 0 ? (
              <button
                type="button"
                onClick={handleBorrowClick}
                className="flex-1 py-1.5 px-3 text-center text-xs font-semibold rounded-lg bg-neutral-900 text-white dark:bg-white dark:text-neutral-900 hover:bg-neutral-800 dark:hover:bg-neutral-100 transition-colors cursor-pointer shadow-xs"
              >
                Borrow
              </button>
            ) : (
              <button
                type="button"
                disabled
                aria-disabled="true"
                className="flex-1 py-1.5 px-3 text-center text-xs font-semibold rounded-lg border border-neutral-200 dark:border-neutral-800 bg-neutral-100 text-neutral-400 dark:bg-neutral-800/60 dark:text-neutral-500 cursor-not-allowed opacity-60"
                title="No physical copies currently available"
              >
                Borrow
              </button>
            )
          )}
        </div>
      </div>
    </div>
  );
};

export default BookCard;
