import React from 'react';
import { MapPin, Compass } from 'lucide-react';
import { cn } from '../../utils/helpers';

export const PhysicalLocationBadge = ({
  rackNumber = 1,
  section = 'General',
  shelfNumber = 1,
  position = 1,
  className,
  compact = false,
}) => {
  if (compact) {
    return (
      <div className={cn('inline-flex items-center gap-1.5 text-xs text-neutral-600 dark:text-neutral-400 font-mono', className)}>
        <MapPin className="w-3.5 h-3.5 text-amber-600 dark:text-amber-400 shrink-0" />
        <span>R{rackNumber} · S{shelfNumber} · Pos {position}</span>
      </div>
    );
  }

  return (
    <div className={cn('rounded-xl border border-neutral-200/90 dark:border-neutral-800 bg-neutral-50/80 dark:bg-neutral-900/60 p-3.5', className)}>
      <div className="flex items-center justify-between mb-2 pb-1.5 border-b border-neutral-200/60 dark:border-neutral-800/80">
        <div className="flex items-center gap-1.5 text-xs font-semibold text-neutral-800 dark:text-neutral-200">
          <Compass className="w-3.5 h-3.5 text-amber-600 dark:text-amber-400 shrink-0" />
          <span>Physical Shelf Location</span>
        </div>
        <span className="text-[10px] font-mono uppercase text-neutral-500">Building 4, Floor 2</span>
      </div>

      <div className="grid grid-cols-4 gap-2 text-center text-xs">
        <div className="p-2 rounded-lg bg-white dark:bg-neutral-800 border border-neutral-200/60 dark:border-neutral-700/60">
          <span className="block text-[10px] uppercase text-neutral-400 font-mono">Rack</span>
          <span className="font-bold text-neutral-900 dark:text-neutral-100 font-mono tabular-nums">{rackNumber}</span>
        </div>
        <div className="p-2 rounded-lg bg-white dark:bg-neutral-800 border border-neutral-200/60 dark:border-neutral-700/60">
          <span className="block text-[10px] uppercase text-neutral-400 font-mono">Section</span>
          <span className="font-semibold text-neutral-900 dark:text-neutral-100 truncate block text-[11px]" title={section}>{section}</span>
        </div>
        <div className="p-2 rounded-lg bg-white dark:bg-neutral-800 border border-neutral-200/60 dark:border-neutral-700/60">
          <span className="block text-[10px] uppercase text-neutral-400 font-mono">Shelf</span>
          <span className="font-bold text-neutral-900 dark:text-neutral-100 font-mono tabular-nums">{shelfNumber}</span>
        </div>
        <div className="p-2 rounded-lg bg-white dark:bg-neutral-800 border border-neutral-200/60 dark:border-neutral-700/60">
          <span className="block text-[10px] uppercase text-neutral-400 font-mono">Position</span>
          <span className="font-bold text-neutral-900 dark:text-neutral-100 font-mono tabular-nums">{position}</span>
        </div>
      </div>
    </div>
  );
};

export default PhysicalLocationBadge;
