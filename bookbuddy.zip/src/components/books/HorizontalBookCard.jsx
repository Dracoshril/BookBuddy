import React from 'react';
import { Link } from 'react-router-dom';
import { BookCover } from './BookCover';
import { Star, MapPin, Sparkles, Download } from 'lucide-react';
import { getBookFormatAvailability } from '../../utils/helpers';
import { Button } from '../common/Button';
import { useDispatch } from 'react-redux';
import { openModal } from '../../store/slices/uiSlice';
import { useAuth } from '../../hooks/useAuth';

export const HorizontalBookCard = ({ book, matchReason, aiMatchPercentage }) => {
  const dispatch = useDispatch();
  const { isAuthenticated, role } = useAuth();
  const {
    hasEbook,
    ebookAvailable,
    hasPhysical,
    physicalAvailableCopies,
    physicalTotalCopies,
  } = getBookFormatAvailability(book);

  const bookDetailUrl = isAuthenticated
    ? (role === 'librarian' ? `/librarian/books/${book.id}` : `/student/books/${book.id}`)
    : `/books/${book.id}`;

  const formatLabels = [];
  if (hasEbook) formatLabels.push('E-Book');
  if (hasPhysical) formatLabels.push('Physical');
  const formatString = formatLabels.length > 0 ? formatLabels.join(' · ') : 'Physical';

  return (
    <div className="rounded-xl border border-neutral-200/80 bg-white p-4 shadow-xs dark:border-neutral-800 dark:bg-neutral-900 flex flex-col sm:flex-row gap-4 items-start sm:items-center justify-between">
      <div className="flex gap-3.5 items-center">
        <Link to={bookDetailUrl} className="w-16 shrink-0">
          <BookCover
            title={book.title}
            author={book.author}
            category={book.category}
            coverGradient={book.coverGradient}
            aspectRatio="aspect-[2/3]"
          />
        </Link>
        <div className="space-y-1">
          <div className="flex items-center gap-2 text-xs text-neutral-500">
            <span className="font-medium text-neutral-700 dark:text-neutral-300">{formatString}</span>
            <span aria-hidden="true">·</span>
            <span>{book.category}</span>
            <span aria-hidden="true">·</span>
            <span>{book.publicationYear}</span>
            {aiMatchPercentage && (
              <>
                <span aria-hidden="true">·</span>
                <span className="inline-flex items-center gap-1 text-amber-600 dark:text-amber-400 font-medium">
                  <Sparkles className="w-3 h-3" />
                  {aiMatchPercentage}% Match
                </span>
              </>
            )}
          </div>
          <Link to={bookDetailUrl}>
            <h4 className="font-semibold text-sm text-neutral-900 dark:text-neutral-100 hover:text-amber-600 transition-colors">
              {book.title}
            </h4>
          </Link>
          <p className="text-xs text-neutral-500">{book.author}</p>
          {matchReason && (
            <p className="text-xs text-neutral-600 dark:text-neutral-400 italic line-clamp-1 pt-0.5">
              "{matchReason}"
            </p>
          )}
        </div>
      </div>

      <div className="flex sm:flex-col items-center sm:items-end justify-between w-full sm:w-auto gap-3 pt-2 sm:pt-0 border-t sm:border-t-0 border-neutral-100 dark:border-neutral-800">
        <div className="flex flex-col items-start sm:items-end gap-1 text-xs">
          <span className="flex items-center gap-1 font-semibold text-amber-600 font-mono">
            <Star className="w-3 h-3 fill-current" />
            {book.rating ? Number(book.rating).toFixed(1) : '—'}
          </span>
          <div className="flex items-center gap-3 text-[11px]">
            {hasEbook && (
              <span className="inline-flex items-center gap-1">
                <span className={`w-1.5 h-1.5 rounded-full ${ebookAvailable ? 'bg-emerald-500' : 'bg-neutral-400 dark:bg-neutral-600'}`} />
                <span className={ebookAvailable ? 'text-emerald-600 dark:text-emerald-400' : 'text-neutral-400 dark:text-neutral-500'}>
                  E-Book {ebookAvailable ? 'Avail' : 'Unavail'}
                </span>
              </span>
            )}
            {hasPhysical && (
              <span className="inline-flex items-center gap-1 text-neutral-500">
                <span className={`w-1.5 h-1.5 rounded-full ${physicalAvailableCopies > 0 ? 'bg-emerald-500' : 'bg-rose-500'}`} />
                <span>Physical {physicalAvailableCopies}/{physicalTotalCopies}</span>
              </span>
            )}
          </div>
        </div>

        <div className="flex items-center gap-2">
          {hasEbook && (
            ebookAvailable ? (
              <a href={book.downloadUrl || '/ebooks/clean-architecture.pdf'} download>
                <Button
                  variant="primary"
                  size="sm"
                  leftIcon={<Download className="w-3.5 h-3.5" />}
                >
                  Download
                </Button>
              </a>
            ) : (
              <Button
                variant="outline"
                size="sm"
                disabled
                leftIcon={<Download className="w-3.5 h-3.5" />}
                title="E-Book currently unavailable"
              >
                Download
              </Button>
            )
          )}

          <Link to={bookDetailUrl}>
            <Button variant="outline" size="sm">
              View
            </Button>
          </Link>

          {hasPhysical && (
            physicalAvailableCopies > 0 ? (
              <Button
                variant="primary"
                size="sm"
                onClick={() => dispatch(openModal({ type: 'BORROW', data: book }))}
              >
                Borrow
              </Button>
            ) : (
              <Button
                variant="outline"
                size="sm"
                disabled
                title="No physical copies available"
              >
                Borrow
              </Button>
            )
          )}
        </div>
      </div>
    </div>
  );
};

export const CompactBookCard = ({ book }) => {
  const { isAuthenticated, role } = useAuth();
  const bookDetailUrl = isAuthenticated
    ? (role === 'librarian' ? `/librarian/books/${book.id}` : `/student/books/${book.id}`)
    : `/books/${book.id}`;

  return (
    <Link
      to={bookDetailUrl}
      className="group flex items-center gap-3 p-2.5 rounded-xl border border-neutral-200/60 bg-white hover:border-neutral-300 dark:border-neutral-800 dark:bg-neutral-900 transition-colors"
    >
      <div className="w-10 shrink-0">
        <BookCover
          title={book.title}
          author={book.author}
          coverGradient={book.coverGradient}
          aspectRatio="aspect-[2/3]"
        />
      </div>
      <div className="min-w-0 flex-1">
        <h5 className="text-xs font-semibold text-neutral-900 dark:text-neutral-100 truncate group-hover:text-amber-600 transition-colors">
          {book.title}
        </h5>
        <p className="text-[11px] text-neutral-500 truncate">{book.author}</p>
        <div className="flex items-center gap-1.5 text-[10px] text-neutral-400 mt-0.5">
          <span>{book.category}</span>
          <span aria-hidden="true">·</span>
          <span>{book.category === 'E-Book' ? 'Digital' : `Rack ${book.rackNumber}`}</span>
        </div>
      </div>
    </Link>
  );
};
