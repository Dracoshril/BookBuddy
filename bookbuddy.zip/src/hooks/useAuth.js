import { useSelector, useDispatch } from 'react-redux';
import { loginUser, logoutUser, setAuthUser } from '../store/slices/authSlice';
import { initialUsers } from '../data/users';

export const useAuth = () => {
  const dispatch = useDispatch();
  const { user, token, isAuthenticated, isLoading, error } = useSelector((state) => state.auth);

  const login = (username, password, role) => {
    return dispatch(loginUser({ username, password, role })).unwrap();
  };

  const logout = () => {
    return dispatch(logoutUser()).unwrap();
  };

  const quickLogin = (roleName) => {
    const demoUser = initialUsers.find((u) => u.role === roleName) || initialUsers[0];
    dispatch(setAuthUser({ user: demoUser, token: `mock-token-${demoUser.id}` }));
    return demoUser;
  };

  return {
    user,
    token,
    isAuthenticated,
    isLoading,
    error,
    role: user?.role || null,
    isStudent: user?.role === 'student',
    isLibrarian: user?.role === 'librarian',
    login,
    logout,
    quickLogin,
  };
};

export default useAuth;
