import { ROLES } from './constants';

export const isStudent = (role) => {
  return role === ROLES.STUDENT;
};

export const isLibrarian = (role) => {
  return role === ROLES.LIBRARIAN;
};

export const canBorrowBooks = (role) => {
  return role === ROLES.STUDENT;
};

export const canManageLibrary = (role) => {
  return role === ROLES.LIBRARIAN;
};

export const getRoleLabel = (role) => {
  switch (role) {
    case ROLES.STUDENT:
      return 'Student Reader';
    case ROLES.LIBRARIAN:
      return 'Librarian';
    default:
      return 'Guest';
  }
};

