export const ROLES = {
  STUDENT: 'student',
  LIBRARIAN: 'librarian',
};

export const BOOK_STATUS = {
  AVAILABLE: 'AVAILABLE',
  ISSUED: 'ISSUED',
  RESERVED: 'RESERVED',
  UNAVAILABLE: 'UNAVAILABLE',
};

export const BORROW_STATUS = {
  CURRENT: 'CURRENT',
  DUE_SOON: 'DUE_SOON',
  OVERDUE: 'OVERDUE',
  RETURNED: 'RETURNED',
};

export const RESERVATION_STATUS = {
  RESERVED: 'RESERVED',
  WAITING: 'WAITING',
  AVAILABLE: 'AVAILABLE',
  COMPLETED: 'COMPLETED',
  CANCELLED: 'CANCELLED',
};

export const STORAGE_KEYS = {
  USER: 'bookbuddy_user',
  AUTH: 'bookbuddy_auth',
  BOOKS: 'bookbuddy_books',
  BORROWINGS: 'bookbuddy_borrowings',
  RESERVATIONS: 'bookbuddy_reservations',
  WANT_TO_READ: 'bookbuddy_want_to_read',
  LISTS: 'bookbuddy_lists',
  REVIEWS: 'bookbuddy_reviews',
  NOTIFICATIONS: 'bookbuddy_notifications',
  ACTIVITIES: 'bookbuddy_activities',
  SETTINGS: 'bookbuddy_settings',
  THEME: 'bookbuddy-theme',
  FOLLOWS: 'bookbuddy_follows',
  AI_CHAT: 'bookbuddy_ai_chat',
};

export const DEFAULT_LIBRARY_SETTINGS = {
  openingTime: '08:00',
  closingTime: '21:00',
  borrowLimitStudent: 4,
  borrowDurationDays: 14,
  renewalLimit: 2,
  finePerDay: 1.0,
  reservationExpiryHours: 48,
  emailReminders: true,
  autoRenewals: false,
};
