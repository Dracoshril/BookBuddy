import { format, formatDistanceToNow, isAfter, isBefore, addDays, parseISO } from 'date-fns';

export const formatDate = (dateString, formatPattern = 'MMM dd, yyyy') => {
  if (!dateString) return '—';
  try {
    const date = typeof dateString === 'string' ? parseISO(dateString) : dateString;
    return format(date, formatPattern);
  } catch {
    return dateString;
  }
};

export const formatRelativeTime = (dateString) => {
  if (!dateString) return '—';
  try {
    const date = typeof dateString === 'string' ? parseISO(dateString) : dateString;
    return formatDistanceToNow(date, { addSuffix: true });
  } catch {
    return dateString;
  }
};

export const getDaysRemaining = (dueDateString) => {
  if (!dueDateString) return 0;
  try {
    const dueDate = typeof dueDateString === 'string' ? parseISO(dueDateString) : dueDateString;
    const now = new Date();
    const diffTime = dueDate.getTime() - now.getTime();
    return Math.ceil(diffTime / (1000 * 60 * 60 * 24));
  } catch {
    return 0;
  }
};

export const isDateOverdue = (dueDateString) => {
  if (!dueDateString) return false;
  try {
    const dueDate = typeof dueDateString === 'string' ? parseISO(dueDateString) : dueDateString;
    return isBefore(dueDate, new Date());
  } catch {
    return false;
  }
};

export const calculateDueDate = (daysFromNow = 14) => {
  return addDays(new Date(), daysFromNow).toISOString();
};
