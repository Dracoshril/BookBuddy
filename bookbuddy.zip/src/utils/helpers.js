import { clsx } from 'clsx';
import { twMerge } from 'tailwind-merge';

export function cn(...inputs) {
  return twMerge(clsx(inputs));
}

export const generateId = (prefix = 'id') => {
  return `${prefix}-${Date.now().toString(36)}-${Math.random().toString(36).substr(2, 5)}`;
};

export const truncateText = (text, maxLength = 100) => {
  if (!text || text.length <= maxLength) return text;
  return `${text.slice(0, maxLength).trim()}...`;
};

export const getBookStatusColor = (status) => {
  switch (status) {
    case 'AVAILABLE':
      return {
        bg: 'bg-emerald-500/10 text-emerald-700 dark:text-emerald-400 border-emerald-500/20',
        dot: 'bg-emerald-500',
        label: 'Available',
      };
    case 'ISSUED':
      return {
        bg: 'bg-rose-500/10 text-rose-700 dark:text-rose-400 border-rose-500/20',
        dot: 'bg-rose-500',
        label: 'Issued',
      };
    case 'RESERVED':
      return {
        bg: 'bg-amber-500/10 text-amber-700 dark:text-amber-400 border-amber-500/20',
        dot: 'bg-amber-500',
        label: 'Reserved',
      };
    case 'UNAVAILABLE':
    default:
      return {
        bg: 'bg-neutral-500/10 text-neutral-700 dark:text-neutral-400 border-neutral-500/20',
        dot: 'bg-neutral-500',
        label: 'Unavailable',
      };
  }
};

export const getBookFormatAvailability = (book) => {
  if (!book) {
    return {
      hasEbook: false,
      ebookAvailable: false,
      hasPhysical: false,
      physicalAvailableCopies: 0,
      physicalTotalCopies: 0,
    };
  }

  const hasEbook = Boolean(
    book.hasEbook !== undefined
      ? book.hasEbook
      : Boolean(book.downloadUrl || book.category === 'E-Book' || book.ebookAvailable !== undefined)
  );

  const ebookAvailable = Boolean(
    book.ebookAvailable !== undefined
      ? book.ebookAvailable
      : (hasEbook && (Boolean(book.downloadUrl) || book.status !== 'UNAVAILABLE'))
  );

  const hasPhysical = Boolean(
    book.hasPhysical !== undefined
      ? book.hasPhysical
      : (book.totalCopies !== undefined ? book.totalCopies > 0 : true)
  );

  const physicalAvailableCopies = Number(
    book.physicalAvailableCopies !== undefined
      ? book.physicalAvailableCopies
      : (book.availableCopies ?? 0)
  );

  const physicalTotalCopies = Number(
    book.physicalTotalCopies !== undefined
      ? book.physicalTotalCopies
      : (book.totalCopies ?? 0)
  );

  return {
    hasEbook,
    ebookAvailable,
    hasPhysical,
    physicalAvailableCopies,
    physicalTotalCopies,
  };
};
