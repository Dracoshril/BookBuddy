import React from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { GraduationCap, Shield, ArrowRight } from 'lucide-react';
import { useAuth } from '../../hooks/useAuth';
import { toast } from 'sonner';

export const LoginSelectPage = () => {
  const { quickLogin } = useAuth();
  const navigate = useNavigate();

  const handleQuickDemo = (role) => {
    quickLogin(role);
    toast.success(`Signed in as ${role === 'student' ? 'Student' : 'Librarian'} demo account!`);
    if (role === 'student') {
      navigate('/student/dashboard');
    } else {
      navigate('/librarian/dashboard');
    }
  };

  return (
    <div className="min-h-[80vh] flex items-center justify-center p-4 sm:p-6">
      <div className="max-w-md w-full p-8 rounded-3xl border border-neutral-200/80 bg-white dark:border-neutral-800 dark:bg-neutral-900 shadow-xl space-y-8">
        <div className="text-center space-y-3">
          <div className="flex justify-center">
            <img
              src="/assets/images/bookbuddy-logo.svg"
              alt="BookBuddy"
              className="h-9 w-auto object-contain hidden dark:block"
            />
            <img
              src="/assets/images/bookbuddy-logo-light.svg"
              alt="BookBuddy"
              className="h-9 w-auto object-contain block dark:hidden"
            />
          </div>
          <h2 className="text-2xl font-bold tracking-tight text-neutral-900 dark:text-neutral-100">
            Welcome Back
          </h2>
          <p className="text-xs text-neutral-500 dark:text-neutral-400">
            Sign in to continue to BookBuddy
          </p>
        </div>

        {/* The Two Roles */}
        <div className="space-y-3">
          <Link
            to="/auth/student"
            className="flex items-center justify-between p-5 rounded-2xl border border-neutral-200/80 hover:border-amber-500/60 dark:border-neutral-800 dark:hover:border-amber-500/60 bg-neutral-50/50 hover:bg-amber-50/20 dark:bg-neutral-850 dark:hover:bg-neutral-800 transition-all group"
          >
            <div className="flex items-center gap-3.5">
              <div className="w-11 h-11 rounded-xl bg-amber-500/10 text-amber-600 dark:text-amber-400 flex items-center justify-center">
                <GraduationCap className="w-6 h-6" />
              </div>
              <div>
                <h4 className="font-bold text-sm text-neutral-900 dark:text-neutral-100 group-hover:text-amber-600 transition-colors">
                  Student
                </h4>
                <p className="text-xs text-neutral-500">Access student portal</p>
              </div>
            </div>
            <ArrowRight className="w-4 h-4 text-neutral-400 group-hover:text-amber-600 group-hover:translate-x-0.5 transition-all" />
          </Link>

          <Link
            to="/auth/librarian"
            className="flex items-center justify-between p-5 rounded-2xl border border-neutral-200/80 hover:border-emerald-500/60 dark:border-neutral-800 dark:hover:border-emerald-500/60 bg-neutral-50/50 hover:bg-emerald-50/20 dark:bg-neutral-850 dark:hover:bg-neutral-800 transition-all group"
          >
            <div className="flex items-center gap-3.5">
              <div className="w-11 h-11 rounded-xl bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 flex items-center justify-center">
                <Shield className="w-6 h-6" />
              </div>
              <div>
                <h4 className="font-bold text-sm text-neutral-900 dark:text-neutral-100 group-hover:text-emerald-600 transition-colors">
                  Librarian
                </h4>
                <p className="text-xs text-neutral-500">Manage library</p>
              </div>
            </div>
            <ArrowRight className="w-4 h-4 text-neutral-400 group-hover:text-emerald-600 group-hover:translate-x-0.5 transition-all" />
          </Link>
        </div>

        {/* Quick Demo Launch */}
        <div className="pt-4 border-t border-neutral-100 dark:border-neutral-800 space-y-2">
          <div className="text-[11px] font-mono uppercase tracking-wider text-neutral-400 text-center">
            Instant 1-Click Demo Login
          </div>
          <div className="grid grid-cols-2 gap-2 text-xs">
            <button
              onClick={() => handleQuickDemo('student')}
              className="p-2.5 rounded-xl border border-neutral-200 dark:border-neutral-800 hover:bg-neutral-50 dark:hover:bg-neutral-800/80 text-left transition-colors cursor-pointer"
            >
              <span className="font-bold block text-neutral-900 dark:text-neutral-100">Student Demo</span>
              <span className="text-[10px] text-neutral-500">student001</span>
            </button>
            <button
              onClick={() => handleQuickDemo('librarian')}
              className="p-2.5 rounded-xl border border-neutral-200 dark:border-neutral-800 hover:bg-neutral-50 dark:hover:bg-neutral-800/80 text-left transition-colors cursor-pointer"
            >
              <span className="font-bold block text-neutral-900 dark:text-neutral-100">Librarian Demo</span>
              <span className="text-[10px] text-neutral-500">librarian001</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default LoginSelectPage;
