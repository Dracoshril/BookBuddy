import React, { useEffect } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { initialUsers } from '../../data/users';
import { fetchFollowing, toggleFollowUser } from '../../store/slices/socialSlice';
import { Avatar } from '../../components/common/Avatar';
import { Button } from '../../components/common/Button';
import { Users, UserPlus, UserCheck } from 'lucide-react';
import { toast } from 'sonner';

export const FollowingPage = () => {
  const dispatch = useDispatch();
  const following = useSelector((state) => state.social.following);
  const currentUser = useSelector((state) => state.auth.user);

  useEffect(() => {
    dispatch(fetchFollowing());
  }, [dispatch]);

  const handleToggleFollow = (targetUser) => {
    const isNowFollowing = !following.includes(targetUser.id);
    dispatch(toggleFollowUser(targetUser.id));
    if (isNowFollowing) {
      toast.success(`Started following ${targetUser.name}!`);
    } else {
      toast.info(`Unfollowed ${targetUser.name}.`);
    }
  };

  const otherUsers = initialUsers.filter((u) => u.id !== currentUser?.id);

  return (
    <div className="space-y-6 max-w-4xl">
      <div>
        <h1 className="text-2xl sm:text-3xl font-bold tracking-tight text-neutral-900 dark:text-neutral-100">
          Campus Reading Community
        </h1>
        <p className="text-xs sm:text-sm text-neutral-500 dark:text-neutral-400 mt-1">
          Follow classmates and professors to discover new book recommendations, reading diaries, and course lists.
        </p>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        {otherUsers.map((u) => {
          const isFollowing = following.includes(u.id);
          return (
            <div
              key={u.id}
              className="p-5 rounded-2xl border border-neutral-200/80 bg-white dark:border-neutral-800 dark:bg-neutral-900 shadow-xs flex flex-col justify-between space-y-4"
            >
              <div className="space-y-3">
                <div className="flex items-start justify-between gap-3">
                  <div className="flex items-center gap-3">
                    <Avatar name={u.name} size="md" />
                    <div>
                      <h3 className="font-bold text-sm text-neutral-900 dark:text-neutral-100">
                        {u.name}
                      </h3>
                      <p className="text-[11px] text-neutral-500 font-mono">
                        {u.role} · {u.department}
                      </p>
                    </div>
                  </div>

                  <Button
                    variant={isFollowing ? 'outline' : 'primary'}
                    size="sm"
                    leftIcon={isFollowing ? <UserCheck className="w-3.5 h-3.5 text-emerald-600" /> : <UserPlus className="w-3.5 h-3.5" />}
                    onClick={() => handleToggleFollow(u)}
                  >
                    {isFollowing ? 'Following' : 'Follow'}
                  </Button>
                </div>

                <p className="text-xs text-neutral-600 dark:text-neutral-400 line-clamp-2 leading-relaxed">
                  {u.bio}
                </p>

                {/* Interests */}
                {u.interests && (
                  <div className="flex flex-wrap items-center gap-1 text-[10px] text-neutral-500">
                    {u.interests.map((interest, i) => (
                      <span key={i} className="px-2 py-0.5 rounded-md bg-neutral-100 dark:bg-neutral-800">
                        {interest}
                      </span>
                    ))}
                  </div>
                )}
              </div>

              <div className="flex items-center justify-between pt-3 border-t border-neutral-100 dark:border-neutral-800 text-[11px] text-neutral-400 font-mono">
                <span>{u.booksReadCount || 10} books logged</span>
                <span>{u.reviewsCount || 4} reviews</span>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};

export default FollowingPage;
