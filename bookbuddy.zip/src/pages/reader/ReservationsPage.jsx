import React, { useEffect, useState } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { useAuth } from '../../hooks/useAuth';
import { fetchUserReservations, cancelReservationAction } from '../../store/slices/reservationSlice';
import { Button } from '../../components/common/Button';
import { EmptyState } from '../../components/common/EmptyState';
import { Clock, CheckCircle2, XCircle, AlertCircle, MapPin } from 'lucide-react';
import { format } from 'date-fns';
import { toast } from 'sonner';

export const ReservationsPage = () => {
  const { user } = useAuth();
  const dispatch = useDispatch();
  const reservations = useSelector((state) => state.reservations.items);
  const [cancellingId, setCancellingId] = useState(null);

  useEffect(() => {
    if (user?.id) {
      dispatch(fetchUserReservations(user.id));
    }
  }, [dispatch, user]);

  const handleCancel = async (id, title) => {
    setCancellingId(id);
    try {
      await dispatch(cancelReservationAction(id)).unwrap();
      toast.success(`Cancelled reservation hold for "${title}".`);
    } catch (err) {
      toast.error(err.message || 'Failed to cancel hold');
    } finally {
      setCancellingId(null);
    }
  };

  const getStatusBadge = (status) => {
    switch (status) {
      case 'AVAILABLE':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-emerald-500/10 text-emerald-700 dark:text-emerald-400 border border-emerald-500/20">
            <CheckCircle2 className="w-3.5 h-3.5" />
            Ready for Pickup
          </span>
        );
      case 'WAITING':
      case 'RESERVED':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-amber-500/10 text-amber-700 dark:text-amber-400 border border-amber-500/20">
            <Clock className="w-3.5 h-3.5" />
            In Queue (Waiting)
          </span>
        );
      case 'COMPLETED':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-neutral-100 text-neutral-600 dark:bg-neutral-800 dark:text-neutral-400 border border-neutral-200 dark:border-neutral-700">
            Fulfilled
          </span>
        );
      case 'CANCELLED':
      default:
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-rose-500/10 text-rose-700 dark:text-rose-400 border border-rose-500/20">
            <XCircle className="w-3.5 h-3.5" />
            Cancelled
          </span>
        );
    }
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl sm:text-3xl font-bold tracking-tight text-neutral-900 dark:text-neutral-100">
          Book Hold Queue & Reservations
        </h1>
        <p className="text-xs sm:text-sm text-neutral-500 dark:text-neutral-400 mt-1">
          Track waiting positions for high-demand copies and pickup deadlines at Central Circulation.
        </p>
      </div>

      {reservations.length > 0 ? (
        <div className="space-y-3">
          {reservations.map((res) => {
            const isAvailableForPickup = res.status === 'AVAILABLE';
            const isWaiting = res.status === 'WAITING' || res.status === 'RESERVED';

            return (
              <div
                key={res.id}
                className="p-5 rounded-2xl border border-neutral-200/80 bg-white dark:border-neutral-800 dark:bg-neutral-900 shadow-xs flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4"
              >
                <div className="space-y-2 min-w-0">
                  <div className="flex items-center gap-3">
                    {getStatusBadge(res.status)}
                    <span className="text-[10px] font-mono text-neutral-400">{res.bookNumber}</span>
                  </div>

                  <h3 className="font-bold text-base text-neutral-900 dark:text-neutral-100">
                    {res.title}
                  </h3>
                  <p className="text-xs text-neutral-500">{res.author}</p>

                  <div className="flex flex-wrap items-center gap-4 text-xs text-neutral-600 dark:text-neutral-400 font-mono pt-1">
                    <div>
                      <span className="text-[10px] text-neutral-400 block uppercase">Requested</span>
                      <span>{format(new Date(res.reservationDate), 'MMM dd, yyyy')}</span>
                    </div>

                    {isWaiting && (
                      <div>
                        <span className="text-[10px] text-neutral-400 block uppercase">Queue Position</span>
                        <span className="font-bold text-amber-600">#{res.queuePosition || 1} in line</span>
                      </div>
                    )}

                    {res.expiryDate && (
                      <div>
                        <span className="text-[10px] text-neutral-400 block uppercase">Hold Expiry</span>
                        <span>{format(new Date(res.expiryDate), 'MMM dd, yyyy')}</span>
                      </div>
                    )}
                  </div>

                  {res.notes && (
                    <p className="text-xs text-neutral-600 dark:text-neutral-400 italic">
                      Note: {res.notes}
                    </p>
                  )}
                </div>

                {/* Actions */}
                {isWaiting || isAvailableForPickup ? (
                  <div className="flex items-center gap-2">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => handleCancel(res.id, res.title)}
                      disabled={cancellingId === res.id}
                      isLoading={cancellingId === res.id}
                    >
                      Cancel Hold
                    </Button>
                  </div>
                ) : null}
              </div>
            );
          })}
        </div>
      ) : (
        <EmptyState
          icon={Clock}
          title="No active reservations"
          description="You do not currently have any books on hold. You can place a hold on any book that is currently checked out."
        />
      )}
    </div>
  );
};

export default ReservationsPage;
