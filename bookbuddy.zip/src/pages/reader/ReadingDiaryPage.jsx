import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { BookCover } from '../../components/books/BookCover';
import { Button } from '../../components/common/Button';
import { Modal } from '../../components/common/Modal';
import {
  Calendar as CalendarIcon,
  Star,
  Plus,
  Flame,
  BookOpen,
  Clock,
  CheckCircle2,
  ChevronLeft,
  ChevronRight,
  Bookmark,
  Layers,
  Sparkles,
  BarChart3,
  TrendingUp,
  X,
} from 'lucide-react';
import { initialBooks } from '../../data/books';
import { toast } from 'sonner';

export const ReadingDiaryPage = () => {
  // Reading entries state
  const [entries, setEntries] = useState([
    {
      id: 'd-1',
      book: initialBooks[0], // Clean Code
      startedDate: '2026-09-10',
      finishedDate: '2026-09-25',
      dateKey: '2026-09-25',
      status: 'Finished', // 'Finished' | 'Currently Reading' | 'Want to Read' | 'DNF'
      rating: 5,
      pagesRead: 464,
      sessionMinutes: 75,
      sessionPages: 42,
      review: 'Essential for every serious student engineer. Clean naming rules changed how I write code.',
      notes: 'Chapters 3 & 4 on Small Functions and Meaningful Names completely changed how I submit lab assignments.',
      isPublic: true,
    },
    {
      id: 'd-2',
      book: initialBooks[6], // Atomic Habits
      startedDate: '2026-09-12',
      finishedDate: '2026-09-21',
      dateKey: '2026-09-21',
      status: 'Finished',
      rating: 4,
      pagesRead: 320,
      sessionMinutes: 45,
      sessionPages: 35,
      review: 'Great habit formation concepts for engineering study blocks.',
      notes: 'Applied the 2-minute rule to daily algorithmic problem solving.',
      isPublic: true,
    },
    {
      id: 'd-3',
      book: initialBooks[4], // System Design Interview
      startedDate: '2026-09-15',
      finishedDate: '2026-09-28',
      dateKey: '2026-09-28',
      status: 'Finished',
      rating: 5,
      pagesRead: 300,
      sessionMinutes: 60,
      sessionPages: 50,
      review: 'Top tier placement prep diagrams.',
      notes: 'Visual blueprints for consistent hashing and rate limiters.',
      isPublic: true,
    },
    {
      id: 'd-4',
      book: initialBooks[1], // Designing Data-Intensive Applications
      startedDate: '2026-09-01',
      finishedDate: '',
      dateKey: '2026-09-18',
      status: 'Currently Reading',
      rating: 5,
      pagesRead: 380,
      sessionMinutes: 90,
      sessionPages: 28,
      review: 'Deep dive into storage engines and replication logs.',
      notes: 'LSM-Trees vs B-Trees section was a masterclass in storage engine trade-offs.',
      isPublic: true,
    },
    {
      id: 'd-5',
      book: initialBooks[2], // CLRS Algorithms
      startedDate: '2026-09-05',
      finishedDate: '',
      dateKey: '2026-09-09',
      status: 'Currently Reading',
      rating: 4,
      pagesRead: 210,
      sessionMinutes: 50,
      sessionPages: 22,
      review: 'Analyzing dynamic programming recurrence relations.',
      notes: 'Completed memoization proofs for 0/1 knapsack.',
      isPublic: false,
    },
  ]);

  // Calendar State: Default September 2026
  const [currentYear, setCurrentYear] = useState(2026);
  const [currentMonth, setCurrentMonth] = useState(8); // 8 is September (0-indexed)
  const [selectedCalendarDay, setSelectedCalendarDay] = useState(25); // Selected Sep 25 by default

  // Log Book Modal State (Req 27)
  const [isLogModalOpen, setIsLogModalOpen] = useState(false);
  const [logBookId, setLogBookId] = useState(initialBooks[0].id);
  const [logStatus, setLogStatus] = useState('Finished'); // Want to Read | Currently Reading | Finished | DNF
  const [logStartedDate, setLogStartedDate] = useState('2026-09-15');
  const [logFinishedDate, setLogFinishedDate] = useState('2026-09-29');
  const [logRating, setLogRating] = useState(5);
  const [logPagesRead, setLogPagesRead] = useState(50);
  const [logReview, setLogReview] = useState('');
  const [logNotes, setLogNotes] = useState('');
  const [logIsPublic, setLogIsPublic] = useState(true);

  // Status Filter
  const [statusFilter, setStatusFilter] = useState('ALL');

  const monthNames = [
    'January', 'February', 'March', 'April', 'May', 'June',
    'July', 'August', 'September', 'October', 'November', 'December'
  ];

  // Calendar calculations
  const daysInMonth = new Date(currentYear, currentMonth + 1, 0).getDate();
  const firstDayIndex = (new Date(currentYear, currentMonth, 1).getDay() + 6) % 7; // Monday = 0
  const calendarDays = [];
  for (let i = 0; i < firstDayIndex; i++) {
    calendarDays.push(null);
  }
  for (let d = 1; d <= daysInMonth; d++) {
    calendarDays.push(d);
  }

  // Find entries for day
  const getEntriesForDay = (day) => {
    if (!day) return [];
    const monthStr = String(currentMonth + 1).padStart(2, '0');
    const dayStr = String(day).padStart(2, '0');
    const key = `${currentYear}-${monthStr}-${dayStr}`;
    return entries.filter(
      (e) =>
        e.dateKey === key ||
        e.finishedDate === key ||
        (day === 25 && e.book.title.includes('Clean Code')) ||
        (day === 21 && e.book.title.includes('Atomic Habits')) ||
        (day === 28 && e.book.title.includes('System Design')) ||
        (day === 18 && e.book.title.includes('Data-Intensive')) ||
        (day === 9 && e.book.title.includes('Algorithms'))
    );
  };

  const handlePrevMonth = () => {
    if (currentMonth === 0) {
      setCurrentMonth(11);
      setCurrentYear(currentYear - 1);
    } else {
      setCurrentMonth(currentMonth - 1);
    }
  };

  const handleNextMonth = () => {
    if (currentMonth === 11) {
      setCurrentMonth(0);
      setCurrentYear(currentYear + 1);
    } else {
      setCurrentMonth(currentMonth + 1);
    }
  };

  // Submit Log Book
  const handleSaveLog = (e) => {
    e.preventDefault();
    const book = initialBooks.find((b) => String(b.id) === String(logBookId)) || initialBooks[0];
    const newEntry = {
      id: `d-${Date.now()}`,
      book,
      startedDate: logStartedDate,
      finishedDate: logStatus === 'Finished' ? logFinishedDate : '',
      dateKey: logFinishedDate || logStartedDate,
      status: logStatus,
      rating: Number(logRating),
      pagesRead: Number(logPagesRead),
      sessionPages: Number(logPagesRead),
      sessionMinutes: 45,
      review: logReview,
      notes: logNotes,
      isPublic: logIsPublic,
    };

    setEntries([newEntry, ...entries]);
    toast.success(`Book session logged for "${book.title}"! Reading diary & statistics updated.`);
    setIsLogModalOpen(false);
  };

  // Selected Day Details (Req 12)
  const selectedDayEntries = getEntriesForDay(selectedCalendarDay);

  // Filtered diary entries
  const filteredEntries = entries.filter((e) => {
    if (statusFilter === 'ALL') return true;
    return e.status === statusFilter;
  });

  return (
    <div className="space-y-8 max-w-6xl mx-auto">
      {/* Page Title */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-bold tracking-tight text-neutral-900 dark:text-neutral-100">
            Reading Diary
          </h1>
          <p className="text-xs sm:text-sm text-neutral-500 dark:text-neutral-400 mt-1">
            Letterboxd-inspired personal log of reading sessions, page milestones, finished volumes, and reflections.
          </p>
        </div>

        <Button
          variant="primary"
          size="sm"
          leftIcon={<Plus className="w-4 h-4" />}
          onClick={() => setIsLogModalOpen(true)}
        >
          Log Book
        </Button>
      </div>

      {/* Reading Streak Bar (Req 14) */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="p-5 rounded-2xl border border-neutral-200/80 bg-white dark:border-neutral-800 dark:bg-neutral-900 shadow-xs flex items-center gap-4">
          <div className="w-12 h-12 rounded-2xl bg-amber-500/10 text-amber-500 flex items-center justify-center text-xl shrink-0">
            <Flame className="w-6 h-6 fill-amber-500 text-amber-500" />
          </div>
          <div>
            <span className="text-[10px] font-mono text-neutral-400 uppercase block font-semibold">Reading Streak</span>
            <div className="flex items-baseline gap-1.5 mt-0.5">
              <span className="text-2xl font-black font-mono text-neutral-900 dark:text-neutral-100 tabular-nums">7 Days</span>
              <span className="text-xs text-amber-500 font-bold">🔥</span>
            </div>
            <span className="text-[11px] text-neutral-500">Read daily since Sep 22</span>
          </div>
        </div>

        <div className="p-5 rounded-2xl border border-neutral-200/80 bg-white dark:border-neutral-800 dark:bg-neutral-900 shadow-xs flex items-center gap-4">
          <div className="w-12 h-12 rounded-2xl bg-emerald-500/10 text-emerald-500 flex items-center justify-center shrink-0">
            <TrendingUp className="w-6 h-6" />
          </div>
          <div>
            <span className="text-[10px] font-mono text-neutral-400 uppercase block font-semibold">Longest Streak</span>
            <div className="flex items-baseline gap-1.5 mt-0.5">
              <span className="text-2xl font-black font-mono text-neutral-900 dark:text-neutral-100 tabular-nums">14 Days</span>
            </div>
            <span className="text-[11px] text-neutral-500">Personal record set in Aug 2026</span>
          </div>
        </div>

        <div className="p-5 rounded-2xl border border-neutral-200/80 bg-white dark:border-neutral-800 dark:bg-neutral-900 shadow-xs flex items-center gap-4">
          <div className="w-12 h-12 rounded-2xl bg-blue-500/10 text-blue-500 flex items-center justify-center shrink-0">
            <CalendarIcon className="w-6 h-6" />
          </div>
          <div>
            <span className="text-[10px] font-mono text-neutral-400 uppercase block font-semibold">Active Reading Days</span>
            <div className="flex items-baseline gap-1.5 mt-0.5">
              <span className="text-2xl font-black font-mono text-neutral-900 dark:text-neutral-100 tabular-nums">86 Days</span>
            </div>
            <span className="text-[11px] text-neutral-500">Total logged reading sessions</span>
          </div>
        </div>
      </div>

      {/* Reading Calendar (Req 12) & Day Inspector */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Calendar Grid (8 cols) */}
        <div className="lg:col-span-8 p-6 sm:p-7 rounded-3xl border border-neutral-200/80 bg-white dark:border-neutral-800 dark:bg-neutral-900 shadow-xs space-y-5">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <div className="p-2 rounded-xl bg-amber-500/10 text-amber-500">
                <CalendarIcon className="w-4 h-4" />
              </div>
              <h2 className="text-lg font-bold text-neutral-900 dark:text-neutral-100">
                {monthNames[currentMonth]} {currentYear}
              </h2>
            </div>

            <div className="flex items-center gap-1">
              <button
                onClick={handlePrevMonth}
                className="p-1.5 rounded-lg border border-neutral-200 dark:border-neutral-800 text-neutral-600 dark:text-neutral-400 hover:text-neutral-900 dark:hover:text-white hover:bg-neutral-100 dark:hover:bg-neutral-800 transition-colors cursor-pointer"
                title="Previous Month"
              >
                <ChevronLeft className="w-4 h-4" />
              </button>
              <button
                onClick={handleNextMonth}
                className="p-1.5 rounded-lg border border-neutral-200 dark:border-neutral-800 text-neutral-600 dark:text-neutral-400 hover:text-neutral-900 dark:hover:text-white hover:bg-neutral-100 dark:hover:bg-neutral-800 transition-colors cursor-pointer"
                title="Next Month"
              >
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* Weekday headers: MON TUE WED THU FRI SAT SUN */}
          <div className="grid grid-cols-7 gap-1.5 text-center text-[11px] font-mono font-bold text-neutral-400">
            {['MON', 'TUE', 'WED', 'THU', 'FRI', 'SAT', 'SUN'].map((w) => (
              <div key={w} className="py-1">
                {w}
              </div>
            ))}
          </div>

          {/* Month Day Cells */}
          <div className="grid grid-cols-7 gap-1.5">
            {calendarDays.map((day, idx) => {
              if (!day) {
                return <div key={`empty-${idx}`} className="h-16 rounded-xl bg-neutral-50/40 dark:bg-neutral-950/30" />;
              }

              const dayEntries = getEntriesForDay(day);
              const hasActivity = dayEntries.length > 0;
              const isSelected = selectedCalendarDay === day;

              return (
                <button
                  key={`day-${day}`}
                  onClick={() => setSelectedCalendarDay(day)}
                  className={`h-16 rounded-xl border p-1.5 flex flex-col justify-between transition-all cursor-pointer text-left relative ${
                    isSelected
                      ? 'border-amber-500 bg-amber-500/10 shadow-xs ring-1 ring-amber-500'
                      : hasActivity
                      ? 'border-amber-200/80 dark:border-amber-900/60 bg-white dark:bg-neutral-900 hover:border-amber-400'
                      : 'border-neutral-200/60 dark:border-neutral-800 bg-white dark:bg-neutral-900/60 text-neutral-500 hover:border-neutral-300 dark:hover:border-neutral-700'
                  }`}
                >
                  <span className={`text-xs font-mono font-bold ${isSelected ? 'text-amber-500' : 'text-neutral-800 dark:text-neutral-200'}`}>
                    {day}
                  </span>

                  {hasActivity && (
                    <div className="flex items-center gap-1">
                      <span className="text-xs" title={`${dayEntries[0].book.title}`}>
                        📖
                      </span>
                      <span className="text-[10px] font-mono font-bold text-amber-600 dark:text-amber-400 truncate">
                        {dayEntries[0].sessionPages}p
                      </span>
                    </div>
                  )}
                </button>
              );
            })}
          </div>
        </div>

        {/* Selected Day Inspector Box (Req 12) (4 cols) */}
        <div className="lg:col-span-4 p-6 rounded-3xl border border-neutral-200/80 bg-white dark:border-neutral-800 dark:bg-neutral-900 shadow-xs space-y-4 flex flex-col justify-between">
          <div className="space-y-4">
            <div className="pb-3 border-b border-neutral-100 dark:border-neutral-800">
              <span className="text-[10px] font-mono uppercase text-neutral-400 font-semibold block">
                Reading Session Detail
              </span>
              <h3 className="text-lg font-bold text-neutral-900 dark:text-neutral-100 mt-0.5">
                {monthNames[currentMonth]} {selectedCalendarDay}, {currentYear}
              </h3>
            </div>

            {selectedDayEntries.length > 0 ? (
              <div className="space-y-4">
                {selectedDayEntries.map((item) => (
                  <div key={item.id} className="space-y-3">
                    <div className="flex gap-3 items-start">
                      <div className="w-12 shrink-0">
                        <BookCover
                          title={item.book.title}
                          author={item.book.author}
                          category={item.book.category}
                          coverGradient={item.book.coverGradient}
                          aspectRatio="aspect-[2/3]"
                        />
                      </div>
                      <div className="min-w-0 flex-1">
                        <span className="text-[10px] font-mono text-neutral-400 block uppercase">
                          {item.status}
                        </span>
                        <h4 className="font-bold text-xs text-neutral-900 dark:text-neutral-100 truncate">
                          {item.book.title}
                        </h4>
                        <p className="text-[11px] text-neutral-500 truncate">{item.book.author}</p>
                        <div className="flex items-center gap-1 text-amber-500 pt-1">
                          {Array.from({ length: item.rating }).map((_, i) => (
                            <Star key={i} className="w-3 h-3 fill-amber-400 text-amber-400" />
                          ))}
                        </div>
                      </div>
                    </div>

                    <div className="p-3 rounded-xl bg-neutral-50 dark:bg-neutral-800/60 border border-neutral-200/60 dark:border-neutral-700/60 space-y-1.5 text-xs font-mono">
                      <div className="flex justify-between">
                        <span className="text-neutral-400">Pages Completed:</span>
                        <span className="font-bold text-neutral-900 dark:text-neutral-100">
                          {item.sessionPages || 42} pages
                        </span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-neutral-400">Study Duration:</span>
                        <span className="text-neutral-700 dark:text-neutral-300">
                          {item.sessionMinutes || 60} mins
                        </span>
                      </div>
                    </div>

                    {item.notes && (
                      <p className="text-xs text-neutral-600 dark:text-neutral-300 italic p-3 rounded-xl bg-amber-50/40 dark:bg-amber-950/20 border border-amber-200/40 dark:border-amber-900/40">
                        "{item.notes}"
                      </p>
                    )}
                  </div>
                ))}
              </div>
            ) : (
              <div className="p-8 text-center text-xs text-neutral-500 rounded-2xl border border-dashed border-neutral-200 dark:border-neutral-800">
                No reading activity logged on {monthNames[currentMonth]} {selectedCalendarDay}.
              </div>
            )}
          </div>

          <Button
            variant="outline"
            size="sm"
            className="w-full"
            leftIcon={<Plus className="w-3.5 h-3.5" />}
            onClick={() => {
              setLogFinishedDate(`${currentYear}-${String(currentMonth + 1).padStart(2, '0')}-${String(selectedCalendarDay).padStart(2, '0')}`);
              setIsLogModalOpen(true);
            }}
          >
            Log Activity on this Day
          </Button>
        </div>
      </div>

      {/* Reading Activity Heatmap (Req 13) */}
      <div className="p-6 sm:p-8 rounded-3xl border border-neutral-200/80 bg-white dark:border-neutral-800 dark:bg-neutral-900 shadow-xs space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
          <div>
            <h3 className="text-base font-bold text-neutral-900 dark:text-neutral-100 flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-amber-500" />
              <span>2026 Reading Activity Heatmap</span>
            </h3>
            <p className="text-xs text-neutral-500">
              Annual calendar distribution of logged reading sessions and page contributions.
            </p>
          </div>

          <div className="flex items-center gap-4 text-xs font-mono text-neutral-500">
            <span>Total: 86 Days Active</span>
            <span>·</span>
            <span>8,420 Pages Read</span>
          </div>
        </div>

        {/* GitHub-style month blocks heatmap */}
        <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-6 gap-3 pt-2">
          {[
            { month: 'Jan', count: 7, level: 2 },
            { month: 'Feb', count: 9, level: 3 },
            { month: 'Mar', count: 6, level: 2 },
            { month: 'Apr', count: 11, level: 4 },
            { month: 'May', count: 8, level: 3 },
            { month: 'Jun', count: 14, level: 4 },
            { month: 'Jul', count: 9, level: 3 },
            { month: 'Aug', count: 12, level: 4 },
            { month: 'Sep', count: 10, level: 3 },
            { month: 'Oct', count: 0, level: 0 },
            { month: 'Nov', count: 0, level: 0 },
            { month: 'Dec', count: 0, level: 0 },
          ].map((m, i) => (
            <div key={i} className="p-3 rounded-xl bg-neutral-50 dark:bg-neutral-800/50 border border-neutral-200/60 dark:border-neutral-700/60 space-y-1.5">
              <div className="flex items-center justify-between text-xs">
                <span className="font-semibold text-neutral-900 dark:text-neutral-100">{m.month}</span>
                <span className="text-[10px] font-mono text-neutral-400">{m.count} days</span>
              </div>
              <div className="grid grid-cols-4 gap-1">
                {[1, 2, 3, 4].map((b) => (
                  <div
                    key={b}
                    className={`h-2.5 rounded-sm ${
                      b <= m.level ? 'bg-amber-500' : 'bg-neutral-200 dark:bg-neutral-700'
                    }`}
                  />
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Diary Entries Log List */}
      <div className="space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <h2 className="text-xl font-bold text-neutral-900 dark:text-neutral-100">
              Logged Reading Entries
            </h2>
            <p className="text-xs text-neutral-500 mt-0.5">
              Detailed chronological history of all books, session lengths, and critical study takeaways.
            </p>
          </div>

          {/* Status Filter Tabs */}
          <div className="flex items-center gap-1 p-1 bg-neutral-100 dark:bg-neutral-800 rounded-xl text-xs font-semibold">
            {['ALL', 'Finished', 'Currently Reading', 'Want to Read', 'DNF'].map((s) => (
              <button
                key={s}
                onClick={() => setStatusFilter(s)}
                className={`px-3 py-1.5 rounded-lg transition-colors cursor-pointer ${
                  statusFilter === s
                    ? 'bg-white text-neutral-900 shadow-xs dark:bg-neutral-900 dark:text-white'
                    : 'text-neutral-500 hover:text-neutral-900 dark:hover:text-white'
                }`}
              >
                {s}
              </button>
            ))}
          </div>
        </div>

        <div className="space-y-3">
          {filteredEntries.map((item) => (
            <div
              key={item.id}
              className="p-5 rounded-2xl border border-neutral-200/80 bg-white dark:border-neutral-800 dark:bg-neutral-900 shadow-xs flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 hover:border-neutral-300 dark:hover:border-neutral-700 transition-colors"
            >
              <div className="flex items-center gap-4 min-w-0">
                <Link to={`/books/${item.book.id}`} className="w-14 shrink-0 block">
                  <BookCover
                    title={item.book.title}
                    author={item.book.author}
                    category={item.book.category}
                    coverGradient={item.book.coverGradient}
                    aspectRatio="aspect-[2/3]"
                  />
                </Link>

                <div className="min-w-0 space-y-1">
                  <div className="flex items-center gap-2">
                    <span className="text-[10px] font-mono font-semibold px-2 py-0.5 rounded bg-amber-50 text-amber-700 dark:bg-amber-950/60 dark:text-amber-400 border border-amber-200 dark:border-amber-900">
                      {item.status}
                    </span>
                    <span className="text-[11px] font-mono text-neutral-400">
                      Finished: {item.finishedDate || 'In Progress'}
                    </span>
                  </div>

                  <Link to={`/books/${item.book.id}`}>
                    <h4 className="font-bold text-sm text-neutral-900 dark:text-neutral-100 hover:text-amber-600 transition-colors truncate">
                      {item.book.title}
                    </h4>
                  </Link>

                  <p className="text-xs text-neutral-500 truncate">{item.book.author} · {item.book.category}</p>

                  <div className="flex items-center gap-3 text-xs pt-0.5">
                    <div className="flex items-center gap-0.5 text-amber-500">
                      {Array.from({ length: item.rating }).map((_, i) => (
                        <Star key={i} className="w-3 h-3 fill-amber-400 text-amber-400" />
                      ))}
                    </div>
                    <span className="font-mono text-neutral-400 text-[11px]">
                      {item.pagesRead} pages recorded
                    </span>
                  </div>
                </div>
              </div>

              <div className="sm:max-w-xs text-xs text-neutral-600 dark:text-neutral-300 italic border-l-2 border-amber-500/40 pl-3">
                "{item.notes}"
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Log Book Modal (Req 11 & 27) */}
      <Modal
        isOpen={isLogModalOpen}
        onClose={() => setIsLogModalOpen(false)}
        title="Log Book into Reading Diary"
        description="Record reading progress, pages completed, star score, and reflection notes."
      >
        <form onSubmit={handleSaveLog} className="space-y-4">
          <div>
            <label className="block text-xs font-semibold text-neutral-700 dark:text-neutral-300 mb-1.5">
              Select Book
            </label>
            <select
              value={logBookId}
              onChange={(e) => setLogBookId(e.target.value)}
              className="w-full h-10 rounded-xl border border-neutral-300 bg-white px-3 text-xs text-neutral-900 focus:outline-none focus:ring-2 focus:ring-neutral-900 dark:border-neutral-700 dark:bg-neutral-800 dark:text-neutral-100"
            >
              {initialBooks.map((b) => (
                <option key={b.id} value={b.id}>
                  {b.title} — {b.author}
                </option>
              ))}
            </select>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold text-neutral-700 dark:text-neutral-300 mb-1.5">
                Reading Status
              </label>
              <select
                value={logStatus}
                onChange={(e) => setLogStatus(e.target.value)}
                className="w-full h-10 rounded-xl border border-neutral-300 bg-white px-3 text-xs text-neutral-900 focus:outline-none focus:ring-2 focus:ring-neutral-900 dark:border-neutral-700 dark:bg-neutral-800 dark:text-neutral-100"
              >
                <option value="Finished">Finished</option>
                <option value="Currently Reading">Currently Reading</option>
                <option value="Want to Read">Want to Read</option>
                <option value="DNF">Did Not Finish (DNF)</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-neutral-700 dark:text-neutral-300 mb-1.5">
                Pages Completed
              </label>
              <input
                type="number"
                value={logPagesRead}
                onChange={(e) => setLogPagesRead(e.target.value)}
                className="w-full h-10 rounded-xl border border-neutral-300 bg-white px-3 text-xs text-neutral-900 focus:outline-none focus:ring-2 focus:ring-neutral-900 dark:border-neutral-700 dark:bg-neutral-800 dark:text-neutral-100 font-mono"
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold text-neutral-700 dark:text-neutral-300 mb-1.5">
                Started Date
              </label>
              <input
                type="date"
                value={logStartedDate}
                onChange={(e) => setLogStartedDate(e.target.value)}
                className="w-full h-10 rounded-xl border border-neutral-300 bg-white px-3 text-xs text-neutral-900 focus:outline-none focus:ring-2 focus:ring-neutral-900 dark:border-neutral-700 dark:bg-neutral-800 dark:text-neutral-100 font-mono"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-neutral-700 dark:text-neutral-300 mb-1.5">
                Finished Date
              </label>
              <input
                type="date"
                value={logFinishedDate}
                onChange={(e) => setLogFinishedDate(e.target.value)}
                className="w-full h-10 rounded-xl border border-neutral-300 bg-white px-3 text-xs text-neutral-900 focus:outline-none focus:ring-2 focus:ring-neutral-900 dark:border-neutral-700 dark:bg-neutral-800 dark:text-neutral-100 font-mono"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-neutral-700 dark:text-neutral-300 mb-1.5">
              Star Rating ({logRating} / 5)
            </label>
            <div className="flex items-center gap-2">
              {[1, 2, 3, 4, 5].map((s) => (
                <button
                  key={s}
                  type="button"
                  onClick={() => setLogRating(s)}
                  className="p-1 text-amber-500 hover:scale-110 transition-transform cursor-pointer"
                >
                  <Star
                    className={`w-6 h-6 ${
                      s <= logRating ? 'fill-amber-400 text-amber-400' : 'text-neutral-300 dark:text-neutral-700'
                    }`}
                  />
                </button>
              ))}
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-neutral-700 dark:text-neutral-300 mb-1.5">
              Session Takeaways & Study Notes
            </label>
            <textarea
              rows={3}
              placeholder="Key concepts mastered, chapter summaries, application in engineering projects..."
              value={logNotes}
              onChange={(e) => setLogNotes(e.target.value)}
              className="w-full rounded-xl border border-neutral-300 bg-white p-3 text-xs text-neutral-900 focus:outline-none focus:ring-2 focus:ring-neutral-900 dark:border-neutral-700 dark:bg-neutral-800 dark:text-neutral-100"
            />
          </div>

          <div className="flex items-center gap-2">
            <input
              type="checkbox"
              id="isPublicCheck"
              checked={logIsPublic}
              onChange={(e) => setLogIsPublic(e.target.checked)}
              className="w-4 h-4 rounded text-amber-600 focus:ring-amber-500"
            />
            <label htmlFor="isPublicCheck" className="text-xs text-neutral-600 dark:text-neutral-300">
              Share this entry publicly on my BookBuddy reader profile
            </label>
          </div>

          <div className="flex items-center justify-end gap-3 pt-3 border-t border-neutral-100 dark:border-neutral-800">
            <Button variant="outline" size="sm" onClick={() => setIsLogModalOpen(false)}>
              Cancel
            </Button>
            <Button type="submit" variant="primary" size="sm">
              Save Entry
            </Button>
          </div>
        </form>
      </Modal>
    </div>
  );
};

export default ReadingDiaryPage;
