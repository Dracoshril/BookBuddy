import React, { useState } from 'react';
import { useAuth } from '../../hooks/useAuth';
import { useSelector, useDispatch } from 'react-redux';
import { updateProfile } from '../../store/slices/authSlice';
import { Avatar } from '../../components/common/Avatar';
import { Button } from '../../components/common/Button';
import { Input } from '../../components/common/Input';
import { Modal } from '../../components/common/Modal';
import { BookOpen, Star, MessageSquare, ListOrdered, Users, Edit3, CheckCircle2 } from 'lucide-react';
import { toast } from 'sonner';

export const ProfilePage = () => {
  const { user } = useAuth();
  const dispatch = useDispatch();
  const borrowings = useSelector((state) => state.borrowings.items);
  const lists = useSelector((state) => state.lists.lists);

  const [isEditModalOpen, setIsEditModalOpen] = useState(false);
  const [editName, setEditName] = useState(user?.name || '');
  const [editBio, setEditBio] = useState(user?.bio || '');
  const [editDept, setEditDept] = useState(user?.department || '');

  const handleSaveProfile = (e) => {
    e.preventDefault();
    dispatch(
      updateProfile({
        name: editName,
        bio: editBio,
        department: editDept,
      })
    );
    toast.success('Profile details saved successfully!');
    setIsEditModalOpen(false);
  };

  return (
    <div className="space-y-8 max-w-4xl">
      {/* Profile Header Card */}
      <div className="p-6 sm:p-8 rounded-3xl border border-neutral-200/80 bg-white dark:border-neutral-800 dark:bg-neutral-900 shadow-xs space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex items-center gap-4">
            <Avatar name={user?.name || 'Reader'} size="xl" />
            <div className="space-y-1">
              <div className="flex items-center gap-2">
                <h1 className="text-xl sm:text-2xl font-bold tracking-tight text-neutral-900 dark:text-neutral-100">
                  {user?.name || 'Student Reader'}
                </h1>
                <span className="text-[10px] font-mono font-semibold px-2 py-0.5 rounded bg-amber-50 text-amber-700 dark:bg-amber-950/60 dark:text-amber-300 border border-amber-200/60 dark:border-amber-900/60">
                  {user?.role || 'STUDENT'}
                </span>
              </div>
              <p className="text-xs text-neutral-500 font-mono">
                ID: {user?.studentId || 'CS2023-8891'} · {user?.department || 'Computer Science'}
              </p>
            </div>
          </div>

          <Button
            variant="outline"
            size="sm"
            leftIcon={<Edit3 className="w-3.5 h-3.5" />}
            onClick={() => {
              setEditName(user?.name || '');
              setEditBio(user?.bio || '');
              setEditDept(user?.department || '');
              setIsEditModalOpen(true);
            }}
          >
            Edit Profile
          </Button>
        </div>

        {/* Bio */}
        <p className="text-xs sm:text-sm text-neutral-600 dark:text-neutral-300 leading-relaxed max-w-2xl">
          {user?.bio || 'Passionate university scholar exploring software engineering, distributed systems, and AI.'}
        </p>

        {/* Metric Badges */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 pt-4 border-t border-neutral-100 dark:border-neutral-800 text-center font-mono">
          <div className="p-3 rounded-xl bg-neutral-50 dark:bg-neutral-800/60">
            <span className="block text-xl font-bold text-neutral-900 dark:text-neutral-100 tabular-nums">
              {user?.booksReadCount ?? 28}
            </span>
            <span className="text-[11px] text-neutral-400 font-sans">Books Read</span>
          </div>

          <div className="p-3 rounded-xl bg-neutral-50 dark:bg-neutral-800/60">
            <span className="block text-xl font-bold text-amber-600 dark:text-amber-400 tabular-nums">
              {user?.averageRating ?? 4.8}
            </span>
            <span className="text-[11px] text-neutral-400 font-sans">Average Rating</span>
          </div>

          <div className="p-3 rounded-xl bg-neutral-50 dark:bg-neutral-800/60">
            <span className="block text-xl font-bold text-neutral-900 dark:text-neutral-100 tabular-nums">
              {user?.reviewsCount ?? 12}
            </span>
            <span className="text-[11px] text-neutral-400 font-sans">Reviews Written</span>
          </div>

          <div className="p-3 rounded-xl bg-neutral-50 dark:bg-neutral-800/60">
            <span className="block text-xl font-bold text-neutral-900 dark:text-neutral-100 tabular-nums">
              {lists?.length || user?.listsCount || 4}
            </span>
            <span className="text-[11px] text-neutral-400 font-sans">Curated Lists</span>
          </div>
        </div>

        {/* Social Follower counts */}
        <div className="flex items-center gap-2 sm:gap-3 text-xs text-neutral-500 pt-2 font-mono">
          <span>
            <strong className="text-neutral-900 dark:text-neutral-100 tabular-nums">
              {user?.followersCount ?? 0}
            </strong> Followers
          </span>
          <span aria-hidden="true" className="text-neutral-400">·</span>
          <span>
            <strong className="text-neutral-900 dark:text-neutral-100 tabular-nums">
              {user?.followingCount ?? 0}
            </strong> Following
          </span>
          <span aria-hidden="true" className="text-neutral-400">·</span>
          <span>Member since {user?.memberSince || 'Aug 2025'}</span>
        </div>
      </div>

      {/* Edit Profile Modal */}
      <Modal
        isOpen={isEditModalOpen}
        onClose={() => setIsEditModalOpen(false)}
        title="Edit Reader Profile"
        description="Update your display name, department affiliation, and reading bio"
      >
        <form onSubmit={handleSaveProfile} className="space-y-4">
          <Input
            label="Full Name"
            value={editName}
            onChange={(e) => setEditName(e.target.value)}
            required
          />

          <Input
            label="Department / Course"
            value={editDept}
            onChange={(e) => setEditDept(e.target.value)}
            required
          />

          <div>
            <label className="block text-xs font-semibold text-neutral-700 dark:text-neutral-300 mb-1.5">
              Personal Reading Bio
            </label>
            <textarea
              rows={3}
              value={editBio}
              onChange={(e) => setEditBio(e.target.value)}
              className="w-full rounded-xl border border-neutral-300 bg-white p-3 text-xs text-neutral-900 focus:outline-none focus:ring-2 focus:ring-neutral-900 dark:border-neutral-800 dark:bg-neutral-900 dark:text-neutral-100"
            />
          </div>

          <div className="flex items-center justify-end gap-3 pt-3 border-t border-neutral-100 dark:border-neutral-800">
            <Button variant="outline" size="sm" onClick={() => setIsEditModalOpen(false)}>
              Cancel
            </Button>
            <Button type="submit" variant="primary" size="sm">
              Save Changes
            </Button>
          </div>
        </form>
      </Modal>
    </div>
  );
};

export default ProfilePage;
