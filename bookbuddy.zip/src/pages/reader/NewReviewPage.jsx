import React, { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { useDispatch, useSelector } from 'react-redux';
import { useAuth } from '../../hooks/useAuth';
import { addReview } from '../../store/slices/socialSlice';
import { initialBooks } from '../../data/books';
import { Button } from '../../components/common/Button';
import { Input } from '../../components/common/Input';
import { Select } from '../../components/common/Select';
import { Star, ArrowLeft } from 'lucide-react';
import { toast } from 'sonner';

export const NewReviewPage = () => {
  const navigate = useNavigate();
  const dispatch = useDispatch();
  const { user } = useAuth();

  const [selectedBookId, setSelectedBookId] = useState(initialBooks[0].id);
  const [rating, setRating] = useState(5);
  const [title, setTitle] = useState('');
  const [content, setContent] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  const selectedBook = initialBooks.find((b) => String(b.id) === String(selectedBookId)) || initialBooks[0];

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!content.trim()) {
      toast.error('Please write some review thoughts or key takeaways.');
      return;
    }

    setIsSubmitting(true);
    try {
      await dispatch(
        addReview({
          bookId: selectedBook.id,
          bookTitle: selectedBook.title,
          userId: user?.id || 'user-1',
          userName: user?.name || 'Vishal Gayathri',
          userRole: user?.role || 'STUDENT',
          rating,
          title: title.trim() || 'Comprehensive Book Review',
          content: content.trim(),
        })
      ).unwrap();

      toast.success('Your review has been published to the community!');
      navigate('/student/reviews');
    } catch (err) {
      toast.error(err.message || 'Failed to submit review');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="max-w-2xl mx-auto space-y-6">
      <Link
        to="/student/reviews"
        className="inline-flex items-center gap-1.5 text-xs font-semibold text-neutral-500 hover:text-neutral-900 dark:hover:text-white"
      >
        <ArrowLeft className="w-3.5 h-3.5" />
        <span>Back to Reviews</span>
      </Link>

      <div className="p-8 rounded-3xl border border-neutral-200/80 bg-white dark:border-neutral-800 dark:bg-neutral-900 shadow-sm space-y-6">
        <div>
          <h1 className="text-xl font-bold tracking-tight text-neutral-900 dark:text-neutral-100">
            Write a Reading Review
          </h1>
          <p className="text-xs text-neutral-500 mt-1">
            Provide feedback, ratings, and practical study notes to guide fellow campus scholars.
          </p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <Select
            label="Select Book from Catalog"
            value={selectedBookId}
            onChange={(e) => setSelectedBookId(e.target.value)}
          >
            {initialBooks.map((b) => (
              <option key={b.id} value={b.id}>
                {b.title} — {b.author}
              </option>
            ))}
          </Select>

          {/* Star selector */}
          <div>
            <label className="block text-xs font-semibold text-neutral-700 dark:text-neutral-300 mb-2">
              Your Rating (1–5 Stars)
            </label>
            <div className="flex items-center gap-2">
              {[1, 2, 3, 4, 5].map((star) => (
                <button
                  key={star}
                  type="button"
                  onClick={() => setRating(star)}
                  className="p-1 rounded-md hover:bg-neutral-100 dark:hover:bg-neutral-800 transition-colors cursor-pointer"
                >
                  <Star
                    className={`w-7 h-7 ${
                      rating >= star ? 'fill-amber-400 text-amber-400' : 'text-neutral-300 dark:text-neutral-700'
                    }`}
                  />
                </button>
              ))}
              <span className="text-xs font-bold text-neutral-700 dark:text-neutral-300 ml-2">
                {rating} Stars
              </span>
            </div>
          </div>

          <Input
            label="Review Headline"
            placeholder="e.g. Invaluable foundational reading for Distributed Systems labs"
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            required
          />

          <div>
            <label className="block text-xs font-semibold text-neutral-700 dark:text-neutral-300 mb-1.5">
              Review Content & Key Concept Takeaways
            </label>
            <textarea
              rows={5}
              required
              value={content}
              onChange={(e) => setContent(e.target.value)}
              placeholder="What made this text useful? Which chapters stood out? How does it relate to academic coursework?"
              className="w-full rounded-xl border border-neutral-300 bg-white p-3 text-sm text-neutral-900 placeholder:text-neutral-400 focus:outline-none focus:ring-2 focus:ring-neutral-900 dark:border-neutral-800 dark:bg-neutral-900 dark:text-neutral-100"
            />
          </div>

          <div className="flex items-center justify-end gap-3 pt-4 border-t border-neutral-100 dark:border-neutral-800">
            <Button variant="outline" size="md" onClick={() => navigate('/reader/reviews')} disabled={isSubmitting}>
              Cancel
            </Button>
            <Button type="submit" variant="primary" size="md" isLoading={isSubmitting}>
              Publish Review
            </Button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default NewReviewPage;
