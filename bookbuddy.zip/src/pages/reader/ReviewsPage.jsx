import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../../hooks/useAuth';
import { initialReviews } from '../../data/reviews';
import { initialBooks } from '../../data/books';
import { Avatar } from '../../components/common/Avatar';
import { Button } from '../../components/common/Button';
import { Modal } from '../../components/common/Modal';
import {
  MessageSquare,
  Star,
  Heart,
  Plus,
  Trash2,
  Edit3,
  BookOpen,
  Share2,
  AlertTriangle,
  Clock,
  Sparkles,
  TrendingUp,
} from 'lucide-react';
import { format } from 'date-fns';
import { toast } from 'sonner';

export const ReviewsPage = () => {
  const { user } = useAuth();
  const currentUserId = user?.id || 'student-1';
  const currentUserName = user?.name || 'Vishal Gayathri';

  const [reviews, setReviews] = useState(() => {
    return initialReviews.map((r) => ({
      ...r,
      author: initialBooks.find((b) => String(b.id) === String(r.bookId))?.author || 'Author',
      isLikedByUser: r.likedBy?.includes(currentUserId) || (r.userId === 'user-1' && r.likedBy?.includes('user-1')),
    }));
  });

  const [activeTab, setActiveTab] = useState('ALL'); // 'ALL' | 'MINE' | 'POPULAR' | 'RECENT'

  // Modals
  const [isWriteModalOpen, setIsWriteModalOpen] = useState(false);
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);
  const [isDeleteModalOpen, setIsDeleteModalOpen] = useState(false);

  // Active review targets
  const [editingReview, setEditingReview] = useState(null);
  const [deletingReview, setDeletingReview] = useState(null);

  // Form fields
  const [formBookId, setFormBookId] = useState(initialBooks[0].id);
  const [formRating, setFormRating] = useState(5);
  const [formTitle, setFormTitle] = useState('');
  const [formContent, setFormContent] = useState('');
  const [formDate, setFormDate] = useState('2026-09-25');
  const [formSpoiler, setFormSpoiler] = useState(false);

  // Like Toggle (Req 25)
  const handleToggleLike = (reviewId) => {
    setReviews((prev) =>
      prev.map((r) => {
        if (r.id === reviewId) {
          const currentlyLiked = r.isLikedByUser;
          const nextLikes = currentlyLiked ? Math.max(0, r.likesCount - 1) : r.likesCount + 1;
          return {
            ...r,
            likesCount: nextLikes,
            isLikedByUser: !currentlyLiked,
          };
        }
        return r;
      })
    );
  };

  // Open Write Modal (Req 22)
  const handleOpenWriteModal = () => {
    setFormBookId(initialBooks[0].id);
    setFormRating(5);
    setFormTitle('');
    setFormContent('');
    setFormDate(new Date().toISOString().split('T')[0]);
    setFormSpoiler(false);
    setIsWriteModalOpen(true);
  };

  // Submit New Review (Req 22)
  const handlePublishReview = (e) => {
    e.preventDefault();
    if (!formTitle.trim() || !formContent.trim()) {
      toast.error('Please enter a review title and thoughts.');
      return;
    }

    const selectedBook = initialBooks.find((b) => String(b.id) === String(formBookId)) || initialBooks[0];

    const newRev = {
      id: `rev-${Date.now()}`,
      bookId: String(selectedBook.id),
      bookTitle: selectedBook.title,
      author: selectedBook.author,
      userId: currentUserId,
      userName: currentUserName,
      userRole: 'STUDENT',
      rating: Number(formRating),
      title: formTitle.trim(),
      content: formContent.trim(),
      likesCount: 0,
      isLikedByUser: false,
      comments: [],
      spoiler: formSpoiler,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    setReviews([newRev, ...reviews]);
    toast.success('Review added successfully');
    setIsWriteModalOpen(false);
  };

  // Open Edit Modal (Req 23)
  const handleOpenEditModal = (rev) => {
    setEditingReview(rev);
    setFormBookId(rev.bookId);
    setFormRating(rev.rating);
    setFormTitle(rev.title);
    setFormContent(rev.content);
    setFormDate(rev.createdAt?.split('T')[0] || new Date().toISOString().split('T')[0]);
    setFormSpoiler(Boolean(rev.spoiler));
    setIsEditModalOpen(true);
  };

  // Save Edit (Req 23)
  const handleSaveEdit = (e) => {
    e.preventDefault();
    if (!formTitle.trim() || !formContent.trim()) {
      toast.error('Review title and content cannot be empty.');
      return;
    }

    setReviews((prev) =>
      prev.map((r) =>
        r.id === editingReview.id
          ? {
              ...r,
              rating: Number(formRating),
              title: formTitle.trim(),
              content: formContent.trim(),
              spoiler: formSpoiler,
              updatedAt: new Date().toISOString(),
            }
          : r
      )
    );

    toast.success('Review updated successfully');
    setIsEditModalOpen(false);
    setEditingReview(null);
  };

  // Open Delete Modal (Req 24)
  const handleOpenDeleteModal = (rev) => {
    setDeletingReview(rev);
    setIsDeleteModalOpen(true);
  };

  // Confirm Delete (Req 24)
  const handleConfirmDelete = () => {
    if (!deletingReview) return;
    setReviews((prev) => prev.filter((r) => r.id !== deletingReview.id));
    toast.success('Review deleted successfully');
    setIsDeleteModalOpen(false);
    setDeletingReview(null);
  };

  // Filter & Sort Tabs (Req 20)
  const displayedReviews = reviews
    .filter((r) => {
      if (activeTab === 'MINE') {
        return r.userId === currentUserId || r.userId === 'user-1' || r.userName === currentUserName;
      }
      return true;
    })
    .sort((a, b) => {
      if (activeTab === 'POPULAR') {
        return (b.likesCount || 0) - (a.likesCount || 0);
      }
      if (activeTab === 'RECENT') {
        return new Date(b.createdAt || 0) - new Date(a.createdAt || 0);
      }
      return 0; // Default order
    });

  return (
    <div className="space-y-6 max-w-4xl mx-auto">
      {/* Page Title & Subtitle (Req 19) */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-bold tracking-tight text-neutral-900 dark:text-neutral-100">
            Book Reviews & Critiques
          </h1>
          <p className="text-xs sm:text-sm text-neutral-500 dark:text-neutral-400 mt-1 max-w-2xl">
            Share your thoughts, reading insights, and study takeaways with the BookBuddy community.
          </p>
        </div>

        <Button
          variant="primary"
          size="sm"
          leftIcon={<Plus className="w-4 h-4" />}
          onClick={handleOpenWriteModal}
        >
          + Write Review
        </Button>
      </div>

      {/* Review Filter Tabs (Req 20) */}
      <div className="flex items-center gap-1.5 p-1 bg-neutral-100 dark:bg-neutral-800 rounded-xl text-xs font-semibold w-fit">
        <button
          onClick={() => setActiveTab('ALL')}
          className={`px-3 py-1.5 rounded-lg transition-colors cursor-pointer ${
            activeTab === 'ALL'
              ? 'bg-white text-neutral-900 shadow-xs dark:bg-neutral-900 dark:text-white'
              : 'text-neutral-500 hover:text-neutral-900 dark:hover:text-white'
          }`}
        >
          All Reviews ({reviews.length})
        </button>

        <button
          onClick={() => setActiveTab('MINE')}
          className={`px-3 py-1.5 rounded-lg transition-colors cursor-pointer ${
            activeTab === 'MINE'
              ? 'bg-white text-neutral-900 shadow-xs dark:bg-neutral-900 dark:text-white'
              : 'text-neutral-500 hover:text-neutral-900 dark:hover:text-white'
          }`}
        >
          My Reviews ({reviews.filter((r) => r.userId === currentUserId || r.userId === 'user-1').length})
        </button>

        <button
          onClick={() => setActiveTab('POPULAR')}
          className={`flex items-center gap-1 px-3 py-1.5 rounded-lg transition-colors cursor-pointer ${
            activeTab === 'POPULAR'
              ? 'bg-white text-neutral-900 shadow-xs dark:bg-neutral-900 dark:text-white'
              : 'text-neutral-500 hover:text-neutral-900 dark:hover:text-white'
          }`}
        >
          <TrendingUp className="w-3.5 h-3.5" />
          <span>Popular</span>
        </button>

        <button
          onClick={() => setActiveTab('RECENT')}
          className={`flex items-center gap-1 px-3 py-1.5 rounded-lg transition-colors cursor-pointer ${
            activeTab === 'RECENT'
              ? 'bg-white text-neutral-900 shadow-xs dark:bg-neutral-900 dark:text-white'
              : 'text-neutral-500 hover:text-neutral-900 dark:hover:text-white'
          }`}
        >
          <Clock className="w-3.5 h-3.5" />
          <span>Recent</span>
        </button>
      </div>

      {/* Reviews List (Req 21) */}
      {displayedReviews.length > 0 ? (
        <div className="space-y-4">
          {displayedReviews.map((rev) => {
            const isOwner = rev.userId === currentUserId || rev.userId === 'user-1' || rev.userName === currentUserName;
            const formattedDate = rev.createdAt
              ? format(new Date(rev.createdAt), 'MMM dd, yyyy')
              : 'Sep 25, 2026';

            return (
              <div
                key={rev.id}
                className="p-6 rounded-3xl border border-neutral-200/80 bg-white dark:border-neutral-800 dark:bg-neutral-900 shadow-xs space-y-4"
              >
                {/* Reviewer Header */}
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <Avatar name={rev.userName} size="md" />
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-bold text-sm text-neutral-900 dark:text-neutral-100">
                          {rev.userName}
                        </span>
                        <span className="text-[10px] font-mono font-semibold px-2 py-0.5 rounded bg-amber-50 text-amber-700 dark:bg-amber-950/60 dark:text-amber-400 border border-amber-200 dark:border-amber-900">
                          {rev.userRole || 'STUDENT'}
                        </span>
                      </div>
                      <span className="text-[11px] font-mono text-neutral-400 block mt-0.5">
                        {formattedDate}
                      </span>
                    </div>
                  </div>

                  {rev.spoiler && (
                    <span className="text-[10px] font-mono uppercase px-2 py-0.5 rounded bg-rose-50 text-rose-700 dark:bg-rose-950/60 dark:text-rose-400 border border-rose-200 dark:border-rose-900">
                      Contains Spoilers
                    </span>
                  )}
                </div>

                {/* Book Reference & Star Rating */}
                <div className="p-3.5 rounded-2xl bg-neutral-50 dark:bg-neutral-800/50 border border-neutral-200/60 dark:border-neutral-700/60 flex items-center justify-between">
                  <div>
                    <Link
                      to={`/books/${rev.bookId}`}
                      className="font-bold text-xs sm:text-sm text-neutral-900 dark:text-neutral-100 hover:text-amber-600 transition-colors"
                    >
                      {rev.bookTitle}
                    </Link>
                    <p className="text-[11px] text-neutral-500">{rev.author}</p>
                  </div>

                  <div className="flex items-center gap-1 text-amber-500">
                    {Array.from({ length: 5 }).map((_, i) => (
                      <Star
                        key={i}
                        className={`w-3.5 h-3.5 ${
                          i < rev.rating
                            ? 'fill-amber-400 text-amber-400'
                            : 'text-neutral-300 dark:text-neutral-700'
                        }`}
                      />
                    ))}
                  </div>
                </div>

                {/* Review Title & Body */}
                <div className="space-y-1.5">
                  <h3 className="font-bold text-base text-neutral-900 dark:text-neutral-100">
                    {rev.title}
                  </h3>
                  <p className="text-xs sm:text-sm text-neutral-700 dark:text-neutral-300 leading-relaxed whitespace-pre-line">
                    {rev.content}
                  </p>
                </div>

                {/* Footer Actions: Likes, Comments, Share, Edit, Delete (Req 21 & 25) */}
                <div className="pt-3 border-t border-neutral-100 dark:border-neutral-800 flex items-center justify-between text-xs">
                  <div className="flex items-center gap-3">
                    <button
                      onClick={() => handleToggleLike(rev.id)}
                      className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg border transition-colors cursor-pointer ${
                        rev.isLikedByUser
                          ? 'border-rose-300 bg-rose-50 text-rose-600 dark:border-rose-900 dark:bg-rose-950/40 dark:text-rose-400'
                          : 'border-neutral-200 dark:border-neutral-800 text-neutral-600 dark:text-neutral-400 hover:text-neutral-900 dark:hover:text-white'
                      }`}
                      title={rev.isLikedByUser ? 'Unlike' : 'Like'}
                    >
                      <Heart
                        className={`w-3.5 h-3.5 ${
                          rev.isLikedByUser ? 'fill-current text-rose-500' : ''
                        }`}
                      />
                      <span className="font-mono font-semibold">{rev.likesCount || 0}</span>
                    </button>

                    <div className="flex items-center gap-1 text-neutral-500 font-mono text-[11px]">
                      <MessageSquare className="w-3.5 h-3.5" />
                      <span>{rev.comments?.length || 0}</span>
                    </div>

                    <button
                      onClick={() => {
                        navigator.clipboard.writeText(window.location.href);
                        toast.success('Review link copied to clipboard!');
                      }}
                      className="p-1.5 text-neutral-400 hover:text-neutral-900 dark:hover:text-white rounded-lg transition-colors cursor-pointer"
                      title="Share Review"
                    >
                      <Share2 className="w-3.5 h-3.5" />
                    </button>
                  </div>

                  {/* Edit & Delete for owner */}
                  <div className="flex items-center gap-2">
                    {isOwner && (
                      <>
                        <button
                          onClick={() => handleOpenEditModal(rev)}
                          className="inline-flex items-center gap-1 text-neutral-500 hover:text-neutral-900 dark:hover:text-white font-medium cursor-pointer"
                        >
                          <Edit3 className="w-3 h-3" />
                          <span>Edit</span>
                        </button>

                        <span className="text-neutral-300 dark:text-neutral-700">·</span>

                        <button
                          onClick={() => handleOpenDeleteModal(rev)}
                          className="inline-flex items-center gap-1 text-neutral-400 hover:text-rose-600 dark:hover:text-rose-400 font-medium cursor-pointer"
                        >
                          <Trash2 className="w-3 h-3" />
                          <span>Delete</span>
                        </button>

                        <span className="text-neutral-300 dark:text-neutral-700">·</span>
                      </>
                    )}

                    <Link
                      to={`/books/${rev.bookId}`}
                      className="inline-flex items-center gap-1 text-amber-600 dark:text-amber-400 font-semibold hover:underline"
                    >
                      <BookOpen className="w-3 h-3" />
                      <span>View Book</span>
                    </Link>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      ) : (
        <div className="p-12 text-center rounded-3xl border border-dashed border-neutral-200 dark:border-neutral-800 bg-white dark:bg-neutral-900">
          <MessageSquare className="w-8 h-8 text-neutral-400 mx-auto mb-2" />
          <h3 className="text-sm font-semibold text-neutral-900 dark:text-neutral-100">
            You haven't written any reviews yet.
          </h3>
          <p className="text-xs text-neutral-500 mt-1 max-w-sm mx-auto">
            Share your thoughts about a book you've read with your university reading peers.
          </p>
          <div className="mt-4">
            <Button variant="primary" size="sm" onClick={handleOpenWriteModal}>
              Write a Review
            </Button>
          </div>
        </div>
      )}

      {/* Write Review Modal (Req 22) */}
      <Modal
        isOpen={isWriteModalOpen}
        onClose={() => setIsWriteModalOpen(false)}
        title="Write Book Review"
        description="Share chapter critiques, study recommendations, or practical ratings with your peers."
      >
        <form onSubmit={handlePublishReview} className="space-y-4">
          <div>
            <label className="block text-xs font-semibold text-neutral-700 dark:text-neutral-300 mb-1.5">
              Select Book
            </label>
            <select
              value={formBookId}
              onChange={(e) => setFormBookId(e.target.value)}
              className="w-full h-10 rounded-xl border border-neutral-300 bg-white px-3 text-xs text-neutral-900 focus:outline-none focus:ring-2 focus:ring-neutral-900 dark:border-neutral-700 dark:bg-neutral-800 dark:text-neutral-100"
            >
              {initialBooks.map((b) => (
                <option key={b.id} value={b.id}>
                  {b.title} — {b.author}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-xs font-semibold text-neutral-700 dark:text-neutral-300 mb-1.5">
              Rating ({formRating} / 5)
            </label>
            <div className="flex items-center gap-1.5">
              {[1, 2, 3, 4, 5].map((s) => (
                <button
                  key={s}
                  type="button"
                  onClick={() => setFormRating(s)}
                  className="p-1 text-amber-500 hover:scale-110 transition-transform cursor-pointer"
                >
                  <Star
                    className={`w-6 h-6 ${
                      s <= formRating ? 'fill-amber-400 text-amber-400' : 'text-neutral-300 dark:text-neutral-700'
                    }`}
                  />
                </button>
              ))}
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-neutral-700 dark:text-neutral-300 mb-1.5">
              Review Title
            </label>
            <input
              type="text"
              required
              placeholder="e.g. Essential for every serious student engineer"
              value={formTitle}
              onChange={(e) => setFormTitle(e.target.value)}
              className="w-full h-10 rounded-xl border border-neutral-300 bg-white px-3 text-xs text-neutral-900 focus:outline-none focus:ring-2 focus:ring-neutral-900 dark:border-neutral-700 dark:bg-neutral-800 dark:text-neutral-100"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-neutral-700 dark:text-neutral-300 mb-1.5">
              Review Text & Critique
            </label>
            <textarea
              rows={4}
              required
              placeholder="Write your analysis, which concepts stood out, or advice for students preparing for exams or labs..."
              value={formContent}
              onChange={(e) => setFormContent(e.target.value)}
              className="w-full rounded-xl border border-neutral-300 bg-white p-3 text-xs text-neutral-900 focus:outline-none focus:ring-2 focus:ring-neutral-900 dark:border-neutral-700 dark:bg-neutral-800 dark:text-neutral-100"
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold text-neutral-700 dark:text-neutral-300 mb-1.5">
                Reading Date
              </label>
              <input
                type="date"
                value={formDate}
                onChange={(e) => setFormDate(e.target.value)}
                className="w-full h-10 rounded-xl border border-neutral-300 bg-white px-3 text-xs text-neutral-900 focus:outline-none focus:ring-2 focus:ring-neutral-900 dark:border-neutral-700 dark:bg-neutral-800 dark:text-neutral-100 font-mono"
              />
            </div>

            <div className="flex items-center gap-2 pt-6">
              <input
                type="checkbox"
                id="spoilerCheck"
                checked={formSpoiler}
                onChange={(e) => setFormSpoiler(e.target.checked)}
                className="w-4 h-4 rounded text-amber-600 focus:ring-amber-500"
              />
              <label htmlFor="spoilerCheck" className="text-xs text-neutral-600 dark:text-neutral-300">
                Mark as spoiler
              </label>
            </div>
          </div>

          <div className="flex items-center justify-end gap-3 pt-3 border-t border-neutral-100 dark:border-neutral-800">
            <Button variant="outline" size="sm" onClick={() => setIsWriteModalOpen(false)}>
              Cancel
            </Button>
            <Button type="submit" variant="primary" size="sm">
              Publish Review
            </Button>
          </div>
        </form>
      </Modal>

      {/* Edit Review Modal (Req 23) */}
      <Modal
        isOpen={isEditModalOpen}
        onClose={() => setIsEditModalOpen(false)}
        title="Edit Book Review"
        description="Update your star rating, thoughts, or reflections."
      >
        <form onSubmit={handleSaveEdit} className="space-y-4">
          <div>
            <label className="block text-xs font-semibold text-neutral-700 dark:text-neutral-300 mb-1.5">
              Book
            </label>
            <p className="text-xs font-bold text-neutral-900 dark:text-neutral-100">
              {editingReview?.bookTitle}
            </p>
          </div>

          <div>
            <label className="block text-xs font-semibold text-neutral-700 dark:text-neutral-300 mb-1.5">
              Rating ({formRating} / 5)
            </label>
            <div className="flex items-center gap-1.5">
              {[1, 2, 3, 4, 5].map((s) => (
                <button
                  key={s}
                  type="button"
                  onClick={() => setFormRating(s)}
                  className="p-1 text-amber-500 hover:scale-110 transition-transform cursor-pointer"
                >
                  <Star
                    className={`w-6 h-6 ${
                      s <= formRating ? 'fill-amber-400 text-amber-400' : 'text-neutral-300 dark:text-neutral-700'
                    }`}
                  />
                </button>
              ))}
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-neutral-700 dark:text-neutral-300 mb-1.5">
              Review Title
            </label>
            <input
              type="text"
              required
              value={formTitle}
              onChange={(e) => setFormTitle(e.target.value)}
              className="w-full h-10 rounded-xl border border-neutral-300 bg-white px-3 text-xs text-neutral-900 focus:outline-none focus:ring-2 focus:ring-neutral-900 dark:border-neutral-700 dark:bg-neutral-800 dark:text-neutral-100"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-neutral-700 dark:text-neutral-300 mb-1.5">
              Review Text
            </label>
            <textarea
              rows={4}
              required
              value={formContent}
              onChange={(e) => setFormContent(e.target.value)}
              className="w-full rounded-xl border border-neutral-300 bg-white p-3 text-xs text-neutral-900 focus:outline-none focus:ring-2 focus:ring-neutral-900 dark:border-neutral-700 dark:bg-neutral-800 dark:text-neutral-100"
            />
          </div>

          <div className="flex items-center gap-2">
            <input
              type="checkbox"
              id="spoilerCheckEdit"
              checked={formSpoiler}
              onChange={(e) => setFormSpoiler(e.target.checked)}
              className="w-4 h-4 rounded text-amber-600 focus:ring-amber-500"
            />
            <label htmlFor="spoilerCheckEdit" className="text-xs text-neutral-600 dark:text-neutral-300">
              Contains Spoilers
            </label>
          </div>

          <div className="flex items-center justify-end gap-3 pt-3 border-t border-neutral-100 dark:border-neutral-800">
            <Button variant="outline" size="sm" onClick={() => setIsEditModalOpen(false)}>
              Cancel
            </Button>
            <Button type="submit" variant="primary" size="sm">
              Save Changes
            </Button>
          </div>
        </form>
      </Modal>

      {/* Delete Review Confirmation Modal (Req 24) */}
      <Modal
        isOpen={isDeleteModalOpen}
        onClose={() => setIsDeleteModalOpen(false)}
        title="Delete Review?"
        description="This action cannot be undone."
      >
        <div className="space-y-4">
          <p className="text-xs text-neutral-600 dark:text-neutral-300">
            Are you sure you want to delete your review for{' '}
            <strong className="text-neutral-900 dark:text-neutral-100">
              "{deletingReview?.bookTitle}"
            </strong>
            ? It will be removed from your profile and community feeds.
          </p>

          <div className="flex items-center justify-end gap-3 pt-3 border-t border-neutral-100 dark:border-neutral-800">
            <Button variant="outline" size="sm" onClick={() => setIsDeleteModalOpen(false)}>
              Cancel
            </Button>
            <Button
              variant="primary"
              size="sm"
              className="bg-rose-600 hover:bg-rose-700 text-white"
              onClick={handleConfirmDelete}
            >
              Delete Review
            </Button>
          </div>
        </div>
      </Modal>
    </div>
  );
};

export default ReviewsPage;
