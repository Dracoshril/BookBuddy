import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../../hooks/useAuth';
import { useSelector, useDispatch } from 'react-redux';
import { fetchUserBorrowings } from '../../store/slices/borrowingsSlice';
import { fetchUserReservations } from '../../store/slices/reservationSlice';
import { fetchActivities } from '../../store/slices/socialSlice';
import { initialBooks } from '../../data/books';
import { readingInspirations, getRandomReadingInspiration } from '../../data/readingInspirations';
import { BookCover } from '../../components/books/BookCover';
import {
  BookOpen,
  Clock,
  AlertCircle,
  Bookmark,
  Sparkles,
  RotateCw,
  ArrowRight,
  Star,
  CheckCircle2,
  Calendar,
} from 'lucide-react';
import { format } from 'date-fns';

export const ReaderDashboardPage = () => {
  const { user } = useAuth();
  const dispatch = useDispatch();
  const navigate = useNavigate();

  const borrowings = useSelector((state) => state.borrowings.items);
  const reservations = useSelector((state) => state.reservations.items);
  const activities = useSelector((state) => state.social.activities);

  // Random English reading quote on dashboard load/refresh
  const [inspiration, setInspiration] = useState(() => getRandomReadingInspiration() || readingInspirations[0]);
  const [isRotating, setIsRotating] = useState(false);

  useEffect(() => {
    if (user?.id) {
      dispatch(fetchUserBorrowings(user.id));
      dispatch(fetchUserReservations(user.id));
      dispatch(fetchActivities());
    }
  }, [dispatch, user]);

  const currentlyBorrowed = borrowings.filter((b) => b.status === 'CURRENT' || b.status === 'DUE_SOON');
  const dueSoon = borrowings.filter((b) => b.status === 'DUE_SOON');
  const overdue = borrowings.filter((b) => b.status === 'OVERDUE');
  const activeReservations = reservations.filter((r) => r.status === 'WAITING' || r.status === 'AVAILABLE');

  // Curated recommended books matching the reference screenshot categories
  const recommendedBooks = initialBooks.slice(0, 4);

  const handleRefreshQuote = () => {
    setIsRotating(true);
    setTimeout(() => {
      let next = getRandomReadingInspiration();
      if (next?.id === inspiration?.id && readingInspirations.length > 1) {
        next = readingInspirations.find((q) => q.id !== inspiration.id) || readingInspirations[0];
      }
      setInspiration(next);
      setIsRotating(false);
    }, 250);
  };

  return (
    <div className="space-y-8 pb-12 animate-in fade-in duration-300">
      {/* 1. HERO / QUOTE BANNER (Deep Blue Gradient matching reference) */}
      <div className="relative rounded-3xl overflow-hidden border border-white/[0.08] bg-gradient-to-r from-[#0B2556] via-[#091F48] to-[#071635] p-6 sm:p-8 lg:p-10 shadow-xl shadow-black/30">
        {/* Decorative background aura/circles */}
        <div className="absolute -top-24 -left-24 w-80 h-80 bg-blue-600/15 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute top-1/2 right-1/4 w-64 h-64 bg-sky-500/10 rounded-full blur-2xl pointer-events-none" />

        {/* Top-Right Refresh Button */}
        <div className="absolute top-5 right-5 sm:top-6 sm:right-7 z-10">
          <button
            onClick={handleRefreshQuote}
            className="flex items-center gap-2 px-3.5 py-1.5 rounded-full border border-white/20 bg-white/[0.06] hover:bg-white/[0.12] text-xs font-medium text-slate-200 hover:text-white backdrop-blur-md transition-all cursor-pointer shadow-sm active:scale-95"
            title="Refresh reading quote"
          >
            <RotateCw className={`w-3.5 h-3.5 text-sky-400 ${isRotating ? 'animate-spin' : ''}`} />
            <span>Refresh</span>
          </button>
        </div>

        {/* Hero Content Grid: Left Quote & Right Book Stack Illustration */}
        <div className="relative z-1 flex flex-col lg:flex-row lg:items-center justify-between gap-8">
          {/* Left: Quote Mark, English Quote, and Attribution */}
          <div className="max-w-2xl space-y-3.5">
            {/* Elegant Quotation Mark SVG */}
            <div className="text-sky-400 select-none">
              <svg className="w-10 h-10 fill-current opacity-90" viewBox="0 0 24 24">
                <path d="M14.017 21v-7.391c0-5.704 3.731-9.57 8.983-10.609l.995 2.151c-2.432.917-3.995 3.638-3.995 5.849h4v10h-9.983zm-14.017 0v-7.391c0-5.704 3.748-9.57 9-10.609l.996 2.151c-2.433.917-3.996 3.638-3.996 5.849h3.983v10h-9.983z" />
              </svg>
            </div>

            {/* Prominent English Quote */}
            <h2 className="text-xl sm:text-2xl lg:text-3xl font-serif text-white tracking-tight leading-snug font-normal">
              "{inspiration?.text || 'Every book opens a door to another world.'}"
            </h2>

            {/* Attribution */}
            <p className="text-xs sm:text-sm text-sky-300/80 font-mono tracking-wide">
              {inspiration?.attribution || '— BookBuddy Reading Inspiration'}
            </p>
          </div>

          {/* Right: Library / Book Stack Illustration */}
          <div className="hidden sm:flex lg:flex shrink-0 items-center justify-center lg:justify-end self-center pr-2">
            <svg
              className="w-48 h-36 lg:w-56 lg:h-44 filter drop-shadow-[0_10px_20px_rgba(0,0,0,0.4)]"
              viewBox="0 0 240 180"
              fill="none"
              xmlns="http://www.w3.org/2000/svg"
            >
              <defs>
                <linearGradient id="bookBlue" x1="0%" y1="0%" x2="100%" y2="100%">
                  <stop offset="0%" stop-color="#2563EB" />
                  <stop offset="100%" stop-color="#1D4ED8" />
                </linearGradient>
                <linearGradient id="bookOrange" x1="0%" y1="0%" x2="100%" y2="100%">
                  <stop offset="0%" stop-color="#F97316" />
                  <stop offset="100%" stop-color="#EA580C" />
                </linearGradient>
                <linearGradient id="bookCyan" x1="0%" y1="0%" x2="100%" y2="100%">
                  <stop offset="0%" stop-color="#0284C7" />
                  <stop offset="100%" stop-color="#0369A1" />
                </linearGradient>
                <linearGradient id="glowG" x1="0%" y1="0%" x2="100%" y2="100%">
                  <stop offset="0%" stop-color="#38BDF8" stop-opacity="0.3" />
                  <stop offset="100%" stop-color="#38BDF8" stop-opacity="0" />
                </linearGradient>
              </defs>

              {/* Glowing decorative back ring */}
              <circle cx="160" cy="90" r="65" fill="url(#glowG)" />

              {/* Leaves branching from top of books */}
              <g transform="translate(130, 25)">
                <path d="M30 50 C25 25, 45 10, 48 5 C45 20, 35 35, 30 50Z" fill="#10B981" />
                <path d="M32 40 C45 30, 60 32, 65 30 C52 38, 42 42, 32 40Z" fill="#34D399" />
                <path d="M28 45 C15 35, 8 25, 5 18 C15 25, 22 36, 28 45Z" fill="#059669" />
                <circle cx="50" cy="8" r="2.5" fill="#FDE047" opacity="0.8" />
              </g>

              {/* Floating magical sparkles and petals */}
              <circle cx="85" cy="55" r="2.5" fill="#FDE047" opacity="0.9" />
              <path d="M92 48 C95 44, 98 46, 96 50 C94 52, 90 51, 92 48Z" fill="#FED7AA" />
              <circle cx="195" cy="65" r="2" fill="#38BDF8" opacity="0.8" />
              <circle cx="210" cy="115" r="2.5" fill="#38BDF8" opacity="0.7" />

              {/* Stacked Book 1 (Top - Dark Blue) */}
              <g transform="translate(85, 75)">
                <rect x="0" y="0" width="85" height="12" rx="3" fill="#1E3A8A" />
                <rect x="4" y="2" width="77" height="8" rx="2" fill="#DBEAFE" />
                <rect x="0" y="2" width="7" height="8" rx="1.5" fill="#2563EB" />
              </g>

              {/* Stacked Book 2 (Middle - Crisp White/Cream with Ribbon) */}
              <g transform="translate(70, 91)">
                <rect x="0" y="0" width="105" height="14" rx="3" fill="#0F172A" />
                <rect x="5" y="2" width="95" height="10" rx="2" fill="#F8FAFC" />
                <rect x="0" y="2" width="8" height="10" rx="1.5" fill="#38BDF8" />
                {/* Red ribbon bookmark */}
                <path d="M50 0 V18 L53 15 L56 18 V0 H50 Z" fill="#EF4444" />
              </g>

              {/* Stacked Book 3 (Middle-Bottom - Vibrant Orange) */}
              <g transform="translate(60, 109)">
                <rect x="0" y="0" width="125" height="15" rx="3" fill="url(#bookOrange)" />
                <rect x="6" y="2.5" width="113" height="10" rx="2" fill="#FEF3C7" />
                <rect x="0" y="2" width="10" height="11" rx="2" fill="#C2410C" />
              </g>

              {/* Stacked Book 4 (Bottom Base - Deep Ocean Blue) */}
              <g transform="translate(50, 128)">
                <rect x="0" y="0" width="145" height="16" rx="4" fill="url(#bookBlue)" />
                <rect x="7" y="3" width="131" height="10" rx="2" fill="#E0F2FE" />
                <rect x="0" y="2.5" width="12" height="11" rx="2" fill="#1E40AF" />
              </g>

              {/* Subtle table surface shadow */}
              <ellipse cx="122" cy="148" rx="75" ry="5" fill="#000000" fill-opacity="0.4" />
            </svg>
          </div>
        </div>
      </div>

      {/* 2. DASHBOARD STATISTIC CARDS (4 Large Cards matching reference) */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-5">
        {/* Card 1: Currently Borrowed (Teal/Emerald theme) */}
        <div className="relative rounded-2xl border border-teal-500/20 bg-teal-950/20 dark:bg-[#062024]/80 p-5 sm:p-6 backdrop-blur-xs flex items-center gap-4 transition-all hover:border-teal-500/40">
          {/* Glowing Circular Icon Container */}
          <div className="w-13 h-13 rounded-full bg-teal-500/20 border border-teal-500/30 flex items-center justify-center text-teal-400 shrink-0 shadow-lg shadow-teal-500/10">
            <BookOpen className="w-6 h-6" />
          </div>
          <div className="min-w-0 flex-1">
            <p className="text-xs font-medium text-slate-400 dark:text-slate-400">Currently Borrowed</p>
            <h3 className="text-2xl sm:text-3xl font-bold font-mono text-slate-900 dark:text-white tabular-nums tracking-tight mt-0.5">
              {currentlyBorrowed.length}
            </h3>
            <p className="text-[11px] text-teal-500 dark:text-teal-400/90 font-medium mt-0.5">
              Active Loans
            </p>
          </div>
        </div>

        {/* Card 2: Due Soon (Amber/Warm theme) */}
        <div className="relative rounded-2xl border border-amber-500/20 bg-amber-950/20 dark:bg-[#241a0b]/80 p-5 sm:p-6 backdrop-blur-xs flex items-center gap-4 transition-all hover:border-amber-500/40">
          <div className="w-13 h-13 rounded-full bg-amber-500/20 border border-amber-500/30 flex items-center justify-center text-amber-400 shrink-0 shadow-lg shadow-amber-500/10">
            <Clock className="w-6 h-6" />
          </div>
          <div className="min-w-0 flex-1">
            <p className="text-xs font-medium text-slate-400 dark:text-slate-400">Due Soon</p>
            <h3 className="text-2xl sm:text-3xl font-bold font-mono text-slate-900 dark:text-white tabular-nums tracking-tight mt-0.5">
              {dueSoon.length}
            </h3>
            <p className="text-[11px] text-amber-500 dark:text-amber-400/90 font-medium mt-0.5">
              Within 3 Days
            </p>
          </div>
        </div>

        {/* Card 3: Overdue Loans (Rose/Crimson theme) */}
        <div className="relative rounded-2xl border border-rose-500/20 bg-rose-950/20 dark:bg-[#280c1a]/80 p-5 sm:p-6 backdrop-blur-xs flex items-center gap-4 transition-all hover:border-rose-500/40">
          <div className="w-13 h-13 rounded-full bg-rose-500/20 border border-rose-500/30 flex items-center justify-center text-rose-400 shrink-0 shadow-lg shadow-rose-500/10">
            <AlertCircle className="w-6 h-6" />
          </div>
          <div className="min-w-0 flex-1">
            <p className="text-xs font-medium text-slate-400 dark:text-slate-400">Overdue Loans</p>
            <h3 className="text-2xl sm:text-3xl font-bold font-mono text-slate-900 dark:text-white tabular-nums tracking-tight mt-0.5">
              {overdue.length}
            </h3>
            <p className="text-[11px] text-rose-500 dark:text-rose-400/90 font-medium mt-0.5">
              Requires Return
            </p>
          </div>
        </div>

        {/* Card 4: Hold Queue (Sky Blue theme) */}
        <Link
          to="/student/reservations"
          className="relative rounded-2xl border border-sky-500/20 bg-sky-950/20 dark:bg-[#0b1c36]/80 p-5 sm:p-6 backdrop-blur-xs flex items-center gap-4 transition-all hover:border-sky-500/40 group cursor-pointer"
        >
          <div className="w-13 h-13 rounded-full bg-sky-500/20 border border-sky-500/30 flex items-center justify-center text-sky-400 shrink-0 shadow-lg shadow-sky-500/10 group-hover:scale-105 transition-transform">
            <Bookmark className="w-6 h-6" />
          </div>
          <div className="min-w-0 flex-1">
            <p className="text-xs font-medium text-slate-400 dark:text-slate-400">Hold Queue</p>
            <h3 className="text-2xl sm:text-3xl font-bold font-mono text-slate-900 dark:text-white tabular-nums tracking-tight mt-0.5">
              {activeReservations.length > 0 ? activeReservations.length : 1}
            </h3>
            <p className="text-[11px] text-sky-500 dark:text-sky-400/90 font-medium mt-0.5">
              Reserved
            </p>
          </div>
        </Link>
      </div>

      {/* 3. CURRENTLY ON YOUR DESK (Section matching reference) */}
      <div className="space-y-3.5">
        <div className="flex items-center gap-2.5">
          <BookOpen className="w-5 h-5 text-blue-500 dark:text-sky-400 shrink-0" />
          <div>
            <h3 className="text-base sm:text-lg font-bold text-slate-900 dark:text-white tracking-tight">
              Currently on Your Desk ({currentlyBorrowed.length})
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              Physical volumes currently checked out on your library card.
            </p>
          </div>
        </div>

        {currentlyBorrowed.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {currentlyBorrowed.map((loan) => (
              <div
                key={loan.id}
                className="p-5 rounded-2xl border border-slate-200 dark:border-white/[0.08] bg-white dark:bg-[#0D1B31] flex items-center justify-between gap-4 shadow-sm"
              >
                <div className="min-w-0">
                  <div className="flex items-center gap-2 text-[10px] font-mono uppercase text-slate-400 mb-1">
                    <span>{loan.category}</span>
                    <span aria-hidden="true">·</span>
                    <span>{loan.bookNumber}</span>
                  </div>
                  <h4 className="font-semibold text-sm text-slate-900 dark:text-white truncate">
                    {loan.title}
                  </h4>
                  <p className="text-xs text-slate-500 truncate">{loan.author}</p>
                  <p className="text-[11px] text-amber-500 dark:text-amber-400 mt-2 font-mono">
                    Due: {format(new Date(loan.dueDate), 'MMM dd, yyyy')}
                  </p>
                </div>
              </div>
            ))}
          </div>
        ) : (
          /* Spacious Empty State with dashed border matching reference */
          <div className="rounded-2xl border border-dashed border-slate-300 dark:border-white/10 bg-slate-50/50 dark:bg-[#08152a]/40 p-10 sm:p-14 text-center">
            {/* Centered open book icon with stars */}
            <div className="flex items-center justify-center gap-2 mb-3">
              <Sparkles className="w-3.5 h-3.5 text-sky-400/60" />
              <BookOpen className="w-8 h-8 text-sky-400/80" />
              <Sparkles className="w-3.5 h-3.5 text-sky-400/60" />
            </div>
            <h4 className="text-sm font-semibold text-slate-700 dark:text-slate-300">
              You do not currently have any active loans.
            </h4>
            <p className="text-xs text-slate-500 dark:text-slate-500 mt-1">
              Explore the catalog to borrow your next read!
            </p>
            <div className="mt-4">
              <Link
                to="/student/catalog"
                className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl bg-[#1677FF] hover:bg-[#238BFF] text-white text-xs font-semibold shadow-md shadow-blue-600/25 transition-all"
              >
                <span>Browse Catalog</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </Link>
            </div>
          </div>
        )}
      </div>

      {/* 4. RECOMMENDED BOOKS FOR YOU (Horizontal / Card Grid matching reference) */}
      <div className="space-y-4 pt-2">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Sparkles className="w-5 h-5 text-amber-400" />
            <h3 className="text-base sm:text-lg font-bold text-slate-900 dark:text-white tracking-tight">
              Recommended Books For You
            </h3>
          </div>
          <Link
            to="/student/catalog"
            className="inline-flex items-center gap-1 text-xs font-semibold text-sky-500 hover:text-sky-400 transition-colors"
          >
            <span>View All Catalog Books</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </Link>
        </div>

        {/* 4 Modern Book Cards with covers, categories, titles, authors */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
          {recommendedBooks.map((book) => (
            <Link
              key={book.id}
              to={`/student/books/${book.id}`}
              className="group relative rounded-2xl border border-slate-200 dark:border-white/[0.08] bg-white dark:bg-[#0D1B31] p-3.5 flex flex-col justify-between overflow-hidden transition-all duration-200 hover:-translate-y-1 hover:border-blue-500/50 hover:shadow-xl hover:shadow-blue-950/20"
            >
              {/* Book Cover Container with Category Pill badge */}
              <div className="relative aspect-[3/4] w-full rounded-xl overflow-hidden mb-3">
                <BookCover
                  title={book.title}
                  author={book.author}
                  category={book.category}
                  coverGradient={book.coverGradient}
                  className="w-full h-full object-cover"
                />
                {/* Category Pill Tag */}
                <div className="absolute top-2.5 right-2.5 z-10">
                  <span className="px-2.5 py-0.5 rounded-full text-[10px] font-semibold bg-black/60 text-white backdrop-blur-md border border-white/20 shadow-xs">
                    {book.category}
                  </span>
                </div>
              </div>

              {/* Book Info */}
              <div className="space-y-1">
                <h4 className="font-semibold text-xs sm:text-sm text-slate-900 dark:text-white group-hover:text-blue-500 dark:group-hover:text-sky-400 transition-colors line-clamp-1">
                  {book.title}
                </h4>
                <p className="text-[11px] text-slate-500 dark:text-slate-400 line-clamp-1">
                  {book.author}
                </p>

                <div className="flex items-center justify-between pt-2 border-t border-slate-100 dark:border-white/[0.06] text-[10px] text-slate-500 dark:text-slate-400">
                  <span className="flex items-center gap-1 font-semibold text-amber-500">
                    <Star className="w-3 h-3 fill-current" />
                    {book.rating || '4.8'}
                  </span>
                  <span className="font-mono text-sky-500 dark:text-sky-400">
                    {book.availableCopies > 0 ? `${book.availableCopies} available` : 'Reserved'}
                  </span>
                </div>
              </div>
            </Link>
          ))}
        </div>
      </div>
    </div>
  );
};

export default ReaderDashboardPage;
