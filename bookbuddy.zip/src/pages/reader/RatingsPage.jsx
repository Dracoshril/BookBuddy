import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { BookCover } from '../../components/books/BookCover';
import { Button } from '../../components/common/Button';
import { Modal } from '../../components/common/Modal';
import {
  Star,
  Plus,
  Edit3,
  Trash2,
  BookOpen,
  MessageSquare,
  BarChart2,
  TrendingUp,
  Award,
  Layers,
  Calendar,
  Flame,
  Clock,
  ArrowRight,
} from 'lucide-react';
import { initialBooks } from '../../data/books';
import { toast } from 'sonner';

export const RatingsPage = () => {
  // Initial rated books dataset derived from user reading journey
  const [ratedBooks, setRatedBooks] = useState([
    {
      id: 'rat-1',
      book: initialBooks[0], // Clean Code
      userRating: 5,
      date: 'Sep 25, 2026',
      notes: 'Indispensable guide for robust, testable software design.',
    },
    {
      id: 'rat-2',
      book: initialBooks[1], // Designing Data-Intensive Applications
      userRating: 5,
      date: 'Aug 28, 2026',
      notes: 'Masterclass in distributed storage systems and consensus protocols.',
    },
    {
      id: 'rat-3',
      book: initialBooks[6], // Atomic Habits
      userRating: 4,
      date: 'Sep 21, 2026',
      notes: 'Very practical habit stacking frameworks for daily coding discipline.',
    },
    {
      id: 'rat-4',
      book: initialBooks[4], // System Design Interview
      userRating: 5,
      date: 'Aug 02, 2026',
      notes: 'Comprehensive architectural diagrams for large-scale backends.',
    },
    {
      id: 'rat-5',
      book: initialBooks[7], // Deep Work
      userRating: 4,
      date: 'Jul 19, 2026',
      notes: 'Great mental models for focus during semester exams.',
    },
    {
      id: 'rat-6',
      book: initialBooks[3], // Pragmatic Programmer
      userRating: 5,
      date: 'Jun 10, 2026',
      notes: 'Timeless engineering wisdom on refactoring and tracer bullets.',
    },
  ]);

  // Modal states
  const [isRateModalOpen, setIsRateModalOpen] = useState(false);
  const [editingItem, setEditingItem] = useState(null);
  const [selectedBookId, setSelectedBookId] = useState(initialBooks[2].id);
  const [formRating, setFormRating] = useState(5);
  const [formNotes, setFormNotes] = useState('');
  const [timeRange, setTimeRange] = useState('monthly'); // 'monthly' | 'quarterly' | 'yearly'

  // Dynamic calculations from rating state
  const totalCount = ratedBooks.length;
  const sumRatings = ratedBooks.reduce((acc, r) => acc + r.userRating, 0);
  const overallAvgRating = totalCount > 0 ? (sumRatings / totalCount).toFixed(1) : '0.0';

  const distributionCounts = [5, 4, 3, 2, 1].map((s) => {
    const c = ratedBooks.filter((r) => r.userRating === s).length;
    return {
      stars: s,
      count: c,
      percent: totalCount > 0 ? Math.round((c / totalCount) * 100) : 0,
    };
  });

  // Handlers for Add/Edit/Delete
  const handleOpenAddModal = () => {
    setEditingItem(null);
    setSelectedBookId(initialBooks[2].id);
    setFormRating(5);
    setFormNotes('');
    setIsRateModalOpen(true);
  };

  const handleOpenEditModal = (item) => {
    setEditingItem(item);
    setSelectedBookId(item.book.id);
    setFormRating(item.userRating);
    setFormNotes(item.notes || '');
    setIsRateModalOpen(true);
  };

  const handleSaveRating = (e) => {
    e.preventDefault();
    const targetBook = initialBooks.find((b) => String(b.id) === String(selectedBookId)) || initialBooks[0];
    const today = new Date().toLocaleDateString('en-US', {
      month: 'short',
      day: '2-digit',
      year: 'numeric',
    });

    if (editingItem) {
      setRatedBooks((prev) =>
        prev.map((r) =>
          r.id === editingItem.id
            ? {
                ...r,
                book: targetBook,
                userRating: Number(formRating),
                notes: formNotes,
                date: today,
              }
            : r
        )
      );
      toast.success(`Rating for "${targetBook.title}" updated to ${formRating} stars.`);
    } else {
      const newRating = {
        id: `rat-${Date.now()}`,
        book: targetBook,
        userRating: Number(formRating),
        notes: formNotes,
        date: today,
      };
      setRatedBooks([newRating, ...ratedBooks.filter((r) => r.book.id !== targetBook.id)]);
      toast.success(`Rating saved! Evaluated "${targetBook.title}" with ${formRating} stars.`);
    }

    setIsRateModalOpen(false);
  };

  const handleDeleteRating = (itemId, bookTitle) => {
    setRatedBooks((prev) => prev.filter((r) => r.id !== itemId));
    toast.info(`Rating removed for "${bookTitle}".`);
  };

  // Category breakdown calculation
  const categoryMix = [
    { label: 'Programming & SE', percent: 42, color: 'bg-amber-500' },
    { label: 'Distributed Systems', percent: 25, color: 'bg-blue-500' },
    { label: 'Personal Mastery', percent: 18, color: 'bg-emerald-500' },
    { label: 'Science & Math', percent: 10, color: 'bg-purple-500' },
    { label: 'Other Topics', percent: 5, color: 'bg-neutral-400' },
  ];

  // Books read over time data
  const timeData = {
    monthly: [
      { period: 'Jan', count: 3 },
      { period: 'Feb', count: 5 },
      { period: 'Mar', count: 2 },
      { period: 'Apr', count: 6 },
      { period: 'May', count: 4 },
      { period: 'Jun', count: 8 },
      { period: 'Jul', count: 4 },
      { period: 'Aug', count: 5 },
      { period: 'Sep', count: 6 },
    ],
    quarterly: [
      { period: 'Q1 2026', count: 10 },
      { period: 'Q2 2026', count: 18 },
      { period: 'Q3 2026', count: 15 },
      { period: 'Q4 2026', count: 8 },
    ],
    yearly: [
      { period: '2024', count: 14 },
      { period: '2025', count: 22 },
      { period: '2026', count: 28 },
    ],
  };

  return (
    <div className="space-y-8 max-w-5xl mx-auto">
      {/* Title Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-bold tracking-tight text-neutral-900 dark:text-neutral-100">
            My Ratings & Reading Stats
          </h1>
          <p className="text-xs sm:text-sm text-neutral-500 dark:text-neutral-400 mt-1 max-w-2xl">
            Track every book you've rated, discover your reading patterns, and see how your reading journey evolves over time.
          </p>
        </div>

        <Button
          variant="primary"
          size="sm"
          leftIcon={<Plus className="w-4 h-4" />}
          onClick={handleOpenAddModal}
        >
          Rate a Book
        </Button>
      </div>

      {/* Top Section: Rating Summary & Distribution (Req 8 & 9) */}
      <div className="grid grid-cols-1 md:grid-cols-12 gap-6 p-6 sm:p-8 rounded-3xl border border-neutral-200/80 bg-white dark:border-neutral-800 dark:bg-neutral-900 shadow-xs">
        {/* Overall Rating Box */}
        <div className="md:col-span-4 flex flex-col justify-center items-center md:items-start md:border-r border-neutral-100 dark:border-neutral-800 md:pr-6 space-y-2">
          <span className="text-xs font-mono font-bold uppercase tracking-wider text-neutral-400">
            Overall Rating
          </span>
          <div className="flex items-baseline gap-2">
            <span className="text-5xl font-extrabold font-mono text-neutral-900 dark:text-neutral-100 tabular-nums">
              {overallAvgRating}
            </span>
            <span className="text-2xl text-amber-500 font-bold">★</span>
          </div>

          <div className="flex items-center gap-1 text-amber-500">
            {[1, 2, 3, 4, 5].map((s) => (
              <Star
                key={s}
                className={`w-4 h-4 ${
                  s <= Math.round(Number(overallAvgRating))
                    ? 'fill-amber-400 text-amber-400'
                    : 'text-neutral-300 dark:text-neutral-700'
                }`}
              />
            ))}
          </div>

          <p className="text-xs text-neutral-500 pt-1 font-mono">
            {totalCount} Books Rated & Evaluated
          </p>
        </div>

        {/* Dynamic Rating Distribution (Req 9) */}
        <div className="md:col-span-8 flex flex-col justify-center space-y-2.5">
          <span className="text-xs font-mono font-bold uppercase tracking-wider text-neutral-400 mb-1">
            Score Distribution
          </span>
          {distributionCounts.map((row) => (
            <div key={row.stars} className="flex items-center gap-3 text-xs">
              {/* Stars Icon representation */}
              <div className="w-16 flex items-center gap-0.5 text-amber-500 justify-end">
                {Array.from({ length: row.stars }).map((_, i) => (
                  <Star key={i} className="w-3 h-3 fill-amber-400 text-amber-400" />
                ))}
              </div>

              {/* Progress Bar */}
              <div className="flex-1 bg-neutral-100 dark:bg-neutral-800 rounded-full h-3 overflow-hidden">
                <div
                  className="bg-amber-500 h-full rounded-full transition-all duration-500"
                  style={{ width: `${row.percent}%` }}
                />
              </div>

              {/* Count and percent */}
              <span className="w-12 text-right font-mono text-neutral-600 dark:text-neutral-300 tabular-nums font-semibold">
                {row.count} ({row.percent}%)
              </span>
            </div>
          ))}
        </div>
      </div>

      {/* Reading Statistics Cards (Req 16) */}
      <div className="space-y-4">
        <h2 className="text-lg font-bold text-neutral-900 dark:text-neutral-100 flex items-center gap-2">
          <BarChart2 className="w-4 h-4 text-amber-500" />
          <span>Reading Statistics</span>
        </h2>

        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3.5">
          <div className="p-4 rounded-2xl border border-neutral-200/80 bg-white dark:border-neutral-800 dark:bg-neutral-900 shadow-xs">
            <span className="text-[10px] font-mono text-neutral-400 uppercase">Books Read</span>
            <p className="text-2xl font-bold font-mono text-neutral-900 dark:text-neutral-100 mt-1">28</p>
            <span className="text-[10px] text-emerald-600 dark:text-emerald-400">+4 this month</span>
          </div>

          <div className="p-4 rounded-2xl border border-neutral-200/80 bg-white dark:border-neutral-800 dark:bg-neutral-900 shadow-xs">
            <span className="text-[10px] font-mono text-neutral-400 uppercase">Pages Read</span>
            <p className="text-2xl font-bold font-mono text-neutral-900 dark:text-neutral-100 mt-1">8,420</p>
            <span className="text-[10px] text-neutral-400">~301 pages / book</span>
          </div>

          <div className="p-4 rounded-2xl border border-neutral-200/80 bg-white dark:border-neutral-800 dark:bg-neutral-900 shadow-xs">
            <span className="text-[10px] font-mono text-neutral-400 uppercase">Reading Days</span>
            <p className="text-2xl font-bold font-mono text-neutral-900 dark:text-neutral-100 mt-1">86</p>
            <span className="text-[10px] text-neutral-400">Past 12 months</span>
          </div>

          <div className="p-4 rounded-2xl border border-neutral-200/80 bg-white dark:border-neutral-800 dark:bg-neutral-900 shadow-xs">
            <span className="text-[10px] font-mono text-neutral-400 uppercase">Avg Books / Month</span>
            <p className="text-2xl font-bold font-mono text-neutral-900 dark:text-neutral-100 mt-1">3.5</p>
            <span className="text-[10px] text-neutral-400">Consistent pace</span>
          </div>

          <div className="p-4 rounded-2xl border border-neutral-200/80 bg-white dark:border-neutral-800 dark:bg-neutral-900 shadow-xs">
            <span className="text-[10px] font-mono text-neutral-400 uppercase">Longest Streak</span>
            <p className="text-2xl font-bold font-mono text-amber-500 mt-1">14 Days</p>
            <span className="text-[10px] text-neutral-400">Current: 7 days 🔥</span>
          </div>
        </div>

        {/* Qualitative Reader Milestones */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3.5">
          <div className="p-4 rounded-2xl bg-neutral-50 dark:bg-neutral-850/60 border border-neutral-200/60 dark:border-neutral-800 flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-amber-500/10 text-amber-500 flex items-center justify-center shrink-0">
              <Award className="w-5 h-5" />
            </div>
            <div className="min-w-0">
              <span className="text-[10px] font-mono text-neutral-400 uppercase block">Highest Rated Book</span>
              <p className="text-xs font-bold text-neutral-900 dark:text-neutral-100 truncate">Clean Code (5.0 ★)</p>
            </div>
          </div>

          <div className="p-4 rounded-2xl bg-neutral-50 dark:bg-neutral-850/60 border border-neutral-200/60 dark:border-neutral-800 flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-blue-500/10 text-blue-500 flex items-center justify-center shrink-0">
              <Layers className="w-5 h-5" />
            </div>
            <div className="min-w-0">
              <span className="text-[10px] font-mono text-neutral-400 uppercase block">Most Read Category</span>
              <p className="text-xs font-bold text-neutral-900 dark:text-neutral-100 truncate">Computer Science (12 books)</p>
            </div>
          </div>

          <div className="p-4 rounded-2xl bg-neutral-50 dark:bg-neutral-850/60 border border-neutral-200/60 dark:border-neutral-800 flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-purple-500/10 text-purple-500 flex items-center justify-center shrink-0">
              <BookOpen className="w-5 h-5" />
            </div>
            <div className="min-w-0">
              <span className="text-[10px] font-mono text-neutral-400 uppercase block">Most Read Author</span>
              <p className="text-xs font-bold text-neutral-900 dark:text-neutral-100 truncate">Robert C. Martin (3 books)</p>
            </div>
          </div>
        </div>
      </div>

      {/* Genre / Category Breakdown & Books Read Over Time (Req 15 & 17) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Category Breakdown: Your Reading Mix (Req 17) */}
        <div className="lg:col-span-5 p-6 rounded-3xl border border-neutral-200/80 bg-white dark:border-neutral-800 dark:bg-neutral-900 shadow-xs space-y-4">
          <div>
            <h3 className="text-base font-bold text-neutral-900 dark:text-neutral-100">
              Your Reading Mix
            </h3>
            <p className="text-xs text-neutral-500">
              Topic diversity derived from books you've completed and rated.
            </p>
          </div>

          {/* Bar mix visual */}
          <div className="h-4 rounded-full overflow-hidden flex w-full">
            {categoryMix.map((cat, idx) => (
              <div
                key={idx}
                className={`${cat.color} transition-all`}
                style={{ width: `${cat.percent}%` }}
                title={`${cat.label}: ${cat.percent}%`}
              />
            ))}
          </div>

          {/* Legend items */}
          <div className="space-y-2 pt-2">
            {categoryMix.map((cat, idx) => (
              <div key={idx} className="flex items-center justify-between text-xs">
                <div className="flex items-center gap-2">
                  <span className={`w-2.5 h-2.5 rounded-full ${cat.color}`} />
                  <span className="text-neutral-700 dark:text-neutral-300 font-medium">
                    {cat.label}
                  </span>
                </div>
                <span className="font-mono font-semibold text-neutral-900 dark:text-neutral-100 tabular-nums">
                  {cat.percent}%
                </span>
              </div>
            ))}
          </div>
        </div>

        {/* Books Read Over Time (Req 15) */}
        <div className="lg:col-span-7 p-6 rounded-3xl border border-neutral-200/80 bg-white dark:border-neutral-800 dark:bg-neutral-900 shadow-xs space-y-4 flex flex-col justify-between">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-base font-bold text-neutral-900 dark:text-neutral-100">
                Books Read Over Time
              </h3>
              <p className="text-xs text-neutral-500">
                Volume completion trajectory across academic terms.
              </p>
            </div>

            {/* Time toggle */}
            <div className="flex items-center gap-1 p-1 bg-neutral-100 dark:bg-neutral-800 rounded-xl text-xs font-semibold">
              {['monthly', 'quarterly', 'yearly'].map((mode) => (
                <button
                  key={mode}
                  onClick={() => setTimeRange(mode)}
                  className={`px-2.5 py-1 rounded-lg capitalize transition-colors cursor-pointer ${
                    timeRange === mode
                      ? 'bg-white text-neutral-900 shadow-xs dark:bg-neutral-900 dark:text-white'
                      : 'text-neutral-500 hover:text-neutral-900 dark:hover:text-white'
                  }`}
                >
                  {mode}
                </button>
              ))}
            </div>
          </div>

          {/* Chart Bars */}
          <div className="flex items-end gap-2 sm:gap-3 h-40 pt-4">
            {timeData[timeRange].map((item, idx) => {
              const maxVal = Math.max(...timeData[timeRange].map((t) => t.count), 1);
              const heightPercent = Math.round((item.count / maxVal) * 100);

              return (
                <div key={idx} className="flex-1 flex flex-col items-center gap-1.5 h-full justify-end group">
                  <span className="text-[10px] font-mono text-neutral-400 opacity-0 group-hover:opacity-100 transition-opacity">
                    {item.count}
                  </span>
                  <div className="w-full bg-neutral-100 dark:bg-neutral-800 rounded-t-lg relative flex items-end h-full overflow-hidden">
                    <div
                      className="w-full bg-amber-500 hover:bg-amber-400 rounded-t-lg transition-all duration-300"
                      style={{ height: `${heightPercent}%` }}
                    />
                  </div>
                  <span className="text-[10px] font-mono text-neutral-500 truncate w-full text-center">
                    {item.period}
                  </span>
                </div>
              );
            })}
          </div>
        </div>
      </div>

      {/* Section: Your Rating History (Req 10) */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-xl font-bold text-neutral-900 dark:text-neutral-100">
              Your Rating History
            </h2>
            <p className="text-xs text-neutral-500 mt-0.5">
              Personal score log and critical reactions across library volumes.
            </p>
          </div>
          <span className="text-xs font-mono text-neutral-400">
            {ratedBooks.length} items logged
          </span>
        </div>

        {ratedBooks.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {ratedBooks.map((item) => (
              <div
                key={item.id}
                className="p-5 rounded-2xl border border-neutral-200/80 bg-white dark:border-neutral-800 dark:bg-neutral-900 shadow-xs flex flex-col justify-between space-y-4 hover:border-neutral-300 dark:hover:border-neutral-700 transition-colors"
              >
                <div className="flex gap-4">
                  <Link to={`/books/${item.book.id}`} className="w-16 shrink-0 block">
                    <BookCover
                      title={item.book.title}
                      author={item.book.author}
                      category={item.book.category}
                      coverGradient={item.book.coverGradient}
                      aspectRatio="aspect-[2/3]"
                    />
                  </Link>

                  <div className="min-w-0 flex-1 space-y-1.5">
                    <Link to={`/books/${item.book.id}`}>
                      <h4 className="font-bold text-sm text-neutral-900 dark:text-neutral-100 hover:text-amber-600 transition-colors line-clamp-1">
                        {item.book.title}
                      </h4>
                    </Link>
                    <p className="text-xs text-neutral-500 truncate">{item.book.author}</p>

                    <div className="flex items-center gap-2 pt-0.5">
                      <div className="flex items-center gap-0.5 text-amber-500">
                        {Array.from({ length: 5 }).map((_, i) => (
                          <Star
                            key={i}
                            className={`w-3.5 h-3.5 ${
                              i < item.userRating ? 'fill-amber-400 text-amber-400' : 'text-neutral-300 dark:text-neutral-700'
                            }`}
                          />
                        ))}
                      </div>
                      <span className="text-xs font-mono font-bold text-neutral-700 dark:text-neutral-300">
                        Rated {item.userRating}/5
                      </span>
                    </div>

                    <span className="text-[11px] font-mono text-neutral-400 block">
                      Rated: {item.date}
                    </span>

                    {item.notes && (
                      <p className="text-xs text-neutral-600 dark:text-neutral-300 italic line-clamp-2 pt-1">
                        "{item.notes}"
                      </p>
                    )}
                  </div>
                </div>

                {/* Actions: Edit Rating, Remove Rating, View Book, Write Review (Req 10) */}
                <div className="pt-3 border-t border-neutral-100 dark:border-neutral-800 flex items-center justify-between text-xs">
                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => handleOpenEditModal(item)}
                      className="inline-flex items-center gap-1 text-neutral-600 hover:text-neutral-900 dark:text-neutral-400 dark:hover:text-white transition-colors cursor-pointer"
                    >
                      <Edit3 className="w-3.5 h-3.5" />
                      <span>Edit Rating</span>
                    </button>

                    <span className="text-neutral-300 dark:text-neutral-700">·</span>

                    <button
                      onClick={() => handleDeleteRating(item.id, item.book.title)}
                      className="inline-flex items-center gap-1 text-neutral-400 hover:text-rose-500 transition-colors cursor-pointer"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                      <span>Remove</span>
                    </button>
                  </div>

                  <div className="flex items-center gap-2">
                    <Link
                      to={`/books/${item.book.id}`}
                      className="inline-flex items-center gap-1 text-neutral-500 hover:text-neutral-900 dark:hover:text-white font-medium"
                    >
                      <BookOpen className="w-3.5 h-3.5" />
                      <span>View Book</span>
                    </Link>

                    <Link
                      to={`/student/reviews/new?bookId=${item.book.id}`}
                      className="inline-flex items-center gap-1 text-amber-600 dark:text-amber-400 hover:underline font-semibold"
                    >
                      <MessageSquare className="w-3.5 h-3.5" />
                      <span>Write Review</span>
                    </Link>
                  </div>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="p-12 text-center rounded-3xl border border-dashed border-neutral-200 dark:border-neutral-800 bg-white dark:bg-neutral-900">
            <Star className="w-8 h-8 text-neutral-400 mx-auto mb-2" />
            <h3 className="text-sm font-semibold text-neutral-900 dark:text-neutral-100">
              You haven't rated any books yet.
            </h3>
            <p className="text-xs text-neutral-500 mt-1 max-w-sm mx-auto">
              Start exploring the catalog and rate your first book to activate your reading scorecard.
            </p>
            <div className="mt-4">
              <Link to="/student/catalog">
                <Button variant="primary" size="sm">
                  Explore Books
                </Button>
              </Link>
            </div>
          </div>
        )}
      </div>

      {/* Rate or Edit Rating Modal */}
      <Modal
        isOpen={isRateModalOpen}
        onClose={() => setIsRateModalOpen(false)}
        title={editingItem ? 'Edit Book Rating' : 'Rate a Book'}
        description="Share your star score and study impressions with your personal library diary."
      >
        <form onSubmit={handleSaveRating} className="space-y-4">
          <div>
            <label className="block text-xs font-semibold text-neutral-700 dark:text-neutral-300 mb-1.5">
              Select Book
            </label>
            <select
              value={selectedBookId}
              onChange={(e) => setSelectedBookId(e.target.value)}
              disabled={Boolean(editingItem)}
              className="w-full h-10 rounded-xl border border-neutral-300 bg-white px-3 text-xs text-neutral-900 focus:outline-none focus:ring-2 focus:ring-neutral-900 dark:border-neutral-700 dark:bg-neutral-800 dark:text-neutral-100 disabled:opacity-60"
            >
              {initialBooks.map((b) => (
                <option key={b.id} value={b.id}>
                  {b.title} — {b.author}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-xs font-semibold text-neutral-700 dark:text-neutral-300 mb-1.5">
              Star Evaluation ({formRating} / 5)
            </label>
            <div className="flex items-center gap-2">
              {[1, 2, 3, 4, 5].map((s) => (
                <button
                  key={s}
                  type="button"
                  onClick={() => setFormRating(s)}
                  className="p-1 text-amber-500 hover:scale-110 transition-transform cursor-pointer"
                >
                  <Star
                    className={`w-7 h-7 ${
                      s <= formRating ? 'fill-amber-400 text-amber-400' : 'text-neutral-300 dark:text-neutral-700'
                    }`}
                  />
                </button>
              ))}
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-neutral-700 dark:text-neutral-300 mb-1.5">
              Personal Study Takeaways / Notes (Optional)
            </label>
            <textarea
              rows={3}
              placeholder="What did you learn? How will this help in your coursework or placement prep?"
              value={formNotes}
              onChange={(e) => setFormNotes(e.target.value)}
              className="w-full rounded-xl border border-neutral-300 bg-white p-3 text-xs text-neutral-900 focus:outline-none focus:ring-2 focus:ring-neutral-900 dark:border-neutral-700 dark:bg-neutral-800 dark:text-neutral-100"
            />
          </div>

          <div className="flex items-center justify-end gap-3 pt-3 border-t border-neutral-100 dark:border-neutral-800">
            <Button variant="outline" size="sm" onClick={() => setIsRateModalOpen(false)}>
              Cancel
            </Button>
            <Button type="submit" variant="primary" size="sm">
              {editingItem ? 'Save Changes' : 'Submit Rating'}
            </Button>
          </div>
        </form>
      </Modal>
    </div>
  );
};

export default RatingsPage;
