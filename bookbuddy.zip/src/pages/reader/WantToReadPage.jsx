import React, { useState } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { initialBooks } from '../../data/books';
import { toggleWantToReadBook } from '../../store/slices/listSlice';
import { BookCover } from '../../components/books/BookCover';
import { EmptyState } from '../../components/common/EmptyState';
import { Button } from '../../components/common/Button';
import { Modal } from '../../components/common/Modal';
import {
  Bookmark,
  Compass,
  Plus,
  Trash2,
  BookOpen,
  CheckCircle2,
  Star,
  MessageSquare,
  ArrowUpDown,
  Clock,
  Sparkles,
} from 'lucide-react';
import { Link } from 'react-router-dom';
import { toast } from 'sonner';

export const WantToReadPage = () => {
  const dispatch = useDispatch();
  const wantToReadIds = useSelector((state) => state.lists.wantToReadBookIds);

  // Extended local items list to support add, mark as reading, mark as finished, rate
  const [readingStatuses, setReadingStatuses] = useState({
    '1': 'Want to Read',
    '2': 'Want to Read',
    '3': 'Want to Read',
    '4': 'Want to Read',
    '5': 'Currently Reading',
  });

  const [sortOption, setSortOption] = useState('recent'); // 'recent' | 'title' | 'author' | 'category' | 'rating'
  const [isAddBookModalOpen, setIsAddBookModalOpen] = useState(false);
  const [addBookId, setAddBookId] = useState(initialBooks[5].id);

  // Quick Rate Modal
  const [rateModalBook, setRateModalBook] = useState(null);
  const [userStars, setUserStars] = useState(5);

  const rawBooks = initialBooks.filter(
    (b) => wantToReadIds.includes(String(b.id)) || ['1', '2', '3', '4'].includes(String(b.id))
  );

  const handleRemove = (bookId, title) => {
    dispatch(toggleWantToReadBook(bookId));
    toast.info(`Book removed from Want to Read: "${title}"`);
  };

  const handleMarkAsReading = (bookId, title) => {
    setReadingStatuses((prev) => ({ ...prev, [bookId]: 'Currently Reading' }));
    toast.success(`"${title}" marked as Currently Reading!`);
  };

  const handleMarkAsFinished = (bookId, title) => {
    setReadingStatuses((prev) => ({ ...prev, [bookId]: 'Finished' }));
    toast.success(`Book marked as finished: "${title}". Reading session recorded!`);
  };

  const handleAddBookToShelf = (e) => {
    e.preventDefault();
    const book = initialBooks.find((b) => String(b.id) === String(addBookId));
    if (!wantToReadIds.includes(String(book.id))) {
      dispatch(toggleWantToReadBook(book.id));
    }
    toast.success(`Book added to Want to Read: "${book.title}"`);
    setIsAddBookModalOpen(false);
  };

  const handleSaveRate = (e) => {
    e.preventDefault();
    toast.success(`Rating saved! Evaluated "${rateModalBook.title}" with ${userStars} stars.`);
    setRateModalBook(null);
  };

  // Sorting logic (Req 28)
  const sortedBooks = [...rawBooks].sort((a, b) => {
    if (sortOption === 'title') return a.title.localeCompare(b.title);
    if (sortOption === 'author') return a.author.localeCompare(b.author);
    if (sortOption === 'category') return a.category.localeCompare(b.category);
    if (sortOption === 'rating') return (b.rating || 0) - (a.rating || 0);
    return 0; // Default recent
  });

  return (
    <div className="space-y-6 max-w-6xl mx-auto">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-bold tracking-tight text-neutral-900 dark:text-neutral-100">
            Want to Read Shelf
          </h1>
          <p className="text-xs sm:text-sm text-neutral-500 dark:text-neutral-400 mt-1">
            Personal queue of library books you intend to borrow for coursework, research, or personal mastery.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <Button
            variant="outline"
            size="sm"
            leftIcon={<Plus className="w-4 h-4" />}
            onClick={() => setIsAddBookModalOpen(true)}
          >
            Add Book
          </Button>

          <Link to="/student/catalog">
            <Button variant="primary" size="sm" leftIcon={<Compass className="w-4 h-4" />}>
              Explore Catalog
            </Button>
          </Link>
        </div>
      </div>

      {/* Sorting & Filter Bar (Req 28) */}
      <div className="p-4 rounded-2xl border border-neutral-200/80 bg-white dark:border-neutral-800 dark:bg-neutral-900 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div className="flex items-center gap-2 text-xs text-neutral-500">
          <Bookmark className="w-4 h-4 text-amber-500" />
          <span className="font-semibold text-neutral-900 dark:text-neutral-100">
            {sortedBooks.length} Books on Shelf
          </span>
        </div>

        {/* Sorting Dropdown */}
        <div className="flex items-center gap-2">
          <span className="text-xs text-neutral-500 font-mono">Sort by:</span>
          <select
            value={sortOption}
            onChange={(e) => setSortOption(e.target.value)}
            className="h-9 rounded-xl border border-neutral-300 bg-white px-3 text-xs text-neutral-900 focus:outline-none focus:ring-2 focus:ring-neutral-900 dark:border-neutral-700 dark:bg-neutral-800 dark:text-neutral-100 font-medium"
          >
            <option value="recent">Recently Added</option>
            <option value="title">Title (A–Z)</option>
            <option value="author">Author</option>
            <option value="category">Category</option>
            <option value="rating">Rating (Highest)</option>
          </select>
        </div>
      </div>

      {/* Books Cards Grid */}
      {sortedBooks.length > 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {sortedBooks.map((book) => {
            const currentStatus = readingStatuses[book.id] || 'Want to Read';

            return (
              <div
                key={book.id}
                className="p-5 rounded-2xl border border-neutral-200/80 bg-white dark:border-neutral-800 dark:bg-neutral-900 shadow-xs flex flex-col justify-between space-y-4 hover:border-neutral-300 dark:hover:border-neutral-700 transition-colors"
              >
                <div className="flex gap-4">
                  <Link to={`/books/${book.id}`} className="w-16 shrink-0 block">
                    <BookCover
                      title={book.title}
                      author={book.author}
                      category={book.category}
                      coverGradient={book.coverGradient}
                      aspectRatio="aspect-[2/3]"
                    />
                  </Link>

                  <div className="min-w-0 flex-1 space-y-1">
                    <div className="flex items-center justify-between gap-1">
                      <span className="text-[10px] font-mono font-semibold px-2 py-0.5 rounded bg-amber-50 text-amber-700 dark:bg-amber-950/60 dark:text-amber-400 border border-amber-200 dark:border-amber-900 truncate">
                        {currentStatus}
                      </span>
                      <span className="text-[10px] font-mono text-neutral-400">
                        Rack {book.rackNo || 'A-3'}
                      </span>
                    </div>

                    <Link to={`/books/${book.id}`}>
                      <h4 className="font-bold text-sm text-neutral-900 dark:text-neutral-100 hover:text-amber-600 transition-colors line-clamp-1">
                        {book.title}
                      </h4>
                    </Link>

                    <p className="text-xs text-neutral-500 truncate">{book.author}</p>

                    <div className="flex items-center gap-1.5 text-xs text-amber-500 pt-1">
                      <Star className="w-3.5 h-3.5 fill-amber-400" />
                      <span className="font-mono font-bold text-neutral-700 dark:text-neutral-300">
                        {book.rating || 4.8}
                      </span>
                      <span className="text-neutral-400 text-[10px]">({book.ratingsCount || 84})</span>
                    </div>
                  </div>
                </div>

                {/* Actions Bar (Req 28) */}
                <div className="pt-3 border-t border-neutral-100 dark:border-neutral-800 space-y-2 text-xs">
                  <div className="flex items-center justify-between gap-2">
                    {currentStatus !== 'Currently Reading' && currentStatus !== 'Finished' && (
                      <button
                        onClick={() => handleMarkAsReading(book.id, book.title)}
                        className="px-2.5 py-1 rounded-lg text-[11px] font-medium border border-neutral-200 dark:border-neutral-700 hover:bg-neutral-100 dark:hover:bg-neutral-800 transition-colors cursor-pointer"
                      >
                        Mark as Reading
                      </button>
                    )}

                    {currentStatus !== 'Finished' && (
                      <button
                        onClick={() => handleMarkAsFinished(book.id, book.title)}
                        className="px-2.5 py-1 rounded-lg text-[11px] font-semibold bg-emerald-50 text-emerald-700 dark:bg-emerald-950/60 dark:text-emerald-400 border border-emerald-200 dark:border-emerald-800 hover:bg-emerald-100 cursor-pointer"
                      >
                        Mark Finished
                      </button>
                    )}

                    <button
                      onClick={() => handleRemove(book.id, book.title)}
                      className="p-1.5 text-neutral-400 hover:text-rose-500 rounded-lg transition-colors ml-auto cursor-pointer"
                      title="Remove from Shelf"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>

                  <div className="flex items-center justify-between pt-1">
                    <button
                      onClick={() => {
                        setRateModalBook(book);
                        setUserStars(5);
                      }}
                      className="inline-flex items-center gap-1 text-[11px] text-neutral-500 hover:text-amber-500 font-medium cursor-pointer"
                    >
                      <Star className="w-3 h-3" />
                      <span>Rate Book</span>
                    </button>

                    <Link
                      to={`/student/reviews/new?bookId=${book.id}`}
                      className="inline-flex items-center gap-1 text-[11px] text-amber-600 dark:text-amber-400 font-semibold hover:underline"
                    >
                      <MessageSquare className="w-3 h-3" />
                      <span>Write Review</span>
                    </Link>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      ) : (
        <EmptyState
          icon={Bookmark}
          title="Your Want-to-Read shelf is empty"
          description="Click the bookmark icon on any book card in the catalog to save it to your reading plan."
          actionLabel="Explore Catalog"
          onAction={() => (window.location.href = '/student/catalog')}
        />
      )}

      {/* Add Book Modal */}
      <Modal
        isOpen={isAddBookModalOpen}
        onClose={() => setIsAddBookModalOpen(false)}
        title="Add Book to Want to Read"
        description="Choose a title from the central library catalog to place on your reading queue."
      >
        <form onSubmit={handleAddBookToShelf} className="space-y-4">
          <div>
            <label className="block text-xs font-semibold text-neutral-700 dark:text-neutral-300 mb-1.5">
              Select Book from Library Catalog
            </label>
            <select
              value={addBookId}
              onChange={(e) => setAddBookId(e.target.value)}
              className="w-full h-10 rounded-xl border border-neutral-300 bg-white px-3 text-xs text-neutral-900 focus:outline-none focus:ring-2 focus:ring-neutral-900 dark:border-neutral-700 dark:bg-neutral-800 dark:text-neutral-100"
            >
              {initialBooks.map((b) => (
                <option key={b.id} value={b.id}>
                  {b.title} — {b.author} ({b.category})
                </option>
              ))}
            </select>
          </div>

          <div className="flex items-center justify-end gap-3 pt-3 border-t border-neutral-100 dark:border-neutral-800">
            <Button variant="outline" size="sm" onClick={() => setIsAddBookModalOpen(false)}>
              Cancel
            </Button>
            <Button type="submit" variant="primary" size="sm">
              Add to Shelf
            </Button>
          </div>
        </form>
      </Modal>

      {/* Quick Rate Modal */}
      <Modal
        isOpen={Boolean(rateModalBook)}
        onClose={() => setRateModalBook(null)}
        title={`Rate "${rateModalBook?.title}"`}
        description="Submit your star evaluation to update your reading statistics."
      >
        <form onSubmit={handleSaveRate} className="space-y-4">
          <div className="flex items-center justify-center gap-2 py-4">
            {[1, 2, 3, 4, 5].map((s) => (
              <button
                key={s}
                type="button"
                onClick={() => setUserStars(s)}
                className="p-1 text-amber-500 hover:scale-110 transition-transform cursor-pointer"
              >
                <Star
                  className={`w-8 h-8 ${
                    s <= userStars ? 'fill-amber-400 text-amber-400' : 'text-neutral-300 dark:text-neutral-700'
                  }`}
                />
              </button>
            ))}
          </div>

          <div className="flex items-center justify-end gap-3 pt-3 border-t border-neutral-100 dark:border-neutral-800">
            <Button variant="outline" size="sm" onClick={() => setRateModalBook(null)}>
              Cancel
            </Button>
            <Button type="submit" variant="primary" size="sm">
              Save Rating
            </Button>
          </div>
        </form>
      </Modal>
    </div>
  );
};

export default WantToReadPage;
