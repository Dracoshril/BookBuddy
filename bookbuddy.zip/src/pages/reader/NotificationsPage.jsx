import React, { useEffect } from 'react';
import { Link } from 'react-router-dom';
import { useSelector, useDispatch } from 'react-redux';
import {
  fetchNotifications,
  markNotificationRead,
  markAllNotificationsRead,
} from '../../store/slices/notificationSlice';
import { Button } from '../../components/common/Button';
import { EmptyState } from '../../components/common/EmptyState';
import { Bell, Check, Clock, CheckCircle2, Heart, UserPlus, ArrowRight } from 'lucide-react';
import { formatDistanceToNow } from 'date-fns';
import { toast } from 'sonner';

export const NotificationsPage = () => {
  const dispatch = useDispatch();
  const notifications = useSelector((state) => state.notifications.items);

  useEffect(() => {
    dispatch(fetchNotifications());
  }, [dispatch]);

  const handleMarkAllRead = () => {
    dispatch(markAllNotificationsRead());
    toast.success('All notifications marked as read.');
  };

  const handleMarkRead = (id) => {
    dispatch(markNotificationRead(id));
  };

  const getIcon = (type) => {
    switch (type) {
      case 'BOOK_DUE_SOON':
        return <Clock className="w-4 h-4 text-amber-500" />;
      case 'RESERVED_BOOK_AVAILABLE':
        return <CheckCircle2 className="w-4 h-4 text-emerald-500" />;
      case 'REVIEW_LIKE':
        return <Heart className="w-4 h-4 text-rose-500" />;
      case 'NEW_FOLLOWER':
        return <UserPlus className="w-4 h-4 text-sky-500" />;
      default:
        return <Bell className="w-4 h-4 text-neutral-500" />;
    }
  };

  return (
    <div className="space-y-6 max-w-3xl">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-bold tracking-tight text-neutral-900 dark:text-neutral-100">
            Notifications Center
          </h1>
          <p className="text-xs sm:text-sm text-neutral-500 dark:text-neutral-400 mt-1">
            Real-time circulation alerts, hold arrivals, and reading community engagements.
          </p>
        </div>

        {notifications.some((n) => !n.isRead) && (
          <Button
            variant="outline"
            size="sm"
            leftIcon={<Check className="w-4 h-4" />}
            onClick={handleMarkAllRead}
          >
            Mark All as Read
          </Button>
        )}
      </div>

      {notifications.length > 0 ? (
        <div className="space-y-3">
          {notifications.map((notif) => (
            <div
              key={notif.id}
              onClick={() => handleMarkRead(notif.id)}
              className={`p-4 sm:p-5 rounded-2xl border transition-all flex items-start gap-4 text-xs cursor-pointer ${
                notif.isRead
                  ? 'border-neutral-200/60 bg-white/60 dark:border-neutral-800 dark:bg-neutral-900/60 opacity-80'
                  : 'border-amber-500/30 bg-white dark:border-amber-500/20 dark:bg-neutral-900 shadow-xs'
              }`}
            >
              <div className="w-9 h-9 rounded-xl bg-neutral-100 dark:bg-neutral-800 flex items-center justify-center shrink-0">
                {getIcon(notif.type)}
              </div>

              <div className="flex-1 space-y-1">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <h4 className="font-bold text-sm text-neutral-900 dark:text-neutral-100">
                      {notif.title}
                    </h4>
                    {!notif.isRead && (
                      <span className="w-2 h-2 rounded-full bg-amber-500" />
                    )}
                  </div>
                  <span className="text-[10px] font-mono text-neutral-400">
                    {notif.createdAt ? formatDistanceToNow(new Date(notif.createdAt), { addSuffix: true }) : 'Recently'}
                  </span>
                </div>

                <p className="text-neutral-600 dark:text-neutral-300 leading-relaxed text-xs">
                  {notif.message}
                </p>

                {notif.link && (
                  <div className="pt-2">
                    <Link
                      to={notif.link}
                      className="text-amber-600 font-semibold text-xs hover:underline inline-flex items-center gap-1"
                    >
                      <span>Take Action</span>
                      <ArrowRight className="w-3.5 h-3.5" />
                    </Link>
                  </div>
                )}
              </div>
            </div>
          ))}
        </div>
      ) : (
        <EmptyState
          icon={Bell}
          title="No notifications"
          description="You are completely caught up! We will notify you when books are due or holds arrive."
        />
      )}
    </div>
  );
};

export default NotificationsPage;
