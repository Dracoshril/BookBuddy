import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { BookOpen, Star, MessageSquare, ArrowDownLeft, ArrowUpRight, Filter } from 'lucide-react';
import { initialBooks } from '../../data/books';

export const ReadingHistoryPage = () => {
  const [selectedFilter, setSelectedFilter] = useState('ALL');

  const historyEvents = [
    {
      id: 'h-1',
      type: 'RATED',
      title: 'Rated Clean Code',
      book: initialBooks[0],
      detail: 'Assigned 5 out of 5 stars',
      date: 'Sep 25, 2026',
      icon: Star,
      iconColor: 'text-amber-500 bg-amber-500/10',
    },
    {
      id: 'h-2',
      type: 'RETURNED',
      title: 'Returned Atomic Habits',
      book: initialBooks[6],
      detail: 'Returned in pristine condition to Circulation Desk 1',
      date: 'Sep 21, 2026',
      icon: ArrowDownLeft,
      iconColor: 'text-emerald-500 bg-emerald-500/10',
    },
    {
      id: 'h-3',
      type: 'BORROWED',
      title: 'Checked out Clean Code',
      book: initialBooks[0],
      detail: '14-day student loan initiated',
      date: 'Sep 10, 2026',
      icon: ArrowUpRight,
      iconColor: 'text-sky-500 bg-sky-500/10',
    },
    {
      id: 'h-4',
      type: 'REVIEWED',
      title: 'Posted Review for Designing Data-Intensive Applications',
      book: initialBooks[1],
      detail: 'Published 400-word review highlighting consensus protocols',
      date: 'Aug 28, 2026',
      icon: MessageSquare,
      iconColor: 'text-purple-500 bg-purple-500/10',
    },
    {
      id: 'h-5',
      type: 'RETURNED',
      title: 'Returned Designing Data-Intensive Applications',
      book: initialBooks[1],
      detail: 'Loan completed without overdue fees',
      date: 'Aug 20, 2026',
      icon: ArrowDownLeft,
      iconColor: 'text-emerald-500 bg-emerald-500/10',
    },
  ];

  const filtered = selectedFilter === 'ALL'
    ? historyEvents
    : historyEvents.filter((e) => e.type === selectedFilter);

  return (
    <div className="space-y-6 max-w-4xl">
      <div>
        <h1 className="text-2xl sm:text-3xl font-bold tracking-tight text-neutral-900 dark:text-neutral-100">
          Reading History & Timeline
        </h1>
        <p className="text-xs sm:text-sm text-neutral-500 dark:text-neutral-400 mt-1">
          Chronological record of every book borrowed, returned, rated, and reviewed on your library card.
        </p>
      </div>

      {/* Filter Tabs */}
      <div className="flex items-center gap-1.5 p-1 bg-neutral-100 dark:bg-neutral-800 rounded-xl overflow-x-auto text-xs font-semibold">
        {['ALL', 'BORROWED', 'RETURNED', 'RATED', 'REVIEWED'].map((filter) => (
          <button
            key={filter}
            onClick={() => setSelectedFilter(filter)}
            className={`px-3 py-1.5 rounded-lg transition-all cursor-pointer ${
              selectedFilter === filter
                ? 'bg-white text-neutral-900 shadow-xs dark:bg-neutral-900 dark:text-white'
                : 'text-neutral-600 hover:text-neutral-900 dark:text-neutral-400 dark:hover:text-white'
            }`}
          >
            {filter}
          </button>
        ))}
      </div>

      {/* Timeline view */}
      <div className="relative pl-6 border-l-2 border-neutral-200 dark:border-neutral-800 space-y-6 ml-3">
        {filtered.map((item) => {
          const Icon = item.icon;
          return (
            <div key={item.id} className="relative group">
              {/* Dot */}
              <div
                className={`absolute -left-[31px] top-1 w-7 h-7 rounded-full flex items-center justify-center border-2 border-white dark:border-neutral-900 ${item.iconColor}`}
              >
                <Icon className="w-3.5 h-3.5" />
              </div>

              <div className="p-4 rounded-xl border border-neutral-200/80 bg-white dark:border-neutral-800 dark:bg-neutral-900 shadow-xs space-y-1">
                <div className="flex items-center justify-between text-xs">
                  <span className="font-semibold text-neutral-900 dark:text-neutral-100">
                    {item.title}
                  </span>
                  <span className="text-[10px] font-mono text-neutral-400">{item.date}</span>
                </div>
                <p className="text-xs text-neutral-500">{item.detail}</p>
                <div className="pt-2">
                  <Link
                    to={`/books/${item.book.id}`}
                    className="text-xs text-amber-600 font-medium hover:underline inline-flex items-center gap-1"
                  >
                    <span>View Book Specs</span>
                  </Link>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};

export default ReadingHistoryPage;
