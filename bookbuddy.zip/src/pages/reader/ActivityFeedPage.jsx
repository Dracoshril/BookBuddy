import React, { useEffect } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { fetchActivities } from '../../store/slices/socialSlice';
import { Radio, BookCheck, Star, MessageSquare, ListOrdered, UserPlus, Heart } from 'lucide-react';
import { formatDistanceToNow } from 'date-fns';

export const ActivityFeedPage = () => {
  const dispatch = useDispatch();
  const activities = useSelector((state) => state.social.activities);

  useEffect(() => {
    dispatch(fetchActivities());
  }, [dispatch]);

  const getActivityIcon = (type) => {
    switch (type) {
      case 'BOOK_FINISHED':
        return <BookCheck className="w-4 h-4 text-emerald-500" />;
      case 'REVIEW_POSTED':
        return <MessageSquare className="w-4 h-4 text-sky-500" />;
      case 'BOOK_RATED':
        return <Star className="w-4 h-4 text-amber-500" />;
      case 'LIST_CREATED':
        return <ListOrdered className="w-4 h-4 text-purple-500" />;
      case 'FOLLOW_EVENT':
      default:
        return <UserPlus className="w-4 h-4 text-teal-500" />;
    }
  };

  return (
    <div className="space-y-6 max-w-3xl">
      <div>
        <h1 className="text-2xl sm:text-3xl font-bold tracking-tight text-neutral-900 dark:text-neutral-100">
          Campus Social Reading Feed
        </h1>
        <p className="text-xs sm:text-sm text-neutral-500 dark:text-neutral-400 mt-1">
          Real-time activity from students, professors, and reading groups across university departments.
        </p>
      </div>

      <div className="space-y-3">
        {activities.map((act) => (
          <div
            key={act.id}
            className="p-5 rounded-2xl border border-neutral-200/80 bg-white dark:border-neutral-800 dark:bg-neutral-900 shadow-xs flex items-start gap-4 text-xs"
          >
            <div className="w-9 h-9 rounded-xl bg-neutral-100 dark:bg-neutral-800 flex items-center justify-center shrink-0">
              {getActivityIcon(act.type)}
            </div>

            <div className="flex-1 space-y-1">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span className="font-bold text-neutral-900 dark:text-neutral-100 text-sm">
                    {act.userName}
                  </span>
                  <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-neutral-100 dark:bg-neutral-800 text-neutral-500">
                    {act.userRole}
                  </span>
                </div>
                <span className="text-[10px] font-mono text-neutral-400">
                  {act.timestamp ? formatDistanceToNow(new Date(act.timestamp), { addSuffix: true }) : 'Recently'}
                </span>
              </div>

              <p className="text-neutral-600 dark:text-neutral-300 leading-relaxed text-xs">
                {act.details}
              </p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default ActivityFeedPage;
