import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { useSelector, useDispatch } from 'react-redux';
import { fetchLists, createNewList, deleteUserList } from '../../store/slices/listSlice';
import { useAuth } from '../../hooks/useAuth';
import { Button } from '../../components/common/Button';
import { Input } from '../../components/common/Input';
import { Modal } from '../../components/common/Modal';
import { EmptyState } from '../../components/common/EmptyState';
import { ListOrdered, Plus, Lock, Globe, BookOpen, Trash2, ArrowRight } from 'lucide-react';
import { toast } from 'sonner';

export const MyListsPage = () => {
  const dispatch = useDispatch();
  const { user } = useAuth();
  const lists = useSelector((state) => state.lists.lists);

  const [isModalOpen, setIsModalOpen] = useState(false);
  const [newListTitle, setNewListTitle] = useState('');
  const [newListDesc, setNewListDesc] = useState('');
  const [isPublic, setIsPublic] = useState(true);
  const [isSubmitting, setIsSubmitting] = useState(false);

  useEffect(() => {
    dispatch(fetchLists());
  }, [dispatch]);

  const handleCreateList = async (e) => {
    e.preventDefault();
    if (!newListTitle.trim()) return;

    setIsSubmitting(true);
    try {
      await dispatch(
        createNewList({
          userId: user?.id || 'user-1',
          title: newListTitle.trim(),
          description: newListDesc.trim(),
          isPublic,
          books: ['1', '4'], // default seed items
        })
      ).unwrap();

      toast.success(`Reading list "${newListTitle}" created!`);
      setIsModalOpen(false);
      setNewListTitle('');
      setNewListDesc('');
    } catch (err) {
      toast.error('Failed to create list');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleDelete = (id, title) => {
    dispatch(deleteUserList(id));
    toast.info(`Deleted list "${title}".`);
  };

  return (
    <div className="space-y-6 max-w-5xl">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-bold tracking-tight text-neutral-900 dark:text-neutral-100">
            Custom Reading Lists & Syllabi
          </h1>
          <p className="text-xs sm:text-sm text-neutral-500 dark:text-neutral-400 mt-1">
            Curate semester roadmaps, placement prep shelves, and share public collections with classmates.
          </p>
        </div>

        <Button
          variant="primary"
          size="sm"
          leftIcon={<Plus className="w-4 h-4" />}
          onClick={() => setIsModalOpen(true)}
        >
          Create New List
        </Button>
      </div>

      {/* Lists Grid */}
      {lists.length > 0 ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          {lists.map((list) => {
            const isOwner = list.userId === user?.id;
            return (
              <div
                key={list.id}
                className="p-5 rounded-2xl border border-neutral-200/80 bg-white dark:border-neutral-800 dark:bg-neutral-900 shadow-xs flex flex-col justify-between space-y-4"
              >
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="inline-flex items-center gap-1.5 text-[11px] font-mono text-neutral-500">
                      {list.isPublic ? (
                        <>
                          <Globe className="w-3.5 h-3.5 text-emerald-500" />
                          <span>Public List</span>
                        </>
                      ) : (
                        <>
                          <Lock className="w-3.5 h-3.5 text-neutral-400" />
                          <span>Private Shelf</span>
                        </>
                      )}
                    </span>
                    <span className="text-xs font-mono text-neutral-400">
                      {list.books.length} Books
                    </span>
                  </div>

                  <Link to={`/student/custom-lists/${list.id}`}>
                    <h3 className="font-bold text-base text-neutral-900 dark:text-neutral-100 hover:text-amber-600 transition-colors">
                      {list.title}
                    </h3>
                  </Link>

                  {list.description && (
                    <p className="text-xs text-neutral-500 dark:text-neutral-400 line-clamp-2">
                      {list.description}
                    </p>
                  )}
                </div>

                <div className="flex items-center justify-between pt-3 border-t border-neutral-100 dark:border-neutral-800 text-xs">
                  <Link
                    to={`/student/custom-lists/${list.id}`}
                    className="font-semibold text-neutral-900 dark:text-neutral-100 hover:underline inline-flex items-center gap-1"
                  >
                    <span>Inspect Collection</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </Link>

                  {isOwner && (
                    <button
                      onClick={() => handleDelete(list.id, list.title)}
                      className="p-1.5 text-neutral-400 hover:text-rose-600 hover:bg-neutral-100 dark:hover:bg-neutral-800 rounded-lg transition-colors cursor-pointer"
                      title="Delete List"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      ) : (
        <EmptyState
          icon={ListOrdered}
          title="No reading lists created"
          description="Create custom lists to bundle semester textbooks, interview prep questions, or favorites."
          actionLabel="Create First List"
          onAction={() => setIsModalOpen(true)}
        />
      )}

      {/* Create List Modal */}
      <Modal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        title="Create New Reading List"
        description="Organize books for a course semester, interview prep, or research track"
      >
        <form onSubmit={handleCreateList} className="space-y-4">
          <Input
            label="List Title"
            placeholder="e.g. Distributed Systems Placement Prep"
            value={newListTitle}
            onChange={(e) => setNewListTitle(e.target.value)}
            required
          />

          <div>
            <label className="block text-xs font-semibold text-neutral-700 dark:text-neutral-300 mb-1.5">
              Description (Optional)
            </label>
            <textarea
              rows={3}
              value={newListDesc}
              onChange={(e) => setNewListDesc(e.target.value)}
              placeholder="What is the objective of this book collection?"
              className="w-full rounded-xl border border-neutral-300 bg-white p-3 text-xs text-neutral-900 placeholder:text-neutral-400 focus:outline-none focus:ring-2 focus:ring-neutral-900 dark:border-neutral-800 dark:bg-neutral-900 dark:text-neutral-100"
            />
          </div>

          <div className="flex items-center gap-3">
            <input
              type="checkbox"
              id="isPublic"
              checked={isPublic}
              onChange={(e) => setIsPublic(e.target.checked)}
              className="rounded text-neutral-900 focus:ring-neutral-900"
            />
            <label htmlFor="isPublic" className="text-xs text-neutral-700 dark:text-neutral-300">
              Make this list public to the campus community
            </label>
          </div>

          <div className="flex items-center justify-end gap-3 pt-3 border-t border-neutral-100 dark:border-neutral-800">
            <Button variant="outline" size="sm" onClick={() => setIsModalOpen(false)} disabled={isSubmitting}>
              Cancel
            </Button>
            <Button type="submit" variant="primary" size="sm" isLoading={isSubmitting}>
              Create List
            </Button>
          </div>
        </form>
      </Modal>
    </div>
  );
};

export default MyListsPage;
