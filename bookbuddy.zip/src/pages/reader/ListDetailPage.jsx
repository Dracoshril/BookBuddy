import React, { useState } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import { useSelector, useDispatch } from 'react-redux';
import { initialBooks } from '../../data/books';
import { BookCard } from '../../components/books/BookCard';
import { Button } from '../../components/common/Button';
import { Modal } from '../../components/common/Modal';
import {
  ArrowLeft,
  Globe,
  Lock,
  Share2,
  Plus,
  Trash2,
  Edit3,
  BookOpen,
} from 'lucide-react';
import { toast } from 'sonner';

export const ListDetailPage = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const lists = useSelector((state) => state.lists.lists);

  const initialList = lists.find((l) => l.id === id) || {
    id: id || 'list-1',
    title: 'Distributed Systems & Cloud Architecture',
    description: 'Essential volumes for mastering consensus, linearizability, and cloud storage engines.',
    isPublic: true,
    books: ['1', '2', '3', '4'],
  };

  const [currentList, setCurrentList] = useState(initialList);
  const [isAddBookModalOpen, setIsAddBookModalOpen] = useState(false);
  const [isRenameModalOpen, setIsRenameModalOpen] = useState(false);
  const [selectedBookToAdd, setSelectedBookToAdd] = useState(initialBooks[5].id);
  const [renameTitle, setRenameTitle] = useState(initialList.title);
  const [renameDesc, setRenameDesc] = useState(initialList.description || '');

  const listBooks = initialBooks.filter((b) => currentList.books?.includes(String(b.id)));

  const handleShare = () => {
    navigator.clipboard.writeText(window.location.href);
    toast.success('List link copied to clipboard!');
  };

  const handleAddBook = (e) => {
    e.preventDefault();
    if (currentList.books.includes(String(selectedBookToAdd))) {
      toast.info('This book is already in this list.');
      return;
    }
    const updatedBooks = [...currentList.books, String(selectedBookToAdd)];
    setCurrentList({ ...currentList, books: updatedBooks });
    const addedBook = initialBooks.find((b) => String(b.id) === String(selectedBookToAdd));
    toast.success(`Added "${addedBook?.title}" to list!`);
    setIsAddBookModalOpen(false);
  };

  const handleRemoveBook = (bookId, title) => {
    const updatedBooks = currentList.books.filter((b) => b !== String(bookId));
    setCurrentList({ ...currentList, books: updatedBooks });
    toast.info(`Removed "${title}" from list.`);
  };

  const handleSaveRename = (e) => {
    e.preventDefault();
    if (!renameTitle.trim()) return;
    setCurrentList({
      ...currentList,
      title: renameTitle.trim(),
      description: renameDesc.trim(),
    });
    toast.success('List details updated successfully!');
    setIsRenameModalOpen(false);
  };

  const handleDeleteList = () => {
    toast.success(`List "${currentList.title}" deleted.`);
    navigate('/student/custom-lists');
  };

  return (
    <div className="space-y-8 max-w-6xl mx-auto">
      <Link
        to="/student/custom-lists"
        className="inline-flex items-center gap-1.5 text-xs font-semibold text-neutral-500 hover:text-neutral-900 dark:hover:text-white transition-colors"
      >
        <ArrowLeft className="w-3.5 h-3.5" />
        <span>Back to Lists</span>
      </Link>

      <div className="p-6 sm:p-8 rounded-3xl border border-neutral-200/80 bg-white dark:border-neutral-800 dark:bg-neutral-900 shadow-xs space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <span className="inline-flex items-center gap-1.5 text-xs font-mono text-neutral-500">
            {currentList.isPublic ? (
              <>
                <Globe className="w-3.5 h-3.5 text-emerald-500" />
                <span>Public Campus List</span>
              </>
            ) : (
              <>
                <Lock className="w-3.5 h-3.5 text-neutral-400" />
                <span>Private Collection</span>
              </>
            )}
          </span>

          <div className="flex items-center gap-2">
            <Button
              variant="outline"
              size="sm"
              leftIcon={<Edit3 className="w-3.5 h-3.5" />}
              onClick={() => {
                setRenameTitle(currentList.title);
                setRenameDesc(currentList.description || '');
                setIsRenameModalOpen(true);
              }}
            >
              Rename
            </Button>

            <Button
              variant="outline"
              size="sm"
              leftIcon={<Plus className="w-3.5 h-3.5" />}
              onClick={() => setIsAddBookModalOpen(true)}
            >
              Add Book
            </Button>

            <Button variant="outline" size="sm" leftIcon={<Share2 className="w-3.5 h-3.5" />} onClick={handleShare}>
              Share
            </Button>

            <Button
              variant="outline"
              size="sm"
              className="text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-950/40"
              leftIcon={<Trash2 className="w-3.5 h-3.5" />}
              onClick={handleDeleteList}
            >
              Delete
            </Button>
          </div>
        </div>

        <h1 className="text-2xl sm:text-3xl font-bold tracking-tight text-neutral-900 dark:text-neutral-100">
          {currentList.title}
        </h1>

        {currentList.description && (
          <p className="text-xs sm:text-sm text-neutral-600 dark:text-neutral-300 max-w-2xl leading-relaxed">
            {currentList.description}
          </p>
        )}

        <div className="text-xs font-mono text-neutral-400 pt-1">
          <span>{listBooks.length} books in this curated collection</span>
        </div>
      </div>

      {/* Books in list */}
      <div className="space-y-4">
        <h3 className="text-lg font-bold text-neutral-900 dark:text-neutral-100 flex items-center justify-between">
          <span>Volumes in Collection ({listBooks.length})</span>
          <Button
            variant="outline"
            size="sm"
            leftIcon={<Plus className="w-3.5 h-3.5" />}
            onClick={() => setIsAddBookModalOpen(true)}
          >
            Add More Books
          </Button>
        </h3>

        {listBooks.length > 0 ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
            {listBooks.map((book) => (
              <div key={book.id} className="relative group">
                <BookCard book={book} />
                <button
                  onClick={() => handleRemoveBook(book.id, book.title)}
                  className="absolute top-2 right-2 p-1.5 rounded-lg bg-neutral-900/80 text-white hover:bg-rose-600 opacity-0 group-hover:opacity-100 transition-opacity z-10 cursor-pointer"
                  title="Remove from this list"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>
            ))}
          </div>
        ) : (
          <div className="p-12 text-center text-xs text-neutral-500 rounded-3xl border border-dashed border-neutral-200 dark:border-neutral-800">
            No books in this list yet. Click "Add Book" above to include volumes.
          </div>
        )}
      </div>

      {/* Add Book Modal */}
      <Modal
        isOpen={isAddBookModalOpen}
        onClose={() => setIsAddBookModalOpen(false)}
        title="Add Book to List"
        description="Choose a title from the library catalog to add to this curated collection."
      >
        <form onSubmit={handleAddBook} className="space-y-4">
          <div>
            <label className="block text-xs font-semibold text-neutral-700 dark:text-neutral-300 mb-1.5">
              Select Book
            </label>
            <select
              value={selectedBookToAdd}
              onChange={(e) => setSelectedBookToAdd(e.target.value)}
              className="w-full h-10 rounded-xl border border-neutral-300 bg-white px-3 text-xs text-neutral-900 focus:outline-none focus:ring-2 focus:ring-neutral-900 dark:border-neutral-700 dark:bg-neutral-800 dark:text-neutral-100"
            >
              {initialBooks.map((b) => (
                <option key={b.id} value={b.id}>
                  {b.title} — {b.author} ({b.category})
                </option>
              ))}
            </select>
          </div>

          <div className="flex items-center justify-end gap-3 pt-3 border-t border-neutral-100 dark:border-neutral-800">
            <Button variant="outline" size="sm" onClick={() => setIsAddBookModalOpen(false)}>
              Cancel
            </Button>
            <Button type="submit" variant="primary" size="sm">
              Add to List
            </Button>
          </div>
        </form>
      </Modal>

      {/* Rename List Modal */}
      <Modal
        isOpen={isRenameModalOpen}
        onClose={() => setIsRenameModalOpen(false)}
        title="Rename Reading List"
        description="Update collection title and syllabus description"
      >
        <form onSubmit={handleSaveRename} className="space-y-4">
          <div>
            <label className="block text-xs font-semibold text-neutral-700 dark:text-neutral-300 mb-1.5">
              List Name
            </label>
            <input
              type="text"
              required
              value={renameTitle}
              onChange={(e) => setRenameTitle(e.target.value)}
              className="w-full h-10 rounded-xl border border-neutral-300 bg-white px-3 text-xs text-neutral-900 focus:outline-none focus:ring-2 focus:ring-neutral-900 dark:border-neutral-700 dark:bg-neutral-800 dark:text-neutral-100"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-neutral-700 dark:text-neutral-300 mb-1.5">
              Description
            </label>
            <textarea
              rows={3}
              value={renameDesc}
              onChange={(e) => setRenameDesc(e.target.value)}
              className="w-full rounded-xl border border-neutral-300 bg-white p-3 text-xs text-neutral-900 focus:outline-none focus:ring-2 focus:ring-neutral-900 dark:border-neutral-700 dark:bg-neutral-800 dark:text-neutral-100"
            />
          </div>

          <div className="flex items-center justify-end gap-3 pt-3 border-t border-neutral-100 dark:border-neutral-800">
            <Button variant="outline" size="sm" onClick={() => setIsRenameModalOpen(false)}>
              Cancel
            </Button>
            <Button type="submit" variant="primary" size="sm">
              Save Changes
            </Button>
          </div>
        </form>
      </Modal>
    </div>
  );
};

export default ListDetailPage;
