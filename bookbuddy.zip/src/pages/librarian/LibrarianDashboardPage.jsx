import React, { useEffect } from 'react';
import { Link } from 'react-router-dom';
import { useSelector, useDispatch } from 'react-redux';
import {
  fetchOverviewMetrics,
  fetchBorrowingTrends,
  fetchCategoryDistribution,
  fetchPopularBooks,
} from '../../store/slices/analyticsSlice';
import { Button } from '../../components/common/Button';
import {
  BookOpen,
  CheckCircle2,
  ArrowUpRight,
  AlertTriangle,
  Users,
  Clock,
  PlusCircle,
  Boxes,
  ArrowDownLeft,
  Search,
  ChevronRight,
  TrendingUp,
} from 'lucide-react';
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid,
  Legend,
} from 'recharts';

export const LibrarianDashboardPage = () => {
  const dispatch = useDispatch();
  const { overview, borrowingTrends, popularBooks } = useSelector((state) => state.analytics);

  useEffect(() => {
    dispatch(fetchOverviewMetrics());
    dispatch(fetchBorrowingTrends());
    dispatch(fetchCategoryDistribution());
    dispatch(fetchPopularBooks());
  }, [dispatch]);

  // The 6 exact overview cards required by Prompt Section 12
  const overviewCards = [
    {
      label: 'Total Books',
      value: overview?.totalBooks || 42,
      sub: '168 total copies cataloged',
      icon: BookOpen,
      color: 'text-neutral-900 dark:text-white',
      link: '/librarian/books',
    },
    {
      label: 'Available Books',
      value: overview?.availableBooks || 78,
      sub: 'Ready on library stacks',
      icon: CheckCircle2,
      color: 'text-emerald-600',
      link: '/librarian/inventory',
    },
    {
      label: 'Borrowed Books',
      value: overview?.issuedBooks || 82,
      sub: 'In active student circulation',
      icon: ArrowUpRight,
      color: 'text-sky-600',
      link: '/librarian/borrowings',
    },
    {
      label: 'Overdue Books',
      value: overview?.overdueLoans || 14,
      sub: 'Requires return notice',
      icon: AlertTriangle,
      color: 'text-rose-600',
      link: '/librarian/borrowings',
    },
    {
      label: 'Active Members',
      value: overview?.totalReaders || 480,
      sub: 'Enrolled student patrons',
      icon: Users,
      color: 'text-indigo-600 dark:text-indigo-400',
      link: '/librarian/students',
    },
    {
      label: 'Reservations',
      value: overview?.reservedBooks || 8,
      sub: 'In pickup hold queue',
      icon: Clock,
      color: 'text-amber-600',
      link: '/librarian/reservations',
    },
  ];

  return (
    <div className="space-y-8">
      {/* Top Banner and Quick Circulation Actions */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-bold tracking-tight text-neutral-900 dark:text-neutral-100">
            Librarian Console & Circulation Desk
          </h1>
          <p className="text-xs sm:text-sm text-neutral-500 dark:text-neutral-400 mt-1">
            Institutional overview of physical holdings, patron circulation, returns, and inventory control.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <Link to="/librarian/borrowings">
            <Button variant="primary" size="sm" leftIcon={<ArrowUpRight className="w-3.5 h-3.5" />}>
              Issue Book
            </Button>
          </Link>
          <Link to="/librarian/circulation">
            <Button variant="outline" size="sm" leftIcon={<ArrowDownLeft className="w-3.5 h-3.5" />}>
              Circulation Desk
            </Button>
          </Link>
          <Link to="/librarian/books/add">
            <Button variant="outline" size="sm" leftIcon={<PlusCircle className="w-3.5 h-3.5" />}>
              Add Book
            </Button>
          </Link>
          <Link to="/librarian/inventory">
            <Button variant="secondary" size="sm" leftIcon={<Boxes className="w-3.5 h-3.5" />}>
              Inventory Audit
            </Button>
          </Link>
        </div>
      </div>

      {/* Overview Cards (Prompt Section 12) */}
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3">
        {overviewCards.map((card, i) => {
          const Icon = card.icon;
          return (
            <Link
              key={i}
              to={card.link}
              className="p-4 rounded-xl border border-neutral-200/80 bg-white hover:border-neutral-300 dark:border-neutral-800 dark:bg-neutral-900 dark:hover:border-neutral-700 shadow-xs space-y-1.5 transition-all group"
            >
              <div className="flex items-center justify-between text-neutral-400">
                <span className="text-[11px] font-medium truncate text-neutral-600 dark:text-neutral-400">
                  {card.label}
                </span>
                <Icon className="w-4 h-4 shrink-0 group-hover:scale-110 transition-transform" />
              </div>
              <div className="text-2xl font-bold font-mono tracking-tight tabular-nums">
                <span className={card.color}>{card.value}</span>
              </div>
              <p className="text-[10px] text-neutral-400 truncate">{card.sub}</p>
            </Link>
          );
        })}
      </div>

      {/* Circulation Velocity Chart & Highest Demand Titles */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Circulation Velocity */}
        <div className="lg:col-span-8 p-6 rounded-2xl border border-neutral-200/80 bg-white dark:border-neutral-800 dark:bg-neutral-900 shadow-xs space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="font-bold text-sm text-neutral-900 dark:text-neutral-100">
                Monthly Circulation Velocity (Loans vs Returns)
              </h3>
              <p className="text-[11px] text-neutral-500">6-month transaction frequency across campus</p>
            </div>
            <Link to="/librarian/reports" className="text-xs font-semibold text-emerald-600 hover:underline">
              View Detailed Reports
            </Link>
          </div>

          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={borrowingTrends}>
                <CartesianGrid strokeDasharray="3 3" opacity={0.15} />
                <XAxis dataKey="month" tick={{ fontSize: 11 }} />
                <YAxis tick={{ fontSize: 11 }} />
                <Tooltip
                  contentStyle={{
                    backgroundColor: '#18181b',
                    borderColor: '#27272a',
                    borderRadius: '8px',
                    fontSize: '12px',
                    color: '#fff',
                  }}
                />
                <Legend wrapperStyle={{ fontSize: '11px', paddingTop: '8px' }} />
                <Bar dataKey="issues" fill="#10b981" radius={[4, 4, 0, 0]} name="Books Checked Out" />
                <Bar dataKey="returns" fill="#38bdf8" radius={[4, 4, 0, 0]} name="Books Returned" />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Highest Circulation Titles */}
        <div className="lg:col-span-4 p-6 rounded-2xl border border-neutral-200/80 bg-white dark:border-neutral-800 dark:bg-neutral-900 shadow-xs space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="font-bold text-sm text-neutral-900 dark:text-neutral-100">
              Highest Circulation Titles
            </h3>
            <span className="text-[10px] font-mono text-neutral-400">Semester Rank</span>
          </div>

          <div className="space-y-3">
            {popularBooks.map((book, idx) => (
              <div
                key={idx}
                className="flex items-center justify-between text-xs pb-2 border-b border-neutral-100 dark:border-neutral-800 last:border-0"
              >
                <div className="min-w-0 pr-2">
                  <span className="font-semibold text-neutral-900 dark:text-neutral-100 block truncate">
                    {book.title}
                  </span>
                  <span className="text-[10px] text-neutral-400 font-mono">{book.category}</span>
                </div>
                <div className="text-right shrink-0">
                  <span className="font-bold font-mono text-neutral-900 dark:text-neutral-100 tabular-nums">
                    {book.borrowCount}
                  </span>
                  <span className="text-[10px] text-neutral-400 block">issues</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Main Sections Quick Launch */}
      <div className="space-y-3">
        <h3 className="text-sm font-bold text-neutral-900 dark:text-neutral-100">
          Librarian Quick Access Modules
        </h3>
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
          <Link
            to="/librarian/books"
            className="p-4 rounded-xl border border-neutral-200/80 bg-white dark:border-neutral-800 dark:bg-neutral-900 hover:border-emerald-500/60 transition-colors"
          >
            <span className="font-bold text-xs block text-neutral-900 dark:text-white">Book Management</span>
            <span className="text-[10px] text-neutral-400">Add, edit, delete, and coordinate stacks</span>
          </Link>
          <Link
            to="/librarian/inventory"
            className="p-4 rounded-xl border border-neutral-200/80 bg-white dark:border-neutral-800 dark:bg-neutral-900 hover:border-emerald-500/60 transition-colors"
          >
            <span className="font-bold text-xs block text-neutral-900 dark:text-white">Inventory & Stock</span>
            <span className="text-[10px] text-neutral-400">Total, available, damaged, lost stock</span>
          </Link>
          <Link
            to="/librarian/borrowings"
            className="p-4 rounded-xl border border-neutral-200/80 bg-white dark:border-neutral-800 dark:bg-neutral-900 hover:border-emerald-500/60 transition-colors"
          >
            <span className="font-bold text-xs block text-neutral-900 dark:text-white">Borrowing Management</span>
            <span className="text-[10px] text-neutral-400">Loans, due dates, renewals, and fines</span>
          </Link>
          <Link
            to="/librarian/students"
            className="p-4 rounded-xl border border-neutral-200/80 bg-white dark:border-neutral-800 dark:bg-neutral-900 hover:border-emerald-500/60 transition-colors"
          >
            <span className="font-bold text-xs block text-neutral-900 dark:text-white">Student Management</span>
            <span className="text-[10px] text-neutral-400">Student enrollment, card IDs, and loan limits</span>
          </Link>
        </div>
      </div>
    </div>
  );
};

export default LibrarianDashboardPage;
