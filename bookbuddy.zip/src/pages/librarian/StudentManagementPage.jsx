import React, { useState } from 'react';
import { initialUsers } from '../../data/users';
import { initialBorrowings } from '../../data/borrowings';
import { Avatar } from '../../components/common/Avatar';
import { Button } from '../../components/common/Button';
import { Modal } from '../../components/common/Modal';
import {
  Users,
  Search,
  BookOpen,
  Mail,
  Phone,
  Building2,
  CheckCircle2,
  AlertCircle,
  PlusCircle,
  Clock,
  Shield,
  FileText,
  DollarSign,
  Copy,
  Check,
  AlertTriangle,
} from 'lucide-react';
import { toast } from 'sonner';

export const StudentManagementPage = () => {
  const [students, setStudents] = useState(
    initialUsers.filter((u) => u.role === 'student').map((s) => ({
      ...s,
      phone: s.phone || '+91 98765 43210',
      activeLoans: s.id === 'student-1' ? 2 : 1,
      overdueLoans: s.id === 'student-1' ? 1 : 0,
      outstandingFine: s.id === 'student-1' ? 20 : 0,
    }))
  );

  const [searchTerm, setSearchTerm] = useState('');
  const [selectedStudent, setSelectedStudent] = useState(null);
  const [isAddStudentOpen, setIsAddStudentOpen] = useState(false);
  const [copiedField, setCopiedField] = useState(null);

  // New Student Form
  const [newStudent, setNewStudent] = useState({
    name: '',
    email: '',
    studentId: '',
    phone: '',
    department: 'Computer Science & Engineering',
    semester: '1st Semester',
  });

  const getStudentLoans = (studentId) => {
    return initialBorrowings.filter((b) => b.userId === 'user-1' || b.userId === studentId);
  };

  const copyToClipboard = (text, fieldName) => {
    navigator.clipboard.writeText(text);
    setCopiedField(fieldName);
    toast.success(`Copied ${fieldName} to clipboard`);
    setTimeout(() => setCopiedField(null), 2000);
  };

  const filtered = students.filter(
    (s) =>
      s.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      s.studentId.toLowerCase().includes(searchTerm.toLowerCase()) ||
      s.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
      s.phone?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      s.department.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const handleToggleStatus = (id, currentStatus, name) => {
    const nextStatus = currentStatus === 'ACTIVE' ? 'SUSPENDED' : 'ACTIVE';
    setStudents((prev) =>
      prev.map((s) => (s.id === id ? { ...s, status: nextStatus } : s))
    );
    if (selectedStudent && selectedStudent.id === id) {
      setSelectedStudent({ ...selectedStudent, status: nextStatus });
    }
    toast.success(`Updated ${name}'s library account status to ${nextStatus}.`);
  };

  const handleCreateStudent = (e) => {
    e.preventDefault();
    if (!newStudent.name || !newStudent.studentId) {
      toast.error('Name and Student ID are required');
      return;
    }

    const created = {
      id: `student-${Date.now()}`,
      username: newStudent.studentId.toLowerCase().replace(/[^a-z0-9]/g, ''),
      name: newStudent.name,
      email: newStudent.email || `${newStudent.studentId.toLowerCase()}@university.edu`,
      phone: newStudent.phone || '+91 98765 00000',
      role: 'student',
      department: newStudent.department,
      semester: newStudent.semester,
      studentId: newStudent.studentId,
      status: 'ACTIVE',
      booksReadCount: 0,
      activeLoans: 0,
      overdueLoans: 0,
      outstandingFine: 0,
      joinedDate: new Date().toISOString(),
    };

    setStudents([created, ...students]);
    toast.success(`Enrolled student ${newStudent.name} (${newStudent.studentId})!`);
    setIsAddStudentOpen(false);
    setNewStudent({
      name: '',
      email: '',
      studentId: '',
      phone: '',
      department: 'Computer Science & Engineering',
      semester: '1st Semester',
    });
  };

  return (
    <div className="space-y-6 max-w-7xl mx-auto">
      {/* Title */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-bold tracking-tight text-neutral-900 dark:text-neutral-100">
            Student Management & Directory
          </h1>
          <p className="text-xs sm:text-sm text-neutral-500 dark:text-neutral-400 mt-1">
            Registered student readers, borrowing records, overdue loan indicators, and library account summaries.
          </p>
        </div>

        <Button
          variant="primary"
          size="sm"
          leftIcon={<PlusCircle className="w-4 h-4" />}
          onClick={() => setIsAddStudentOpen(true)}
        >
          Enroll New Student
        </Button>
      </div>

      {/* Search Bar */}
      <div className="p-4 rounded-2xl border border-neutral-200/80 bg-white dark:border-neutral-800 dark:bg-neutral-900 shadow-xs flex items-center gap-3">
        <div className="relative flex-1">
          <Search className="w-4 h-4 text-neutral-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Search students by Name, Student ID (e.g. CS2023-8891), Email, Phone, or Department..."
            className="w-full h-10 rounded-xl border border-neutral-300 bg-white pl-9 pr-3 text-xs text-neutral-900 placeholder:text-neutral-400 focus:outline-none focus:ring-2 focus:ring-neutral-900 dark:border-neutral-700 dark:bg-neutral-800 dark:text-neutral-100"
          />
        </div>
      </div>

      {/* Students Data Table (Req 41: Student Name, Student ID, Department, Email, Phone, Active Loans, Overdue Loans, Books Read, Outstanding Fine) */}
      <div className="rounded-2xl border border-neutral-200/80 bg-white dark:border-neutral-800 dark:bg-neutral-900 overflow-hidden shadow-xs">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-neutral-50 dark:bg-neutral-800/60 border-b border-neutral-200 dark:border-neutral-800 font-mono text-[10px] text-neutral-500 uppercase tracking-wider">
              <tr>
                <th className="py-3 px-3.5">Student Name</th>
                <th className="py-3 px-3.5">Student ID</th>
                <th className="py-3 px-3.5">Department</th>
                <th className="py-3 px-3.5">Email</th>
                <th className="py-3 px-3.5">Phone</th>
                <th className="py-3 px-3.5 text-center">Active Loans</th>
                <th className="py-3 px-3.5 text-center">Overdue Loans</th>
                <th className="py-3 px-3.5 text-center">Books Read</th>
                <th className="py-3 px-3.5">Outstanding Fine</th>
                <th className="py-3 px-3.5 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-neutral-100 dark:divide-neutral-800">
              {filtered.map((student) => {
                return (
                  <tr
                    key={student.id}
                    onClick={() => setSelectedStudent(student)}
                    className="hover:bg-neutral-50/50 dark:hover:bg-neutral-800/30 transition-colors cursor-pointer"
                  >
                    {/* Student Name */}
                    <td className="py-3.5 px-3.5">
                      <div className="flex items-center gap-2.5">
                        <Avatar name={student.name} size="sm" />
                        <div>
                          <span className="font-semibold text-neutral-900 dark:text-neutral-100 block">
                            {student.name}
                          </span>
                          <span className="text-[10px] text-neutral-400 font-mono">
                            Joined {student.joinedDate ? format(new Date(student.joinedDate), 'MMM yyyy') : 'Aug 2025'}
                          </span>
                        </div>
                      </div>
                    </td>

                    {/* Student ID */}
                    <td className="py-3.5 px-3.5 font-mono font-medium text-neutral-700 dark:text-neutral-300 whitespace-nowrap">
                      {student.studentId}
                    </td>

                    {/* Department */}
                    <td className="py-3.5 px-3.5 text-neutral-600 dark:text-neutral-300">
                      {student.department}
                    </td>

                    {/* Email */}
                    <td className="py-3.5 px-3.5 font-mono text-neutral-500 whitespace-nowrap">
                      {student.email}
                    </td>

                    {/* Phone */}
                    <td className="py-3.5 px-3.5 font-mono text-neutral-500 whitespace-nowrap">
                      {student.phone}
                    </td>

                    {/* Active Loans */}
                    <td className="py-3.5 px-3.5 font-mono font-semibold text-center text-neutral-900 dark:text-neutral-100 tabular-nums">
                      {student.activeLoans} / 4
                    </td>

                    {/* Overdue Loans */}
                    <td className="py-3.5 px-3.5 font-mono font-bold text-center tabular-nums">
                      {student.overdueLoans > 0 ? (
                        <span className="inline-flex items-center gap-1 text-rose-600">
                          <AlertTriangle className="w-3 h-3" />
                          {student.overdueLoans}
                        </span>
                      ) : (
                        <span className="text-neutral-400">0</span>
                      )}
                    </td>

                    {/* Books Read */}
                    <td className="py-3.5 px-3.5 font-mono text-center text-neutral-700 dark:text-neutral-300 tabular-nums font-semibold">
                      {student.booksReadCount || 28}
                    </td>

                    {/* Outstanding Fine */}
                    <td className="py-3.5 px-3.5 font-mono whitespace-nowrap font-bold">
                      {student.outstandingFine > 0 ? (
                        <span className="text-rose-600">₹{student.outstandingFine}</span>
                      ) : (
                        <span className="text-emerald-600 font-semibold">₹0</span>
                      )}
                    </td>

                    {/* Actions */}
                    <td className="py-3.5 px-3.5 text-right whitespace-nowrap" onClick={(e) => e.stopPropagation()}>
                      <div className="flex items-center justify-end gap-1.5">
                        <button
                          onClick={() => setSelectedStudent(student)}
                          className="px-2.5 py-1 rounded-md text-[11px] font-medium border border-neutral-200 dark:border-neutral-700 hover:bg-neutral-100 dark:hover:bg-neutral-800 transition-colors cursor-pointer"
                        >
                          Account Summary
                        </button>

                        <button
                          onClick={() => handleToggleStatus(student.id, student.status, student.name)}
                          className={`px-2 py-1 rounded-md text-[11px] font-medium transition-colors cursor-pointer ${
                            student.status === 'ACTIVE'
                              ? 'text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-950/40'
                              : 'text-emerald-600 hover:bg-emerald-50 dark:hover:bg-emerald-950/40'
                          }`}
                        >
                          {student.status === 'ACTIVE' ? 'Suspend' : 'Reactivate'}
                        </button>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Student Library Account Summary Modal (Req 41) */}
      <Modal
        isOpen={Boolean(selectedStudent)}
        onClose={() => setSelectedStudent(null)}
        title="Student Library Account Summary"
        description="Comprehensive circulation standing, loan ledger, and university contact details."
      >
        {selectedStudent && (
          <div className="space-y-5">
            {/* Header info card */}
            <div className="p-4 rounded-2xl bg-neutral-50 dark:bg-neutral-800/60 border border-neutral-200/80 dark:border-neutral-700/80 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <Avatar name={selectedStudent.name} size="md" />
                <div>
                  <div className="flex items-center gap-2">
                    <h3 className="font-bold text-sm text-neutral-900 dark:text-neutral-100">
                      {selectedStudent.name}
                    </h3>
                    <span
                      className={`px-2 py-0.5 rounded text-[10px] font-mono font-bold ${
                        selectedStudent.status === 'ACTIVE'
                          ? 'bg-emerald-50 text-emerald-700 dark:bg-emerald-950/60 dark:text-emerald-400 border border-emerald-200 dark:border-emerald-800'
                          : 'bg-rose-50 text-rose-700 dark:bg-rose-950/60 dark:text-rose-400 border border-rose-200 dark:border-rose-800'
                      }`}
                    >
                      {selectedStudent.status}
                    </span>
                  </div>
                  <p className="text-xs text-neutral-500 font-mono mt-0.5">
                    ID: {selectedStudent.studentId} · {selectedStudent.department}
                  </p>
                </div>
              </div>
            </div>

            {/* Quick Metrics */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-center font-mono">
              <div className="p-3 rounded-xl bg-neutral-100/60 dark:bg-neutral-800">
                <span className="text-[10px] text-neutral-400 block uppercase font-sans">Active Loans</span>
                <span className="text-lg font-bold text-neutral-900 dark:text-neutral-100">
                  {selectedStudent.activeLoans} / 4
                </span>
              </div>

              <div className="p-3 rounded-xl bg-neutral-100/60 dark:bg-neutral-800">
                <span className="text-[10px] text-neutral-400 block uppercase font-sans">Overdue Loans</span>
                <span className={`text-lg font-bold ${selectedStudent.overdueLoans > 0 ? 'text-rose-600' : 'text-neutral-900 dark:text-neutral-100'}`}>
                  {selectedStudent.overdueLoans}
                </span>
              </div>

              <div className="p-3 rounded-xl bg-neutral-100/60 dark:bg-neutral-800">
                <span className="text-[10px] text-neutral-400 block uppercase font-sans">Books Read</span>
                <span className="text-lg font-bold text-neutral-900 dark:text-neutral-100">
                  {selectedStudent.booksReadCount || 28}
                </span>
              </div>

              <div className="p-3 rounded-xl bg-neutral-100/60 dark:bg-neutral-800">
                <span className="text-[10px] text-neutral-400 block uppercase font-sans">Unpaid Fine</span>
                <span className={`text-lg font-bold ${selectedStudent.outstandingFine > 0 ? 'text-rose-600' : 'text-emerald-600'}`}>
                  ₹{selectedStudent.outstandingFine}
                </span>
              </div>
            </div>

            {/* Contact Details with Copy */}
            <div className="space-y-2 p-4 rounded-2xl bg-neutral-50 dark:bg-neutral-800/60 border border-neutral-200/80 dark:border-neutral-700/80 text-xs">
              <span className="text-[10px] font-mono text-neutral-400 uppercase block font-semibold">
                Official Student Contacts
              </span>

              <div className="flex items-center justify-between py-1.5 border-b border-neutral-200/40 dark:border-neutral-700/40 font-mono">
                <div className="flex items-center gap-2">
                  <Mail className="w-3.5 h-3.5 text-neutral-400" />
                  <span className="text-neutral-700 dark:text-neutral-300">{selectedStudent.email}</span>
                </div>
                <button
                  onClick={() => copyToClipboard(selectedStudent.email, 'Email')}
                  className="inline-flex items-center gap-1 px-2 py-0.5 rounded bg-neutral-200/60 dark:bg-neutral-700 text-[10px] text-neutral-700 dark:text-neutral-200 hover:bg-neutral-300 dark:hover:bg-neutral-600 cursor-pointer"
                >
                  {copiedField === 'Email' ? <Check className="w-3 h-3 text-emerald-500" /> : <Copy className="w-3 h-3" />}
                  <span>Copy</span>
                </button>
              </div>

              <div className="flex items-center justify-between py-1.5 font-mono">
                <div className="flex items-center gap-2">
                  <Phone className="w-3.5 h-3.5 text-neutral-400" />
                  <span className="text-neutral-700 dark:text-neutral-300">{selectedStudent.phone}</span>
                </div>
                <button
                  onClick={() => copyToClipboard(selectedStudent.phone, 'Phone')}
                  className="inline-flex items-center gap-1 px-2 py-0.5 rounded bg-neutral-200/60 dark:bg-neutral-700 text-[10px] text-neutral-700 dark:text-neutral-200 hover:bg-neutral-300 dark:hover:bg-neutral-600 cursor-pointer"
                >
                  {copiedField === 'Phone' ? <Check className="w-3 h-3 text-emerald-500" /> : <Copy className="w-3 h-3" />}
                  <span>Copy</span>
                </button>
              </div>
            </div>

            {/* Current Active Loans */}
            <div className="space-y-2">
              <span className="text-xs font-bold text-neutral-900 dark:text-neutral-100 block">
                Active Physical Loans
              </span>

              <div className="space-y-2 max-h-40 overflow-y-auto">
                {getStudentLoans(selectedStudent.id).map((b) => (
                  <div
                    key={b.id}
                    className="p-3 rounded-xl border border-neutral-200 dark:border-neutral-800 bg-white dark:bg-neutral-900 flex items-center justify-between text-xs"
                  >
                    <div>
                      <h4 className="font-semibold text-neutral-900 dark:text-neutral-100">
                        {b.title}
                      </h4>
                      <p className="text-[10px] font-mono text-neutral-400">
                        Due: {b.dueDate ? format(new Date(b.dueDate), 'MMM dd, yyyy') : 'In 7 days'}
                      </p>
                    </div>

                    <span
                      className={`px-2 py-0.5 rounded text-[10px] font-mono font-bold ${
                        b.status === 'OVERDUE'
                          ? 'bg-rose-50 text-rose-700 dark:bg-rose-950/60 dark:text-rose-400'
                          : 'bg-emerald-50 text-emerald-700 dark:bg-emerald-950/60 dark:text-emerald-400'
                      }`}
                    >
                      {b.status}
                    </span>
                  </div>
                ))}
              </div>
            </div>

            {/* Action Bar */}
            <div className="flex items-center justify-between pt-3 border-t border-neutral-100 dark:border-neutral-800">
              <button
                onClick={() => handleToggleStatus(selectedStudent.id, selectedStudent.status, selectedStudent.name)}
                className={`text-xs font-semibold px-3 py-1.5 rounded-lg border transition-colors cursor-pointer ${
                  selectedStudent.status === 'ACTIVE'
                    ? 'border-rose-200 text-rose-600 hover:bg-rose-50 dark:border-rose-900 dark:hover:bg-rose-950/40'
                    : 'border-emerald-200 text-emerald-600 hover:bg-emerald-50 dark:border-emerald-900 dark:hover:bg-emerald-950/40'
                }`}
              >
                {selectedStudent.status === 'ACTIVE' ? 'Suspend Account' : 'Reactivate Account'}
              </button>

              <Button variant="primary" size="sm" onClick={() => setSelectedStudent(null)}>
                Close Summary
              </Button>
            </div>
          </div>
        )}
      </Modal>

      {/* Enroll Student Modal */}
      <Modal
        isOpen={isAddStudentOpen}
        onClose={() => setIsAddStudentOpen(false)}
        title="Enroll New University Student"
        description="Create an active reader account with 4-volume concurrent loan privileges."
      >
        <form onSubmit={handleCreateStudent} className="space-y-4">
          <div>
            <label className="block text-xs font-semibold text-neutral-700 dark:text-neutral-300 mb-1.5">
              Full Name
            </label>
            <input
              type="text"
              required
              placeholder="e.g. Vishal Gayathri"
              value={newStudent.name}
              onChange={(e) => setNewStudent({ ...newStudent, name: e.target.value })}
              className="w-full h-10 rounded-xl border border-neutral-300 bg-white px-3 text-xs text-neutral-900 focus:outline-none focus:ring-2 focus:ring-neutral-900 dark:border-neutral-700 dark:bg-neutral-800 dark:text-neutral-100"
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold text-neutral-700 dark:text-neutral-300 mb-1.5">
                Student Card ID
              </label>
              <input
                type="text"
                required
                placeholder="CS2023-8891"
                value={newStudent.studentId}
                onChange={(e) => setNewStudent({ ...newStudent, studentId: e.target.value })}
                className="w-full h-10 rounded-xl border border-neutral-300 bg-white px-3 text-xs text-neutral-900 focus:outline-none focus:ring-2 focus:ring-neutral-900 dark:border-neutral-700 dark:bg-neutral-800 dark:text-neutral-100 font-mono"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-neutral-700 dark:text-neutral-300 mb-1.5">
                Phone Number
              </label>
              <input
                type="text"
                placeholder="+91 98765 43210"
                value={newStudent.phone}
                onChange={(e) => setNewStudent({ ...newStudent, phone: e.target.value })}
                className="w-full h-10 rounded-xl border border-neutral-300 bg-white px-3 text-xs text-neutral-900 focus:outline-none focus:ring-2 focus:ring-neutral-900 dark:border-neutral-700 dark:bg-neutral-800 dark:text-neutral-100 font-mono"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-neutral-700 dark:text-neutral-300 mb-1.5">
              Institutional Email
            </label>
            <input
              type="email"
              placeholder="student@university.edu"
              value={newStudent.email}
              onChange={(e) => setNewStudent({ ...newStudent, email: e.target.value })}
              className="w-full h-10 rounded-xl border border-neutral-300 bg-white px-3 text-xs text-neutral-900 focus:outline-none focus:ring-2 focus:ring-neutral-900 dark:border-neutral-700 dark:bg-neutral-800 dark:text-neutral-100 font-mono"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-neutral-700 dark:text-neutral-300 mb-1.5">
              Department
            </label>
            <select
              value={newStudent.department}
              onChange={(e) => setNewStudent({ ...newStudent, department: e.target.value })}
              className="w-full h-10 rounded-xl border border-neutral-300 bg-white px-3 text-xs text-neutral-900 focus:outline-none focus:ring-2 focus:ring-neutral-900 dark:border-neutral-700 dark:bg-neutral-800 dark:text-neutral-100"
            >
              <option value="Computer Science & Engineering">Computer Science & Engineering</option>
              <option value="Electronics & Communication">Electronics & Communication</option>
              <option value="Data Science & AI">Data Science & AI</option>
              <option value="Mechanical Engineering">Mechanical Engineering</option>
            </select>
          </div>

          <div className="flex items-center justify-end gap-3 pt-3 border-t border-neutral-100 dark:border-neutral-800">
            <Button variant="outline" size="sm" onClick={() => setIsAddStudentOpen(false)}>
              Cancel
            </Button>
            <Button type="submit" variant="primary" size="sm">
              Enroll Student
            </Button>
          </div>
        </form>
      </Modal>
    </div>
  );
};

export default StudentManagementPage;
