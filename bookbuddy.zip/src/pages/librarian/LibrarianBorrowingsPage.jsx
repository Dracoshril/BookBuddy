import React, { useState } from 'react';
import { initialBorrowings } from '../../data/borrowings';
import { initialBooks } from '../../data/books';
import { initialUsers } from '../../data/users';
import { Button } from '../../components/common/Button';
import { Modal } from '../../components/common/Modal';
import {
  ArrowUpRight,
  ArrowDownLeft,
  RotateCcw,
  Search,
  DollarSign,
  Eye,
  CheckCircle2,
  AlertTriangle,
  Clock,
  PlusCircle,
  Phone,
  Mail,
  Copy,
  Check,
  Building2,
  AlertCircle,
  XCircle,
  HelpCircle,
} from 'lucide-react';
import { format, addDays } from 'date-fns';
import { toast } from 'sonner';

export const LibrarianBorrowingsPage = () => {
  const [borrowings, setBorrowings] = useState(() => {
    return initialBorrowings.map((b) => {
      const studentObj =
        initialUsers.find((u) => u.id === b.userId || (b.userId === 'user-1' && u.id === 'student-1')) ||
        initialUsers[0];
      const bookObj = initialBooks.find((bk) => String(bk.id) === String(b.bookId)) || initialBooks[0];

      return {
        ...b,
        studentName: studentObj.name,
        studentIdCode: studentObj.studentId,
        studentEmail: studentObj.email,
        studentPhone: studentObj.phone || '+91 98765 43210',
        department: studentObj.department || 'Computer Science & Engineering',
        category: bookObj.category || b.category,
      };
    });
  });

  // Filters & Search
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('ALL'); // 'ALL' | 'CURRENT' | 'DUE_SOON' | 'OVERDUE' | 'RETURNED' | 'LOST' | 'DAMAGED'
  const [deptFilter, setDeptFilter] = useState('ALL');
  const [categoryFilter, setCategoryFilter] = useState('ALL');
  const [sortOption, setSortOption] = useState('newest'); // 'newest' | 'oldest' | 'due_soon' | 'overdue' | 'student' | 'book'

  // Modals state
  const [isIssueModalOpen, setIsIssueModalOpen] = useState(false);
  const [selectedRecord, setSelectedRecord] = useState(null);
  const [contactStudentRecord, setContactStudentRecord] = useState(null);
  const [fineModalRecord, setFineModalRecord] = useState(null);
  const [fineAdjustment, setFineAdjustment] = useState('');
  const [copiedField, setCopiedField] = useState(null);

  // Issue Book Form
  const [issueStudentId, setIssueStudentId] = useState(initialUsers[0].id);
  const [issueBookId, setIssueBookId] = useState(initialBooks[0].id);
  const [loanDays, setLoanDays] = useState(14);

  const copyToClipboard = (text, fieldName) => {
    navigator.clipboard.writeText(text);
    setCopiedField(fieldName);
    toast.success(`Copied ${fieldName} to clipboard`);
    setTimeout(() => setCopiedField(null), 2000);
  };

  const handleIssueBook = (e) => {
    e.preventDefault();
    const book = initialBooks.find((b) => String(b.id) === String(issueBookId));
    const student = initialUsers.find((u) => u.id === issueStudentId) || initialUsers[0];
    const now = new Date();

    const newBorrowing = {
      id: `bor-${Date.now()}`,
      userId: student.id,
      studentName: student.name,
      studentIdCode: student.studentId,
      studentEmail: student.email,
      studentPhone: student.phone || '+91 98765 43210',
      department: student.department,
      bookId: book.id,
      bookNumber: book.bookNumber,
      title: book.title,
      author: book.author,
      category: book.category,
      borrowDate: now.toISOString(),
      dueDate: addDays(now, Number(loanDays)).toISOString(),
      returnDate: null,
      status: 'CURRENT',
      renewalCount: 0,
      fineAmount: 0,
    };

    setBorrowings([newBorrowing, ...borrowings]);
    toast.success(`Loan issued for "${book.title}" to ${student.name}!`);
    setIsIssueModalOpen(false);
  };

  const handleApproveReturn = (recordId, bookTitle) => {
    setBorrowings((prev) =>
      prev.map((b) =>
        b.id === recordId
          ? { ...b, status: 'RETURNED', returnDate: new Date().toISOString() }
          : b
      )
    );
    toast.success(`Check-in completed for "${bookTitle}". Available inventory copy restored.`);
  };

  const handleRenewLoan = (recordId, bookTitle) => {
    const loan = borrowings.find((b) => b.id === recordId);
    if ((loan?.renewalCount || 0) >= 2) {
      toast.error('Maximum renewal quota reached (2 renewals).');
      return;
    }

    setBorrowings((prev) =>
      prev.map((b) =>
        b.id === recordId
          ? {
              ...b,
              status: 'CURRENT',
              dueDate: addDays(new Date(b.dueDate), 14).toISOString(),
              renewalCount: (b.renewalCount || 0) + 1,
            }
          : b
      )
    );
    toast.success(`Renewed loan for "${bookTitle}" (+14 days).`);
  };

  const handleSaveFine = (e) => {
    e.preventDefault();
    const adjusted = parseFloat(fineAdjustment);
    if (isNaN(adjusted) || adjusted < 0) {
      toast.error('Please enter a valid fine amount');
      return;
    }

    setBorrowings((prev) =>
      prev.map((b) => (b.id === fineModalRecord.id ? { ...b, fineAmount: adjusted } : b))
    );
    toast.success(`Updated overdue fine for "${fineModalRecord.title}" to ₹${adjusted.toFixed(2)}.`);
    setFineModalRecord(null);
  };

  // Filter & Sort logic (Req 42)
  const filtered = borrowings
    .filter((b) => {
      const q = searchTerm.toLowerCase();
      const matchesSearch =
        b.id.toLowerCase().includes(q) ||
        b.studentName.toLowerCase().includes(q) ||
        b.studentIdCode?.toLowerCase().includes(q) ||
        b.studentEmail?.toLowerCase().includes(q) ||
        b.studentPhone?.toLowerCase().includes(q) ||
        b.title.toLowerCase().includes(q) ||
        b.bookNumber?.toLowerCase().includes(q);

      if (!matchesSearch) return false;

      // Status Filter
      if (statusFilter !== 'ALL' && b.status !== statusFilter) return false;

      // Department Filter
      if (deptFilter !== 'ALL' && b.department !== deptFilter) return false;

      // Category Filter
      if (categoryFilter !== 'ALL' && b.category !== categoryFilter) return false;

      return true;
    })
    .sort((a, b) => {
      if (sortOption === 'newest') return new Date(b.borrowDate) - new Date(a.borrowDate);
      if (sortOption === 'oldest') return new Date(a.borrowDate) - new Date(b.borrowDate);
      if (sortOption === 'due_soon') return new Date(a.dueDate) - new Date(b.dueDate);
      if (sortOption === 'overdue') return (b.status === 'OVERDUE' ? 1 : 0) - (a.status === 'OVERDUE' ? 1 : 0);
      if (sortOption === 'student') return a.studentName.localeCompare(b.studentName);
      if (sortOption === 'book') return a.title.localeCompare(b.title);
      return 0;
    });

  // Accessible Status Badges (Req 39: Active, Due Soon, Overdue, Returned, Lost, Damaged)
  const getStatusBadge = (status) => {
    switch (status) {
      case 'CURRENT':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-mono font-bold bg-sky-50 text-sky-700 dark:bg-sky-950/60 dark:text-sky-300 border border-sky-200 dark:border-sky-800">
            <span className="w-1.5 h-1.5 rounded-full bg-sky-500" />
            Active
          </span>
        );
      case 'DUE_SOON':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-mono font-bold bg-amber-50 text-amber-700 dark:bg-amber-950/60 dark:text-amber-300 border border-amber-200 dark:border-amber-800">
            <Clock className="w-3 h-3 text-amber-500" />
            Due Soon
          </span>
        );
      case 'OVERDUE':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-mono font-bold bg-rose-50 text-rose-700 dark:bg-rose-950/60 dark:text-rose-300 border border-rose-200 dark:border-rose-800">
            <AlertTriangle className="w-3 h-3 text-rose-500" />
            Overdue
          </span>
        );
      case 'RETURNED':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-mono font-bold bg-emerald-50 text-emerald-700 dark:bg-emerald-950/60 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-800">
            <CheckCircle2 className="w-3 h-3 text-emerald-500" />
            Returned
          </span>
        );
      case 'LOST':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-mono font-bold bg-neutral-100 text-neutral-700 dark:bg-neutral-800 dark:text-neutral-300 border border-neutral-300 dark:border-neutral-700">
            <XCircle className="w-3 h-3 text-neutral-500" />
            Lost
          </span>
        );
      case 'DAMAGED':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-mono font-bold bg-red-50 text-red-700 dark:bg-red-950/60 dark:text-red-300 border border-red-200 dark:border-red-800">
            <AlertCircle className="w-3 h-3 text-red-500" />
            Damaged
          </span>
        );
      default:
        return (
          <span className="px-2 py-0.5 rounded text-[10px] font-mono bg-neutral-100 dark:bg-neutral-800 text-neutral-600 dark:text-neutral-400">
            {status}
          </span>
        );
    }
  };

  return (
    <div className="space-y-6 max-w-7xl mx-auto">
      {/* Title */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-bold tracking-tight text-neutral-900 dark:text-neutral-100">
            Borrowing Loans
          </h1>
          <p className="text-xs sm:text-sm text-neutral-500 dark:text-neutral-400 mt-1">
            Complete registry of all outgoing and returned physical book loans, student contacts, due dates, and fine settlements.
          </p>
        </div>

        <Button
          variant="primary"
          size="sm"
          leftIcon={<PlusCircle className="w-4 h-4" />}
          onClick={() => setIsIssueModalOpen(true)}
        >
          Issue New Book Loan
        </Button>
      </div>

      {/* Search and Filters Bar (Req 42) */}
      <div className="p-4 rounded-2xl border border-neutral-200/80 bg-white dark:border-neutral-800 dark:bg-neutral-900 shadow-xs space-y-3">
        <div className="relative">
          <Search className="w-4 h-4 text-neutral-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Search by Loan ID, Student Name, Student ID, Email, Phone, Book Title, or Call Number..."
            className="w-full h-10 rounded-xl border border-neutral-300 bg-white pl-9 pr-3 text-xs text-neutral-900 placeholder:text-neutral-400 focus:outline-none focus:ring-2 focus:ring-neutral-900 dark:border-neutral-700 dark:bg-neutral-800 dark:text-neutral-100"
          />
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
          {/* Status Filter */}
          <div>
            <label className="block text-[10px] font-mono text-neutral-400 uppercase mb-1">Status</label>
            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
              className="w-full h-9 rounded-xl border border-neutral-300 bg-white px-2.5 text-xs text-neutral-900 focus:outline-none focus:ring-2 focus:ring-neutral-900 dark:border-neutral-700 dark:bg-neutral-800 dark:text-neutral-100"
            >
              <option value="ALL">All Statuses</option>
              <option value="CURRENT">Active</option>
              <option value="DUE_SOON">Due Soon</option>
              <option value="OVERDUE">Overdue</option>
              <option value="RETURNED">Returned</option>
              <option value="LOST">Lost</option>
              <option value="DAMAGED">Damaged</option>
            </select>
          </div>

          {/* Department Filter */}
          <div>
            <label className="block text-[10px] font-mono text-neutral-400 uppercase mb-1">Department</label>
            <select
              value={deptFilter}
              onChange={(e) => setDeptFilter(e.target.value)}
              className="w-full h-9 rounded-xl border border-neutral-300 bg-white px-2.5 text-xs text-neutral-900 focus:outline-none focus:ring-2 focus:ring-neutral-900 dark:border-neutral-700 dark:bg-neutral-800 dark:text-neutral-100 truncate"
            >
              <option value="ALL">All Departments</option>
              <option value="Computer Science & Engineering">Computer Science</option>
              <option value="Electronics & Communication">Electronics</option>
              <option value="Data Science & AI">Data Science</option>
            </select>
          </div>

          {/* Category Filter */}
          <div>
            <label className="block text-[10px] font-mono text-neutral-400 uppercase mb-1">Category</label>
            <select
              value={categoryFilter}
              onChange={(e) => setCategoryFilter(e.target.value)}
              className="w-full h-9 rounded-xl border border-neutral-300 bg-white px-2.5 text-xs text-neutral-900 focus:outline-none focus:ring-2 focus:ring-neutral-900 dark:border-neutral-700 dark:bg-neutral-800 dark:text-neutral-100 truncate"
            >
              <option value="ALL">All Categories</option>
              <option value="Programming">Programming</option>
              <option value="System Design">System Design</option>
              <option value="DSA">DSA</option>
              <option value="Database">Database</option>
              <option value="Self Development">Self Development</option>
              <option value="Fiction">Fiction</option>
              <option value="Artificial Intelligence">AI</option>
            </select>
          </div>

          {/* Sorting */}
          <div>
            <label className="block text-[10px] font-mono text-neutral-400 uppercase mb-1">Sort By</label>
            <select
              value={sortOption}
              onChange={(e) => setSortOption(e.target.value)}
              className="w-full h-9 rounded-xl border border-neutral-300 bg-white px-2.5 text-xs text-neutral-900 focus:outline-none focus:ring-2 focus:ring-neutral-900 dark:border-neutral-700 dark:bg-neutral-800 dark:text-neutral-100"
            >
              <option value="newest">Newest Loans</option>
              <option value="oldest">Oldest Loans</option>
              <option value="due_soon">Due Soonest</option>
              <option value="overdue">Overdue First</option>
              <option value="student">Student Name</option>
              <option value="book">Book Title</option>
            </select>
          </div>
        </div>
      </div>

      {/* Borrowing Loans Table (Req 38: Loan ID, Book, Student, Student ID, Contact, Borrowed Date, Due Date, Return Date, Status, Fine, Actions) */}
      <div className="rounded-2xl border border-neutral-200/80 bg-white dark:border-neutral-800 dark:bg-neutral-900 overflow-hidden shadow-xs">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-neutral-50 dark:bg-neutral-800/60 border-b border-neutral-200 dark:border-neutral-800 font-mono text-[10px] text-neutral-500 uppercase tracking-wider">
              <tr>
                <th className="py-3 px-3.5">Loan ID</th>
                <th className="py-3 px-3.5">Book</th>
                <th className="py-3 px-3.5">Student</th>
                <th className="py-3 px-3.5">Student ID</th>
                <th className="py-3 px-3.5">Contact</th>
                <th className="py-3 px-3.5">Borrowed</th>
                <th className="py-3 px-3.5">Due Date</th>
                <th className="py-3 px-3.5">Return Date</th>
                <th className="py-3 px-3.5">Status</th>
                <th className="py-3 px-3.5">Fine</th>
                <th className="py-3 px-3.5 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-neutral-100 dark:divide-neutral-800">
              {filtered.map((item) => {
                const isReturned = item.status === 'RETURNED';

                return (
                  <tr key={item.id} className="hover:bg-neutral-50/50 dark:hover:bg-neutral-800/30 transition-colors">
                    {/* Loan ID */}
                    <td className="py-3 px-3.5 font-mono text-neutral-500 font-semibold whitespace-nowrap">
                      {item.id}
                    </td>

                    {/* Book */}
                    <td className="py-3 px-3.5 min-w-[170px]">
                      <div className="font-semibold text-neutral-900 dark:text-neutral-100 line-clamp-1">
                        {item.title}
                      </div>
                      <div className="text-[10px] text-neutral-400 font-mono">{item.bookNumber}</div>
                    </td>

                    {/* Student */}
                    <td className="py-3 px-3.5 whitespace-nowrap">
                      <div className="font-semibold text-neutral-900 dark:text-neutral-100">
                        {item.studentName}
                      </div>
                      <div className="text-[10px] text-neutral-400">{item.department}</div>
                    </td>

                    {/* Student ID */}
                    <td className="py-3 px-3.5 font-mono font-medium text-neutral-700 dark:text-neutral-300 whitespace-nowrap">
                      {item.studentIdCode}
                    </td>

                    {/* Contact (Req 40) */}
                    <td className="py-3 px-3.5 whitespace-nowrap">
                      <button
                        onClick={() => setContactStudentRecord(item)}
                        className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md border border-neutral-200 dark:border-neutral-700 text-[10px] font-mono text-neutral-600 dark:text-neutral-400 hover:text-neutral-900 dark:hover:text-white hover:bg-neutral-100 dark:hover:bg-neutral-800 transition-colors cursor-pointer"
                        title="View Contact Details"
                      >
                        <Phone className="w-3 h-3 text-amber-500" />
                        <span>Contact</span>
                      </button>
                    </td>

                    {/* Borrowed Date */}
                    <td className="py-3 px-3.5 font-mono text-neutral-500 whitespace-nowrap">
                      {format(new Date(item.borrowDate), 'MMM dd, yyyy')}
                    </td>

                    {/* Due Date */}
                    <td className="py-3 px-3.5 font-mono whitespace-nowrap font-medium">
                      <span className={item.status === 'OVERDUE' ? 'text-rose-600 font-bold' : ''}>
                        {format(new Date(item.dueDate), 'MMM dd, yyyy')}
                      </span>
                    </td>

                    {/* Return Date */}
                    <td className="py-3 px-3.5 font-mono text-neutral-500 whitespace-nowrap">
                      {item.returnDate ? format(new Date(item.returnDate), 'MMM dd, yyyy') : '—'}
                    </td>

                    {/* Status */}
                    <td className="py-3 px-3.5 whitespace-nowrap">
                      {getStatusBadge(item.status)}
                    </td>

                    {/* Fine */}
                    <td className="py-3 px-3.5 font-mono whitespace-nowrap font-semibold">
                      {item.fineAmount > 0 ? (
                        <span className="text-rose-600">₹{Number(item.fineAmount).toFixed(0)}</span>
                      ) : (
                        <span className="text-neutral-400">₹0</span>
                      )}
                    </td>

                    {/* Actions: View, Renew, Return, Contact (Req 38) */}
                    <td className="py-3 px-3.5 text-right whitespace-nowrap">
                      <div className="flex items-center justify-end gap-1.5">
                        <button
                          onClick={() => setSelectedRecord(item)}
                          className="p-1.5 text-neutral-400 hover:text-neutral-900 dark:hover:text-white rounded-lg transition-colors cursor-pointer"
                          title="View Complete Loan Details"
                        >
                          <Eye className="w-3.5 h-3.5" />
                        </button>

                        {!isReturned && (
                          <>
                            <button
                              onClick={() => handleRenewLoan(item.id, item.title)}
                              className="px-2 py-0.5 rounded text-[11px] font-medium border border-neutral-200 dark:border-neutral-700 hover:bg-neutral-100 dark:hover:bg-neutral-800 transition-colors cursor-pointer"
                              title="Renew Loan (+14 Days)"
                            >
                              Renew
                            </button>

                            <button
                              onClick={() => handleApproveReturn(item.id, item.title)}
                              className="px-2 py-0.5 rounded text-[11px] font-semibold bg-emerald-600 text-white hover:bg-emerald-700 transition-colors cursor-pointer"
                              title="Check-In Return"
                            >
                              Return
                            </button>
                          </>
                        )}

                        <button
                          onClick={() => {
                            setFineModalRecord(item);
                            setFineAdjustment(item.fineAmount || 0);
                          }}
                          className="p-1 text-neutral-400 hover:text-amber-500 rounded transition-colors cursor-pointer"
                          title="Adjust Overdue Fine"
                        >
                          <DollarSign className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Contact Student Modal (Req 40: Copy Email, Copy Phone) */}
      <Modal
        isOpen={Boolean(contactStudentRecord)}
        onClose={() => setContactStudentRecord(null)}
        title="Student Patron Contact Information"
        description="Official contact channels for borrowing notifications, recall notices, or overdue reminders."
      >
        {contactStudentRecord && (
          <div className="space-y-4">
            <div className="p-4 rounded-2xl bg-neutral-50 dark:bg-neutral-800/60 border border-neutral-200/80 dark:border-neutral-700/80 space-y-3 text-xs">
              <div className="flex justify-between items-center pb-2 border-b border-neutral-200/60 dark:border-neutral-700/60">
                <span className="text-neutral-400 uppercase font-mono">Student Patron</span>
                <span className="font-bold text-sm text-neutral-900 dark:text-neutral-100">
                  {contactStudentRecord.studentName}
                </span>
              </div>

              <div className="flex justify-between items-center">
                <span className="text-neutral-400">Student ID:</span>
                <span className="font-mono font-semibold text-neutral-900 dark:text-neutral-100">
                  {contactStudentRecord.studentIdCode}
                </span>
              </div>

              <div className="flex justify-between items-center">
                <span className="text-neutral-400">Department:</span>
                <span className="text-neutral-700 dark:text-neutral-300">
                  {contactStudentRecord.department}
                </span>
              </div>

              <div className="flex justify-between items-center pt-2 border-t border-neutral-200/60 dark:border-neutral-700/60">
                <div>
                  <span className="text-[10px] text-neutral-400 block font-mono uppercase">Email Address</span>
                  <span className="font-mono font-medium text-neutral-800 dark:text-neutral-200">
                    {contactStudentRecord.studentEmail}
                  </span>
                </div>
                <button
                  onClick={() => copyToClipboard(contactStudentRecord.studentEmail, 'Email')}
                  className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg bg-neutral-200/70 dark:bg-neutral-700 text-neutral-800 dark:text-neutral-200 hover:bg-neutral-300 dark:hover:bg-neutral-600 transition-colors text-[11px] font-mono cursor-pointer"
                >
                  {copiedField === 'Email' ? <Check className="w-3.5 h-3.5 text-emerald-500" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>Copy Email</span>
                </button>
              </div>

              <div className="flex justify-between items-center pt-2 border-t border-neutral-200/60 dark:border-neutral-700/60">
                <div>
                  <span className="text-[10px] text-neutral-400 block font-mono uppercase">Phone Contact</span>
                  <span className="font-mono font-medium text-neutral-800 dark:text-neutral-200">
                    {contactStudentRecord.studentPhone}
                  </span>
                </div>
                <button
                  onClick={() => copyToClipboard(contactStudentRecord.studentPhone, 'Phone')}
                  className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg bg-neutral-200/70 dark:bg-neutral-700 text-neutral-800 dark:text-neutral-200 hover:bg-neutral-300 dark:hover:bg-neutral-600 transition-colors text-[11px] font-mono cursor-pointer"
                >
                  {copiedField === 'Phone' ? <Check className="w-3.5 h-3.5 text-emerald-500" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>Copy Phone</span>
                </button>
              </div>
            </div>

            <div className="flex justify-end pt-2">
              <Button variant="outline" size="sm" onClick={() => setContactStudentRecord(null)}>
                Close
              </Button>
            </div>
          </div>
        )}
      </Modal>

      {/* View Loan Details Modal */}
      <Modal
        isOpen={Boolean(selectedRecord)}
        onClose={() => setSelectedRecord(null)}
        title="Borrowing Loan Specification"
        description="Audited loan ledger item"
      >
        {selectedRecord && (
          <div className="space-y-4 text-xs">
            <div className="p-4 rounded-2xl bg-neutral-50 dark:bg-neutral-800/60 border border-neutral-200/80 dark:border-neutral-700/80 space-y-2.5 font-mono">
              <div className="flex justify-between">
                <span className="text-neutral-400">Loan ID:</span>
                <span className="font-bold text-neutral-900 dark:text-neutral-100">{selectedRecord.id}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-neutral-400">Book Title:</span>
                <span className="font-semibold text-right">{selectedRecord.title}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-neutral-400">Borrower:</span>
                <span>{selectedRecord.studentName} ({selectedRecord.studentIdCode})</span>
              </div>
              <div className="flex justify-between">
                <span className="text-neutral-400">Borrowed Date:</span>
                <span>{format(new Date(selectedRecord.borrowDate), 'MMM dd, yyyy')}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-neutral-400">Due Date:</span>
                <span className="font-bold">{format(new Date(selectedRecord.dueDate), 'MMM dd, yyyy')}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-neutral-400">Loan Status:</span>
                <span>{selectedRecord.status}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-neutral-400">Fine Balance:</span>
                <span className="font-bold text-rose-600">₹{selectedRecord.fineAmount || 0}</span>
              </div>
            </div>

            <div className="flex justify-end pt-2">
              <Button variant="primary" size="sm" onClick={() => setSelectedRecord(null)}>
                Done
              </Button>
            </div>
          </div>
        )}
      </Modal>

      {/* Adjust Fine Modal */}
      <Modal
        isOpen={Boolean(fineModalRecord)}
        onClose={() => setFineModalRecord(null)}
        title="Adjust Overdue Fine"
        description={`Set fine amount for ${fineModalRecord?.studentName}`}
      >
        <form onSubmit={handleSaveFine} className="space-y-4">
          <div>
            <label className="block text-xs font-semibold text-neutral-700 dark:text-neutral-300 mb-1.5">
              Fine Assessment (₹)
            </label>
            <input
              type="number"
              step="1"
              min="0"
              value={fineAdjustment}
              onChange={(e) => setFineAdjustment(e.target.value)}
              className="w-full h-10 rounded-xl border border-neutral-300 bg-white px-3 text-xs text-neutral-900 focus:outline-none focus:ring-2 focus:ring-neutral-900 dark:border-neutral-700 dark:bg-neutral-800 dark:text-neutral-100 font-mono"
            />
          </div>

          <div className="flex items-center justify-end gap-3 pt-3 border-t border-neutral-100 dark:border-neutral-800">
            <Button variant="outline" size="sm" onClick={() => setFineModalRecord(null)}>
              Cancel
            </Button>
            <Button type="submit" variant="primary" size="sm">
              Save Fine
            </Button>
          </div>
        </form>
      </Modal>

      {/* Issue Book Modal */}
      <Modal
        isOpen={isIssueModalOpen}
        onClose={() => setIsIssueModalOpen(false)}
        title="Issue New Book Loan"
        description="Check out a physical volume from the stacks to an enrolled student."
      >
        <form onSubmit={handleIssueBook} className="space-y-4">
          <div>
            <label className="block text-xs font-semibold text-neutral-700 dark:text-neutral-300 mb-1.5">
              Select Book Volume
            </label>
            <select
              value={issueBookId}
              onChange={(e) => setIssueBookId(e.target.value)}
              className="w-full h-10 rounded-xl border border-neutral-300 bg-white px-3 text-xs text-neutral-900 focus:outline-none focus:ring-2 focus:ring-neutral-900 dark:border-neutral-700 dark:bg-neutral-800 dark:text-neutral-100"
            >
              {initialBooks.map((b) => (
                <option key={b.id} value={b.id}>
                  [{b.bookNumber}] {b.title} — {b.author}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-xs font-semibold text-neutral-700 dark:text-neutral-300 mb-1.5">
              Select Student Patron
            </label>
            <select
              value={issueStudentId}
              onChange={(e) => setIssueStudentId(e.target.value)}
              className="w-full h-10 rounded-xl border border-neutral-300 bg-white px-3 text-xs text-neutral-900 focus:outline-none focus:ring-2 focus:ring-neutral-900 dark:border-neutral-700 dark:bg-neutral-800 dark:text-neutral-100"
            >
              {initialUsers
                .filter((u) => u.role === 'student')
                .map((s) => (
                  <option key={s.id} value={s.id}>
                    {s.name} ({s.studentId}) — {s.department}
                  </option>
                ))}
            </select>
          </div>

          <div>
            <label className="block text-xs font-semibold text-neutral-700 dark:text-neutral-300 mb-1.5">
              Loan Duration (Days)
            </label>
            <select
              value={loanDays}
              onChange={(e) => setLoanDays(e.target.value)}
              className="w-full h-10 rounded-xl border border-neutral-300 bg-white px-3 text-xs text-neutral-900 focus:outline-none focus:ring-2 focus:ring-neutral-900 dark:border-neutral-700 dark:bg-neutral-800 dark:text-neutral-100 font-mono"
            >
              <option value={7}>7 Days</option>
              <option value={14}>14 Days (Standard)</option>
              <option value={28}>28 Days (Research)</option>
            </select>
          </div>

          <div className="flex items-center justify-end gap-3 pt-3 border-t border-neutral-100 dark:border-neutral-800">
            <Button variant="outline" size="sm" onClick={() => setIsIssueModalOpen(false)}>
              Cancel
            </Button>
            <Button type="submit" variant="primary" size="sm">
              Authorize Loan
            </Button>
          </div>
        </form>
      </Modal>
    </div>
  );
};

export default LibrarianBorrowingsPage;
