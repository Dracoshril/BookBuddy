import React, { useState } from 'react';
import { initialBorrowings } from '../../data/borrowings';
import { initialBooks } from '../../data/books';
import { initialUsers } from '../../data/users';
import { Button } from '../../components/common/Button';
import { Input } from '../../components/common/Input';
import { Modal } from '../../components/common/Modal';
import {
  ArrowDownLeft,
  ArrowUpRight,
  RotateCcw,
  Search,
  CheckCircle2,
  AlertTriangle,
  Clock,
  User,
  Phone,
  Mail,
  BookOpen,
  Calendar,
  DollarSign,
  Building2,
  FileCheck,
  Shield,
  Layers,
  History,
  Copy,
  Check,
} from 'lucide-react';
import { format, differenceInDays, addDays } from 'date-fns';
import { toast } from 'sonner';

export const CirculationDeskPage = () => {
  const [activeTab, setActiveTab] = useState('RETURN'); // 'RETURN' | 'ISSUE' | 'RENEW' | 'HISTORY'
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedLoanId, setSelectedLoanId] = useState('bor-3'); // default CLRS Algorithms for Vishal
  const [copiedField, setCopiedField] = useState(null);

  // Check-In Confirmation Modal
  const [isCheckInModalOpen, setIsCheckInModalOpen] = useState(false);
  const [checkInCondition, setCheckInCondition] = useState('EXCELLENT');

  // Issue Book Form State
  const [issueBookId, setIssueBookId] = useState(initialBooks[0].id);
  const [issueStudentId, setIssueStudentId] = useState('student-1');
  const [issueDurationDays, setIssueDurationDays] = useState(14);
  const [issueNotes, setIssueNotes] = useState('');

  // Loans State enriched with student & book contact details
  const [loans, setLoans] = useState(() => {
    return initialBorrowings.map((b) => {
      const student =
        initialUsers.find((u) => u.id === b.userId || (b.userId === 'user-1' && u.id === 'student-1')) ||
        initialUsers[0];
      const book = initialBooks.find((bk) => String(bk.id) === String(b.bookId)) || initialBooks[0];

      return {
        ...b,
        studentName: student.name,
        studentId: student.studentId || 'CS2023-8891',
        department: student.department || 'Computer Science & Engineering',
        email: student.email || 'vishal.g@university.edu',
        phone: student.phone || '+91 98765 43210',
        isbn: book.isbn || '978-0132350884',
        rackNo: book.rackNo || 'CS-A4',
        shelfNo: book.shelfNo || 'Shelf 2',
        returnedBy: b.status === 'RETURNED' ? 'Sarah Jenkins (Librarian)' : null,
        previousDueDate: b.status === 'RETURNED' ? b.dueDate : null,
        actualReturnDate: b.status === 'RETURNED' ? b.returnDate : null,
      };
    });
  });

  const now = new Date();

  // Search filter across Book Title, ISBN, Book ID, Student Name, Student ID, Email, Phone Number, Loan ID
  const filteredActiveLoans = loans.filter((l) => {
    if (l.status === 'RETURNED') return false;
    if (!searchQuery.trim()) return true;
    const q = searchQuery.toLowerCase().trim();
    return (
      l.title?.toLowerCase().includes(q) ||
      l.author?.toLowerCase().includes(q) ||
      l.isbn?.toLowerCase().includes(q) ||
      l.bookNumber?.toLowerCase().includes(q) ||
      String(l.bookId).toLowerCase().includes(q) ||
      l.studentName?.toLowerCase().includes(q) ||
      l.studentId?.toLowerCase().includes(q) ||
      l.email?.toLowerCase().includes(q) ||
      l.phone?.toLowerCase().includes(q) ||
      l.id?.toLowerCase().includes(q)
    );
  });

  const historyLoans = loans.filter((l) => l.status === 'RETURNED');

  const selectedLoan =
    loans.find((l) => l.id === selectedLoanId) ||
    filteredActiveLoans[0] ||
    loans[0];

  // Calculate overdue details for selected loan
  const daysOverdue = selectedLoan
    ? Math.max(0, differenceInDays(now, new Date(selectedLoan.dueDate)))
    : 0;
  const fineAmount = daysOverdue > 0 ? daysOverdue * 5 : 0; // ₹5 per day

  const copyToClipboard = (text, fieldName) => {
    navigator.clipboard.writeText(text);
    setCopiedField(fieldName);
    toast.success(`Copied ${fieldName} to clipboard`);
    setTimeout(() => setCopiedField(null), 2000);
  };

  // Check In Handler
  const handleConfirmCheckIn = () => {
    if (!selectedLoan) return;

    const returnTimestamp = new Date().toISOString();

    setLoans((prev) =>
      prev.map((l) => {
        if (l.id === selectedLoan.id) {
          return {
            ...l,
            status: 'RETURNED',
            returnDate: returnTimestamp,
            actualReturnDate: returnTimestamp,
            previousDueDate: l.dueDate,
            returnedBy: 'Sarah Jenkins (Chief Librarian)',
            fineAmount: fineAmount,
            condition: checkInCondition,
          };
        }
        return l;
      })
    );

    setIsCheckInModalOpen(false);
    toast.success(`Book "${selectedLoan.title}" checked in successfully. Available copies restored.`);
  };

  // Issue Book Handler
  const handleIssueBookSubmit = (e) => {
    e.preventDefault();
    const book = initialBooks.find((b) => String(b.id) === String(issueBookId)) || initialBooks[0];
    const student = initialUsers.find((u) => u.id === issueStudentId) || initialUsers[0];

    const newLoan = {
      id: `bor-${Date.now()}`,
      userId: student.id,
      bookId: String(book.id),
      bookNumber: book.bookNumber,
      title: book.title,
      author: book.author,
      category: book.category,
      studentName: student.name,
      studentId: student.studentId,
      department: student.department,
      email: student.email,
      phone: student.phone || '+91 98765 43210',
      isbn: book.isbn,
      rackNo: book.rackNo,
      shelfNo: book.shelfNo,
      borrowDate: now.toISOString(),
      dueDate: addDays(now, Number(issueDurationDays)).toISOString(),
      returnDate: null,
      status: 'CURRENT',
      renewalCount: 0,
      fineAmount: 0,
      notes: issueNotes,
    };

    setLoans([newLoan, ...loans]);
    setSelectedLoanId(newLoan.id);
    toast.success(`Successfully issued "${book.title}" to ${student.name}!`);
    setActiveTab('RETURN');
    setIssueNotes('');
  };

  // Renew Loan Handler
  const handleRenewLoan = (loanId) => {
    const loan = loans.find((l) => l.id === loanId);
    if (!loan) return;

    if ((loan.renewalCount || 0) >= 2) {
      toast.error('Maximum renewal quota reached (2 renewals allowed).');
      return;
    }

    setLoans((prev) =>
      prev.map((l) => {
        if (l.id === loanId) {
          const newDueDate = addDays(new Date(l.dueDate), 14).toISOString();
          return {
            ...l,
            dueDate: newDueDate,
            renewalCount: (l.renewalCount || 0) + 1,
            status: 'CURRENT',
          };
        }
        return l;
      })
    );

    toast.success(`Renewed loan for "${loan.title}". Due date extended by 14 days.`);
  };

  return (
    <div className="space-y-6 max-w-7xl mx-auto">
      {/* Page Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="p-1.5 rounded-lg bg-emerald-50 text-emerald-700 dark:bg-emerald-500/10 dark:text-emerald-400">
              <Layers className="w-5 h-5" />
            </span>
            <h1 className="text-2xl sm:text-3xl font-bold tracking-tight text-neutral-900 dark:text-neutral-100">
              Circulation Desk
            </h1>
          </div>
          <p className="text-xs sm:text-sm text-neutral-500 dark:text-neutral-400 mt-1">
            Central circulation console for issuing books, processing returns, managing student check-ins, and inspecting loan condition.
          </p>
        </div>

        {/* Tab Switcher */}
        <div className="flex items-center gap-1.5 p-1 bg-neutral-100 dark:bg-neutral-800 rounded-xl text-xs font-semibold">
          <button
            onClick={() => setActiveTab('RETURN')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg transition-colors cursor-pointer ${
              activeTab === 'RETURN'
                ? 'bg-white text-neutral-900 shadow-xs dark:bg-neutral-900 dark:text-white'
                : 'text-neutral-500 hover:text-neutral-900 dark:hover:text-white'
            }`}
          >
            <ArrowDownLeft className="w-3.5 h-3.5 text-emerald-500" />
            <span>Return & Check-In</span>
          </button>

          <button
            onClick={() => setActiveTab('ISSUE')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg transition-colors cursor-pointer ${
              activeTab === 'ISSUE'
                ? 'bg-white text-neutral-900 shadow-xs dark:bg-neutral-900 dark:text-white'
                : 'text-neutral-500 hover:text-neutral-900 dark:hover:text-white'
            }`}
          >
            <ArrowUpRight className="w-3.5 h-3.5 text-blue-500" />
            <span>Issue Book</span>
          </button>

          <button
            onClick={() => setActiveTab('HISTORY')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg transition-colors cursor-pointer ${
              activeTab === 'HISTORY'
                ? 'bg-white text-neutral-900 shadow-xs dark:bg-neutral-900 dark:text-white'
                : 'text-neutral-500 hover:text-neutral-900 dark:hover:text-white'
            }`}
          >
            <History className="w-3.5 h-3.5 text-amber-500" />
            <span>Returned Archive ({historyLoans.length})</span>
          </button>
        </div>
      </div>

      {/* Circulation Metric Quick Bar */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        <div className="p-4 rounded-2xl border border-neutral-200/80 bg-white dark:border-neutral-800 dark:bg-neutral-900 shadow-xs">
          <span className="text-[11px] font-mono text-neutral-500 uppercase">Active Outgoing Loans</span>
          <p className="text-2xl font-bold font-mono text-neutral-900 dark:text-neutral-100 mt-1">
            {filteredActiveLoans.length}
          </p>
        </div>
        <div className="p-4 rounded-2xl border border-neutral-200/80 bg-white dark:border-neutral-800 dark:bg-neutral-900 shadow-xs">
          <span className="text-[11px] font-mono text-neutral-500 uppercase">Overdue Items</span>
          <p className="text-2xl font-bold font-mono text-rose-600 dark:text-rose-400 mt-1">
            {filteredActiveLoans.filter((l) => l.status === 'OVERDUE' || differenceInDays(now, new Date(l.dueDate)) > 0).length}
          </p>
        </div>
        <div className="p-4 rounded-2xl border border-neutral-200/80 bg-white dark:border-neutral-800 dark:bg-neutral-900 shadow-xs">
          <span className="text-[11px] font-mono text-neutral-500 uppercase">Due Today / Soon</span>
          <p className="text-2xl font-bold font-mono text-amber-600 dark:text-amber-400 mt-1">
            {filteredActiveLoans.filter((l) => l.status === 'DUE_SOON').length}
          </p>
        </div>
        <div className="p-4 rounded-2xl border border-neutral-200/80 bg-white dark:border-neutral-800 dark:bg-neutral-900 shadow-xs">
          <span className="text-[11px] font-mono text-neutral-500 uppercase">Returned to Stacks</span>
          <p className="text-2xl font-bold font-mono text-emerald-600 dark:text-emerald-400 mt-1">
            {historyLoans.length}
          </p>
        </div>
      </div>

      {/* Main Tab Content */}
      {activeTab === 'RETURN' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* Left Column: Search & Loan Selector (5 cols) */}
          <div className="lg:col-span-5 space-y-4">
            <div className="p-4 rounded-2xl border border-neutral-200/80 bg-white dark:border-neutral-800 dark:bg-neutral-900 shadow-xs space-y-3">
              <label className="block text-xs font-semibold text-neutral-700 dark:text-neutral-300">
                Find Loan Record to Return
              </label>
              <div className="relative">
                <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-neutral-400" />
                <input
                  type="text"
                  placeholder="Search by Title, ISBN, Student Name, Student ID, Email, Phone, or Loan ID..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full h-10 pl-9 pr-3 rounded-xl border border-neutral-300 bg-white dark:border-neutral-700 dark:bg-neutral-800 text-xs text-neutral-900 dark:text-neutral-100 placeholder:text-neutral-400 focus:outline-none focus:ring-2 focus:ring-emerald-500"
                />
              </div>
              <p className="text-[10px] text-neutral-400">
                Found {filteredActiveLoans.length} active physical loans eligible for check-in.
              </p>
            </div>

            {/* Loans List */}
            <div className="space-y-2.5 max-h-[560px] overflow-y-auto pr-1">
              {filteredActiveLoans.length > 0 ? (
                filteredActiveLoans.map((loan) => {
                  const isOverdue =
                    loan.status === 'OVERDUE' || differenceInDays(now, new Date(loan.dueDate)) > 0;
                  const isSelected = selectedLoan?.id === loan.id;

                  return (
                    <div
                      key={loan.id}
                      onClick={() => setSelectedLoanId(loan.id)}
                      className={`p-4 rounded-2xl border transition-all cursor-pointer ${
                        isSelected
                          ? 'border-emerald-500 bg-emerald-50/50 dark:bg-emerald-950/20 shadow-xs'
                          : 'border-neutral-200/80 bg-white hover:border-neutral-300 dark:border-neutral-800 dark:bg-neutral-900 dark:hover:border-neutral-700'
                      }`}
                    >
                      <div className="flex items-start justify-between gap-2">
                        <div className="space-y-1 min-w-0">
                          <h4 className="font-semibold text-xs sm:text-sm text-neutral-900 dark:text-neutral-100 truncate">
                            {loan.title}
                          </h4>
                          <p className="text-[11px] text-neutral-500 truncate">
                            Student: <span className="font-medium text-neutral-700 dark:text-neutral-300">{loan.studentName}</span> ({loan.studentId})
                          </p>
                        </div>
                        <span
                          className={`px-2 py-0.5 rounded text-[10px] font-mono font-bold shrink-0 ${
                            isOverdue
                              ? 'bg-rose-50 text-rose-700 border border-rose-200 dark:bg-rose-950/60 dark:text-rose-400 dark:border-rose-900'
                              : loan.status === 'DUE_SOON'
                              ? 'bg-amber-50 text-amber-700 border border-amber-200 dark:bg-amber-950/60 dark:text-amber-400 dark:border-amber-900'
                              : 'bg-sky-50 text-sky-700 border border-sky-200 dark:bg-sky-950/60 dark:text-sky-400 dark:border-sky-900'
                          }`}
                        >
                          {isOverdue ? 'OVERDUE' : loan.status}
                        </span>
                      </div>

                      <div className="flex items-center justify-between text-[10px] font-mono text-neutral-400 mt-2.5 pt-2 border-t border-neutral-100 dark:border-neutral-800">
                        <span>Due: {format(new Date(loan.dueDate), 'MMM dd, yyyy')}</span>
                        <span>Loan ID: {loan.id}</span>
                      </div>
                    </div>
                  );
                })
              ) : (
                <div className="p-8 text-center rounded-2xl border border-dashed border-neutral-200 dark:border-neutral-800 text-xs text-neutral-500">
                  No active loans found matching "{searchQuery}".
                </div>
              )}
            </div>
          </div>

          {/* Right Column: Selected Return Loan Full Details (7 cols) */}
          <div className="lg:col-span-7">
            {selectedLoan ? (
              <div className="p-6 sm:p-8 rounded-3xl border border-neutral-200/80 bg-white dark:border-neutral-800 dark:bg-neutral-900 shadow-xs space-y-6">
                {/* Header */}
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-neutral-100 dark:border-neutral-800">
                  <div>
                    <span className="text-[10px] font-mono font-bold uppercase tracking-wider text-emerald-600 dark:text-emerald-400">
                      Circulation Return Inspection
                    </span>
                    <h2 className="text-xl font-bold text-neutral-900 dark:text-neutral-100 mt-0.5">
                      {selectedLoan.title}
                    </h2>
                    <p className="text-xs text-neutral-500">By {selectedLoan.author} · {selectedLoan.category}</p>
                  </div>

                  <span
                    className={`px-3 py-1 rounded-full text-xs font-mono font-bold w-fit ${
                      daysOverdue > 0
                        ? 'bg-rose-50 text-rose-700 border border-rose-200 dark:bg-rose-950/60 dark:text-rose-400 dark:border-rose-900'
                        : 'bg-emerald-50 text-emerald-700 border border-emerald-200 dark:bg-emerald-950/60 dark:text-emerald-400 dark:border-emerald-900'
                    }`}
                  >
                    {daysOverdue > 0 ? `OVERDUE (${daysOverdue} DAYS)` : 'ACTIVE ON LOAN'}
                  </span>
                </div>

                {/* Section 1: Complete Student Information (Req 34, 35) */}
                <div className="space-y-3">
                  <h3 className="text-xs font-mono font-bold uppercase tracking-wider text-neutral-400 flex items-center gap-1.5">
                    <User className="w-3.5 h-3.5" />
                    <span>Registered Student Borrower Information</span>
                  </h3>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 p-4 rounded-2xl bg-neutral-50 dark:bg-neutral-800/50 border border-neutral-200/60 dark:border-neutral-700/60 text-xs">
                    <div>
                      <span className="text-[10px] font-mono text-neutral-400 block uppercase">Student Full Name</span>
                      <span className="font-semibold text-neutral-900 dark:text-neutral-100">{selectedLoan.studentName}</span>
                    </div>

                    <div>
                      <span className="text-[10px] font-mono text-neutral-400 block uppercase">Student ID Code</span>
                      <span className="font-mono font-semibold text-neutral-900 dark:text-neutral-100">{selectedLoan.studentId}</span>
                    </div>

                    <div>
                      <span className="text-[10px] font-mono text-neutral-400 block uppercase">Academic Department</span>
                      <span className="text-neutral-700 dark:text-neutral-300 flex items-center gap-1">
                        <Building2 className="w-3 h-3 text-neutral-400" />
                        {selectedLoan.department}
                      </span>
                    </div>

                    <div>
                      <span className="text-[10px] font-mono text-neutral-400 block uppercase">Institutional Email</span>
                      <div className="flex items-center gap-1.5 text-neutral-700 dark:text-neutral-300">
                        <Mail className="w-3 h-3 text-neutral-400" />
                        <span className="truncate">{selectedLoan.email}</span>
                        <button
                          onClick={() => copyToClipboard(selectedLoan.email, 'Email')}
                          className="p-1 text-neutral-400 hover:text-neutral-900 dark:hover:text-white cursor-pointer"
                          title="Copy Email"
                        >
                          {copiedField === 'Email' ? <Check className="w-3 h-3 text-emerald-500" /> : <Copy className="w-3 h-3" />}
                        </button>
                      </div>
                    </div>

                    <div className="sm:col-span-2 pt-1 border-t border-neutral-200/40 dark:border-neutral-700/40 flex items-center justify-between">
                      <div>
                        <span className="text-[10px] font-mono text-neutral-400 block uppercase">Contact Phone Number</span>
                        <span className="font-mono font-medium text-neutral-800 dark:text-neutral-200 flex items-center gap-1.5">
                          <Phone className="w-3 h-3 text-neutral-400" />
                          {selectedLoan.phone}
                        </span>
                      </div>
                      <button
                        onClick={() => copyToClipboard(selectedLoan.phone, 'Phone')}
                        className="inline-flex items-center gap-1 px-2 py-1 rounded bg-neutral-200/60 dark:bg-neutral-700/60 text-[11px] font-mono text-neutral-700 dark:text-neutral-200 hover:bg-neutral-300 dark:hover:bg-neutral-600 transition-colors cursor-pointer"
                      >
                        {copiedField === 'Phone' ? <Check className="w-3 h-3 text-emerald-500" /> : <Copy className="w-3 h-3" />}
                        <span>Copy Phone</span>
                      </button>
                    </div>
                  </div>
                </div>

                {/* Section 2: Book & Physical Shelf Details */}
                <div className="space-y-3">
                  <h3 className="text-xs font-mono font-bold uppercase tracking-wider text-neutral-400 flex items-center gap-1.5">
                    <BookOpen className="w-3.5 h-3.5" />
                    <span>Physical Book & Catalog Record</span>
                  </h3>

                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 p-4 rounded-2xl bg-neutral-50 dark:bg-neutral-800/50 border border-neutral-200/60 dark:border-neutral-700/60 text-xs font-mono">
                    <div>
                      <span className="text-[10px] text-neutral-400 block uppercase">Barcode / ID</span>
                      <span className="font-semibold text-neutral-900 dark:text-neutral-100">{selectedLoan.bookNumber}</span>
                    </div>
                    <div>
                      <span className="text-[10px] text-neutral-400 block uppercase">ISBN-13</span>
                      <span className="text-neutral-700 dark:text-neutral-300">{selectedLoan.isbn}</span>
                    </div>
                    <div>
                      <span className="text-[10px] text-neutral-400 block uppercase">Stack Location</span>
                      <span className="text-neutral-700 dark:text-neutral-300">{selectedLoan.rackNo} · {selectedLoan.shelfNo}</span>
                    </div>
                    <div>
                      <span className="text-[10px] text-neutral-400 block uppercase">Renewals Used</span>
                      <span className="text-neutral-700 dark:text-neutral-300">{selectedLoan.renewalCount || 0} / 2</span>
                    </div>
                  </div>
                </div>

                {/* Section 3: Loan Timeline & Overdue Fine Assessment */}
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 p-4 rounded-2xl bg-neutral-50 dark:bg-neutral-800/50 border border-neutral-200/60 dark:border-neutral-700/60 font-mono text-xs">
                  <div>
                    <span className="text-[10px] text-neutral-400 uppercase block">Borrowed Date</span>
                    <span className="font-semibold text-neutral-900 dark:text-neutral-100">
                      {format(new Date(selectedLoan.borrowDate), 'MMM dd, yyyy')}
                    </span>
                  </div>
                  <div>
                    <span className="text-[10px] text-neutral-400 uppercase block">Due Date</span>
                    <span className={`font-semibold ${daysOverdue > 0 ? 'text-rose-600 dark:text-rose-400' : 'text-neutral-900 dark:text-neutral-100'}`}>
                      {format(new Date(selectedLoan.dueDate), 'MMM dd, yyyy')}
                    </span>
                  </div>
                  <div>
                    <span className="text-[10px] text-neutral-400 uppercase block">Return Date</span>
                    <span className="font-semibold text-emerald-600 dark:text-emerald-400">
                      {format(now, 'MMM dd, yyyy')}
                    </span>
                  </div>
                  <div>
                    <span className="text-[10px] text-neutral-400 uppercase block">Overdue Fine</span>
                    <span className={`font-bold ${daysOverdue > 0 ? 'text-rose-600 dark:text-rose-400' : 'text-emerald-600 dark:text-emerald-400'}`}>
                      {daysOverdue > 0 ? `₹${fineAmount}` : '₹0.00'}
                    </span>
                  </div>
                </div>

                {/* Check In Action Bar */}
                <div className="flex flex-col sm:flex-row items-center gap-3 pt-2">
                  <Button
                    variant="primary"
                    size="md"
                    className="w-full sm:flex-1 bg-emerald-600 hover:bg-emerald-700 text-white"
                    leftIcon={<CheckCircle2 className="w-4 h-4" />}
                    onClick={() => setIsCheckInModalOpen(true)}
                  >
                    Check In Book & Restore Stock
                  </Button>

                  <Button
                    variant="outline"
                    size="md"
                    className="w-full sm:w-auto"
                    leftIcon={<RotateCcw className="w-4 h-4" />}
                    onClick={() => handleRenewLoan(selectedLoan.id)}
                    disabled={(selectedLoan.renewalCount || 0) >= 2}
                  >
                    Extend Loan (+14d)
                  </Button>
                </div>
              </div>
            ) : (
              <div className="p-12 rounded-3xl border border-neutral-200 dark:border-neutral-800 bg-white dark:bg-neutral-900 text-center text-xs text-neutral-500">
                Select an active borrowing record from the left column to view student details and process return.
              </div>
            )}
          </div>
        </div>
      )}

      {/* Tab: Issue Book */}
      {activeTab === 'ISSUE' && (
        <div className="max-w-2xl mx-auto p-6 sm:p-8 rounded-3xl border border-neutral-200/80 bg-white dark:border-neutral-800 dark:bg-neutral-900 shadow-xs space-y-6">
          <div className="space-y-1">
            <h2 className="text-xl font-bold text-neutral-900 dark:text-neutral-100">
              Issue Book to Student Borrower
            </h2>
            <p className="text-xs text-neutral-500">
              Register an outgoing physical volume from library stacks and allocate to student account.
            </p>
          </div>

          <form onSubmit={handleIssueBookSubmit} className="space-y-4">
            <div>
              <label className="block text-xs font-semibold text-neutral-700 dark:text-neutral-300 mb-1.5">
                Select Volume from Catalog
              </label>
              <select
                value={issueBookId}
                onChange={(e) => setIssueBookId(e.target.value)}
                className="w-full h-10 rounded-xl border border-neutral-300 bg-white px-3 text-xs text-neutral-900 focus:outline-none focus:ring-2 focus:ring-emerald-500 dark:border-neutral-700 dark:bg-neutral-800 dark:text-neutral-100"
              >
                {initialBooks.map((b) => (
                  <option key={b.id} value={b.id}>
                    [{b.bookNumber}] {b.title} — {b.author} ({b.availableCopies} available)
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-neutral-700 dark:text-neutral-300 mb-1.5">
                Student Reader Account
              </label>
              <select
                value={issueStudentId}
                onChange={(e) => setIssueStudentId(e.target.value)}
                className="w-full h-10 rounded-xl border border-neutral-300 bg-white px-3 text-xs text-neutral-900 focus:outline-none focus:ring-2 focus:ring-emerald-500 dark:border-neutral-700 dark:bg-neutral-800 dark:text-neutral-100"
              >
                {initialUsers
                  .filter((u) => u.role === 'student')
                  .map((s) => (
                    <option key={s.id} value={s.id}>
                      {s.name} ({s.studentId}) — {s.department}
                    </option>
                  ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-neutral-700 dark:text-neutral-300 mb-1.5">
                Standard Loan Duration
              </label>
              <select
                value={issueDurationDays}
                onChange={(e) => setIssueDurationDays(Number(e.target.value))}
                className="w-full h-10 rounded-xl border border-neutral-300 bg-white px-3 text-xs text-neutral-900 focus:outline-none focus:ring-2 focus:ring-emerald-500 dark:border-neutral-700 dark:bg-neutral-800 dark:text-neutral-100 font-mono"
              >
                <option value={7}>7 Calendar Days (Accelerated Coursework)</option>
                <option value={14}>14 Calendar Days (Standard Student Loan)</option>
                <option value={28}>28 Calendar Days (Extended Semester Research)</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-neutral-700 dark:text-neutral-300 mb-1.5">
                Circulation Notes (Optional)
              </label>
              <textarea
                rows={2}
                placeholder="Special permissions, lab reserve, barcode condition notes..."
                value={issueNotes}
                onChange={(e) => setIssueNotes(e.target.value)}
                className="w-full rounded-xl border border-neutral-300 bg-white p-3 text-xs text-neutral-900 focus:outline-none focus:ring-2 focus:ring-emerald-500 dark:border-neutral-700 dark:bg-neutral-800 dark:text-neutral-100"
              />
            </div>

            <div className="pt-2">
              <Button type="submit" variant="primary" size="md" className="w-full" leftIcon={<ArrowUpRight className="w-4 h-4" />}>
                Authorize Loan & Issue Physical Copy
              </Button>
            </div>
          </form>
        </div>
      )}

      {/* Tab: Returned Archive History (Requirement 37) */}
      {activeTab === 'HISTORY' && (
        <div className="space-y-4">
          <div className="p-4 rounded-2xl border border-neutral-200/80 bg-white dark:border-neutral-800 dark:bg-neutral-900 shadow-xs flex items-center justify-between">
            <div className="flex items-center gap-2">
              <FileCheck className="w-4 h-4 text-emerald-500" />
              <span className="text-xs font-bold text-neutral-900 dark:text-neutral-100">
                Preserved Historical Check-In Archive
              </span>
            </div>
            <span className="text-xs font-mono text-neutral-500">
              {historyLoans.length} Historical Records Retained
            </span>
          </div>

          <div className="rounded-2xl border border-neutral-200/80 bg-white dark:border-neutral-800 dark:bg-neutral-900 overflow-hidden shadow-xs">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-neutral-50 dark:bg-neutral-800/60 border-b border-neutral-200 dark:border-neutral-800 text-[10px] font-mono uppercase text-neutral-500">
                  <tr>
                    <th className="px-4 py-3">Book Title</th>
                    <th className="px-4 py-3">Student Borrower</th>
                    <th className="px-4 py-3">Previous Due</th>
                    <th className="px-4 py-3">Actual Return Date</th>
                    <th className="px-4 py-3">Checked-in By</th>
                    <th className="px-4 py-3">Settled Fine</th>
                    <th className="px-4 py-3">Status</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-neutral-100 dark:divide-neutral-800">
                  {historyLoans.map((h) => (
                    <tr key={h.id} className="hover:bg-neutral-50/50 dark:hover:bg-neutral-800/30">
                      <td className="px-4 py-3 font-semibold text-neutral-900 dark:text-neutral-100">
                        {h.title}
                      </td>
                      <td className="px-4 py-3 text-neutral-600 dark:text-neutral-300">
                        {h.studentName} ({h.studentId})
                      </td>
                      <td className="px-4 py-3 font-mono text-neutral-500">
                        {h.previousDueDate ? format(new Date(h.previousDueDate), 'MMM dd, yyyy') : '—'}
                      </td>
                      <td className="px-4 py-3 font-mono text-emerald-600 dark:text-emerald-400 font-semibold">
                        {h.actualReturnDate ? format(new Date(h.actualReturnDate), 'MMM dd, yyyy') : format(now, 'MMM dd, yyyy')}
                      </td>
                      <td className="px-4 py-3 text-neutral-500">
                        {h.returnedBy || 'Sarah Jenkins (Librarian)'}
                      </td>
                      <td className="px-4 py-3 font-mono text-neutral-700 dark:text-neutral-300">
                        {h.fineAmount > 0 ? `₹${h.fineAmount}` : '₹0.00'}
                      </td>
                      <td className="px-4 py-3">
                        <span className="px-2 py-0.5 rounded text-[10px] font-mono font-semibold bg-emerald-50 text-emerald-700 dark:bg-emerald-950/60 dark:text-emerald-400 border border-emerald-200 dark:border-emerald-800">
                          RETURNED
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* Check In Confirmation Modal (Req 36) */}
      <Modal
        isOpen={isCheckInModalOpen}
        onClose={() => setIsCheckInModalOpen(false)}
        title="Check In Book?"
        description="Verify borrowing return details before restocking physical shelf inventory."
      >
        {selectedLoan && (
          <div className="space-y-4">
            <div className="p-4 rounded-2xl bg-neutral-50 dark:bg-neutral-800/60 border border-neutral-200/80 dark:border-neutral-700/80 space-y-2.5 text-xs font-mono">
              <div className="flex justify-between">
                <span className="text-neutral-400">Book:</span>
                <span className="font-semibold text-neutral-900 dark:text-neutral-100 text-right">
                  {selectedLoan.title}
                </span>
              </div>

              <div className="flex justify-between">
                <span className="text-neutral-400">Student:</span>
                <span className="font-semibold text-neutral-900 dark:text-neutral-100">
                  {selectedLoan.studentName} ({selectedLoan.studentId})
                </span>
              </div>

              <div className="flex justify-between">
                <span className="text-neutral-400">Due:</span>
                <span>{format(new Date(selectedLoan.dueDate), 'MMM dd, yyyy')}</span>
              </div>

              <div className="flex justify-between">
                <span className="text-neutral-400">Returned:</span>
                <span className="text-emerald-600 font-semibold">{format(now, 'MMM dd, yyyy')}</span>
              </div>

              <div className="flex justify-between">
                <span className="text-neutral-400">Overdue:</span>
                <span className={daysOverdue > 0 ? 'text-rose-600 font-bold' : 'text-neutral-500'}>
                  {daysOverdue > 0 ? `${daysOverdue} days` : '0 days (On Time)'}
                </span>
              </div>

              <div className="flex justify-between pt-2 border-t border-neutral-200/60 dark:border-neutral-700/60 text-sm">
                <span className="text-neutral-500 font-bold">Fine Assessment:</span>
                <span className={daysOverdue > 0 ? 'text-rose-600 font-bold' : 'text-emerald-600 font-bold'}>
                  {daysOverdue > 0 ? `₹${fineAmount}` : '₹0.00'}
                </span>
              </div>
            </div>

            {/* Condition check */}
            <div>
              <label className="block text-xs font-semibold text-neutral-700 dark:text-neutral-300 mb-1.5">
                Physical Copy Condition
              </label>
              <div className="grid grid-cols-3 gap-2 text-xs">
                {['EXCELLENT', 'GOOD', 'DAMAGED'].map((cond) => (
                  <button
                    key={cond}
                    type="button"
                    onClick={() => setCheckInCondition(cond)}
                    className={`py-2 rounded-lg border text-center font-medium transition-colors cursor-pointer ${
                      checkInCondition === cond
                        ? 'bg-neutral-900 text-white dark:bg-white dark:text-neutral-900 border-neutral-900 dark:border-white'
                        : 'border-neutral-200 dark:border-neutral-800 text-neutral-600 dark:text-neutral-400'
                    }`}
                  >
                    {cond}
                  </button>
                ))}
              </div>
            </div>

            <div className="flex items-center justify-end gap-3 pt-4 border-t border-neutral-100 dark:border-neutral-800">
              <Button variant="outline" size="sm" onClick={() => setIsCheckInModalOpen(false)}>
                Cancel
              </Button>
              <Button
                variant="primary"
                size="sm"
                className="bg-emerald-600 hover:bg-emerald-700 text-white"
                onClick={handleConfirmCheckIn}
              >
                Confirm Check-In
              </Button>
            </div>
          </div>
        )}
      </Modal>
    </div>
  );
};

export default CirculationDeskPage;
