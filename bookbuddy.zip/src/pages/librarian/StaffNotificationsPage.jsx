import React, { useState } from 'react';
import { Button } from '../../components/common/Button';
import {
  Bell,
  AlertTriangle,
  Clock,
  Boxes,
  CheckCircle2,
  Check,
  Send,
  ArrowRight,
} from 'lucide-react';
import { toast } from 'sonner';

export const StaffNotificationsPage = () => {
  const [alerts, setAlerts] = useState([
    {
      id: 'alert-1',
      type: 'OVERDUE_CRITICAL',
      title: 'Overdue Loan Notice: 14 Days Past Due',
      message: 'Patron Vishal Gayathri has not returned "Introduction to Algorithms" (BK-0003). Automated 2nd reminder was transmitted.',
      time: '12 minutes ago',
      actionLabel: 'Contact Patron',
      isRead: false,
    },
    {
      id: 'alert-2',
      type: 'HOLD_READY',
      title: 'Hold Shelf Ready for Patron Pickup',
      message: 'Returned copy of "Clean Architecture" has been transferred to Hold Shelf B for student pickup.',
      time: '1 hour ago',
      actionLabel: 'View Hold',
      isRead: false,
    },
    {
      id: 'alert-3',
      type: 'LOW_STOCK',
      title: 'Low Stock Alert: Artificial Intelligence',
      message: '"Hands-On Machine Learning" has only 1 copy remaining on Shelf Tier 1.',
      time: '3 hours ago',
      actionLabel: 'Reorder Copies',
      isRead: false,
    },
    {
      id: 'alert-4',
      type: 'SYSTEM',
      title: 'Nightly Database Backup & Index Synchronization',
      message: 'Circulation transactions reconciled with physical shelf RFID readers. 0 unindexed scans.',
      time: 'Yesterday',
      actionLabel: 'View Log',
      isRead: true,
    },
  ]);

  const handleMarkAll = () => {
    setAlerts((prev) => prev.map((a) => ({ ...a, isRead: true })));
    toast.success('All staff circulation notices marked as read.');
  };

  const handleAction = (alert) => {
    toast.success(`Action processed: ${alert.actionLabel}`);
  };

  return (
    <div className="space-y-6 max-w-4xl">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-bold tracking-tight text-neutral-900 dark:text-neutral-100">
            Circulation Desk Staff Notifications
          </h1>
          <p className="text-xs sm:text-sm text-neutral-500 dark:text-neutral-400 mt-1">
            Overdue patron alerts, hold shelf allocations, inventory re-order alerts, and system notices.
          </p>
        </div>

        <Button
          variant="outline"
          size="sm"
          leftIcon={<Check className="w-4 h-4" />}
          onClick={handleMarkAll}
        >
          Mark All Read
        </Button>
      </div>

      <div className="space-y-3">
        {alerts.map((alert) => (
          <div
            key={alert.id}
            className={`p-5 rounded-2xl border transition-all flex items-start justify-between gap-4 ${
              alert.isRead
                ? 'border-neutral-200/60 bg-white/60 dark:border-neutral-800 dark:bg-neutral-900/60 opacity-80'
                : 'border-emerald-500/30 bg-white dark:border-emerald-500/20 dark:bg-neutral-900 shadow-xs'
            }`}
          >
            <div className="flex items-start gap-3.5">
              <div className="w-9 h-9 rounded-xl bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 flex items-center justify-center shrink-0 mt-0.5">
                {alert.type === 'OVERDUE_CRITICAL' && <AlertTriangle className="w-4 h-4 text-rose-500" />}
                {alert.type === 'HOLD_READY' && <Clock className="w-4 h-4 text-amber-500" />}
                {alert.type === 'LOW_STOCK' && <Boxes className="w-4 h-4 text-sky-500" />}
                {alert.type === 'SYSTEM' && <CheckCircle2 className="w-4 h-4 text-emerald-500" />}
              </div>

              <div className="space-y-1">
                <div className="flex items-center gap-2">
                  <h4 className="font-bold text-sm text-neutral-900 dark:text-neutral-100">
                    {alert.title}
                  </h4>
                  {!alert.isRead && (
                    <span className="w-2 h-2 rounded-full bg-emerald-500" />
                  )}
                </div>
                <p className="text-xs text-neutral-600 dark:text-neutral-400 leading-relaxed">
                  {alert.message}
                </p>
                <span className="text-[11px] font-mono text-neutral-400 block pt-1">
                  {alert.time}
                </span>
              </div>
            </div>

            <div className="shrink-0">
              <Button
                variant="outline"
                size="sm"
                onClick={() => handleAction(alert)}
              >
                {alert.actionLabel}
              </Button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default StaffNotificationsPage;
