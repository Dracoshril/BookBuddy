import React, { useState } from 'react';
import { initialBooks } from '../../data/books';
import { Button } from '../../components/common/Button';
import { Input } from '../../components/common/Input';
import { Select } from '../../components/common/Select';
import {
  Boxes,
  Search,
  Filter,
  ArrowUpDown,
  AlertTriangle,
  CheckCircle2,
  BookOpen,
  ArrowUpRight,
  ShieldAlert,
  HelpCircle,
  ChevronLeft,
  ChevronRight,
} from 'lucide-react';
import { toast } from 'sonner';

export const LibrarianInventoryPage = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('ALL'); // 'ALL' | 'AVAILABLE' | 'LOW_STOCK' | 'ISSUED' | 'DAMAGED' | 'LOST'
  const [sortBy, setSortBy] = useState('title'); // 'title' | 'copies' | 'available'
  const [currentPage, setCurrentPage] = useState(1);
  const pageSize = 8;

  // Add mock damaged/lost tracking to books
  const inventoryList = initialBooks.map((b, idx) => ({
    ...b,
    damagedCopies: idx === 3 ? 1 : idx === 12 ? 2 : 0,
    lostCopies: idx === 5 ? 1 : 0,
    borrowedCopies: Math.max(0, b.totalCopies - b.availableCopies),
    isLowStock: b.availableCopies <= 1,
  }));

  // Overview metrics
  const totalBooks = inventoryList.length;
  const totalAvailableCopies = inventoryList.reduce((acc, b) => acc + b.availableCopies, 0);
  const totalBorrowedCopies = inventoryList.reduce((acc, b) => acc + b.borrowedCopies, 0);
  const totalDamagedBooks = inventoryList.reduce((acc, b) => acc + b.damagedCopies, 0);
  const totalLostBooks = inventoryList.reduce((acc, b) => acc + b.lostCopies, 0);
  const totalLowStockTitles = inventoryList.filter((b) => b.isLowStock).length;

  // Filtering
  const filtered = inventoryList.filter((b) => {
    const matchesSearch =
      b.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      b.bookNumber.toLowerCase().includes(searchTerm.toLowerCase()) ||
      b.author.toLowerCase().includes(searchTerm.toLowerCase()) ||
      b.isbn.includes(searchTerm);

    if (!matchesSearch) return false;

    if (statusFilter === 'LOW_STOCK') return b.isLowStock;
    if (statusFilter === 'AVAILABLE') return b.availableCopies > 0;
    if (statusFilter === 'DAMAGED') return b.damagedCopies > 0;
    if (statusFilter === 'LOST') return b.lostCopies > 0;
    if (statusFilter === 'ISSUED') return b.borrowedCopies > 0;
    return true;
  });

  // Sorting
  const sorted = [...filtered].sort((a, b) => {
    if (sortBy === 'title') return a.title.localeCompare(b.title);
    if (sortBy === 'copies') return b.totalCopies - a.totalCopies;
    if (sortBy === 'available') return b.availableCopies - a.availableCopies;
    return 0;
  });

  // Pagination
  const totalPages = Math.ceil(sorted.length / pageSize) || 1;
  const paginated = sorted.slice((currentPage - 1) * pageSize, currentPage * pageSize);

  const handleStockAction = (bookTitle, actionName) => {
    toast.success(`Action "${actionName}" performed for "${bookTitle}".`);
  };

  return (
    <div className="space-y-6">
      {/* Title */}
      <div>
        <h1 className="text-2xl sm:text-3xl font-bold tracking-tight text-neutral-900 dark:text-neutral-100">
          Library Physical Holdings & Inventory Audit
        </h1>
        <p className="text-xs sm:text-sm text-neutral-500 dark:text-neutral-400 mt-1">
          Complete stock reconciliations, copy availability breakdowns, low-stock triggers, and physical condition tracking.
        </p>
      </div>

      {/* KPI Cards Row */}
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3">
        <div className="p-4 rounded-xl border border-neutral-200/80 bg-white dark:border-neutral-800 dark:bg-neutral-900 shadow-xs space-y-1">
          <div className="flex items-center justify-between text-neutral-400 text-xs">
            <span>Total Titles</span>
            <BookOpen className="w-4 h-4 text-sky-500" />
          </div>
          <div className="text-2xl font-bold font-mono text-neutral-900 dark:text-white tabular-nums">
            {totalBooks}
          </div>
          <p className="text-[10px] text-neutral-400">Master Catalog</p>
        </div>

        <div className="p-4 rounded-xl border border-neutral-200/80 bg-white dark:border-neutral-800 dark:bg-neutral-900 shadow-xs space-y-1">
          <div className="flex items-center justify-between text-neutral-400 text-xs">
            <span>Available Copies</span>
            <CheckCircle2 className="w-4 h-4 text-emerald-500" />
          </div>
          <div className="text-2xl font-bold font-mono text-emerald-600 tabular-nums">
            {totalAvailableCopies}
          </div>
          <p className="text-[10px] text-neutral-400">On Physical Stacks</p>
        </div>

        <div className="p-4 rounded-xl border border-neutral-200/80 bg-white dark:border-neutral-800 dark:bg-neutral-900 shadow-xs space-y-1">
          <div className="flex items-center justify-between text-neutral-400 text-xs">
            <span>Borrowed Copies</span>
            <ArrowUpRight className="w-4 h-4 text-amber-500" />
          </div>
          <div className="text-2xl font-bold font-mono text-amber-600 tabular-nums">
            {totalBorrowedCopies}
          </div>
          <p className="text-[10px] text-neutral-400">In Active Circulation</p>
        </div>

        <div className="p-4 rounded-xl border border-neutral-200/80 bg-white dark:border-neutral-800 dark:bg-neutral-900 shadow-xs space-y-1">
          <div className="flex items-center justify-between text-neutral-400 text-xs">
            <span>Low-Stock Titles</span>
            <AlertTriangle className="w-4 h-4 text-amber-500" />
          </div>
          <div className="text-2xl font-bold font-mono text-amber-500 tabular-nums">
            {totalLowStockTitles}
          </div>
          <p className="text-[10px] text-neutral-400">≤ 1 copy left</p>
        </div>

        <div className="p-4 rounded-xl border border-neutral-200/80 bg-white dark:border-neutral-800 dark:bg-neutral-900 shadow-xs space-y-1">
          <div className="flex items-center justify-between text-neutral-400 text-xs">
            <span>Damaged Books</span>
            <ShieldAlert className="w-4 h-4 text-rose-500" />
          </div>
          <div className="text-2xl font-bold font-mono text-rose-600 tabular-nums">
            {totalDamagedBooks}
          </div>
          <p className="text-[10px] text-neutral-400">Needs repair/bindery</p>
        </div>

        <div className="p-4 rounded-xl border border-neutral-200/80 bg-white dark:border-neutral-800 dark:bg-neutral-900 shadow-xs space-y-1">
          <div className="flex items-center justify-between text-neutral-400 text-xs">
            <span>Lost Books</span>
            <HelpCircle className="w-4 h-4 text-neutral-400" />
          </div>
          <div className="text-2xl font-bold font-mono text-neutral-500 tabular-nums">
            {totalLostBooks}
          </div>
          <p className="text-[10px] text-neutral-400">Unaccounted copies</p>
        </div>
      </div>

      {/* Search, Filter & Sort Controls */}
      <div className="p-4 rounded-2xl border border-neutral-200/80 bg-white dark:border-neutral-800 dark:bg-neutral-900 shadow-xs flex flex-col sm:flex-row gap-3">
        <div className="relative flex-1">
          <Search className="w-4 h-4 text-neutral-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => {
              setSearchTerm(e.target.value);
              setCurrentPage(1);
            }}
            placeholder="Search by title, call number, author, or ISBN..."
            className="w-full h-10 rounded-xl border border-neutral-300 bg-white pl-9 pr-3 text-xs text-neutral-900 placeholder:text-neutral-400 focus:outline-none focus:ring-2 focus:ring-neutral-900 dark:border-neutral-800 dark:bg-neutral-900 dark:text-neutral-100"
          />
        </div>

        <div className="w-full sm:w-44">
          <Select
            value={statusFilter}
            onChange={(e) => {
              setStatusFilter(e.target.value);
              setCurrentPage(1);
            }}
          >
            <option value="ALL">All Holdings</option>
            <option value="AVAILABLE">Available Now</option>
            <option value="LOW_STOCK">Low-Stock (≤ 1)</option>
            <option value="ISSUED">Currently Borrowed</option>
            <option value="DAMAGED">Damaged Copies</option>
            <option value="LOST">Lost / Missing</option>
          </Select>
        </div>

        <div className="w-full sm:w-40">
          <Select
            value={sortBy}
            onChange={(e) => setSortBy(e.target.value)}
          >
            <option value="title">Sort by Title</option>
            <option value="copies">Total Copies (High-Low)</option>
            <option value="available">Available (High-Low)</option>
          </Select>
        </div>
      </div>

      {/* Inventory Table */}
      <div className="rounded-2xl border border-neutral-200/80 bg-white dark:border-neutral-800 dark:bg-neutral-900 overflow-hidden shadow-xs">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-neutral-50 dark:bg-neutral-850 border-b border-neutral-200/80 dark:border-neutral-800 font-mono text-[11px] text-neutral-500 uppercase">
              <tr>
                <th className="py-3.5 px-4">Call Number</th>
                <th className="py-3.5 px-4">Title & Details</th>
                <th className="py-3.5 px-4">Shelf Coordinates</th>
                <th className="py-3.5 px-4">Total</th>
                <th className="py-3.5 px-4">On Shelf</th>
                <th className="py-3.5 px-4">Circulating</th>
                <th className="py-3.5 px-4">Damaged / Lost</th>
                <th className="py-3.5 px-4">Stock Status</th>
                <th className="py-3.5 px-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-neutral-100 dark:divide-neutral-800">
              {paginated.map((book) => (
                <tr key={book.id} className="hover:bg-neutral-50/50 dark:hover:bg-neutral-800/40 transition-colors">
                  <td className="py-3.5 px-4 font-mono font-medium text-neutral-400 whitespace-nowrap">
                    {book.bookNumber}
                  </td>
                  <td className="py-3.5 px-4 min-w-[220px]">
                    <div className="font-semibold text-neutral-900 dark:text-neutral-100 truncate">
                      {book.title}
                    </div>
                    <div className="text-[11px] text-neutral-500 truncate">
                      {book.author} · <span className="font-mono">{book.isbn}</span>
                    </div>
                  </td>
                  <td className="py-3.5 px-4 font-mono text-neutral-600 dark:text-neutral-400 whitespace-nowrap">
                    R{book.rackNumber} · S{book.shelfNumber} · P{book.position} ({book.section})
                  </td>
                  <td className="py-3.5 px-4 font-mono font-semibold tabular-nums text-neutral-900 dark:text-neutral-100">
                    {book.totalCopies}
                  </td>
                  <td className="py-3.5 px-4 font-mono font-semibold tabular-nums text-emerald-600">
                    {book.availableCopies}
                  </td>
                  <td className="py-3.5 px-4 font-mono font-semibold tabular-nums text-amber-600">
                    {book.borrowedCopies}
                  </td>
                  <td className="py-3.5 px-4 font-mono whitespace-nowrap">
                    {book.damagedCopies > 0 || book.lostCopies > 0 ? (
                      <span className="text-rose-600 font-semibold">
                        {book.damagedCopies > 0 && `${book.damagedCopies} Damaged`}
                        {book.damagedCopies > 0 && book.lostCopies > 0 && ' · '}
                        {book.lostCopies > 0 && `${book.lostCopies} Lost`}
                      </span>
                    ) : (
                      <span className="text-neutral-400">None</span>
                    )}
                  </td>
                  <td className="py-3.5 px-4 whitespace-nowrap">
                    {book.availableCopies === 0 ? (
                      <span className="px-2 py-0.5 rounded-full text-[10px] font-semibold bg-rose-500/10 text-rose-700 dark:text-rose-400">
                        Out of Stock
                      </span>
                    ) : book.isLowStock ? (
                      <span className="px-2 py-0.5 rounded-full text-[10px] font-semibold bg-amber-500/10 text-amber-700 dark:text-amber-400">
                        Low Stock (1 left)
                      </span>
                    ) : (
                      <span className="px-2 py-0.5 rounded-full text-[10px] font-semibold bg-emerald-500/10 text-emerald-700 dark:text-emerald-400">
                        In Stock ({book.availableCopies})
                      </span>
                    )}
                  </td>
                  <td className="py-3.5 px-4 text-right whitespace-nowrap">
                    <div className="flex items-center justify-end gap-1.5">
                      <button
                        onClick={() => handleStockAction(book.title, 'Audit Physical Copy')}
                        className="px-2 py-1 rounded-md text-[11px] font-medium border border-neutral-200 dark:border-neutral-700 hover:bg-neutral-100 dark:hover:bg-neutral-800 cursor-pointer"
                      >
                        Audit
                      </button>
                      <button
                        onClick={() => handleStockAction(book.title, 'Order New Copies')}
                        className="px-2 py-1 rounded-md text-[11px] font-medium bg-neutral-900 text-white dark:bg-white dark:text-neutral-900 hover:opacity-90 cursor-pointer"
                      >
                        Re-order
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* Pagination Bar */}
        <div className="p-4 border-t border-neutral-100 dark:border-neutral-800 flex items-center justify-between text-xs text-neutral-500">
          <div>
            Showing {(currentPage - 1) * pageSize + 1} to{' '}
            {Math.min(currentPage * pageSize, sorted.length)} of {sorted.length} titles
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={() => setCurrentPage((p) => Math.max(1, p - 1))}
              disabled={currentPage === 1}
              className="p-1.5 rounded-lg border border-neutral-200 dark:border-neutral-700 disabled:opacity-40 cursor-pointer"
            >
              <ChevronLeft className="w-4 h-4" />
            </button>
            <span className="font-mono text-neutral-700 dark:text-neutral-300 font-semibold">
              Page {currentPage} of {totalPages}
            </span>
            <button
              onClick={() => setCurrentPage((p) => Math.min(totalPages, p + 1))}
              disabled={currentPage === totalPages}
              className="p-1.5 rounded-lg border border-neutral-200 dark:border-neutral-700 disabled:opacity-40 cursor-pointer"
            >
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default LibrarianInventoryPage;
