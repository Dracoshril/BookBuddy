import React, { useState } from 'react';
import { initialBooks } from '../../data/books';
import { aiApi } from '../../services/api/aiApi';
import { BookCover } from '../../components/books/BookCover';
import { Button } from '../../components/common/Button';
import { Sparkles, BookOpen, Clock, Users, ArrowRight } from 'lucide-react';
import { Link } from 'react-router-dom';

export const AISummariesPage = () => {
  const [selectedBookId, setSelectedBookId] = useState('1');
  const [summary, setSummary] = useState(null);
  const [loading, setLoading] = useState(false);

  React.useEffect(() => {
    setLoading(true);
    aiApi.getBookSummary(selectedBookId).then((res) => {
      setSummary(res);
      setLoading(false);
    });
  }, [selectedBookId]);

  const selectedBook = initialBooks.find((b) => String(b.id) === String(selectedBookId)) || initialBooks[0];

  return (
    <div className="space-y-8 max-w-5xl">
      <div>
        <div className="inline-flex items-center gap-1.5 text-xs text-amber-600 dark:text-amber-400 font-semibold mb-1">
          <Sparkles className="w-3.5 h-3.5" />
          <span>Executive Knowledge Synthesis</span>
        </div>
        <h1 className="text-2xl sm:text-3xl font-bold tracking-tight text-neutral-900 dark:text-neutral-100">
          AI Book Summaries & Concept Briefs
        </h1>
        <p className="text-xs sm:text-sm text-neutral-500 dark:text-neutral-400 mt-1">
          Review executive takeaways, core conceptual pillars, estimated reading investment, and prerequisite difficulty.
        </p>
      </div>

      {/* Book Quick Switcher */}
      <div className="flex items-center gap-2 overflow-x-auto pb-2">
        {initialBooks.slice(0, 8).map((b) => (
          <button
            key={b.id}
            onClick={() => setSelectedBookId(b.id)}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap transition-colors cursor-pointer border ${
              selectedBookId === b.id
                ? 'bg-neutral-900 text-white border-neutral-900 dark:bg-white dark:text-neutral-900 dark:border-white'
                : 'bg-white dark:bg-neutral-900 border-neutral-200 dark:border-neutral-800 text-neutral-700 dark:text-neutral-300 hover:border-neutral-400'
            }`}
          >
            {b.title.split(':')[0]}
          </button>
        ))}
      </div>

      {/* Summary Detailed Card */}
      {summary && (
        <div className="p-6 sm:p-8 rounded-3xl border border-neutral-200/80 bg-white dark:border-neutral-800 dark:bg-neutral-900 shadow-xs space-y-6">
          <div className="flex flex-col sm:flex-row items-start gap-6 pb-6 border-b border-neutral-100 dark:border-neutral-800">
            <div className="w-24 shrink-0">
              <BookCover
                title={selectedBook.title}
                author={selectedBook.author}
                category={selectedBook.category}
                coverGradient={selectedBook.coverGradient}
                aspectRatio="aspect-[2/3]"
              />
            </div>
            <div className="space-y-1.5 flex-1">
              <span className="text-[10px] font-mono uppercase tracking-wider text-amber-600 font-semibold">
                {summary.mainTopic} · Synthesized Study Brief
              </span>
              <h2 className="text-xl font-bold text-neutral-900 dark:text-neutral-100">
                {selectedBook.title}
              </h2>
              <p className="text-xs text-neutral-500 font-medium">By {selectedBook.author}</p>
              <div className="flex items-center gap-4 text-xs font-mono text-neutral-400 pt-2">
                <span>Reading Time: {summary.estimatedReadingTime}</span>
                <span aria-hidden="true">·</span>
                <span>Difficulty: {summary.difficulty}</span>
              </div>
            </div>
          </div>

          {/* Overview */}
          <div className="space-y-2">
            <h4 className="font-bold text-sm text-neutral-900 dark:text-neutral-100">Overview</h4>
            <p className="text-xs text-neutral-600 dark:text-neutral-400 leading-relaxed">
              {summary.overview}
            </p>
          </div>

          {/* Key Topics */}
          <div className="space-y-2">
            <h4 className="font-bold text-sm text-neutral-900 dark:text-neutral-100">Key Conceptual Topics</h4>
            <ul className="list-disc pl-4 space-y-1 text-xs text-neutral-600 dark:text-neutral-400">
              {summary.keyTopics.map((topic, i) => (
                <li key={i}>{topic}</li>
              ))}
            </ul>
          </div>

          {/* Target Audience */}
          <div className="p-4 rounded-xl bg-neutral-50 dark:bg-neutral-800/60 border border-neutral-200/60 dark:border-neutral-700/60 text-xs text-neutral-600 dark:text-neutral-400">
            <strong className="block text-neutral-900 dark:text-neutral-100 mb-0.5">Who Should Read It:</strong>
            {summary.whoShouldRead}
          </div>

          <div className="pt-2 flex items-center justify-between">
            <Link to={`/books/${selectedBook.id}`}>
              <Button variant="primary" size="sm" rightIcon={<ArrowRight className="w-3.5 h-3.5" />}>
                View Full Physical Specs & Shelf Locator
              </Button>
            </Link>
          </div>
        </div>
      )}
    </div>
  );
};

export default AISummariesPage;
