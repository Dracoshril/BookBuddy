import React, { useState, useRef, useEffect } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { sendChatMessage, clearChat, addLocalUserMessage } from '../../store/slices/aiSlice';
import { Button } from '../../components/common/Button';
import { Sparkles, Send, Trash2, Copy, Check, RotateCcw, Compass, BookOpen } from 'lucide-react';
import ReactMarkdown from 'react-markdown';
import { toast } from 'sonner';

export const AIAssistantPage = () => {
  const dispatch = useDispatch();
  const { messages, isThinking } = useSelector((state) => state.ai);
  const [inputPrompt, setInputPrompt] = useState('');
  const [copiedIndex, setCopiedIndex] = useState(null);
  const chatEndRef = useRef(null);

  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, isThinking]);

  const suggestedPrompts = [
    'Find beginner Java books and where they are placed',
    'Where is Clean Code located?',
    'Show available DSA and algorithm books',
    'Create a 6-stage Java Backend learning roadmap',
  ];

  const handleSend = (textToSend) => {
    const text = (textToSend || inputPrompt).trim();
    if (!text || isThinking) return;

    dispatch(addLocalUserMessage(text));
    dispatch(sendChatMessage(text));
    setInputPrompt('');
  };

  const handleCopy = (content, idx) => {
    navigator.clipboard.writeText(content);
    setCopiedIndex(idx);
    toast.success('Response copied to clipboard!');
    setTimeout(() => setCopiedIndex(null), 2000);
  };

  return (
    <div className="max-w-4xl mx-auto flex flex-col h-[calc(100vh-8rem)]">
      {/* Header */}
      <div className="flex items-center justify-between pb-4 border-b border-neutral-200/80 dark:border-neutral-800 shrink-0">
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-lg bg-amber-500/10 text-amber-600 dark:text-amber-400 flex items-center justify-center">
            <Sparkles className="w-4 h-4" />
          </div>
          <div>
            <h1 className="text-base font-bold text-neutral-900 dark:text-neutral-100">
              BookBuddy AI Academic Assistant
            </h1>
            <p className="text-[11px] text-neutral-500">
              Grounded in campus physical catalog, stack locations, and engineering curricula.
            </p>
          </div>
        </div>

        <Button
          variant="outline"
          size="sm"
          leftIcon={<Trash2 className="w-3.5 h-3.5" />}
          onClick={() => {
            dispatch(clearChat());
            toast.info('Chat history cleared.');
          }}
        >
          Clear Chat
        </Button>
      </div>

      {/* Conversation Area */}
      <div className="flex-1 overflow-y-auto py-6 space-y-5">
        {messages.map((msg, idx) => {
          const isUser = msg.role === 'user';
          return (
            <div
              key={idx}
              className={`flex gap-3 text-xs sm:text-sm ${isUser ? 'justify-end' : 'justify-start'}`}
            >
              {!isUser && (
                <div className="w-7 h-7 rounded-lg bg-amber-600 text-white flex items-center justify-center shrink-0 mt-0.5 shadow-xs font-serif text-xs font-bold">
                  AI
                </div>
              )}

              <div
                className={`max-w-[85%] rounded-2xl p-4 space-y-2 leading-relaxed ${
                  isUser
                    ? 'bg-neutral-900 text-white dark:bg-white dark:text-neutral-900 rounded-br-xs'
                    : 'bg-white dark:bg-neutral-900 border border-neutral-200/80 dark:border-neutral-800 text-neutral-800 dark:text-neutral-200 shadow-xs rounded-bl-xs'
                }`}
              >
                <div className="prose prose-xs dark:prose-invert max-w-none">
                  <ReactMarkdown>{msg.content}</ReactMarkdown>
                </div>

                {!isUser && (
                  <div className="flex items-center justify-end gap-2 pt-2 border-t border-neutral-100 dark:border-neutral-800 text-[10px] text-neutral-400">
                    <button
                      onClick={() => handleCopy(msg.content, idx)}
                      className="hover:text-neutral-800 dark:hover:text-neutral-200 flex items-center gap-1 cursor-pointer"
                    >
                      {copiedIndex === idx ? (
                        <>
                          <Check className="w-3 h-3 text-emerald-500" />
                          <span>Copied</span>
                        </>
                      ) : (
                        <>
                          <Copy className="w-3 h-3" />
                          <span>Copy</span>
                        </>
                      )}
                    </button>
                  </div>
                )}
              </div>
            </div>
          );
        })}

        {isThinking && (
          <div className="flex gap-3 text-xs">
            <div className="w-7 h-7 rounded-lg bg-amber-600 text-white flex items-center justify-center shrink-0 shadow-xs font-serif text-xs font-bold">
              AI
            </div>
            <div className="p-3.5 rounded-2xl bg-white dark:bg-neutral-900 border border-neutral-200/80 dark:border-neutral-800 flex items-center gap-2 text-neutral-500">
              <span className="w-1.5 h-1.5 rounded-full bg-amber-500 animate-pulse" />
              <span className="w-1.5 h-1.5 rounded-full bg-amber-500 animate-pulse delay-100" />
              <span className="w-1.5 h-1.5 rounded-full bg-amber-500 animate-pulse delay-200" />
              <span className="text-[11px] font-mono ml-1">Analyzing physical library index...</span>
            </div>
          </div>
        )}

        <div ref={chatEndRef} />
      </div>

      {/* Suggested prompt chips */}
      <div className="py-2 flex items-center gap-2 overflow-x-auto text-xs shrink-0">
        <span className="text-[10px] uppercase font-mono text-neutral-400 shrink-0">Try:</span>
        {suggestedPrompts.map((p, i) => (
          <button
            key={i}
            onClick={() => handleSend(p)}
            className="px-2.5 py-1 rounded-full border border-neutral-200 dark:border-neutral-800 bg-white dark:bg-neutral-900 text-neutral-600 dark:text-neutral-300 hover:border-neutral-400 dark:hover:border-neutral-700 whitespace-nowrap text-[11px] transition-colors cursor-pointer"
          >
            {p}
          </button>
        ))}
      </div>

      {/* Prompt Input Form */}
      <form
        onSubmit={(e) => {
          e.preventDefault();
          handleSend();
        }}
        className="pt-2 flex items-center gap-2 shrink-0"
      >
        <div className="relative flex-1">
          <input
            type="text"
            value={inputPrompt}
            onChange={(e) => setInputPrompt(e.target.value)}
            placeholder="Ask about shelf locations, concepts, or study recommendations..."
            className="w-full h-12 rounded-xl border border-neutral-300 bg-white px-4 text-xs sm:text-sm text-neutral-900 placeholder:text-neutral-400 focus:outline-none focus:ring-2 focus:ring-neutral-900 dark:border-neutral-800 dark:bg-neutral-900 dark:text-neutral-100 dark:focus:ring-neutral-400 shadow-xs"
          />
        </div>
        <Button
          type="submit"
          variant="primary"
          size="md"
          className="h-12 px-5"
          disabled={!inputPrompt.trim() || isThinking}
          rightIcon={<Send className="w-4 h-4" />}
        >
          Send
        </Button>
      </form>
    </div>
  );
};

export default AIAssistantPage;
