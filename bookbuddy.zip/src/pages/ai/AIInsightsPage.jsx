import React, { useEffect } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { fetchReaderInsights } from '../../store/slices/analyticsSlice';
import { useAuth } from '../../hooks/useAuth';
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  PieChart,
  Pie,
  Cell,
  LineChart,
  Line,
  CartesianGrid,
} from 'recharts';
import { Sparkles, TrendingUp, BookOpen, Clock, Target } from 'lucide-react';

export const AIInsightsPage = () => {
  const dispatch = useDispatch();
  const { user } = useAuth();
  const insights = useSelector((state) => state.analytics.readerInsights);

  useEffect(() => {
    dispatch(fetchReaderInsights(user?.id || 'user-1'));
  }, [dispatch, user]);

  const COLORS = ['#d97706', '#0284c7', '#10b981', '#8b5cf6', '#f43f5e'];

  if (!insights) return null;

  return (
    <div className="space-y-8 max-w-5xl">
      <div>
        <div className="inline-flex items-center gap-1.5 text-xs text-amber-600 dark:text-amber-400 font-semibold mb-1">
          <Sparkles className="w-3.5 h-3.5" />
          <span>Cognitive Reading Analytics</span>
        </div>
        <h1 className="text-2xl sm:text-3xl font-bold tracking-tight text-neutral-900 dark:text-neutral-100">
          Personal Reading Velocity & Insights
        </h1>
        <p className="text-xs sm:text-sm text-neutral-500 dark:text-neutral-400 mt-1">
          Data visualization of your reading pace, category distribution, and semester milestone completions.
        </p>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        <div className="p-4 rounded-xl border border-neutral-200/80 bg-white dark:border-neutral-800 dark:bg-neutral-900 shadow-xs">
          <span className="text-xs text-neutral-500 block mb-1">Semester Completed</span>
          <span className="text-2xl font-bold font-mono text-neutral-900 dark:text-neutral-100 tabular-nums">
            {insights.booksReadThisSemester} / {insights.goalCount}
          </span>
          <span className="text-[10px] text-emerald-600 font-mono block mt-1">66% of target achieved</span>
        </div>

        <div className="p-4 rounded-xl border border-neutral-200/80 bg-white dark:border-neutral-800 dark:bg-neutral-900 shadow-xs">
          <span className="text-xs text-neutral-500 block mb-1">Reading Velocity</span>
          <span className="text-2xl font-bold font-mono text-neutral-900 dark:text-neutral-100 tabular-nums">
            {insights.readingVelocity}
          </span>
          <span className="text-[10px] text-neutral-400 font-mono block mt-1">Consistent pace</span>
        </div>

        <div className="p-4 rounded-xl border border-neutral-200/80 bg-white dark:border-neutral-800 dark:bg-neutral-900 shadow-xs">
          <span className="text-xs text-neutral-500 block mb-1">Est. Pages Consumed</span>
          <span className="text-2xl font-bold font-mono text-neutral-900 dark:text-neutral-100 tabular-nums">
            {insights.pagesEstimated}
          </span>
          <span className="text-[10px] text-neutral-400 font-mono block mt-1">Across 8 volumes</span>
        </div>

        <div className="p-4 rounded-xl border border-neutral-200/80 bg-white dark:border-neutral-800 dark:bg-neutral-900 shadow-xs">
          <span className="text-xs text-neutral-500 block mb-1">Favorite Subject</span>
          <span className="text-lg font-bold text-neutral-900 dark:text-neutral-100 truncate block">
            {insights.favoriteCategory}
          </span>
          <span className="text-[10px] text-amber-600 font-mono block mt-1">45% total reading</span>
        </div>
      </div>

      {/* Charts Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Monthly Progress Trend */}
        <div className="p-5 rounded-2xl border border-neutral-200/80 bg-white dark:border-neutral-800 dark:bg-neutral-900 shadow-xs space-y-4">
          <div>
            <h3 className="font-bold text-sm text-neutral-900 dark:text-neutral-100">
              Monthly Completion Velocity (2026)
            </h3>
            <p className="text-[11px] text-neutral-500">Books finished per calendar month</p>
          </div>

          <div className="h-60 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={insights.monthlyProgress}>
                <CartesianGrid strokeDasharray="3 3" opacity={0.15} />
                <XAxis dataKey="month" tick={{ fontSize: 11 }} />
                <YAxis allowDecimals={false} tick={{ fontSize: 11 }} />
                <Tooltip
                  contentStyle={{
                    backgroundColor: '#18181b',
                    borderColor: '#27272a',
                    borderRadius: '8px',
                    fontSize: '12px',
                    color: '#fff',
                  }}
                />
                <Bar dataKey="count" fill="#d97706" radius={[4, 4, 0, 0]} name="Books Finished" />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Subject Category Distribution */}
        <div className="p-5 rounded-2xl border border-neutral-200/80 bg-white dark:border-neutral-800 dark:bg-neutral-900 shadow-xs space-y-4">
          <div>
            <h3 className="font-bold text-sm text-neutral-900 dark:text-neutral-100">
              Subject Distribution Ratio
            </h3>
            <p className="text-[11px] text-neutral-500">Breakdown of disciplines studied</p>
          </div>

          <div className="h-60 w-full flex items-center justify-center">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={insights.topCategories}
                  dataKey="percent"
                  nameKey="name"
                  cx="50%"
                  cy="50%"
                  outerRadius={80}
                  innerRadius={50}
                  paddingAngle={4}
                >
                  {insights.topCategories.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip
                  contentStyle={{
                    backgroundColor: '#18181b',
                    borderColor: '#27272a',
                    borderRadius: '8px',
                    fontSize: '12px',
                    color: '#fff',
                  }}
                />
              </PieChart>
            </ResponsiveContainer>
          </div>

          <div className="flex flex-wrap items-center justify-center gap-3 text-xs pt-1">
            {insights.topCategories.map((c, i) => (
              <div key={i} className="flex items-center gap-1.5 font-mono text-[11px]">
                <span
                  className="w-2.5 h-2.5 rounded-full"
                  style={{ backgroundColor: COLORS[i % COLORS.length] }}
                />
                <span className="text-neutral-600 dark:text-neutral-400">
                  {c.name} ({c.percent}%)
                </span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default AIInsightsPage;
