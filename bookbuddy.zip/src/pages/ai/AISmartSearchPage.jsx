import React, { useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { performSmartSearch } from '../../store/slices/aiSlice';
import { BookCard } from '../../components/books/BookCard';
import { Button } from '../../components/common/Button';
import { Sparkles, Search, Compass, BookOpen, ArrowRight } from 'lucide-react';
import { Link } from 'react-router-dom';

export const AISmartSearchPage = () => {
  const dispatch = useDispatch();
  const searchResult = useSelector((state) => state.ai.smartSearchResult);
  const [query, setQuery] = useState('I need books to learn Java backend development');
  const [isSearching, setIsSearching] = useState(false);

  const handleSearch = async (e) => {
    e?.preventDefault();
    if (!query.trim()) return;

    setIsSearching(true);
    try {
      await dispatch(performSmartSearch(query.trim())).unwrap();
    } finally {
      setIsSearching(false);
    }
  };

  const samplePrompts = [
    'I need books to learn Java backend development',
    'Find DSA books available on shelf right now',
    'Explain distributed consensus and storage engines',
    'Beginner friendly personal focus and study habits',
  ];

  return (
    <div className="space-y-8 max-w-5xl">
      <div>
        <div className="inline-flex items-center gap-1.5 text-xs text-amber-600 dark:text-amber-400 font-semibold mb-1">
          <Sparkles className="w-3.5 h-3.5" />
          <span>Natural Language Semantic Discovery</span>
        </div>
        <h1 className="text-2xl sm:text-3xl font-bold tracking-tight text-neutral-900 dark:text-neutral-100">
          AI Smart Catalog Search
        </h1>
        <p className="text-xs sm:text-sm text-neutral-500 dark:text-neutral-400 mt-1">
          Describe your academic goal in natural language. The AI parses your learning intent and locates corresponding campus holdings.
        </p>
      </div>

      {/* Query Bar */}
      <div className="p-6 rounded-2xl border border-neutral-200/80 bg-white dark:border-neutral-800 dark:bg-neutral-900 shadow-sm space-y-4">
        <form onSubmit={handleSearch} className="flex gap-2">
          <div className="relative flex-1">
            <Search className="w-4 h-4 text-neutral-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="e.g. 'I need beginner-friendly books to prepare for Java backend interviews'"
              className="w-full h-11 rounded-xl border border-neutral-300 bg-white pl-9 pr-3 text-xs sm:text-sm text-neutral-900 placeholder:text-neutral-400 focus:outline-none focus:ring-2 focus:ring-neutral-900 dark:border-neutral-800 dark:bg-neutral-900 dark:text-neutral-100"
            />
          </div>
          <Button type="submit" variant="primary" size="md" isLoading={isSearching}>
            Analyze Intent
          </Button>
        </form>

        {/* Sample queries */}
        <div className="flex flex-wrap items-center gap-2 pt-2 text-xs">
          <span className="text-neutral-400 font-mono text-[11px]">Try Intent:</span>
          {samplePrompts.map((s, i) => (
            <button
              key={i}
              type="button"
              onClick={() => {
                setQuery(s);
              }}
              className="px-2.5 py-1 rounded-full border border-neutral-200 dark:border-neutral-800 bg-neutral-50 dark:bg-neutral-800 text-[11px] text-neutral-600 dark:text-neutral-300 hover:border-neutral-400 transition-colors cursor-pointer"
            >
              {s}
            </button>
          ))}
        </div>
      </div>

      {/* Results View */}
      {searchResult && (
        <div className="space-y-6 animate-in fade-in duration-200">
          {/* Analysis Banner */}
          <div className="p-5 rounded-2xl border border-amber-500/20 bg-amber-500/5 space-y-2">
            <div className="flex items-center gap-2 text-xs text-amber-700 dark:text-amber-400 font-bold uppercase tracking-wider font-mono">
              <Sparkles className="w-4 h-4" />
              <span>Detected Intent: {searchResult.detectedIntent}</span>
            </div>
            <p className="text-xs text-neutral-600 dark:text-neutral-300 leading-relaxed">
              {searchResult.explanation}
            </p>
            <div className="flex items-center gap-2 text-xs text-neutral-500 pt-1">
              <span>Suggested Disciplines:</span>
              {searchResult.suggestedCategories.map((c, i) => (
                <span key={i} className="px-2 py-0.5 rounded bg-white dark:bg-neutral-800 font-mono font-medium">
                  {c}
                </span>
              ))}
            </div>
          </div>

          {/* Matched Books */}
          <div className="space-y-4">
            <h3 className="text-lg font-bold text-neutral-900 dark:text-neutral-100">
              Matched Physical Holdings ({searchResult.results.length})
            </h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6">
              {searchResult.results.map((book) => (
                <BookCard key={book.id} book={book} aiMatchScore={92} />
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default AISmartSearchPage;
