import React, { useState, useEffect } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { fetchLearningRoadmaps } from '../../store/slices/aiSlice';
import { initialBooks } from '../../data/books';
import { BookCover } from '../../components/books/BookCover';
import { Button } from '../../components/common/Button';
import { Sparkles, CheckCircle, Circle, ArrowRight, Lock, BookOpen } from 'lucide-react';
import { Link } from 'react-router-dom';
import { toast } from 'sonner';

export const AILearningPathPage = () => {
  const dispatch = useDispatch();
  const roadmaps = useSelector((state) => state.ai.roadmaps);
  const [selectedRoadmapId, setSelectedRoadmapId] = useState('road-1');

  useEffect(() => {
    dispatch(fetchLearningRoadmaps());
  }, [dispatch]);

  const activeRoadmap = roadmaps.find((r) => r.id === selectedRoadmapId) || roadmaps[0];

  const handleStageClick = (stage) => {
    toast.info(`Stage ${stage.stage}: "${stage.name}" details loaded.`);
  };

  return (
    <div className="space-y-8 max-w-5xl">
      <div>
        <div className="inline-flex items-center gap-1.5 text-xs text-amber-600 dark:text-amber-400 font-semibold mb-1">
          <Sparkles className="w-3.5 h-3.5" />
          <span>Curriculum & Career Roadmaps</span>
        </div>
        <h1 className="text-2xl sm:text-3xl font-bold tracking-tight text-neutral-900 dark:text-neutral-100">
          AI Sequential Learning Paths
        </h1>
        <p className="text-xs sm:text-sm text-neutral-500 dark:text-neutral-400 mt-1">
          Follow structured book progressions connected directly to university holdings and syllabus prerequisites.
        </p>
      </div>

      {/* Roadmap Selector */}
      {roadmaps.length > 0 && (
        <div className="flex items-center gap-3 overflow-x-auto pb-1">
          {roadmaps.map((rm) => (
            <button
              key={rm.id}
              onClick={() => setSelectedRoadmapId(rm.id)}
              className={`p-4 rounded-2xl border text-left min-w-[280px] transition-all cursor-pointer ${
                selectedRoadmapId === rm.id
                  ? 'border-neutral-900 bg-neutral-900 text-white dark:border-white dark:bg-white dark:text-neutral-900 shadow-sm'
                  : 'border-neutral-200 dark:border-neutral-800 bg-white dark:bg-neutral-900 text-neutral-700 dark:text-neutral-300 hover:border-neutral-300'
              }`}
            >
              <span className="text-[10px] font-mono uppercase tracking-wider block opacity-70 mb-1">
                Roadmap #{rm.id.replace('road-', '')}
              </span>
              <h4 className="font-bold text-sm tracking-tight">{rm.title}</h4>
              <p className="text-[11px] opacity-80 mt-1 truncate">{rm.targetGoal}</p>
            </button>
          ))}
        </div>
      )}

      {/* Active Roadmap Timeline */}
      {activeRoadmap && (
        <div className="p-6 sm:p-8 rounded-3xl border border-neutral-200/80 bg-white dark:border-neutral-800 dark:bg-neutral-900 shadow-xs space-y-8">
          <div className="space-y-2 pb-4 border-b border-neutral-100 dark:border-neutral-800">
            <h2 className="text-xl font-bold text-neutral-900 dark:text-neutral-100">
              {activeRoadmap.title}
            </h2>
            <p className="text-xs text-neutral-500 leading-relaxed max-w-2xl">
              {activeRoadmap.targetGoal}
            </p>
          </div>

          {/* Sequential Stages */}
          <div className="relative pl-6 border-l-2 border-neutral-200 dark:border-neutral-800 space-y-8 ml-2">
            {activeRoadmap.stages.map((stg) => {
              const recBook = initialBooks.find((b) => b.id === stg.recommendedBookId) || initialBooks[0];
              const isCompleted = stg.status === 'COMPLETED';
              const isInProgress = stg.status === 'IN_PROGRESS';
              const isLocked = stg.status === 'LOCKED';

              return (
                <div key={stg.stage} className="relative group">
                  {/* Step Indicator Dot */}
                  <div
                    className={`absolute -left-[33px] top-1 w-8 h-8 rounded-full flex items-center justify-center border-2 border-white dark:border-neutral-900 text-xs font-bold font-mono ${
                      isCompleted
                        ? 'bg-emerald-500 text-white'
                        : isInProgress
                        ? 'bg-amber-500 text-white animate-pulse'
                        : 'bg-neutral-200 dark:bg-neutral-800 text-neutral-400'
                    }`}
                  >
                    {isCompleted ? <CheckCircle className="w-4 h-4" /> : isLocked ? <Lock className="w-3.5 h-3.5" /> : stg.stage}
                  </div>

                  <div className="p-5 rounded-2xl border border-neutral-200/80 bg-neutral-50/50 dark:border-neutral-800 dark:bg-neutral-900/60 space-y-3">
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                      <div className="space-y-0.5">
                        <span className="text-[10px] font-mono uppercase tracking-wider text-amber-600 font-semibold">
                          Stage {stg.stage} · {stg.status.replace('_', ' ')}
                        </span>
                        <h3 className="font-bold text-base text-neutral-900 dark:text-neutral-100">
                          {stg.name}
                        </h3>
                      </div>
                      <span className="text-xs font-mono text-neutral-400">Prerequisite Stage</span>
                    </div>

                    <p className="text-xs text-neutral-600 dark:text-neutral-400 leading-relaxed">
                      {stg.description}
                    </p>

                    {/* Book Recommendation for this Stage */}
                    <div className="p-3.5 rounded-xl bg-white dark:bg-neutral-800 border border-neutral-200/80 dark:border-neutral-700/80 flex items-center justify-between gap-4">
                      <div className="flex items-center gap-3 min-w-0">
                        <div className="w-10 shrink-0">
                          <BookCover
                            title={recBook.title}
                            author={recBook.author}
                            coverGradient={recBook.coverGradient}
                            aspectRatio="aspect-[2/3]"
                          />
                        </div>
                        <div className="min-w-0">
                          <span className="text-[10px] font-mono text-neutral-400 block uppercase">
                            Recommended Syllabus Text
                          </span>
                          <Link to={`/books/${recBook.id}`}>
                            <h4 className="font-semibold text-xs text-neutral-900 dark:text-neutral-100 truncate hover:text-amber-600">
                              {recBook.title}
                            </h4>
                          </Link>
                          <p className="text-[11px] text-neutral-500 font-mono">
                            Rack {recBook.rackNumber} · Shelf {recBook.shelfNumber} ({recBook.availableCopies} available)
                          </p>
                        </div>
                      </div>

                      <Link to={`/books/${recBook.id}`} className="shrink-0">
                        <Button variant="outline" size="sm">
                          Inspect
                        </Button>
                      </Link>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
};

export default AILearningPathPage;
