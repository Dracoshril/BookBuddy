import React, { useEffect } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { fetchAIRecommendations } from '../../store/slices/aiSlice';
import { HorizontalBookCard } from '../../components/books/HorizontalBookCard';
import { Sparkles, Info } from 'lucide-react';

export const AIRecommendationsPage = () => {
  const dispatch = useDispatch();
  const recommendations = useSelector((state) => state.ai.recommendations);

  useEffect(() => {
    dispatch(fetchAIRecommendations());
  }, [dispatch]);

  return (
    <div className="space-y-6 max-w-5xl">
      <div>
        <div className="inline-flex items-center gap-1.5 text-xs text-amber-600 dark:text-amber-400 font-semibold mb-1">
          <Sparkles className="w-3.5 h-3.5" />
          <span>Personalized Adaptive Learning</span>
        </div>
        <h1 className="text-2xl sm:text-3xl font-bold tracking-tight text-neutral-900 dark:text-neutral-100">
          AI Recommendations For You
        </h1>
        <p className="text-xs sm:text-sm text-neutral-500 dark:text-neutral-400 mt-1">
          Curated holdings matching your major, completed borrowings, rated books, and active career goals.
        </p>
      </div>

      {/* Transparency Banner: AI Match % is relevance, not universal quality */}
      <div className="p-4 rounded-xl border border-neutral-200 dark:border-neutral-800 bg-neutral-100/60 dark:bg-neutral-900/60 flex items-start gap-3 text-xs text-neutral-600 dark:text-neutral-400">
        <Info className="w-4 h-4 text-neutral-500 shrink-0 mt-0.5" />
        <p className="leading-relaxed">
          <strong>Understanding AI Match:</strong> The match percentage indicates semantic and syllabus alignment with your registered Computer Science interests (Distributed Systems, DSA, Java) and recent reading history. It does not measure absolute book quality.
        </p>
      </div>

      {/* Recommendations Cards */}
      <div className="space-y-4">
        {recommendations.map((rec) => (
          <HorizontalBookCard
            key={rec.bookId}
            book={rec.book}
            matchReason={rec.matchReason}
            aiMatchPercentage={rec.matchPercentage}
          />
        ))}
      </div>
    </div>
  );
};

export default AIRecommendationsPage;
