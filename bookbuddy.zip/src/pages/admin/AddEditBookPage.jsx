import React, { useState, useEffect } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import { initialBooks } from '../../data/books';
import { initialCategories } from '../../data/categories';
import { Button } from '../../components/common/Button';
import { Input } from '../../components/common/Input';
import { Select } from '../../components/common/Select';
import { ArrowLeft, Save, RotateCcw } from 'lucide-react';
import { toast } from 'sonner';

export const AddEditBookPage = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const isEditing = Boolean(id);

  const existingBook = isEditing
    ? initialBooks.find((b) => String(b.id) === String(id)) || initialBooks[0]
    : null;

  const [formData, setFormData] = useState({
    bookNumber: existingBook?.bookNumber || `BK-${String(initialBooks.length + 1).padStart(4, '0')}`,
    title: existingBook?.title || '',
    author: existingBook?.author || '',
    publisher: existingBook?.publisher || '',
    isbn: existingBook?.isbn || '',
    category: existingBook?.category || 'Programming',
    description: existingBook?.description || '',
    publicationYear: existingBook?.publicationYear || 2026,
    language: existingBook?.language || 'English',
    totalCopies: existingBook?.totalCopies || 4,
    availableCopies: existingBook?.availableCopies || 4,
    rackNumber: existingBook?.rackNumber || 1,
    section: existingBook?.section || 'General',
    shelfNumber: existingBook?.shelfNumber || 1,
    position: existingBook?.position || 1,
  });

  const [errors, setErrors] = useState({});
  const [isSubmitting, setIsSubmitting] = useState(false);

  const validate = () => {
    const errs = {};
    if (!formData.title.trim()) errs.title = 'Title is required';
    if (!formData.author.trim()) errs.author = 'Author is required';
    if (!formData.isbn.trim()) errs.isbn = 'ISBN is required';
    if (Number(formData.totalCopies) < 1) errs.totalCopies = 'Total copies must be at least 1';
    if (Number(formData.availableCopies) < 0) errs.availableCopies = 'Cannot be negative';
    if (Number(formData.availableCopies) > Number(formData.totalCopies)) {
      errs.availableCopies = 'Available copies cannot exceed total copies';
    }
    setErrors(errs);
    return Object.keys(errs).length === 0;
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!validate()) {
      toast.error('Please resolve form validation errors before saving.');
      return;
    }

    setIsSubmitting(true);
    setTimeout(() => {
      setIsSubmitting(false);
      toast.success(
        isEditing
          ? `Updated "${formData.title}" in library index.`
          : `Cataloged new book "${formData.title}" (${formData.bookNumber})!`
      );
      navigate('/admin/books');
    }, 400);
  };

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      <Link
        to="/admin/books"
        className="inline-flex items-center gap-1.5 text-xs font-semibold text-neutral-500 hover:text-neutral-900 dark:hover:text-white"
      >
        <ArrowLeft className="w-3.5 h-3.5" />
        <span>Back to Book Management</span>
      </Link>

      <div className="p-8 rounded-3xl border border-neutral-200/80 bg-white dark:border-neutral-800 dark:bg-neutral-900 shadow-sm space-y-6">
        <div>
          <h1 className="text-xl font-bold tracking-tight text-neutral-900 dark:text-neutral-100">
            {isEditing ? 'Edit Volume Specifications' : 'Add New Physical Volume to Catalog'}
          </h1>
          <p className="text-xs text-neutral-500 mt-1">
            Specify bibliographical metadata, total inventory copies, and exact physical stack coordinates.
          </p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Section 1: Bibliographical Specs */}
          <div className="space-y-4">
            <h3 className="text-xs font-mono uppercase tracking-wider text-neutral-400 font-semibold border-b border-neutral-100 dark:border-neutral-800 pb-1">
              01. Bibliographical Information
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <Input
                label="Call Number / Book ID"
                value={formData.bookNumber}
                onChange={(e) => setFormData({ ...formData, bookNumber: e.target.value })}
                required
              />
              <div className="sm:col-span-2">
                <Input
                  label="Book Title"
                  value={formData.title}
                  onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                  error={errors.title}
                  required
                />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <Input
                label="Author"
                value={formData.author}
                onChange={(e) => setFormData({ ...formData, author: e.target.value })}
                error={errors.author}
                required
              />
              <Input
                label="Publisher"
                value={formData.publisher}
                onChange={(e) => setFormData({ ...formData, publisher: e.target.value })}
              />
              <Input
                label="ISBN-13"
                value={formData.isbn}
                onChange={(e) => setFormData({ ...formData, isbn: e.target.value })}
                error={errors.isbn}
                required
              />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <Select
                label="Subject Category"
                value={formData.category}
                onChange={(e) => setFormData({ ...formData, category: e.target.value })}
              >
                {initialCategories.map((c) => (
                  <option key={c.id} value={c.name}>
                    {c.name}
                  </option>
                ))}
              </Select>
              <Input
                label="Publication Year"
                type="number"
                value={formData.publicationYear}
                onChange={(e) => setFormData({ ...formData, publicationYear: e.target.value })}
              />
              <Input
                label="Language"
                value={formData.language}
                onChange={(e) => setFormData({ ...formData, language: e.target.value })}
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-neutral-700 dark:text-neutral-300 mb-1.5">
                Description & Syllabus Scope
              </label>
              <textarea
                rows={3}
                value={formData.description}
                onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                className="w-full rounded-xl border border-neutral-300 bg-white p-3 text-xs text-neutral-900 focus:outline-none focus:ring-2 focus:ring-neutral-900 dark:border-neutral-800 dark:bg-neutral-900 dark:text-neutral-100"
              />
            </div>
          </div>

          {/* Section 2: Copies & Inventory */}
          <div className="space-y-4">
            <h3 className="text-xs font-mono uppercase tracking-wider text-neutral-400 font-semibold border-b border-neutral-100 dark:border-neutral-800 pb-1">
              02. Inventory Holdings
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <Input
                label="Total Physical Copies"
                type="number"
                value={formData.totalCopies}
                onChange={(e) => setFormData({ ...formData, totalCopies: Number(e.target.value) })}
                error={errors.totalCopies}
                required
              />
              <Input
                label="Available Copies on Shelf"
                type="number"
                value={formData.availableCopies}
                onChange={(e) => setFormData({ ...formData, availableCopies: Number(e.target.value) })}
                error={errors.availableCopies}
                required
              />
            </div>
          </div>

          {/* Section 3: Physical Library Location */}
          <div className="space-y-4">
            <h3 className="text-xs font-mono uppercase tracking-wider text-neutral-400 font-semibold border-b border-neutral-100 dark:border-neutral-800 pb-1">
              03. Physical Shelf & Stack Location Coordinates
            </h3>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
              <Input
                label="Rack Number"
                type="number"
                value={formData.rackNumber}
                onChange={(e) => setFormData({ ...formData, rackNumber: Number(e.target.value) })}
                required
              />
              <Input
                label="Section Topic"
                value={formData.section}
                onChange={(e) => setFormData({ ...formData, section: e.target.value })}
                required
              />
              <Input
                label="Shelf Tier"
                type="number"
                value={formData.shelfNumber}
                onChange={(e) => setFormData({ ...formData, shelfNumber: Number(e.target.value) })}
                required
              />
              <Input
                label="Spine Index Position"
                type="number"
                value={formData.position}
                onChange={(e) => setFormData({ ...formData, position: Number(e.target.value) })}
                required
              />
            </div>
          </div>

          {/* Action buttons */}
          <div className="flex items-center justify-end gap-3 pt-6 border-t border-neutral-100 dark:border-neutral-800">
            <Button variant="outline" size="md" onClick={() => navigate('/admin/books')} disabled={isSubmitting}>
              Cancel
            </Button>
            <Button
              type="submit"
              variant="primary"
              size="md"
              leftIcon={<Save className="w-4 h-4" />}
              isLoading={isSubmitting}
            >
              {isEditing ? 'Save Changes' : 'Catalog Book'}
            </Button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default AddEditBookPage;
