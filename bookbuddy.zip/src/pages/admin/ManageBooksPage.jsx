import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useSelector, useDispatch } from 'react-redux';
import { initialBooks } from '../../data/books';
import { initialCategories } from '../../data/categories';
import { Button } from '../../components/common/Button';
import { Input } from '../../components/common/Input';
import { Select } from '../../components/common/Select';
import { ConfirmDialog } from '../../components/common/ConfirmDialog';
import { PlusCircle, Search, Edit3, Trash2, Eye, MapPin, Filter } from 'lucide-react';
import { toast } from 'sonner';

export const ManageBooksPage = () => {
  const navigate = useNavigate();
  const [books, setBooks] = useState(initialBooks);
  const [searchTerm, setSearchTerm] = useState('');
  const [categoryFilter, setCategoryFilter] = useState('all');
  const [deleteModal, setDeleteModal] = useState({ isOpen: false, book: null });

  const filteredBooks = books.filter((b) => {
    const matchesSearch =
      b.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      b.author.toLowerCase().includes(searchTerm.toLowerCase()) ||
      b.bookNumber.toLowerCase().includes(searchTerm.toLowerCase()) ||
      b.isbn.includes(searchTerm);
    const matchesCat =
      categoryFilter === 'all' || b.category.toLowerCase() === categoryFilter.toLowerCase();
    return matchesSearch && matchesCat;
  });

  const handleDeleteConfirm = () => {
    if (deleteModal.book) {
      setBooks((prev) => prev.filter((b) => b.id !== deleteModal.book.id));
      toast.success(`Book "${deleteModal.book.title}" removed from catalog.`);
      setDeleteModal({ isOpen: false, book: null });
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-bold tracking-tight text-neutral-900 dark:text-neutral-100">
            Catalog Inventory Management
          </h1>
          <p className="text-xs sm:text-sm text-neutral-500 dark:text-neutral-400 mt-1">
            Browse, inspect, edit physical metadata, update copy quantities, and remove catalog entries.
          </p>
        </div>

        <Link to="/admin/books/new">
          <Button variant="primary" size="sm" leftIcon={<PlusCircle className="w-4 h-4" />}>
            Add New Volume
          </Button>
        </Link>
      </div>

      {/* Filter Row */}
      <div className="p-4 rounded-xl border border-neutral-200/80 bg-white dark:border-neutral-800 dark:bg-neutral-900 flex flex-col sm:flex-row gap-3">
        <div className="relative flex-1">
          <Search className="w-4 h-4 text-neutral-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Search by title, call number, author, or ISBN..."
            className="w-full h-10 rounded-lg border border-neutral-300 bg-white pl-9 pr-3 text-xs text-neutral-900 placeholder:text-neutral-400 focus:outline-none focus:ring-2 focus:ring-neutral-900 dark:border-neutral-800 dark:bg-neutral-900 dark:text-neutral-100"
          />
        </div>

        <div className="w-full sm:w-48">
          <Select
            value={categoryFilter}
            onChange={(e) => setCategoryFilter(e.target.value)}
          >
            <option value="all">All Categories</option>
            {initialCategories.map((c) => (
              <option key={c.id} value={c.slug}>
                {c.name}
              </option>
            ))}
          </Select>
        </div>
      </div>

      {/* Responsive Data Table */}
      <div className="rounded-2xl border border-neutral-200/80 bg-white dark:border-neutral-800 dark:bg-neutral-900 overflow-hidden shadow-xs">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-neutral-50 dark:bg-neutral-850 border-b border-neutral-200/80 dark:border-neutral-800 font-mono text-[11px] text-neutral-500 uppercase">
              <tr>
                <th className="py-3 px-4">Call No.</th>
                <th className="py-3 px-4">Title & Author</th>
                <th className="py-3 px-4">Category</th>
                <th className="py-3 px-4">Copies</th>
                <th className="py-3 px-4">Available</th>
                <th className="py-3 px-4">Shelf Location</th>
                <th className="py-3 px-4">Status</th>
                <th className="py-3 px-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-neutral-100 dark:divide-neutral-800">
              {filteredBooks.map((b) => (
                <tr key={b.id} className="hover:bg-neutral-50/50 dark:hover:bg-neutral-800/40 transition-colors">
                  <td className="py-3 px-4 font-mono font-medium text-neutral-500 whitespace-nowrap">
                    {b.bookNumber}
                  </td>
                  <td className="py-3 px-4 min-w-[240px]">
                    <div className="font-semibold text-neutral-900 dark:text-neutral-100 truncate">
                      {b.title}
                    </div>
                    <div className="text-[11px] text-neutral-500 truncate">{b.author}</div>
                  </td>
                  <td className="py-3 px-4 whitespace-nowrap text-neutral-600 dark:text-neutral-400">
                    {b.category}
                  </td>
                  <td className="py-3 px-4 font-mono tabular-nums text-neutral-900 dark:text-neutral-100">
                    {b.totalCopies}
                  </td>
                  <td className="py-3 px-4 font-mono tabular-nums font-semibold">
                    <span className={b.availableCopies > 0 ? 'text-emerald-600' : 'text-rose-600'}>
                      {b.availableCopies}
                    </span>
                  </td>
                  <td className="py-3 px-4 font-mono text-neutral-500 whitespace-nowrap">
                    Rack {b.rackNumber} · S{b.shelfNumber} · P{b.position}
                  </td>
                  <td className="py-3 px-4 whitespace-nowrap">
                    <span
                      className={`inline-flex items-center gap-1.5 px-2 py-0.5 rounded-full text-[10px] font-semibold ${
                        b.status === 'AVAILABLE'
                          ? 'bg-emerald-500/10 text-emerald-700 dark:text-emerald-400'
                          : b.status === 'RESERVED'
                          ? 'bg-amber-500/10 text-amber-700 dark:text-amber-400'
                          : 'bg-rose-500/10 text-rose-700 dark:text-rose-400'
                      }`}
                    >
                      <span className={`w-1.5 h-1.5 rounded-full ${b.status === 'AVAILABLE' ? 'bg-emerald-500' : 'bg-rose-500'}`} />
                      {b.status}
                    </span>
                  </td>
                  <td className="py-3 px-4 text-right whitespace-nowrap">
                    <div className="flex items-center justify-end gap-1.5">
                      <Link
                        to={`/books/${b.id}`}
                        className="p-1.5 text-neutral-400 hover:text-neutral-900 dark:hover:text-white rounded-lg transition-colors"
                        title="View Public Details"
                      >
                        <Eye className="w-4 h-4" />
                      </Link>
                      <Link
                        to={`/admin/books/${b.id}/edit`}
                        className="p-1.5 text-neutral-400 hover:text-neutral-900 dark:hover:text-white rounded-lg transition-colors"
                        title="Edit Book Specs"
                      >
                        <Edit3 className="w-4 h-4" />
                      </Link>
                      <button
                        onClick={() => setDeleteModal({ isOpen: true, book: b })}
                        className="p-1.5 text-neutral-400 hover:text-rose-600 rounded-lg transition-colors cursor-pointer"
                        title="Delete Book"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Delete Confirmation Modal */}
      <ConfirmDialog
        isOpen={deleteModal.isOpen}
        onClose={() => setDeleteModal({ isOpen: false, book: null })}
        onConfirm={handleDeleteConfirm}
        isDestructive={true}
        title="Delete Book from Library Catalog?"
        message={`Are you sure you want to remove "${deleteModal.book?.title}" (${deleteModal.book?.bookNumber})? This will de-index the volume and remove it from shelf tracking.`}
        confirmText="Delete Book"
      />
    </div>
  );
};

export default ManageBooksPage;
