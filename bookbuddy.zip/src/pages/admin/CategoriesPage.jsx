import React, { useState } from 'react';
import { initialCategories } from '../../data/categories';
import { Button } from '../../components/common/Button';
import { Input } from '../../components/common/Input';
import { Modal } from '../../components/common/Modal';
import { FolderTree, Plus, Search, Trash2 } from 'lucide-react';
import { toast } from 'sonner';

export const CategoriesPage = () => {
  const [categories, setCategories] = useState(initialCategories);
  const [searchTerm, setSearchTerm] = useState('');
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [catName, setCatName] = useState('');
  const [catDesc, setCatDesc] = useState('');

  const filtered = categories.filter((c) =>
    c.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    c.description.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const handleAdd = (e) => {
    e.preventDefault();
    if (!catName.trim()) return;

    const newCat = {
      id: `cat-${Date.now()}`,
      name: catName.trim(),
      slug: catName.toLowerCase().replace(/\s+/g, '-'),
      description: catDesc.trim() || 'Academic subject discipline.',
      bookCount: 0,
    };
    setCategories([...categories, newCat]);
    toast.success(`Category "${catName}" added!`);
    setIsModalOpen(false);
    setCatName('');
    setCatDesc('');
  };

  const handleDelete = (id, name) => {
    setCategories((prev) => prev.filter((c) => c.id !== id));
    toast.info(`Category "${name}" removed.`);
  };

  return (
    <div className="space-y-6 max-w-5xl">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-bold tracking-tight text-neutral-900 dark:text-neutral-100">
            Subject Classification & Categories
          </h1>
          <p className="text-xs sm:text-sm text-neutral-500 dark:text-neutral-400 mt-1">
            Organize catalog disciplines according to university departmental syllabi.
          </p>
        </div>

        <Button
          variant="primary"
          size="sm"
          leftIcon={<Plus className="w-4 h-4" />}
          onClick={() => setIsModalOpen(true)}
        >
          Add Discipline
        </Button>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
        {filtered.map((cat) => (
          <div
            key={cat.id}
            className="p-5 rounded-2xl border border-neutral-200/80 bg-white dark:border-neutral-800 dark:bg-neutral-900 shadow-xs flex flex-col justify-between space-y-3"
          >
            <div>
              <div className="flex items-center justify-between">
                <h3 className="font-bold text-sm text-neutral-900 dark:text-neutral-100">{cat.name}</h3>
                <span className="text-[11px] font-mono text-neutral-400 font-semibold">
                  {cat.bookCount} Holdings
                </span>
              </div>
              <p className="text-xs text-neutral-500 line-clamp-2 mt-1">{cat.description}</p>
            </div>

            <div className="flex items-center justify-end gap-2 pt-2 border-t border-neutral-100 dark:border-neutral-800">
              <button
                onClick={() => handleDelete(cat.id, cat.name)}
                className="p-1.5 text-neutral-400 hover:text-rose-600 rounded-lg transition-colors cursor-pointer"
                title="Remove Category"
              >
                <Trash2 className="w-4 h-4" />
              </button>
            </div>
          </div>
        ))}
      </div>

      <Modal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        title="Add Subject Category"
        description="Register a new academic discipline in the library catalog"
      >
        <form onSubmit={handleAdd} className="space-y-4">
          <Input
            label="Category Name"
            placeholder="e.g. Distributed Computing"
            value={catName}
            onChange={(e) => setCatName(e.target.value)}
            required
          />
          <div>
            <label className="block text-xs font-semibold text-neutral-700 dark:text-neutral-300 mb-1.5">
              Subject Scope
            </label>
            <textarea
              rows={3}
              value={catDesc}
              onChange={(e) => setCatDesc(e.target.value)}
              placeholder="Scope of courses and technical domains included in this classification..."
              className="w-full rounded-xl border border-neutral-300 bg-white p-3 text-xs text-neutral-900 focus:outline-none focus:ring-2 focus:ring-neutral-900 dark:border-neutral-800 dark:bg-neutral-900 dark:text-neutral-100"
            />
          </div>
          <div className="flex items-center justify-end gap-3 pt-3 border-t border-neutral-100 dark:border-neutral-800">
            <Button variant="outline" size="sm" onClick={() => setIsModalOpen(false)}>
              Cancel
            </Button>
            <Button type="submit" variant="primary" size="sm">
              Save Category
            </Button>
          </div>
        </form>
      </Modal>
    </div>
  );
};

export default CategoriesPage;
