import React, { useState } from 'react';
import { Button } from '../../components/common/Button';
import { Search, ArrowDownLeft, ArrowUpRight, Clock, XCircle, RotateCcw } from 'lucide-react';
import { format, subDays, subHours } from 'date-fns';

export const TransactionsPage = () => {
  const [filterType, setFilterType] = useState('ALL');
  const now = new Date();

  const auditTransactions = [
    { id: 'TXN-9021', type: 'ISSUE', reader: 'Vishal Gayathri (student001)', book: 'Clean Code (BK-0001)', date: subHours(now, 2).toISOString(), staff: 'Sarah Jenkins', status: 'SUCCESS' },
    { id: 'TXN-9020', type: 'RETURN', reader: 'Arun Patel (user-5)', book: 'Atomic Habits (BK-0007)', date: subHours(now, 5).toISOString(), staff: 'Sarah Jenkins', status: 'SUCCESS' },
    { id: 'TXN-9019', type: 'RENEWAL', reader: 'Dr. Priya Sharma (teacher001)', book: 'Designing Data-Intensive Applications (BK-0002)', date: subDays(now, 1).toISOString(), staff: 'System Auto-Renew', status: 'SUCCESS' },
    { id: 'TXN-9018', type: 'HOLD_PLACED', reader: 'Elena Rostova (user-6)', book: 'Hands-On Machine Learning (BK-0020)', date: subDays(now, 1).toISOString(), staff: 'Self Service Web', status: 'PENDING' },
    { id: 'TXN-9017', type: 'HOLD_CANCELLED', reader: 'Vishal Gayathri (student001)', book: 'System Design Interview (BK-0005)', date: subDays(now, 2).toISOString(), staff: 'Self Service Web', status: 'CANCELLED' },
    { id: 'TXN-9016', type: 'ISSUE', reader: 'Elena Rostova (user-6)', book: 'Deep Learning (BK-0013)', date: subDays(now, 3).toISOString(), staff: 'Marcus Vance', status: 'SUCCESS' },
    { id: 'TXN-9015', type: 'RETURN', reader: 'Vishal Gayathri (student001)', book: 'Introduction to Algorithms (BK-0003)', date: subDays(now, 4).toISOString(), staff: 'Sarah Jenkins', status: 'OVERDUE_PAID' },
  ];

  const filtered = filterType === 'ALL'
    ? auditTransactions
    : auditTransactions.filter((t) => t.type === filterType);

  const getTypeBadge = (type) => {
    switch (type) {
      case 'ISSUE':
        return <span className="text-sky-600 font-semibold font-mono">LOAN ISSUE</span>;
      case 'RETURN':
        return <span className="text-emerald-600 font-semibold font-mono">RETURN CHECKIN</span>;
      case 'RENEWAL':
        return <span className="text-amber-600 font-semibold font-mono">RENEWAL</span>;
      case 'HOLD_PLACED':
        return <span className="text-purple-600 font-semibold font-mono">HOLD PLACED</span>;
      case 'HOLD_CANCELLED':
      default:
        return <span className="text-neutral-500 font-semibold font-mono">CANCELLED</span>;
    }
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl sm:text-3xl font-bold tracking-tight text-neutral-900 dark:text-neutral-100">
          Circulation Audit & Transaction Log
        </h1>
        <p className="text-xs sm:text-sm text-neutral-500 dark:text-neutral-400 mt-1">
          Immutable institutional activity record of checkouts, returns, hold queue modifications, and staff actions.
        </p>
      </div>

      {/* Filter Tabs */}
      <div className="flex items-center gap-1.5 p-1 bg-neutral-100 dark:bg-neutral-800 rounded-xl overflow-x-auto text-xs font-semibold w-fit">
        {['ALL', 'ISSUE', 'RETURN', 'RENEWAL', 'HOLD_PLACED'].map((t) => (
          <button
            key={t}
            onClick={() => setFilterType(t)}
            className={`px-3 py-1.5 rounded-lg transition-colors cursor-pointer whitespace-nowrap ${
              filterType === t
                ? 'bg-white text-neutral-900 shadow-xs dark:bg-neutral-900 dark:text-white'
                : 'text-neutral-500 hover:text-neutral-900 dark:hover:text-white'
            }`}
          >
            {t.replace('_', ' ')}
          </button>
        ))}
      </div>

      <div className="rounded-2xl border border-neutral-200/80 bg-white dark:border-neutral-800 dark:bg-neutral-900 overflow-hidden shadow-xs">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-neutral-50 dark:bg-neutral-850 border-b border-neutral-200/80 dark:border-neutral-800 font-mono text-[11px] text-neutral-500 uppercase">
              <tr>
                <th className="py-3 px-4">Audit ID</th>
                <th className="py-3 px-4">Transaction Event</th>
                <th className="py-3 px-4">Patron</th>
                <th className="py-3 px-4">Catalog Volume</th>
                <th className="py-3 px-4">Timestamp</th>
                <th className="py-3 px-4">Processed By</th>
                <th className="py-3 px-4 text-right">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-neutral-100 dark:divide-neutral-800">
              {filtered.map((t) => (
                <tr key={t.id} className="hover:bg-neutral-50/50 dark:hover:bg-neutral-800/40">
                  <td className="py-3 px-4 font-mono font-medium text-neutral-400">{t.id}</td>
                  <td className="py-3 px-4">{getTypeBadge(t.type)}</td>
                  <td className="py-3 px-4 text-neutral-800 dark:text-neutral-200">{t.reader}</td>
                  <td className="py-3 px-4 font-semibold text-neutral-900 dark:text-neutral-100">{t.book}</td>
                  <td className="py-3 px-4 font-mono text-neutral-500">
                    {format(new Date(t.date), 'MMM dd, HH:mm')}
                  </td>
                  <td className="py-3 px-4 text-neutral-500">{t.staff}</td>
                  <td className="py-3 px-4 text-right font-mono text-[10px]">
                    <span className="px-2 py-0.5 rounded bg-neutral-100 dark:bg-neutral-800 font-semibold text-neutral-600 dark:text-neutral-300">
                      {t.status}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default TransactionsPage;
