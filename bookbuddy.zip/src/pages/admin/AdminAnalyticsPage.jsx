import React, { useEffect } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import {
  fetchOverviewMetrics,
  fetchBorrowingTrends,
  fetchCategoryDistribution,
  fetchPopularBooks,
} from '../../store/slices/analyticsSlice';
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  PieChart,
  Pie,
  Cell,
  LineChart,
  Line,
  CartesianGrid,
  Legend,
} from 'recharts';
import { BarChart3, TrendingUp, BookOpen, AlertTriangle } from 'lucide-react';

export const AdminAnalyticsPage = () => {
  const dispatch = useDispatch();
  const { overview, borrowingTrends, categories, popularBooks } = useSelector(
    (state) => state.analytics
  );

  useEffect(() => {
    dispatch(fetchOverviewMetrics());
    dispatch(fetchBorrowingTrends());
    dispatch(fetchCategoryDistribution());
    dispatch(fetchPopularBooks());
  }, [dispatch]);

  const COLORS = ['#d97706', '#0284c7', '#10b981', '#8b5cf6', '#ef4444', '#64748b'];

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-2xl sm:text-3xl font-bold tracking-tight text-neutral-900 dark:text-neutral-100">
          Circulation Analytics & Utilization Insights
        </h1>
        <p className="text-xs sm:text-sm text-neutral-500 dark:text-neutral-400 mt-1">
          Institutional metrics across checkout velocity, subject allocation, return punctuality, and patron engagement.
        </p>
      </div>

      {/* Analytics Charts Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Circulation Volume Chart */}
        <div className="p-6 rounded-2xl border border-neutral-200/80 bg-white dark:border-neutral-800 dark:bg-neutral-900 shadow-xs space-y-4">
          <div>
            <h3 className="font-bold text-sm text-neutral-900 dark:text-neutral-100">
              6-Month Loan & Return Velocity
            </h3>
            <p className="text-[11px] text-neutral-500">Transaction counts recorded at circulation desks</p>
          </div>

          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={borrowingTrends}>
                <CartesianGrid strokeDasharray="3 3" opacity={0.15} />
                <XAxis dataKey="month" tick={{ fontSize: 11 }} />
                <YAxis tick={{ fontSize: 11 }} />
                <Tooltip
                  contentStyle={{
                    backgroundColor: '#18181b',
                    borderColor: '#27272a',
                    borderRadius: '8px',
                    fontSize: '12px',
                    color: '#fff',
                  }}
                />
                <Legend wrapperStyle={{ fontSize: '11px', paddingTop: '8px' }} />
                <Line type="monotone" dataKey="issues" stroke="#d97706" strokeWidth={2} name="New Issues" />
                <Line type="monotone" dataKey="returns" stroke="#10b981" strokeWidth={2} name="Returns Logged" />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Category Allocation Pie */}
        <div className="p-6 rounded-2xl border border-neutral-200/80 bg-white dark:border-neutral-800 dark:bg-neutral-900 shadow-xs space-y-4">
          <div>
            <h3 className="font-bold text-sm text-neutral-900 dark:text-neutral-100">
              Holdings by Academic Discipline
            </h3>
            <p className="text-[11px] text-neutral-500">Proportional catalog distribution</p>
          </div>

          <div className="h-64 w-full flex items-center justify-center">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={categories}
                  dataKey="value"
                  nameKey="name"
                  cx="50%"
                  cy="50%"
                  outerRadius={80}
                  innerRadius={50}
                  paddingAngle={3}
                >
                  {categories.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip
                  contentStyle={{
                    backgroundColor: '#18181b',
                    borderColor: '#27272a',
                    borderRadius: '8px',
                    fontSize: '12px',
                    color: '#fff',
                  }}
                />
              </PieChart>
            </ResponsiveContainer>
          </div>

          <div className="flex flex-wrap items-center justify-center gap-3 text-xs">
            {categories.map((c, i) => (
              <div key={i} className="flex items-center gap-1 font-mono text-[11px]">
                <span className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: COLORS[i % COLORS.length] }} />
                <span className="text-neutral-600 dark:text-neutral-400">{c.name} ({c.value}%)</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default AdminAnalyticsPage;
