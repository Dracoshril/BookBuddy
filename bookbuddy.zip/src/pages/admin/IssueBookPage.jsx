import React, { useState } from 'react';
import { initialBooks } from '../../data/books';
import { initialUsers } from '../../data/users';
import { Button } from '../../components/common/Button';
import { Input } from '../../components/common/Input';
import { Select } from '../../components/common/Select';
import { BookCover } from '../../components/books/BookCover';
import { ArrowUpRight, CheckCircle2, User, BookOpen, Calendar } from 'lucide-react';
import { addDays, format } from 'date-fns';
import { toast } from 'sonner';

export const IssueBookPage = () => {
  const [selectedUserId, setSelectedUserId] = useState(initialUsers[0].id);
  const [selectedBookId, setSelectedBookId] = useState(initialBooks[0].id);
  const [durationDays, setDurationDays] = useState(14);
  const [notes, setNotes] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  const selectedUser = initialUsers.find((u) => u.id === selectedUserId) || initialUsers[0];
  const selectedBook = initialBooks.find((b) => b.id === selectedBookId) || initialBooks[0];

  const dueDate = addDays(new Date(), Number(durationDays));
  const isAvailable = selectedBook.availableCopies > 0;

  const handleIssue = (e) => {
    e.preventDefault();
    if (!isAvailable) {
      toast.error('Cannot issue: zero physical copies currently available on shelf.');
      return;
    }

    setIsSubmitting(true);
    setTimeout(() => {
      setIsSubmitting(false);
      toast.success(
        `Issued "${selectedBook.title}" to ${selectedUser.name}! Return due by ${format(dueDate, 'MMM dd, yyyy')}.`
      );
      setNotes('');
    }, 400);
  };

  return (
    <div className="max-w-3xl mx-auto space-y-6">
      <div>
        <h1 className="text-2xl font-bold tracking-tight text-neutral-900 dark:text-neutral-100">
          Circulation Desk — Issue Physical Book Loan
        </h1>
        <p className="text-xs text-neutral-500 mt-1">
          Perform patron checkout validation, assign due date, and decrement shelf copy count.
        </p>
      </div>

      <div className="p-8 rounded-3xl border border-neutral-200/80 bg-white dark:border-neutral-800 dark:bg-neutral-900 shadow-sm space-y-6">
        <form onSubmit={handleIssue} className="space-y-6">
          {/* Step 1: Select Reader */}
          <div className="space-y-3">
            <h3 className="text-xs font-mono uppercase tracking-wider text-neutral-400 font-semibold border-b border-neutral-100 dark:border-neutral-800 pb-1">
              Step 1: Select Patron / Reader
            </h3>
            <Select
              label="Patron Directory"
              value={selectedUserId}
              onChange={(e) => setSelectedUserId(e.target.value)}
            >
              {initialUsers.map((u) => (
                <option key={u.id} value={u.id}>
                  {u.name} ({u.studentId || u.email}) — {u.role}
                </option>
              ))}
            </Select>
            <div className="p-3 rounded-xl bg-neutral-50 dark:bg-neutral-800/60 text-xs text-neutral-600 dark:text-neutral-400 font-mono flex items-center justify-between">
              <span>Department: {selectedUser.department}</span>
              <span>Active Loans: 2 / {selectedUser.role === 'TEACHER' ? 8 : 4} Limit</span>
            </div>
          </div>

          {/* Step 2: Select Book */}
          <div className="space-y-3">
            <h3 className="text-xs font-mono uppercase tracking-wider text-neutral-400 font-semibold border-b border-neutral-100 dark:border-neutral-800 pb-1">
              Step 2: Select Volume to Checkout
            </h3>
            <Select
              label="Library Catalog"
              value={selectedBookId}
              onChange={(e) => setSelectedBookId(e.target.value)}
            >
              {initialBooks.map((b) => (
                <option key={b.id} value={b.id}>
                  [{b.bookNumber}] {b.title} ({b.availableCopies} available)
                </option>
              ))}
            </Select>

            <div className="flex items-center gap-3 p-3 rounded-xl border border-neutral-200/80 dark:border-neutral-700/80 bg-white dark:bg-neutral-850">
              <div className="w-10 shrink-0">
                <BookCover
                  title={selectedBook.title}
                  author={selectedBook.author}
                  coverGradient={selectedBook.coverGradient}
                  aspectRatio="aspect-[2/3]"
                />
              </div>
              <div className="min-w-0 flex-1 text-xs">
                <span className="font-semibold text-neutral-900 dark:text-neutral-100 block truncate">
                  {selectedBook.title}
                </span>
                <span className="text-[11px] text-neutral-500 font-mono block">
                  Rack {selectedBook.rackNumber} · Shelf {selectedBook.shelfNumber} · Pos {selectedBook.position}
                </span>
                <span
                  className={`inline-block font-semibold mt-1 ${
                    isAvailable ? 'text-emerald-600' : 'text-rose-600'
                  }`}
                >
                  {isAvailable ? `${selectedBook.availableCopies} copies on shelf` : 'Currently unavailable'}
                </span>
              </div>
            </div>
          </div>

          {/* Step 3: Duration */}
          <div className="space-y-3">
            <h3 className="text-xs font-mono uppercase tracking-wider text-neutral-400 font-semibold border-b border-neutral-100 dark:border-neutral-800 pb-1">
              Step 3: Loan Duration & Return Terms
            </h3>
            <div className="grid grid-cols-3 gap-2">
              {[7, 14, 28].map((d) => (
                <button
                  key={d}
                  type="button"
                  onClick={() => setDurationDays(d)}
                  className={`py-2 px-3 text-xs font-medium rounded-lg border transition-all cursor-pointer ${
                    durationDays === d
                      ? 'border-neutral-900 bg-neutral-900 text-white dark:border-white dark:bg-white dark:text-neutral-900'
                      : 'border-neutral-300 dark:border-neutral-700 text-neutral-700 dark:text-neutral-300'
                  }`}
                >
                  {d} Days Loan
                </button>
              ))}
            </div>

            <p className="text-xs font-mono text-neutral-500">
              Expected Return Due Date: <strong>{format(dueDate, 'EEEE, MMM dd, yyyy')}</strong>
            </p>
          </div>

          <Button
            type="submit"
            variant="primary"
            size="md"
            className="w-full"
            disabled={!isAvailable || isSubmitting}
            isLoading={isSubmitting}
            leftIcon={<ArrowUpRight className="w-4 h-4" />}
          >
            Confirm & Issue Book Loan
          </Button>
        </form>
      </div>
    </div>
  );
};

export default IssueBookPage;
