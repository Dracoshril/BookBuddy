import React, { useState, useCallback } from 'react';
import { useDropzone } from 'react-dropzone';
import Papa from 'papaparse';
import * as XLSX from 'xlsx';
import { Button } from '../../components/common/Button';
import { initialBooks } from '../../data/books';
import { FileSpreadsheet, Upload, CheckCircle2, AlertTriangle, Download, ArrowRight } from 'lucide-react';
import { toast } from 'sonner';

export const ImportBooksPage = () => {
  const [fileData, setFileData] = useState(null);
  const [validRecords, setValidRecords] = useState([]);
  const [errors, setErrors] = useState([]);
  const [isProcessing, setIsProcessing] = useState(false);
  const [isImported, setIsImported] = useState(false);

  const processRows = (rows) => {
    const valid = [];
    const errs = [];

    rows.forEach((row, idx) => {
      const rowNum = idx + 2; // header is row 1
      const title = row.title || row.Title || row['Book Title'];
      const author = row.author || row.Author;
      const isbn = row.isbn || row.ISBN;
      const bookNumber = row.bookNumber || row['Book Number'] || row.CallNumber;
      const totalCopies = Number(row.totalCopies || row['Total Copies'] || 1);
      const availableCopies = Number(row.availableCopies || row['Available Copies'] || totalCopies);

      if (!title) {
        errs.push({ row: rowNum, error: 'Missing required title field', data: row });
        return;
      }
      if (!author) {
        errs.push({ row: rowNum, error: 'Missing required author field', data: row });
        return;
      }
      if (isNaN(totalCopies) || totalCopies < 1) {
        errs.push({ row: rowNum, error: 'Total copies must be a positive integer', data: row });
        return;
      }
      if (availableCopies > totalCopies) {
        errs.push({ row: rowNum, error: 'Available copies cannot exceed total copies', data: row });
        return;
      }

      valid.push({
        id: `imp-${Date.now()}-${idx}`,
        bookNumber: bookNumber || `BK-IMP-${idx + 1}`,
        title,
        author,
        publisher: row.publisher || row.Publisher || 'University Press',
        isbn: isbn || `978${Math.floor(1000000000 + Math.random() * 9000000000)}`,
        category: row.category || row.Category || 'General',
        totalCopies,
        availableCopies,
        status: availableCopies > 0 ? 'AVAILABLE' : 'ISSUED',
        rackNumber: Number(row.rackNumber || 1),
        section: row.section || 'General',
        shelfNumber: Number(row.shelfNumber || 1),
        position: Number(row.position || idx + 1),
      });
    });

    setValidRecords(valid);
    setErrors(errs);
  };

  const onDrop = useCallback((acceptedFiles) => {
    const file = acceptedFiles[0];
    if (!file) return;

    setFileData({ name: file.name, size: (file.size / 1024).toFixed(1) + ' KB' });
    setIsProcessing(true);
    setIsImported(false);

    if (file.name.endsWith('.csv')) {
      Papa.parse(file, {
        header: true,
        skipEmptyLines: true,
        complete: (results) => {
          processRows(results.data);
          setIsProcessing(false);
        },
        error: (err) => {
          toast.error('Failed to parse CSV: ' + err.message);
          setIsProcessing(false);
        },
      });
    } else {
      // Excel parse (.xlsx)
      const reader = new FileReader();
      reader.onload = (e) => {
        try {
          const data = new Uint8Array(e.target.result);
          const workbook = XLSX.read(data, { type: 'array' });
          const firstSheet = workbook.Sheets[workbook.SheetNames[0]];
          const json = XLSX.utils.sheet_to_json(firstSheet);
          processRows(json);
        } catch (err) {
          toast.error('Failed to parse Excel spreadsheet');
        } finally {
          setIsProcessing(false);
        }
      };
      reader.readAsArrayBuffer(file);
    }
  }, []);

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    accept: {
      'text/csv': ['.csv'],
      'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet': ['.xlsx'],
    },
    maxFiles: 1,
  });

  const handleConfirmImport = () => {
    toast.success(`Successfully imported ${validRecords.length} records into the library catalog!`);
    setIsImported(true);
  };

  const handleDownloadSample = () => {
    const sample = [
      {
        'Book Number': 'BK-5001',
        Title: 'Introduction to Distributed Algorithms',
        Author: 'Gerard Tel',
        ISBN: '9780521794831',
        Category: 'Computer Networks',
        'Total Copies': 4,
        'Available Copies': 3,
        rackNumber: 3,
        section: 'Distributed Systems',
        shelfNumber: 2,
        position: 12,
      },
      {
        'Book Number': 'BK-5002',
        Title: 'Advanced Programming in the UNIX Environment',
        Author: 'W. Richard Stevens',
        ISBN: '9780321637734',
        Category: 'Programming',
        'Total Copies': 3,
        'Available Copies': 2,
        rackNumber: 2,
        section: 'Operating Systems',
        shelfNumber: 1,
        position: 8,
      },
    ];
    const csv = Papa.unparse(sample);
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', 'bookbuddy_catalog_template.csv');
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="space-y-8 max-w-5xl">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-bold tracking-tight text-neutral-900 dark:text-neutral-100">
            Batch Catalog Ingestion (CSV / Excel)
          </h1>
          <p className="text-xs sm:text-sm text-neutral-500 dark:text-neutral-400 mt-1">
            Upload institutional spreadsheets to bulk catalog new acquisitions with automated schema validation.
          </p>
        </div>

        <Button
          variant="outline"
          size="sm"
          leftIcon={<Download className="w-3.5 h-3.5" />}
          onClick={handleDownloadSample}
        >
          Download Template (.CSV)
        </Button>
      </div>

      {/* Drag & Drop Zone */}
      <div
        {...getRootProps()}
        className={`p-10 rounded-3xl border-2 border-dashed text-center transition-all cursor-pointer ${
          isDragActive
            ? 'border-amber-500 bg-amber-500/5'
            : 'border-neutral-300 dark:border-neutral-700 bg-white dark:bg-neutral-900 hover:border-neutral-400'
        }`}
      >
        <input {...getInputProps()} />
        <div className="w-12 h-12 rounded-2xl bg-neutral-100 dark:bg-neutral-800 text-neutral-600 dark:text-neutral-300 flex items-center justify-center mx-auto mb-3">
          <Upload className="w-6 h-6" />
        </div>
        <h3 className="font-bold text-base text-neutral-900 dark:text-neutral-100">
          Drag & drop your CSV or Excel file here
        </h3>
        <p className="text-xs text-neutral-500 mt-1">
          Supports .csv and .xlsx formats up to 5,000 records per upload batch.
        </p>
      </div>

      {/* Parsing Summary */}
      {fileData && (
        <div className="p-6 rounded-2xl border border-neutral-200/80 bg-white dark:border-neutral-800 dark:bg-neutral-900 shadow-xs space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-neutral-100 dark:border-neutral-800">
            <div>
              <span className="font-semibold text-sm text-neutral-900 dark:text-neutral-100">{fileData.name}</span>
              <span className="text-xs text-neutral-400 ml-2 font-mono">{fileData.size}</span>
            </div>
            <div className="flex items-center gap-3">
              <span className="inline-flex items-center gap-1.5 text-xs text-emerald-600 font-semibold font-mono">
                <CheckCircle2 className="w-4 h-4" />
                {validRecords.length} Valid Records
              </span>
              {errors.length > 0 && (
                <span className="inline-flex items-center gap-1.5 text-xs text-rose-600 font-semibold font-mono">
                  <AlertTriangle className="w-4 h-4" />
                  {errors.length} Validation Errors
                </span>
              )}
            </div>
          </div>

          {/* Error Table if any */}
          {errors.length > 0 && (
            <div className="p-4 rounded-xl bg-rose-500/10 border border-rose-500/20 text-xs text-rose-700 dark:text-rose-300 space-y-2">
              <h5 className="font-bold">Errors Detected in Uploaded Rows:</h5>
              <ul className="list-disc pl-5 space-y-1 font-mono text-[11px]">
                {errors.slice(0, 5).map((e, idx) => (
                  <li key={idx}>
                    Row {e.row}: {e.error}
                  </li>
                ))}
              </ul>
            </div>
          )}

          {/* Valid Records Preview */}
          {validRecords.length > 0 && (
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <h4 className="font-bold text-xs uppercase tracking-wider text-neutral-500 font-mono">
                  Validated Preview (First 5 Items)
                </h4>
                {!isImported ? (
                  <Button variant="primary" size="sm" onClick={handleConfirmImport}>
                    Import {validRecords.length} Records
                  </Button>
                ) : (
                  <span className="text-xs font-semibold text-emerald-600 font-mono flex items-center gap-1">
                    <CheckCircle2 className="w-4 h-4" />
                    Ingested into Catalog
                  </span>
                )}
              </div>

              <div className="overflow-x-auto rounded-xl border border-neutral-200 dark:border-neutral-800">
                <table className="w-full text-left text-xs">
                  <thead className="bg-neutral-50 dark:bg-neutral-800 text-[10px] font-mono uppercase text-neutral-400">
                    <tr>
                      <th className="p-2.5">Call No.</th>
                      <th className="p-2.5">Title</th>
                      <th className="p-2.5">Author</th>
                      <th className="p-2.5">Category</th>
                      <th className="p-2.5">Copies</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-neutral-100 dark:divide-neutral-800">
                    {validRecords.slice(0, 5).map((r, i) => (
                      <tr key={i}>
                        <td className="p-2.5 font-mono text-neutral-400">{r.bookNumber}</td>
                        <td className="p-2.5 font-semibold text-neutral-900 dark:text-neutral-100">{r.title}</td>
                        <td className="p-2.5 text-neutral-500">{r.author}</td>
                        <td className="p-2.5 text-neutral-500">{r.category}</td>
                        <td className="p-2.5 font-mono">{r.availableCopies} / {r.totalCopies}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
};

export default ImportBooksPage;
