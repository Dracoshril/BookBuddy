import React, { useState } from 'react';
import { initialAuthors } from '../../data/authors';
import { Button } from '../../components/common/Button';
import { Input } from '../../components/common/Input';
import { Modal } from '../../components/common/Modal';
import { Users, Plus, Search, Edit3, Trash2 } from 'lucide-react';
import { toast } from 'sonner';

export const AuthorsPage = () => {
  const [authors, setAuthors] = useState(initialAuthors);
  const [searchTerm, setSearchTerm] = useState('');
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [authorName, setAuthorName] = useState('');
  const [authorBio, setAuthorBio] = useState('');

  const filteredAuthors = authors.filter(
    (a) =>
      a.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      a.bio.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const handleAddAuthor = (e) => {
    e.preventDefault();
    if (!authorName.trim()) return;

    const newAuth = {
      id: `auth-${Date.now()}`,
      name: authorName.trim(),
      bio: authorBio.trim() || 'Author in university collections.',
      bookCount: 1,
    };
    setAuthors([newAuth, ...authors]);
    toast.success(`Author "${authorName}" added to directory!`);
    setIsModalOpen(false);
    setAuthorName('');
    setAuthorBio('');
  };

  const handleDelete = (id, name) => {
    setAuthors((prev) => prev.filter((a) => a.id !== id));
    toast.info(`Author "${name}" removed.`);
  };

  return (
    <div className="space-y-6 max-w-5xl">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-bold tracking-tight text-neutral-900 dark:text-neutral-100">
            Authors Directory
          </h1>
          <p className="text-xs sm:text-sm text-neutral-500 dark:text-neutral-400 mt-1">
            Manage author bibliographies, biographic profiles, and linked library holdings.
          </p>
        </div>

        <Button
          variant="primary"
          size="sm"
          leftIcon={<Plus className="w-4 h-4" />}
          onClick={() => setIsModalOpen(true)}
        >
          Add Author
        </Button>
      </div>

      <div className="relative">
        <Search className="w-4 h-4 text-neutral-400 absolute left-3 top-1/2 -translate-y-1/2" />
        <input
          type="text"
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          placeholder="Search authors..."
          className="w-full h-10 rounded-xl border border-neutral-300 bg-white pl-9 pr-3 text-xs text-neutral-900 placeholder:text-neutral-400 focus:outline-none focus:ring-2 focus:ring-neutral-900 dark:border-neutral-800 dark:bg-neutral-900 dark:text-neutral-100"
        />
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
        {filteredAuthors.map((author) => (
          <div
            key={author.id}
            className="p-5 rounded-2xl border border-neutral-200/80 bg-white dark:border-neutral-800 dark:bg-neutral-900 shadow-xs flex flex-col justify-between space-y-3"
          >
            <div>
              <div className="flex items-center justify-between">
                <h3 className="font-bold text-sm text-neutral-900 dark:text-neutral-100">{author.name}</h3>
                <span className="text-[11px] font-mono text-neutral-400 font-semibold">
                  {author.bookCount} Books
                </span>
              </div>
              <p className="text-xs text-neutral-500 line-clamp-3 mt-1 leading-relaxed">{author.bio}</p>
            </div>

            <div className="flex items-center justify-end gap-2 pt-2 border-t border-neutral-100 dark:border-neutral-800">
              <button
                onClick={() => handleDelete(author.id, author.name)}
                className="p-1.5 text-neutral-400 hover:text-rose-600 rounded-lg transition-colors cursor-pointer"
                title="Remove Author"
              >
                <Trash2 className="w-4 h-4" />
              </button>
            </div>
          </div>
        ))}
      </div>

      <Modal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        title="Add New Author"
        description="Register a new academic author to the directory"
      >
        <form onSubmit={handleAddAuthor} className="space-y-4">
          <Input
            label="Author Full Name"
            placeholder="e.g. Donald E. Knuth"
            value={authorName}
            onChange={(e) => setAuthorName(e.target.value)}
            required
          />
          <div>
            <label className="block text-xs font-semibold text-neutral-700 dark:text-neutral-300 mb-1.5">
              Biographical Profile
            </label>
            <textarea
              rows={3}
              value={authorBio}
              onChange={(e) => setAuthorBio(e.target.value)}
              placeholder="Academic affiliation, research contributions, notable achievements..."
              className="w-full rounded-xl border border-neutral-300 bg-white p-3 text-xs text-neutral-900 focus:outline-none focus:ring-2 focus:ring-neutral-900 dark:border-neutral-800 dark:bg-neutral-900 dark:text-neutral-100"
            />
          </div>
          <div className="flex items-center justify-end gap-3 pt-3 border-t border-neutral-100 dark:border-neutral-800">
            <Button variant="outline" size="sm" onClick={() => setIsModalOpen(false)}>
              Cancel
            </Button>
            <Button type="submit" variant="primary" size="sm">
              Save Author
            </Button>
          </div>
        </form>
      </Modal>
    </div>
  );
};

export default AuthorsPage;
