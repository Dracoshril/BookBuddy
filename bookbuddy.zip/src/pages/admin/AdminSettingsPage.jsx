import React, { useState } from 'react';
import { storage } from '../../utils/storage';
import { STORAGE_KEYS, DEFAULT_LIBRARY_SETTINGS } from '../../utils/constants';
import { Button } from '../../components/common/Button';
import { Input } from '../../components/common/Input';
import { Settings, Save, RotateCcw } from 'lucide-react';
import { toast } from 'sonner';

export const AdminSettingsPage = () => {
  const [settings, setSettings] = useState(() => {
    return storage.get(STORAGE_KEYS.SETTINGS, DEFAULT_LIBRARY_SETTINGS);
  });

  const [isSaving, setIsSaving] = useState(false);

  const handleSave = (e) => {
    e.preventDefault();
    setIsSaving(true);
    setTimeout(() => {
      storage.set(STORAGE_KEYS.SETTINGS, settings);
      setIsSaving(false);
      toast.success('Library institutional circulation parameters updated and persisted!');
    }, 300);
  };

  const handleReset = () => {
    setSettings(DEFAULT_LIBRARY_SETTINGS);
    storage.set(STORAGE_KEYS.SETTINGS, DEFAULT_LIBRARY_SETTINGS);
    toast.info('Restored default university circulation policies.');
  };

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-bold tracking-tight text-neutral-900 dark:text-neutral-100">
            Institutional Library Settings & Policies
          </h1>
          <p className="text-xs sm:text-sm text-neutral-500 dark:text-neutral-400 mt-1">
            Configure campus operating hours, student loan quotas, fine assessments, and hold shelf expiration limits.
          </p>
        </div>

        <Button
          variant="outline"
          size="sm"
          leftIcon={<RotateCcw className="w-3.5 h-3.5" />}
          onClick={handleReset}
        >
          Reset Defaults
        </Button>
      </div>

      <div className="p-8 rounded-3xl border border-neutral-200/80 bg-white dark:border-neutral-800 dark:bg-neutral-900 shadow-sm space-y-6">
        <form onSubmit={handleSave} className="space-y-6">
          {/* Operating Hours */}
          <div className="space-y-4">
            <h3 className="text-xs font-mono uppercase tracking-wider text-neutral-400 font-semibold border-b border-neutral-100 dark:border-neutral-800 pb-1">
              01. Central Knowledge Commons Hours
            </h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <Input
                label="Daily Opening Time"
                type="time"
                value={settings.openingTime}
                onChange={(e) => setSettings({ ...settings, openingTime: e.target.value })}
              />
              <Input
                label="Daily Closing Time"
                type="time"
                value={settings.closingTime}
                onChange={(e) => setSettings({ ...settings, closingTime: e.target.value })}
              />
            </div>
          </div>

          {/* Circulation Quotas & Loan Rules */}
          <div className="space-y-4">
            <h3 className="text-xs font-mono uppercase tracking-wider text-neutral-400 font-semibold border-b border-neutral-100 dark:border-neutral-800 pb-1">
              02. Circulation Quotas & Loan Durations
            </h3>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <Input
                label="Student Loan Limit (Volumes)"
                type="number"
                value={settings.borrowLimitStudent}
                onChange={(e) => setSettings({ ...settings, borrowLimitStudent: Number(e.target.value) })}
              />
              <Input
                label="Faculty Loan Limit (Volumes)"
                type="number"
                value={settings.borrowLimitTeacher}
                onChange={(e) => setSettings({ ...settings, borrowLimitTeacher: Number(e.target.value) })}
              />
              <Input
                label="Base Loan Duration (Days)"
                type="number"
                value={settings.borrowDurationDays}
                onChange={(e) => setSettings({ ...settings, borrowDurationDays: Number(e.target.value) })}
              />
            </div>
          </div>

          {/* Fines and Hold Policies */}
          <div className="space-y-4">
            <h3 className="text-xs font-mono uppercase tracking-wider text-neutral-400 font-semibold border-b border-neutral-100 dark:border-neutral-800 pb-1">
              03. Fines & Hold Shelf Expiration
            </h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <Input
                label="Overdue Assessment Fee ($ / day)"
                type="number"
                step="0.25"
                value={settings.finePerDay}
                onChange={(e) => setSettings({ ...settings, finePerDay: Number(e.target.value) })}
              />
              <Input
                label="Hold Shelf Reservation Window (Hours)"
                type="number"
                value={settings.reservationExpiryHours}
                onChange={(e) => setSettings({ ...settings, reservationExpiryHours: Number(e.target.value) })}
              />
            </div>
          </div>

          {/* Toggle Switches */}
          <div className="space-y-3 pt-2">
            <div className="flex items-center justify-between p-3 rounded-xl bg-neutral-50 dark:bg-neutral-800/60 text-xs">
              <div>
                <span className="font-semibold text-neutral-900 dark:text-neutral-100 block">
                  Automated Overdue Email Reminders
                </span>
                <span className="text-neutral-500">
                  Send patron notice 48 hours and 24 hours prior to loan expiry.
                </span>
              </div>
              <input
                type="checkbox"
                checked={settings.emailReminders}
                onChange={(e) => setSettings({ ...settings, emailReminders: e.target.checked })}
                className="rounded text-neutral-900 focus:ring-neutral-900"
              />
            </div>
          </div>

          <div className="flex items-center justify-end gap-3 pt-4 border-t border-neutral-100 dark:border-neutral-800">
            <Button
              type="submit"
              variant="primary"
              size="md"
              leftIcon={<Save className="w-4 h-4" />}
              isLoading={isSaving}
            >
              Save Library Settings
            </Button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default AdminSettingsPage;
