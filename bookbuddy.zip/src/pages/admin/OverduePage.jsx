import React, { useState } from 'react';
import { initialBorrowings } from '../../data/borrowings';
import { Button } from '../../components/common/Button';
import { AlertTriangle, Mail, Send, CheckCircle2 } from 'lucide-react';
import { format, differenceInDays } from 'date-fns';
import { toast } from 'sonner';

export const OverduePage = () => {
  const [filterDays, setFilterDays] = useState(1);
  const now = new Date();

  const overdueLoans = [
    {
      id: 'ov-1',
      readerName: 'Vishal Gayathri',
      readerEmail: 'vishalgayathri27@gmail.com',
      readerId: 'student001',
      title: 'Introduction to Algorithms (CLRS)',
      bookNumber: 'BK-0003',
      dueDate: '2026-09-23',
      daysOverdue: 6,
      fine: 6.0,
    },
    {
      id: 'ov-2',
      readerName: 'Elena Rostova',
      readerEmail: 'e.rostova@student.edu',
      readerId: 'user-6',
      title: 'Hands-On Machine Learning',
      bookNumber: 'BK-0020',
      dueDate: '2026-09-25',
      daysOverdue: 4,
      fine: 4.0,
    },
    {
      id: 'ov-3',
      readerName: 'Karan Mehra',
      readerEmail: 'karan.m@student.edu',
      readerId: 'user-7',
      title: 'High Performance MySQL',
      bookNumber: 'BK-0014',
      dueDate: '2026-09-15',
      daysOverdue: 14,
      fine: 14.0,
    },
  ];

  const filtered = overdueLoans.filter((o) => o.daysOverdue >= filterDays);

  const handleSendReminder = (readerName, bookTitle) => {
    toast.success(`Overdue circulation reminder sent to ${readerName} for "${bookTitle}"!`);
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-bold tracking-tight text-neutral-900 dark:text-neutral-100">
            Overdue Loans & Fine Monitoring
          </h1>
          <p className="text-xs sm:text-sm text-neutral-500 dark:text-neutral-400 mt-1">
            Track unreturned books past their loan period, inspect accrued fines, and issue automated reminders.
          </p>
        </div>

        <Button
          variant="danger"
          size="sm"
          leftIcon={<Send className="w-3.5 h-3.5" />}
          onClick={() => toast.success('Dispatched batch overdue emails to all delinquent accounts.')}
        >
          Send All Reminders
        </Button>
      </div>

      {/* Filter by severity */}
      <div className="flex items-center gap-1.5 p-1 bg-neutral-100 dark:bg-neutral-800 rounded-xl text-xs font-semibold w-fit">
        {[
          { days: 1, label: '1+ Day Overdue' },
          { days: 3, label: '3+ Days Overdue' },
          { days: 7, label: '7+ Days Overdue' },
          { days: 14, label: '14+ Days Overdue' },
        ].map((f) => (
          <button
            key={f.days}
            onClick={() => setFilterDays(f.days)}
            className={`px-3 py-1.5 rounded-lg transition-colors cursor-pointer ${
              filterDays === f.days
                ? 'bg-white text-neutral-900 shadow-xs dark:bg-neutral-900 dark:text-white'
                : 'text-neutral-500 hover:text-neutral-900 dark:hover:text-white'
            }`}
          >
            {f.label}
          </button>
        ))}
      </div>

      <div className="rounded-2xl border border-neutral-200/80 bg-white dark:border-neutral-800 dark:bg-neutral-900 overflow-hidden shadow-xs">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-neutral-50 dark:bg-neutral-850 border-b border-neutral-200/80 dark:border-neutral-800 font-mono text-[11px] text-neutral-500 uppercase">
              <tr>
                <th className="py-3 px-4">Patron</th>
                <th className="py-3 px-4">Book Title & Call No</th>
                <th className="py-3 px-4">Due Date</th>
                <th className="py-3 px-4">Days Overdue</th>
                <th className="py-3 px-4">Calculated Fine</th>
                <th className="py-3 px-4 text-right">Circulation Notice</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-neutral-100 dark:divide-neutral-800">
              {filtered.map((o) => (
                <tr key={o.id} className="hover:bg-neutral-50/50 dark:hover:bg-neutral-800/40">
                  <td className="py-3 px-4">
                    <span className="font-semibold text-neutral-900 dark:text-neutral-100 block">{o.readerName}</span>
                    <span className="text-[11px] text-neutral-400 font-mono">{o.readerEmail}</span>
                  </td>
                  <td className="py-3 px-4">
                    <span className="font-semibold text-neutral-900 dark:text-neutral-100 block">{o.title}</span>
                    <span className="text-[10px] font-mono text-neutral-500">{o.bookNumber}</span>
                  </td>
                  <td className="py-3 px-4 font-mono text-neutral-500">{o.dueDate}</td>
                  <td className="py-3 px-4 font-mono font-bold text-rose-600 tabular-nums">
                    {o.daysOverdue} days
                  </td>
                  <td className="py-3 px-4 font-mono font-bold tabular-nums">
                    ${o.fine.toFixed(2)}
                  </td>
                  <td className="py-3 px-4 text-right">
                    <button
                      onClick={() => handleSendReminder(o.readerName, o.title)}
                      className="px-2.5 py-1 rounded-md text-[11px] font-medium border border-neutral-300 dark:border-neutral-700 hover:bg-neutral-100 dark:hover:bg-neutral-800 inline-flex items-center gap-1 cursor-pointer"
                    >
                      <Mail className="w-3.5 h-3.5" />
                      <span>Send Notice</span>
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default OverduePage;
