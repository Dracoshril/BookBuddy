import React, { useState } from 'react';
import { initialReservations } from '../../data/reservations';
import { Button } from '../../components/common/Button';
import { Clock, CheckCircle2, XCircle } from 'lucide-react';
import { format } from 'date-fns';
import { toast } from 'sonner';

export const AdminReservationsPage = () => {
  const [reservations, setReservations] = useState(initialReservations);

  const handleUpdateStatus = (id, newStatus, title) => {
    setReservations((prev) =>
      prev.map((r) => (r.id === id ? { ...r, status: newStatus } : r))
    );
    toast.success(`Hold for "${title}" marked as ${newStatus}.`);
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl sm:text-3xl font-bold tracking-tight text-neutral-900 dark:text-neutral-100">
          Circulation Hold Shelf & Reservations Queue
        </h1>
        <p className="text-xs sm:text-sm text-neutral-500 dark:text-neutral-400 mt-1">
          Review incoming hold requests, assign returned copies to hold shelf, and notify patrons.
        </p>
      </div>

      <div className="rounded-2xl border border-neutral-200/80 bg-white dark:border-neutral-800 dark:bg-neutral-900 overflow-hidden shadow-xs">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-neutral-50 dark:bg-neutral-850 border-b border-neutral-200/80 dark:border-neutral-800 font-mono text-[11px] text-neutral-500 uppercase">
              <tr>
                <th className="py-3 px-4">Hold ID</th>
                <th className="py-3 px-4">Title & Call No</th>
                <th className="py-3 px-4">Patron ID</th>
                <th className="py-3 px-4">Requested Date</th>
                <th className="py-3 px-4">Queue Position</th>
                <th className="py-3 px-4">Status</th>
                <th className="py-3 px-4 text-right">Circulation Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-neutral-100 dark:divide-neutral-800">
              {reservations.map((r) => (
                <tr key={r.id} className="hover:bg-neutral-50/50 dark:hover:bg-neutral-800/40">
                  <td className="py-3 px-4 font-mono text-neutral-400">{r.id}</td>
                  <td className="py-3 px-4">
                    <span className="font-semibold text-neutral-900 dark:text-neutral-100 block">{r.title}</span>
                    <span className="text-[10px] font-mono text-neutral-500">{r.bookNumber}</span>
                  </td>
                  <td className="py-3 px-4 font-mono">{r.userId}</td>
                  <td className="py-3 px-4 font-mono">{format(new Date(r.reservationDate), 'MMM dd, yyyy')}</td>
                  <td className="py-3 px-4 font-mono font-bold text-amber-600">
                    {r.queuePosition > 0 ? `#${r.queuePosition}` : 'Next'}
                  </td>
                  <td className="py-3 px-4">
                    <span
                      className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-semibold ${
                        r.status === 'AVAILABLE'
                          ? 'bg-emerald-500/10 text-emerald-700 dark:text-emerald-400'
                          : r.status === 'COMPLETED'
                          ? 'bg-neutral-100 text-neutral-600 dark:bg-neutral-800 dark:text-neutral-400'
                          : 'bg-amber-500/10 text-amber-700 dark:text-amber-400'
                      }`}
                    >
                      {r.status}
                    </span>
                  </td>
                  <td className="py-3 px-4 text-right">
                    <div className="flex items-center justify-end gap-1.5">
                      {r.status !== 'AVAILABLE' && r.status !== 'COMPLETED' && (
                        <button
                          onClick={() => handleUpdateStatus(r.id, 'AVAILABLE', r.title)}
                          className="px-2 py-1 rounded bg-neutral-900 text-white dark:bg-white dark:text-neutral-900 text-[11px] font-medium"
                        >
                          Place on Shelf
                        </button>
                      )}
                      {r.status === 'AVAILABLE' && (
                        <button
                          onClick={() => handleUpdateStatus(r.id, 'COMPLETED', r.title)}
                          className="px-2 py-1 rounded bg-emerald-600 text-white text-[11px] font-medium"
                        >
                          Fulfill Loan
                        </button>
                      )}
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default AdminReservationsPage;
