import React, { useEffect } from 'react';
import { Link } from 'react-router-dom';
import { useSelector, useDispatch } from 'react-redux';
import {
  fetchOverviewMetrics,
  fetchBorrowingTrends,
  fetchCategoryDistribution,
  fetchPopularBooks,
} from '../../store/slices/analyticsSlice';
import { Button } from '../../components/common/Button';
import {
  BookOpen,
  Users,
  ArrowUpRight,
  ArrowDownLeft,
  Clock,
  AlertTriangle,
  PlusCircle,
  FileSpreadsheet,
  TrendingUp,
} from 'lucide-react';
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid,
  Legend,
} from 'recharts';

export const AdminDashboardPage = () => {
  const dispatch = useDispatch();
  const { overview, borrowingTrends, popularBooks } = useSelector((state) => state.analytics);

  useEffect(() => {
    dispatch(fetchOverviewMetrics());
    dispatch(fetchBorrowingTrends());
    dispatch(fetchCategoryDistribution());
    dispatch(fetchPopularBooks());
  }, [dispatch]);

  const kpis = [
    { label: 'Total Books Cataloged', value: overview?.totalBooks || 42, sub: '168 physical copies', icon: BookOpen, color: 'text-neutral-900 dark:text-white' },
    { label: 'Books Currently Issued', value: overview?.issuedBooks || 82, sub: 'Active circulation loans', icon: ArrowUpRight, color: 'text-sky-600' },
    { label: 'Available on Stacks', value: overview?.availableBooks || 78, sub: 'Ready for checkout', icon: BookOpen, color: 'text-emerald-600' },
    { label: 'Overdue Volumes', value: overview?.overdueLoans || 14, sub: 'Action required', icon: AlertTriangle, color: 'text-rose-600' },
    { label: 'Active Reservations', value: overview?.reservedBooks || 8, sub: 'In hold queue', icon: Clock, color: 'text-amber-600' },
    { label: 'Registered Readers', value: overview?.totalReaders || 480, sub: 'Students & Faculty', icon: Users, color: 'text-neutral-900 dark:text-white' },
  ];

  return (
    <div className="space-y-8">
      {/* Top Banner and Quick Circulation Actions */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-bold tracking-tight text-neutral-900 dark:text-neutral-100">
            Circulation Desk & System Administration
          </h1>
          <p className="text-xs sm:text-sm text-neutral-500 dark:text-neutral-400 mt-1">
            Real-time physical inventory control, patron loan tracking, and catalog maintenance.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <Link to="/admin/issue">
            <Button variant="primary" size="sm" leftIcon={<ArrowUpRight className="w-3.5 h-3.5" />}>
              Issue Loan
            </Button>
          </Link>
          <Link to="/admin/return">
            <Button variant="outline" size="sm" leftIcon={<ArrowDownLeft className="w-3.5 h-3.5" />}>
              Check-in Book
            </Button>
          </Link>
          <Link to="/admin/books/new">
            <Button variant="outline" size="sm" leftIcon={<PlusCircle className="w-3.5 h-3.5" />}>
              Add Book
            </Button>
          </Link>
          <Link to="/admin/import">
            <Button variant="secondary" size="sm" leftIcon={<FileSpreadsheet className="w-3.5 h-3.5" />}>
              Import File
            </Button>
          </Link>
        </div>
      </div>

      {/* KPI Cards Grid */}
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3">
        {kpis.map((kpi, i) => {
          const Icon = kpi.icon;
          return (
            <div
              key={i}
              className="p-4 rounded-xl border border-neutral-200/80 bg-white dark:border-neutral-800 dark:bg-neutral-900 shadow-xs space-y-1.5"
            >
              <div className="flex items-center justify-between text-neutral-400">
                <span className="text-[11px] font-medium truncate">{kpi.label}</span>
                <Icon className="w-4 h-4 shrink-0" />
              </div>
              <div className="text-2xl font-bold font-mono tracking-tight tabular-nums">
                <span className={kpi.color}>{kpi.value}</span>
              </div>
              <p className="text-[10px] text-neutral-400 truncate">{kpi.sub}</p>
            </div>
          );
        })}
      </div>

      {/* Charts Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Circulation Velocity Chart */}
        <div className="lg:col-span-8 p-6 rounded-2xl border border-neutral-200/80 bg-white dark:border-neutral-800 dark:bg-neutral-900 shadow-xs space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="font-bold text-sm text-neutral-900 dark:text-neutral-100">
                Monthly Circulation Velocity (Loans vs Returns)
              </h3>
              <p className="text-[11px] text-neutral-500">6-month transaction frequency across campus</p>
            </div>
            <Link to="/admin/analytics" className="text-xs font-semibold text-amber-600 hover:underline">
              View Detailed Analytics
            </Link>
          </div>

          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={borrowingTrends}>
                <CartesianGrid strokeDasharray="3 3" opacity={0.15} />
                <XAxis dataKey="month" tick={{ fontSize: 11 }} />
                <YAxis tick={{ fontSize: 11 }} />
                <Tooltip
                  contentStyle={{
                    backgroundColor: '#18181b',
                    borderColor: '#27272a',
                    borderRadius: '8px',
                    fontSize: '12px',
                    color: '#fff',
                  }}
                />
                <Legend wrapperStyle={{ fontSize: '11px', paddingTop: '8px' }} />
                <Bar dataKey="issues" fill="#171717" radius={[4, 4, 0, 0]} name="Books Checked Out" />
                <Bar dataKey="returns" fill="#10b981" radius={[4, 4, 0, 0]} name="Books Returned" />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Most Borrowed Titles ranking */}
        <div className="lg:col-span-4 p-6 rounded-2xl border border-neutral-200/80 bg-white dark:border-neutral-800 dark:bg-neutral-900 shadow-xs space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="font-bold text-sm text-neutral-900 dark:text-neutral-100">
              Highest Circulation Titles
            </h3>
            <span className="text-[10px] font-mono text-neutral-400">Semester Rank</span>
          </div>

          <div className="space-y-3">
            {popularBooks.map((book, idx) => (
              <div key={idx} className="flex items-center justify-between text-xs pb-2 border-b border-neutral-100 dark:border-neutral-800 last:border-0">
                <div className="min-w-0 pr-2">
                  <span className="font-semibold text-neutral-900 dark:text-neutral-100 block truncate">
                    {book.title}
                  </span>
                  <span className="text-[10px] text-neutral-400 font-mono">{book.category}</span>
                </div>
                <div className="text-right shrink-0">
                  <span className="font-bold font-mono text-neutral-900 dark:text-neutral-100 tabular-nums">
                    {book.borrowCount}
                  </span>
                  <span className="text-[10px] text-neutral-400 block">issues</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default AdminDashboardPage;
