import React, { useState } from 'react';
import { initialBorrowings } from '../../data/borrowings';
import { initialBooks } from '../../data/books';
import { Button } from '../../components/common/Button';
import { ArrowDownLeft, CheckCircle2, AlertCircle, Clock } from 'lucide-react';
import { format, differenceInDays } from 'date-fns';
import { toast } from 'sonner';

export const ReturnBookPage = () => {
  const [loans, setLoans] = useState(
    initialBorrowings.filter((b) => b.status === 'CURRENT' || b.status === 'DUE_SOON' || b.status === 'OVERDUE')
  );
  const [selectedLoanId, setSelectedLoanId] = useState(loans[0]?.id || '');
  const [condition, setCondition] = useState('EXCELLENT');
  const [isProcessing, setIsProcessing] = useState(false);

  const selectedLoan = loans.find((l) => l.id === selectedLoanId) || loans[0];
  const now = new Date();

  const handleReturn = (e) => {
    e.preventDefault();
    if (!selectedLoan) return;

    setIsProcessing(true);
    setTimeout(() => {
      setLoans((prev) => prev.filter((l) => l.id !== selectedLoan.id));
      setIsProcessing(false);
      toast.success(`Book "${selectedLoan.title}" checked in successfully! Stock replenished.`);
    }, 400);
  };

  const daysOverdue = selectedLoan ? Math.max(0, differenceInDays(now, new Date(selectedLoan.dueDate))) : 0;
  const fineAmount = daysOverdue * 1.0;

  return (
    <div className="max-w-3xl mx-auto space-y-6">
      <div>
        <h1 className="text-2xl font-bold tracking-tight text-neutral-900 dark:text-neutral-100">
          Circulation Desk — Return Book & Check-In
        </h1>
        <p className="text-xs text-neutral-500 mt-1">
          Process physical returns, inspect book condition, assess overdue fines if applicable, and restore shelf stock.
        </p>
      </div>

      <div className="p-8 rounded-3xl border border-neutral-200/80 bg-white dark:border-neutral-800 dark:bg-neutral-900 shadow-sm space-y-6">
        {loans.length > 0 ? (
          <form onSubmit={handleReturn} className="space-y-6">
            <div>
              <label className="block text-xs font-semibold text-neutral-700 dark:text-neutral-300 mb-1.5">
                Select Active Loan Record to Check-In
              </label>
              <select
                value={selectedLoanId}
                onChange={(e) => setSelectedLoanId(e.target.value)}
                className="w-full h-10 rounded-xl border border-neutral-300 bg-white px-3 text-xs text-neutral-900 focus:outline-none focus:ring-2 focus:ring-neutral-900 dark:border-neutral-800 dark:bg-neutral-900 dark:text-neutral-100"
              >
                {loans.map((l) => (
                  <option key={l.id} value={l.id}>
                    [{l.bookNumber}] {l.title} — Due: {format(new Date(l.dueDate), 'MMM dd, yyyy')} ({l.status})
                  </option>
                ))}
              </select>
            </div>

            {/* Selected Loan Assessment Box */}
            {selectedLoan && (
              <div className="p-4 rounded-2xl bg-neutral-50 dark:bg-neutral-800/60 border border-neutral-200/80 dark:border-neutral-700/80 space-y-3 text-xs">
                <div className="flex items-center justify-between">
                  <h4 className="font-bold text-sm text-neutral-900 dark:text-neutral-100">
                    {selectedLoan.title}
                  </h4>
                  <span className="font-mono text-neutral-500">{selectedLoan.bookNumber}</span>
                </div>
                <p className="text-neutral-500">Author: {selectedLoan.author}</p>

                <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 pt-2 border-t border-neutral-200/60 dark:border-neutral-700/60 font-mono">
                  <div>
                    <span className="block text-[10px] text-neutral-400 uppercase">Borrowed</span>
                    <span>{format(new Date(selectedLoan.borrowDate), 'MMM dd, yyyy')}</span>
                  </div>
                  <div>
                    <span className="block text-[10px] text-neutral-400 uppercase">Due Date</span>
                    <span className={daysOverdue > 0 ? 'text-rose-600 font-bold' : ''}>
                      {format(new Date(selectedLoan.dueDate), 'MMM dd, yyyy')}
                    </span>
                  </div>
                  <div>
                    <span className="block text-[10px] text-neutral-400 uppercase">Overdue Fee</span>
                    <span className={fineAmount > 0 ? 'text-rose-600 font-bold' : 'text-emerald-600 font-bold'}>
                      ${fineAmount.toFixed(2)}
                    </span>
                  </div>
                </div>
              </div>
            )}

            {/* Book Condition Check */}
            <div>
              <label className="block text-xs font-semibold text-neutral-700 dark:text-neutral-300 mb-1.5">
                Physical Copy Condition Assessment
              </label>
              <div className="grid grid-cols-3 gap-2">
                {[
                  { key: 'EXCELLENT', label: 'Excellent / Like New' },
                  { key: 'GOOD', label: 'Normal Reading Wear' },
                  { key: 'DAMAGED', label: 'Requires Maintenance' },
                ].map((c) => (
                  <button
                    key={c.key}
                    type="button"
                    onClick={() => setCondition(c.key)}
                    className={`py-2 px-3 text-xs font-medium rounded-lg border transition-all cursor-pointer ${
                      condition === c.key
                        ? 'border-neutral-900 bg-neutral-900 text-white dark:border-white dark:bg-white dark:text-neutral-900'
                        : 'border-neutral-300 dark:border-neutral-700 text-neutral-700 dark:text-neutral-300'
                    }`}
                  >
                    {c.label}
                  </button>
                ))}
              </div>
            </div>

            <Button
              type="submit"
              variant="primary"
              size="md"
              className="w-full"
              isLoading={isProcessing}
              leftIcon={<ArrowDownLeft className="w-4 h-4" />}
            >
              Confirm Book Return & Increment Shelf Inventory
            </Button>
          </form>
        ) : (
          <div className="p-8 text-center text-xs text-neutral-500">
            All active loans in this demo session have been returned to the stacks.
          </div>
        )}
      </div>
    </div>
  );
};

export default ReturnBookPage;
