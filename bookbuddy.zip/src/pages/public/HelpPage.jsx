import React, { useState } from 'react';
import { Button } from '../../components/common/Button';
import { HelpCircle, ChevronDown, ChevronUp, BookOpen, Clock, ShieldAlert, Mail, MapPin } from 'lucide-react';

export const HelpPage = () => {
  const [openFaq, setOpenFaq] = useState(0);

  const faqs = [
    {
      q: 'How do I locate a physical book in the library?',
      a: 'Every book in BookBuddy includes exact spatial coordinates: Floor (e.g. 2nd Floor), Rack Number, Section Topic, Shelf Tier, and Spine Position. Look for these coordinates on any book details card.',
    },
    {
      q: 'How many books can I borrow simultaneously?',
      a: 'Undergraduate and graduate students may borrow up to 4 books concurrently for a 14-day loan period with online renewal options.',
    },
    {
      q: 'How do book holds and reservations work?',
      a: 'If all physical copies of a book are checked out, click "Reserve". You will be placed in the queue. When a copy is returned, it is set aside on Hold Shelf B at Circulation Desk 1 for 48 hours.',
    },
    {
      q: 'What is the AI Match percentage?',
      a: 'The AI Match percentage indicates how closely a book aligns with your registered academic interests, previous reading logs, and target career roadmaps. It does not measure universal book quality.',
    },
    {
      q: 'How can I renew my active loans?',
      a: 'You can renew an active book loan up to 2 times from your "My Borrowings" page, provided no other reader has placed a pending reservation hold on that title.',
    },
  ];

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 py-12 space-y-12">
      {/* Header */}
      <div>
        <h1 className="text-3xl font-extrabold tracking-tight text-neutral-900 dark:text-neutral-100">
          Library Rules & Patron Help Center
        </h1>
        <p className="text-xs sm:text-sm text-neutral-500 dark:text-neutral-400 mt-1">
          Everything you need to know about physical borrowing, renewals, holds, and circulation policies.
        </p>
      </div>

      {/* Circulation Hours & Rules Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="p-5 rounded-2xl border border-neutral-200/80 bg-white dark:border-neutral-800 dark:bg-neutral-900 space-y-3">
          <Clock className="w-5 h-5 text-amber-600" />
          <h4 className="font-bold text-sm">Library Hours</h4>
          <ul className="text-xs text-neutral-600 dark:text-neutral-400 space-y-1">
            <li><strong>Mon – Fri:</strong> 08:00 – 21:00</li>
            <li><strong>Saturday:</strong> 09:00 – 18:00</li>
            <li><strong>Sunday:</strong> 10:00 – 16:00</li>
          </ul>
        </div>

        <div className="p-5 rounded-2xl border border-neutral-200/80 bg-white dark:border-neutral-800 dark:bg-neutral-900 space-y-3">
          <BookOpen className="w-5 h-5 text-sky-600" />
          <h4 className="font-bold text-sm">Borrowing Limits</h4>
          <ul className="text-xs text-neutral-600 dark:text-neutral-400 space-y-1">
            <li><strong>Loan Quota:</strong> 4 volumes per student</li>
            <li><strong>Loan Period:</strong> 14 calendar days</li>
            <li><strong>Renewals:</strong> Up to 2 online extensions</li>
          </ul>
        </div>

        <div className="p-5 rounded-2xl border border-neutral-200/80 bg-white dark:border-neutral-800 dark:bg-neutral-900 space-y-3">
          <ShieldAlert className="w-5 h-5 text-rose-600" />
          <h4 className="font-bold text-sm">Overdue & Holds</h4>
          <ul className="text-xs text-neutral-600 dark:text-neutral-400 space-y-1">
            <li><strong>Hold Window:</strong> 48 hours for pickup</li>
            <li><strong>Overdue Grace:</strong> 1 calendar day</li>
            <li><strong>Late Notice:</strong> Automated email alert</li>
          </ul>
        </div>
      </div>

      {/* FAQ Accordion */}
      <div className="space-y-4">
        <h3 className="text-xl font-bold tracking-tight text-neutral-900 dark:text-neutral-100">
          Frequently Asked Questions
        </h3>
        <div className="space-y-2">
          {faqs.map((faq, idx) => {
            const isOpen = openFaq === idx;
            return (
              <div
                key={idx}
                className="rounded-xl border border-neutral-200/80 bg-white dark:border-neutral-800 dark:bg-neutral-900 overflow-hidden"
              >
                <button
                  onClick={() => setOpenFaq(isOpen ? -1 : idx)}
                  className="w-full p-4 text-left flex items-center justify-between text-xs sm:text-sm font-semibold text-neutral-900 dark:text-neutral-100 hover:bg-neutral-50 dark:hover:bg-neutral-800/50 transition-colors cursor-pointer"
                >
                  <span>{faq.q}</span>
                  {isOpen ? <ChevronUp className="w-4 h-4 text-neutral-400" /> : <ChevronDown className="w-4 h-4 text-neutral-400" />}
                </button>
                {isOpen && (
                  <div className="px-4 pb-4 text-xs text-neutral-600 dark:text-neutral-400 leading-relaxed border-t border-neutral-100 dark:border-neutral-800 pt-3">
                    {faq.a}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>

      {/* Circulation Contact Box */}
      <div className="p-6 rounded-2xl bg-neutral-100 dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 text-xs">
        <div className="space-y-1">
          <div className="flex items-center gap-2 font-bold text-neutral-900 dark:text-neutral-100">
            <Mail className="w-4 h-4 text-amber-600" />
            <span>Need assistance with a book loan or catalog search?</span>
          </div>
          <p className="text-neutral-500">
            Circulation Help Desk: Building 4, Knowledge Commons, Floor 1. Email: library@university.edu
          </p>
        </div>
        <a href="mailto:library@university.edu">
          <Button variant="outline" size="sm">
            Contact Staff
          </Button>
        </a>
      </div>
    </div>
  );
};

export default HelpPage;
