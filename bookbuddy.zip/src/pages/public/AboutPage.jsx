import React from 'react';
import { Link } from 'react-router-dom';
import { Button } from '../../components/common/Button';
import { BookOpen, Sparkles, Users, Shield, GraduationCap, School, MapPin, CheckCircle2 } from 'lucide-react';

export const AboutPage = () => {
  return (
    <div className="max-w-5xl mx-auto px-4 sm:px-6 py-12 space-y-16">
      {/* Intro */}
      <div className="space-y-4 max-w-3xl">
        <span className="text-xs font-mono uppercase tracking-wider text-amber-600 dark:text-amber-400">
          Academic Library & Social Intelligence
        </span>
        <h1 className="text-3xl sm:text-5xl font-extrabold tracking-tight text-neutral-900 dark:text-neutral-50 text-balance leading-tight">
          Reinventing the campus library experience for modern technical readers.
        </h1>
        <p className="text-base text-neutral-600 dark:text-neutral-400 leading-relaxed">
          BookBuddy bridges the physical and digital divide. We transform traditional university library stacks into an interactive, collaborative, and AI-accelerated reading ecosystem.
        </p>
      </div>

      {/* The Problem & The Solution */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        <div className="p-8 rounded-2xl border border-neutral-200/80 bg-white dark:border-neutral-800 dark:bg-neutral-900 space-y-4">
          <h3 className="text-lg font-bold text-neutral-900 dark:text-neutral-100">
            The Traditional Library Challenge
          </h3>
          <p className="text-xs sm:text-sm text-neutral-600 dark:text-neutral-400 leading-relaxed">
            Students struggle to locate books in massive multi-floor stacks without exact shelf coordinates. Reading progress is isolated without peer discussions, and navigating prerequisites for technical subjects requires tedious trial and error.
          </p>
          <ul className="space-y-2 text-xs text-neutral-600 dark:text-neutral-400">
            <li className="flex items-center gap-2">
              <span className="text-rose-500 font-bold">✕</span> Lost time searching through unmapped shelf rows
            </li>
            <li className="flex items-center gap-2">
              <span className="text-rose-500 font-bold">✕</span> No central diary to record reading velocity and insights
            </li>
            <li className="flex items-center gap-2">
              <span className="text-rose-500 font-bold">✕</span> Disconnected syllabus roadmaps with zero catalog links
            </li>
          </ul>
        </div>

        <div className="p-8 rounded-2xl border border-neutral-200/80 bg-white dark:border-neutral-800 dark:bg-neutral-900 space-y-4">
          <h3 className="text-lg font-bold text-neutral-900 dark:text-neutral-100">
            The BookBuddy Solution
          </h3>
          <p className="text-xs sm:text-sm text-neutral-600 dark:text-neutral-400 leading-relaxed">
            A three-in-one architecture that combines real-time physical stack locator coordinates, Letterboxd-inspired social logging with star ratings, and conversational AI tailored to academic learning roadmaps.
          </p>
          <ul className="space-y-2 text-xs text-neutral-600 dark:text-neutral-400">
            <li className="flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-500 shrink-0" /> Floor, Rack, Shelf, and Position precision
            </li>
            <li className="flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-500 shrink-0" /> Personal reading diary, ratings, and custom semester lists
            </li>
            <li className="flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-500 shrink-0" /> Conversational AI assistant and sequential study roadmaps
            </li>
          </ul>
        </div>
      </div>

      {/* Stakeholder Benefits */}
      <div className="space-y-6">
        <div>
          <h2 className="text-2xl font-bold tracking-tight text-neutral-900 dark:text-neutral-100">
            Engineered for Campus Community Stakeholders
          </h2>
          <p className="text-xs text-neutral-500 mt-1">Specific workflows tailored to each member role.</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="p-6 rounded-2xl border border-neutral-200/80 bg-white dark:border-neutral-800 dark:bg-neutral-900 space-y-3">
            <GraduationCap className="w-6 h-6 text-amber-600" />
            <h4 className="font-bold text-base">For Student Readers</h4>
            <p className="text-xs text-neutral-600 dark:text-neutral-400 leading-relaxed">
              Track due dates with instant notifications, check queue position for reserved copies, follow peer reading activity, and build targeted interview preparation reading shelves.
            </p>
          </div>

          <div className="p-6 rounded-2xl border border-neutral-200/80 bg-white dark:border-neutral-800 dark:bg-neutral-900 space-y-3">
            <School className="w-6 h-6 text-sky-600" />
            <h4 className="font-bold text-base">For Faculty Members</h4>
            <p className="text-xs text-neutral-600 dark:text-neutral-400 leading-relaxed">
              Curate and publish official course reading lists, review foundational textbooks for students, and observe subject interest trends in real-time across academic semesters.
            </p>
          </div>

          <div className="p-6 rounded-2xl border border-neutral-200/80 bg-white dark:border-neutral-800 dark:bg-neutral-900 space-y-3">
            <Shield className="w-6 h-6 text-emerald-600" />
            <h4 className="font-bold text-base">For Librarians & Staff</h4>
            <p className="text-xs text-neutral-600 dark:text-neutral-400 leading-relaxed">
              Fast barcode-ready book checkout and checkin, automated overdue tracking, bulk CSV/Excel catalog ingestion with error validation, and audit transaction logs.
            </p>
          </div>
        </div>
      </div>

      {/* Quick Action */}
      <div className="p-8 rounded-2xl bg-neutral-900 text-white dark:bg-neutral-900 dark:border dark:border-neutral-800 flex flex-col sm:flex-row items-center justify-between gap-6">
        <div>
          <h4 className="text-lg font-bold">Start exploring BookBuddy today</h4>
          <p className="text-xs text-neutral-400 mt-1">Browse the 42 physical books cataloged across 10 subject disciplines.</p>
        </div>
        <Link to="/explore">
          <Button variant="secondary" size="md">
            Explore Physical Catalog
          </Button>
        </Link>
      </div>
    </div>
  );
};

export default AboutPage;
