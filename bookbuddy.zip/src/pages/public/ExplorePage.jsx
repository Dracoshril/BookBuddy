import React, { useState, useEffect, useMemo } from 'react';
import { useSearchParams } from 'react-router-dom';
import { initialBooks } from '../../data/books';
import { initialCategories } from '../../data/categories';
import { BookCard } from '../../components/books/BookCard';
import { Button } from '../../components/common/Button';
import { Input } from '../../components/common/Input';
import { Select } from '../../components/common/Select';
import { EmptyState } from '../../components/common/EmptyState';
import { Search, RotateCcw, Filter, SlidersHorizontal, BookOpen } from 'lucide-react';

export const ExplorePage = () => {
  const [searchParams, setSearchParams] = useSearchParams();

  const querySearch = searchParams.get('search') || '';
  const queryCategory = searchParams.get('category') || 'all';
  const queryAvailability = searchParams.get('availability') || 'all';
  const querySort = searchParams.get('sortBy') || 'popular';

  const [searchTerm, setSearchTerm] = useState(querySearch);
  const [selectedCategory, setSelectedCategory] = useState(queryCategory);
  const [selectedAvailability, setSelectedAvailability] = useState(queryAvailability);
  const [sortBy, setSortBy] = useState(querySort);
  const [itemsPerPage, setItemsPerPage] = useState(12);
  const [currentPage, setCurrentPage] = useState(1);

  // Sync state with URL params
  useEffect(() => {
    setSearchTerm(querySearch);
    setSelectedCategory(queryCategory);
    setSelectedAvailability(queryAvailability);
    setSortBy(querySort);
  }, [querySearch, queryCategory, queryAvailability, querySort]);

  // Filter & Sort Logic
  const filteredBooks = useMemo(() => {
    let result = [...initialBooks];

    // Search filter
    if (searchTerm.trim()) {
      const q = searchTerm.toLowerCase().trim();
      result = result.filter(
        (b) =>
          b.title.toLowerCase().includes(q) ||
          b.author.toLowerCase().includes(q) ||
          b.isbn.includes(q) ||
          b.category.toLowerCase().includes(q) ||
          b.description.toLowerCase().includes(q) ||
          b.bookNumber.toLowerCase().includes(q)
      );
    }

    // Category filter
    if (selectedCategory && selectedCategory !== 'all') {
      result = result.filter((b) => {
        const catObj = initialCategories.find((c) => c.slug === selectedCategory);
        const catName = catObj ? catObj.name.toLowerCase() : selectedCategory.toLowerCase();
        if (selectedCategory === 'e-book' || catName === 'e-book') {
          return b.category.toLowerCase() === 'e-book' || Boolean(b.hasEbook) || Boolean(b.downloadUrl);
        }
        return b.category.toLowerCase() === catName || b.category.toLowerCase().includes(selectedCategory.toLowerCase());
      });
    }

    // Availability filter
    if (selectedAvailability && selectedAvailability !== 'all') {
      result = result.filter((b) => b.status === selectedAvailability);
    }

    // Sorting
    if (sortBy === 'popular') {
      result.sort((a, b) => b.borrowCount - a.borrowCount);
    } else if (sortBy === 'highest-rated') {
      result.sort((a, b) => b.rating - a.rating);
    } else if (sortBy === 'alphabetical') {
      result.sort((a, b) => a.title.localeCompare(b.title));
    } else if (sortBy === 'recently-added') {
      result.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
    }

    return result;
  }, [searchTerm, selectedCategory, selectedAvailability, sortBy]);

  // Pagination slice
  const totalPages = Math.max(1, Math.ceil(filteredBooks.length / itemsPerPage));
  const paginatedBooks = filteredBooks.slice(
    (currentPage - 1) * itemsPerPage,
    currentPage * itemsPerPage
  );

  const handleResetFilters = () => {
    setSearchTerm('');
    setSelectedCategory('all');
    setSelectedAvailability('all');
    setSortBy('popular');
    setCurrentPage(1);
    setSearchParams({});
  };

  const updateSearchParam = (key, value) => {
    const params = new URLSearchParams(searchParams);
    if (value && value !== 'all') {
      params.set(key, value);
    } else {
      params.delete(key);
    }
    setSearchParams(params);
    setCurrentPage(1);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-8 space-y-8">
      {/* Header */}
      <div>
        <h1 className="text-2xl sm:text-3xl font-bold tracking-tight text-neutral-900 dark:text-neutral-100">
          Library Catalog Holdings
        </h1>
        <p className="text-xs sm:text-sm text-neutral-500 dark:text-neutral-400 mt-1">
          Search and filter across {initialBooks.length} titles and digital resources with real-time stack coordinates and download options.
        </p>
      </div>

      {/* Filter and Search Controls */}
      <div className="p-4 sm:p-5 rounded-2xl border border-neutral-200/80 bg-white dark:border-neutral-800 dark:bg-neutral-900 space-y-4">
        {/* Search Input Row */}
        <div className="flex flex-col sm:flex-row gap-3">
          <div className="relative flex-1">
            <Search className="w-4 h-4 text-neutral-400 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => {
                setSearchTerm(e.target.value);
                updateSearchParam('search', e.target.value);
              }}
              placeholder="Search by title, author, keyword, ISBN, or call number..."
              className="w-full h-10 rounded-lg border border-neutral-300 bg-white pl-9 pr-3 text-sm text-neutral-900 placeholder:text-neutral-400 focus:outline-none focus:ring-2 focus:ring-neutral-900 dark:border-neutral-800 dark:bg-neutral-900 dark:text-neutral-100 dark:focus:ring-neutral-400"
            />
          </div>

          <div className="flex items-center gap-2">
            <Button
              variant="outline"
              size="md"
              leftIcon={<RotateCcw className="w-3.5 h-3.5" />}
              onClick={handleResetFilters}
            >
              Reset
            </Button>
          </div>
        </div>

        {/* Filter Selectors Row */}
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-3 pt-2 border-t border-neutral-100 dark:border-neutral-800">
          <div>
            <label className="block text-[11px] font-semibold text-neutral-500 uppercase tracking-wider mb-1">
              Category
            </label>
            <Select
              value={selectedCategory}
              onChange={(e) => {
                setSelectedCategory(e.target.value);
                updateSearchParam('category', e.target.value);
              }}
            >
              <option value="all">All Disciplines</option>
              {initialCategories.map((c) => (
                <option key={c.id} value={c.slug}>
                  {c.name}
                </option>
              ))}
            </Select>
          </div>

          <div>
            <label className="block text-[11px] font-semibold text-neutral-500 uppercase tracking-wider mb-1">
              Shelf Availability
            </label>
            <Select
              value={selectedAvailability}
              onChange={(e) => {
                setSelectedAvailability(e.target.value);
                updateSearchParam('availability', e.target.value);
              }}
            >
              <option value="all">All Statuses</option>
              <option value="AVAILABLE">Available Now</option>
              <option value="ISSUED">Currently Issued</option>
              <option value="RESERVED">Reserved on Hold</option>
            </Select>
          </div>

          <div>
            <label className="block text-[11px] font-semibold text-neutral-500 uppercase tracking-wider mb-1">
              Sort Order
            </label>
            <Select
              value={sortBy}
              onChange={(e) => {
                setSortBy(e.target.value);
                updateSearchParam('sortBy', e.target.value);
              }}
            >
              <option value="popular">Most Borrowed</option>
              <option value="highest-rated">Highest Rated</option>
              <option value="alphabetical">Alphabetical (A-Z)</option>
              <option value="recently-added">Recently Cataloged</option>
            </Select>
          </div>

          <div>
            <label className="block text-[11px] font-semibold text-neutral-500 uppercase tracking-wider mb-1">
              Display Limit
            </label>
            <Select
              value={itemsPerPage}
              onChange={(e) => {
                setItemsPerPage(Number(e.target.value));
                setCurrentPage(1);
              }}
            >
              <option value={12}>12 per page</option>
              <option value={24}>24 per page</option>
              <option value={48}>48 per page</option>
            </Select>
          </div>
        </div>
      </div>

      {/* Results Header Count */}
      <div className="flex items-center justify-between text-xs text-neutral-500 dark:text-neutral-400">
        <span>
          Showing <strong className="font-semibold text-neutral-900 dark:text-neutral-100">{paginatedBooks.length}</strong> of{' '}
          <strong className="font-semibold text-neutral-900 dark:text-neutral-100">{filteredBooks.length}</strong> books
        </span>
        <span>Page {currentPage} of {totalPages}</span>
      </div>

      {/* Book Grid or Empty State */}
      {paginatedBooks.length > 0 ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
          {paginatedBooks.map((book) => (
            <BookCard key={book.id} book={book} />
          ))}
        </div>
      ) : (
        <EmptyState
          icon={BookOpen}
          title="No library books found"
          description="We couldn't find any books matching your active search and filter constraints."
          actionLabel="Clear all filters"
          onAction={handleResetFilters}
        />
      )}

      {/* Pagination Controls */}
      {totalPages > 1 && (
        <div className="flex items-center justify-center gap-2 pt-6 border-t border-neutral-200 dark:border-neutral-800">
          <Button
            variant="outline"
            size="sm"
            onClick={() => setCurrentPage((p) => Math.max(p - 1, 1))}
            disabled={currentPage === 1}
          >
            Previous
          </Button>

          {Array.from({ length: totalPages }).map((_, i) => (
            <button
              key={i}
              onClick={() => setCurrentPage(i + 1)}
              className={`w-8 h-8 rounded-lg text-xs font-semibold transition-colors cursor-pointer ${
                currentPage === i + 1
                  ? 'bg-neutral-900 text-white dark:bg-white dark:text-neutral-900'
                  : 'text-neutral-600 hover:bg-neutral-100 dark:text-neutral-400 dark:hover:bg-neutral-800'
              }`}
            >
              {i + 1}
            </button>
          ))}

          <Button
            variant="outline"
            size="sm"
            onClick={() => setCurrentPage((p) => Math.min(p + 1, totalPages))}
            disabled={currentPage === totalPages}
          >
            Next
          </Button>
        </div>
      )}
    </div>
  );
};

export default ExplorePage;
