import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { initialBooks } from '../../data/books';
import { initialCategories } from '../../data/categories';
import { BookCard } from '../../components/books/BookCard';
import { Button } from '../../components/common/Button';
import { Search, Sparkles, BookOpen, Compass, ArrowRight, MapPin, Users, GraduationCap, Shield } from 'lucide-react';
import { useAuth } from '../../hooks/useAuth';

export const HomePage = () => {
  const navigate = useNavigate();
  const { isAuthenticated, role } = useAuth();
  const [searchQuery, setSearchQuery] = useState('');

  const featuredBooks = initialBooks.slice(0, 4);
  const trendingBooks = initialBooks.filter((b) => b.borrowCount > 120).slice(0, 4);

  const handleSearchSubmit = (e) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      navigate(`/catalog?search=${encodeURIComponent(searchQuery.trim())}`);
    }
  };

  return (
    <div className="space-y-16 sm:space-y-24 pb-16">
      {/* Hero Section */}
      <section className="relative pt-12 sm:pt-20 pb-12 px-4 sm:px-6 max-w-7xl mx-auto">
        <div className="max-w-3xl space-y-6">
          <div className="inline-flex items-center gap-2 text-xs font-semibold text-amber-700 dark:text-amber-400 bg-amber-500/10 border border-amber-500/20 px-3 py-1 rounded-full">
            <Sparkles className="w-3.5 h-3.5" />
            <span>AI-Integrated Physical Library & Social Reading Platform</span>
          </div>

          <h1 className="text-3xl sm:text-5xl lg:text-6xl font-extrabold tracking-tight text-neutral-900 dark:text-neutral-50 text-balance leading-tight">
            Find books. Build your reading journey. Learn smarter with BookBuddy AI.
          </h1>

          <p className="text-base sm:text-lg text-neutral-600 dark:text-neutral-400 max-w-2xl leading-relaxed">
            A unified physical library catalog with precise shelf coordinates, Letterboxd-style reading diaries, and context-aware AI learning roadmaps for university students and librarians.
          </p>

          {/* Quick Catalog Search Bar */}
          <form onSubmit={handleSearchSubmit} className="pt-2 max-w-2xl">
            <div className="relative flex items-center shadow-lg rounded-2xl border border-neutral-300/80 bg-white dark:border-neutral-700 dark:bg-neutral-900 p-2">
              <Search className="w-5 h-5 text-neutral-400 ml-3 shrink-0" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search by title, author, topic, or call number (e.g. 'Clean Code', 'DSA')..."
                className="w-full bg-transparent px-3 py-2 text-sm text-neutral-900 dark:text-neutral-100 placeholder:text-neutral-400 focus:outline-none"
              />
              <Button type="submit" variant="primary" size="md">
                Search Catalog
              </Button>
            </div>
            <div className="flex flex-wrap items-center gap-2 text-xs text-neutral-500 dark:text-neutral-400 mt-3 px-2">
              <span>Popular searches:</span>
              <button
                type="button"
                onClick={() => navigate('/catalog?category=programming')}
                className="hover:text-neutral-900 dark:hover:text-white underline underline-offset-2"
              >
                Java Systems
              </button>
              <span aria-hidden="true">·</span>
              <button
                type="button"
                onClick={() => navigate('/catalog?category=dsa')}
                className="hover:text-neutral-900 dark:hover:text-white underline underline-offset-2"
              >
                Algorithms & CLRS
              </button>
              <span aria-hidden="true">·</span>
              <button
                type="button"
                onClick={() => navigate('/catalog?category=database')}
                className="hover:text-neutral-900 dark:hover:text-white underline underline-offset-2"
              >
                Distributed Storage
              </button>
            </div>
          </form>

          {/* Primary CTA Buttons */}
          <div className="flex flex-wrap items-center gap-3 pt-2">
            <Link to="/catalog">
              <Button variant="primary" size="md" rightIcon={<ArrowRight className="w-4 h-4" />}>
                Explore 42+ Holdings
              </Button>
            </Link>
            <Link to="/ai-assistant">
              <Button variant="outline" size="md" leftIcon={<Sparkles className="w-4 h-4 text-amber-500" />}>
                Ask Library AI
              </Button>
            </Link>
            <Link to="/learning-paths">
              <Button variant="outline" size="md">
                Learning Paths
              </Button>
            </Link>
            {!isAuthenticated ? (
              <Link to="/auth">
                <Button variant="secondary" size="md">
                  Sign In
                </Button>
              </Link>
            ) : (
              <Link to={role === 'librarian' ? '/librarian/dashboard' : '/student/dashboard'}>
                <Button variant="secondary" size="md">
                  Open {role === 'librarian' ? 'Librarian Dashboard' : 'Student Dashboard'}
                </Button>
              </Link>
            )}
          </div>
        </div>

        {/* Quantifiable Stats Banner */}
        <div className="mt-14 grid grid-cols-2 md:grid-cols-4 gap-4 p-6 rounded-2xl border border-neutral-200/80 bg-white dark:border-neutral-800 dark:bg-neutral-900/60 text-center">
          <div>
            <span className="block text-2xl sm:text-3xl font-bold font-mono text-neutral-900 dark:text-neutral-100 tabular-nums">42</span>
            <span className="text-xs text-neutral-500">Physical Books Cataloged</span>
          </div>
          <div>
            <span className="block text-2xl sm:text-3xl font-bold font-mono text-emerald-600 dark:text-emerald-400 tabular-nums">100%</span>
            <span className="text-xs text-neutral-500">Precise Shelf & Rack Mapping</span>
          </div>
          <div>
            <span className="block text-2xl sm:text-3xl font-bold font-mono text-neutral-900 dark:text-neutral-100 tabular-nums">480+</span>
            <span className="text-xs text-neutral-500">Active Campus Students</span>
          </div>
          <div>
            <span className="block text-2xl sm:text-3xl font-bold font-mono text-amber-600 dark:text-amber-400 tabular-nums">4.8 / 5</span>
            <span className="text-xs text-neutral-500">Average Student Review Score</span>
          </div>
        </div>
      </section>

      {/* Featured Books Collection */}
      <section className="px-4 sm:px-6 max-w-7xl mx-auto space-y-6">
        <div className="flex items-end justify-between">
          <div>
            <h2 className="text-xl sm:text-2xl font-bold text-neutral-900 dark:text-neutral-100 tracking-tight">
              Featured Physical Holdings
            </h2>
            <p className="text-xs sm:text-sm text-neutral-500 dark:text-neutral-400 mt-1">
              Curated foundational texts available in campus stacks right now.
            </p>
          </div>
          <Link to="/catalog" className="text-xs font-semibold text-neutral-900 dark:text-neutral-100 hover:underline flex items-center gap-1">
            <span>View All</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </Link>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
          {featuredBooks.map((book) => (
            <BookCard key={book.id} book={book} />
          ))}
        </div>
      </section>

      {/* The Two Dashboards Storytelling */}
      <section className="px-4 sm:px-6 max-w-7xl mx-auto">
        <div className="p-8 sm:p-12 rounded-3xl border border-neutral-200/80 bg-neutral-100/60 dark:border-neutral-800 dark:bg-neutral-900/40 space-y-8">
          <div className="max-w-2xl">
            <h3 className="text-2xl sm:text-3xl font-bold text-neutral-900 dark:text-neutral-100 tracking-tight">
              Tailored Portals for Students and Library Staff
            </h3>
            <p className="text-sm text-neutral-600 dark:text-neutral-400 mt-2">
              Two focused dashboards engineered for frictionless circulation and accelerated academic learning.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="p-6 rounded-2xl bg-white dark:bg-neutral-900 border border-neutral-200/80 dark:border-neutral-800 space-y-4">
              <div className="w-11 h-11 rounded-xl bg-amber-500/10 text-amber-600 dark:text-amber-400 flex items-center justify-center font-bold">
                <GraduationCap className="w-6 h-6" />
              </div>
              <h4 className="font-bold text-base text-neutral-900 dark:text-neutral-100">Student Portal</h4>
              <p className="text-xs text-neutral-600 dark:text-neutral-400 leading-relaxed">
                Log reading in your Letterboxd-style diary, track borrow due dates with return notifications, reserve checked-out copies, rate volumes, and follow personalized AI study roadmaps.
              </p>
              <Link to="/auth/student" className="inline-flex items-center gap-1.5 text-xs font-semibold text-amber-600 hover:underline pt-2">
                <span>Access Student Dashboard</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </Link>
            </div>

            <div className="p-6 rounded-2xl bg-white dark:bg-neutral-900 border border-neutral-200/80 dark:border-neutral-800 space-y-4">
              <div className="w-11 h-11 rounded-xl bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 flex items-center justify-center font-bold">
                <Shield className="w-6 h-6" />
              </div>
              <h4 className="font-bold text-base text-neutral-900 dark:text-neutral-100">Librarian Staff Console</h4>
              <p className="text-xs text-neutral-600 dark:text-neutral-400 leading-relaxed">
                Complete catalog inventory management, one-click book loans and check-ins, automated overdue fine calculation, hold shelf fulfillment, and institutional circulation analytics.
              </p>
              <Link to="/auth/librarian" className="inline-flex items-center gap-1.5 text-xs font-semibold text-emerald-600 hover:underline pt-2">
                <span>Access Librarian Dashboard</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Trending Holdings */}
      <section className="px-4 sm:px-6 max-w-7xl mx-auto space-y-6">
        <div className="flex items-end justify-between">
          <div>
            <h2 className="text-xl sm:text-2xl font-bold text-neutral-900 dark:text-neutral-100 tracking-tight">
              Most Borrowed Volumes This Semester
            </h2>
            <p className="text-xs sm:text-sm text-neutral-500 dark:text-neutral-400 mt-1">
              High-circulation titles across computer science, algorithms, and engineering stacks.
            </p>
          </div>
          <Link to="/catalog?sortBy=most-borrowed" className="text-xs font-semibold text-neutral-900 dark:text-neutral-100 hover:underline flex items-center gap-1">
            <span>View Rankings</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </Link>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
          {trendingBooks.map((book) => (
            <BookCard key={book.id} book={book} />
          ))}
        </div>
      </section>

      {/* Disciplines */}
      <section className="px-4 sm:px-6 max-w-7xl mx-auto space-y-6">
        <div>
          <h2 className="text-xl sm:text-2xl font-bold text-neutral-900 dark:text-neutral-100 tracking-tight">
            Browse Subject Disciplines
          </h2>
          <p className="text-xs sm:text-sm text-neutral-500 dark:text-neutral-400 mt-1">
            Categorized by departmental research tracks and foundational syllabi.
          </p>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-3">
          {initialCategories.map((cat) => (
            <Link
              key={cat.id}
              to={`/catalog?category=${cat.slug}`}
              className="p-4 rounded-xl border border-neutral-200/80 bg-white hover:border-neutral-400 dark:border-neutral-800 dark:bg-neutral-900 dark:hover:border-neutral-600 transition-all group"
            >
              <h4 className="font-semibold text-xs sm:text-sm text-neutral-900 dark:text-neutral-100 group-hover:text-amber-600 transition-colors">
                {cat.name}
              </h4>
              <p className="text-[11px] text-neutral-500 mt-1">{cat.bookCount} Books</p>
            </Link>
          ))}
        </div>
      </section>
    </div>
  );
};

export default HomePage;
