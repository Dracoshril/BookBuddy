import React from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../../hooks/useAuth';
import { Button } from '../../components/common/Button';
import { Sparkles, ArrowRight, CheckCircle2, BookOpen, Layers } from 'lucide-react';

export const PublicLearningPathsPage = () => {
  const { isAuthenticated, role } = useAuth();
  const navigate = useNavigate();

  const handleStartPath = (pathId) => {
    if (isAuthenticated) {
      if (role === 'student') {
        navigate('/student/learning-paths');
      } else {
        navigate('/librarian/dashboard');
      }
    } else {
      navigate('/auth', { state: { from: { pathname: '/student/learning-paths' } } });
    }
  };

  const samplePaths = [
    {
      id: 'road-1',
      title: 'Java Enterprise & Cloud Backend Architect',
      goal: 'Master idiomatically clean Java, concurrency, relational storage engines, Spring Boot, and distributed scalability.',
      stagesCount: 6,
      curatedBooks: [
        'Effective Java (3rd Edition)',
        'Clean Code',
        'Designing Data-Intensive Applications',
        'Spring Boot in Action',
        'System Design Interview',
      ],
      level: 'Foundational to Advanced',
    },
    {
      id: 'road-2',
      title: 'Algorithms & Placement Problem Solving',
      goal: 'Master algorithmic complexity, dynamic programming, divide-and-conquer, and placement interview questions.',
      stagesCount: 4,
      curatedBooks: [
        'Grokking Algorithms',
        'Introduction to Algorithms (CLRS)',
        'Cracking the Coding Interview',
        'Algorithms (Sedgewick)',
      ],
      level: 'Core Computer Science',
    },
    {
      id: 'road-3',
      title: 'Distributed Systems & Cloud Infrastructure',
      goal: 'Understand Paxos consensus, LSM-Tree storage engines, microservice orchestration, and site reliability.',
      stagesCount: 5,
      curatedBooks: [
        'Designing Data-Intensive Applications',
        'Database Internals',
        'Building Microservices',
        'Site Reliability Engineering (Google)',
      ],
      level: 'Advanced Undergraduate / Graduate',
    },
  ];

  return (
    <div className="max-w-5xl mx-auto px-4 sm:px-6 py-10 space-y-10">
      {/* Header */}
      <div className="space-y-3 max-w-3xl">
        <div className="inline-flex items-center gap-1.5 text-xs text-amber-600 dark:text-amber-400 font-semibold font-mono">
          <Sparkles className="w-3.5 h-3.5" />
          <span>Curated Syllabus Progressions</span>
        </div>
        <h1 className="text-3xl sm:text-4xl font-extrabold tracking-tight text-neutral-900 dark:text-neutral-100">
          Academic Learning Pathways
        </h1>
        <p className="text-sm text-neutral-600 dark:text-neutral-400 leading-relaxed">
          Structured reading sequences designed to take you from foundational concepts to production mastery. Every stage is directly matched to physical copies in the university library.
        </p>
      </div>

      {/* Pathways Grid */}
      <div className="space-y-6">
        {samplePaths.map((path) => (
          <div
            key={path.id}
            className="p-6 sm:p-8 rounded-3xl border border-neutral-200/80 bg-white dark:border-neutral-800 dark:bg-neutral-900 shadow-xs flex flex-col md:flex-row items-start md:items-center justify-between gap-6"
          >
            <div className="space-y-3 flex-1">
              <div className="flex items-center gap-3">
                <span className="text-[10px] font-mono uppercase tracking-wider px-2 py-0.5 rounded bg-amber-500/10 text-amber-700 dark:text-amber-400 font-bold border border-amber-500/20">
                  {path.level}
                </span>
                <span className="text-xs font-mono text-neutral-400">{path.stagesCount} Stages</span>
              </div>

              <h3 className="text-xl font-bold text-neutral-900 dark:text-neutral-100">
                {path.title}
              </h3>
              <p className="text-xs sm:text-sm text-neutral-500 leading-relaxed">
                {path.goal}
              </p>

              <div className="pt-2">
                <span className="text-[11px] font-mono text-neutral-400 block mb-1">
                  Key Holdings Included:
                </span>
                <div className="flex flex-wrap gap-1.5 text-xs">
                  {path.curatedBooks.map((book, idx) => (
                    <span
                      key={idx}
                      className="px-2.5 py-1 rounded-lg bg-neutral-100 dark:bg-neutral-800 text-neutral-700 dark:text-neutral-300 text-[11px] font-medium"
                    >
                      {book}
                    </span>
                  ))}
                </div>
              </div>
            </div>

            <div className="shrink-0 w-full md:w-auto">
              <Button
                variant="primary"
                size="md"
                className="w-full md:w-auto"
                rightIcon={<ArrowRight className="w-4 h-4" />}
                onClick={() => handleStartPath(path.id)}
              >
                {isAuthenticated ? 'Open Learning Path' : 'Start Learning Path'}
              </Button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default PublicLearningPathsPage;
