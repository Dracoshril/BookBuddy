import React, { useState, useEffect } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import { initialBooks } from '../../data/books';
import { BookCover } from '../../components/books/BookCover';
import { PhysicalLocationBadge } from '../../components/books/PhysicalLocationBadge';
import { Button } from '../../components/common/Button';
import { BookCard } from '../../components/books/BookCard';
import { aiApi } from '../../services/api/aiApi';
import { reviewApi } from '../../services/api/reviewApi';
import { useDispatch, useSelector } from 'react-redux';
import { openModal } from '../../store/slices/uiSlice';
import { toggleWantToReadBook } from '../../store/slices/listSlice';
import { useAuth } from '../../hooks/useAuth';
import { Star, Sparkles, Bookmark, Share2, ArrowLeft, MessageSquare, Edit3, Boxes, Download } from 'lucide-react';
import { getBookFormatAvailability } from '../../utils/helpers';
import { toast } from 'sonner';

export const BookDetailPage = () => {
  const { bookId, id } = useParams();
  const effectiveId = bookId || id;
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const { isAuthenticated, role } = useAuth();

  const book = initialBooks.find((b) => String(b.id) === String(effectiveId)) || initialBooks[0];
  const wantToReadIds = useSelector((state) => state.lists.wantToReadBookIds);
  const isSaved = wantToReadIds.includes(String(book.id));

  const {
    hasEbook,
    ebookAvailable,
    hasPhysical,
    physicalAvailableCopies,
    physicalTotalCopies,
  } = getBookFormatAvailability(book);

  const catalogPath = isAuthenticated
    ? (role === 'librarian' ? '/librarian/catalog' : '/student/catalog')
    : '/catalog';

  const [aiSummary, setAiSummary] = useState(null);
  const [reviews, setReviews] = useState([]);
  const [activeTab, setActiveTab] = useState('overview');

  useEffect(() => {
    aiApi.getBookSummary(book.id).then(setAiSummary);
    reviewApi.getBookReviews(book.id).then(setReviews);
  }, [book.id]);

  const relatedBooks = initialBooks
    .filter((b) => b.category === book.category && b.id !== book.id)
    .slice(0, 3);

  const handleShare = () => {
    navigator.clipboard.writeText(window.location.href);
    toast.success('Book catalog link copied to clipboard!');
  };

  const handleBorrowClick = () => {
    if (!isAuthenticated) {
      navigate('/auth', { state: { from: { pathname: `/books/${book.id}` } } });
      return;
    }
    dispatch(openModal({ type: 'BORROW', data: book }));
  };

  const handleReserveClick = () => {
    if (!isAuthenticated) {
      navigate('/auth', { state: { from: { pathname: `/books/${book.id}` } } });
      return;
    }
    dispatch(openModal({ type: 'RESERVE', data: book }));
  };

  const handleToggleWantToRead = () => {
    if (!isAuthenticated) {
      navigate('/auth', { state: { from: { pathname: `/books/${book.id}` } } });
      return;
    }
    dispatch(toggleWantToReadBook(book.id));
    toast.success(isSaved ? `Removed "${book.title}" from Want to Read` : `Saved to Want to Read shelf`);
  };

  return (
    <div className="max-w-6xl mx-auto px-4 sm:px-6 py-8 space-y-10">
      {/* Back Link */}
      <Link
        to={catalogPath}
        className="inline-flex items-center gap-1.5 text-xs font-semibold text-neutral-500 hover:text-neutral-900 dark:hover:text-white transition-colors"
      >
        <ArrowLeft className="w-4 h-4" />
        <span>Back to Browse Catalog</span>
      </Link>

      {/* Main Book Hero Layout */}
      <div className="grid grid-cols-1 md:grid-cols-12 gap-8 items-start">
        {/* Left Column: Book Cover & Quick Actions */}
        <div className="md:col-span-4 space-y-4">
          <BookCover
            title={book.title}
            author={book.author}
            category={book.category}
            bookNumber={book.bookNumber}
            coverGradient={book.coverGradient}
            aspectRatio="aspect-[2/3]"
            className="w-full max-w-sm mx-auto shadow-xl"
          />

          <div className="flex items-center gap-2">
            <Button
              variant="outline"
              size="sm"
              className="flex-1"
              leftIcon={<Bookmark className={`w-3.5 h-3.5 ${isSaved ? 'fill-current text-amber-500' : ''}`} />}
              onClick={handleToggleWantToRead}
            >
              {isSaved ? 'In Want to Read' : 'Want to Read'}
            </Button>
            <Button
              variant="outline"
              size="sm"
              leftIcon={<Share2 className="w-3.5 h-3.5" />}
              onClick={handleShare}
            >
              Share
            </Button>
          </div>
        </div>

        {/* Right Column: Title, Availability, Details, and Locator */}
        <div className="md:col-span-8 space-y-6">
          <div className="flex items-center gap-2 text-xs text-neutral-500 dark:text-neutral-400">
            <span className="font-semibold text-neutral-900 dark:text-neutral-100">{book.category}</span>
            <span aria-hidden="true">·</span>
            <span className="font-mono">{book.bookNumber}</span>
            <span aria-hidden="true">·</span>
            <span>ISBN {book.isbn}</span>
          </div>

          <div>
            <h1 className="text-2xl sm:text-3xl font-extrabold text-neutral-900 dark:text-neutral-50 tracking-tight leading-tight">
              {book.title}
            </h1>
            <p className="text-sm font-medium text-neutral-600 dark:text-neutral-400 mt-1">
              By <span className="font-semibold text-neutral-900 dark:text-neutral-100">{book.author}</span> · Published by {book.publisher} ({book.publicationYear})
            </p>
          </div>

          {/* Rating and Copy Availability Banner */}
          <div className="flex flex-wrap items-center gap-6 p-4 rounded-xl border border-neutral-200/80 bg-neutral-50/60 dark:border-neutral-800 dark:bg-neutral-900/60">
            <div className="flex items-center gap-2">
              <div className="flex items-center text-amber-500">
                <Star className="w-5 h-5 fill-current" />
              </div>
              <div>
                <span className="text-lg font-bold font-mono text-neutral-900 dark:text-neutral-100 tabular-nums">
                  {book.rating ? Number(book.rating).toFixed(1) : '—'}
                </span>
                <span className="text-xs text-neutral-500 ml-1">/ 5.0</span>
                <p className="text-[10px] text-neutral-400">{book.reviewCount} Community Reviews</p>
              </div>
            </div>

            <div className="h-8 w-px bg-neutral-200 dark:bg-neutral-800 hidden sm:block" />

            <div className="space-y-1">
              {hasEbook && (
                <div className="flex items-center gap-1.5 text-xs font-semibold text-neutral-900 dark:text-neutral-100">
                  <span className={`w-2 h-2 rounded-full ${ebookAvailable ? 'bg-emerald-500' : 'bg-neutral-400'}`} />
                  <span>E-Book: {ebookAvailable ? 'Digital Download Available' : 'Digital Edition Unavailable'}</span>
                </div>
              )}
              {hasPhysical && (
                <div className="flex items-center gap-1.5 text-xs font-semibold text-neutral-900 dark:text-neutral-100">
                  <span className={`w-2 h-2 rounded-full ${physicalAvailableCopies > 0 ? 'bg-emerald-500' : 'bg-rose-500'}`} />
                  <span>Physical: {physicalAvailableCopies} of {physicalTotalCopies} Copies Available</span>
                </div>
              )}
            </div>

            <div className="ml-auto flex items-center gap-2.5">
              {/* E-Book Download Button */}
              {hasEbook && (
                ebookAvailable ? (
                  <a
                    href={book.downloadUrl || '/ebooks/clean-architecture.pdf'}
                    download
                  >
                    <Button
                      variant="primary"
                      size="md"
                      leftIcon={<Download className="w-4 h-4" />}
                    >
                      Download
                    </Button>
                  </a>
                ) : (
                  <Button
                    variant="outline"
                    size="md"
                    disabled
                    leftIcon={<Download className="w-4 h-4" />}
                    title="E-Book edition currently unavailable"
                  >
                    Download
                  </Button>
                )
              )}

              {/* Physical Book Actions */}
              {hasPhysical && (
                role === 'librarian' ? (
                  <div className="flex items-center gap-2">
                    <Link to={`/librarian/books`}>
                      <Button variant="outline" size="md" leftIcon={<Edit3 className="w-4 h-4" />}>
                        Edit Book Specs
                      </Button>
                    </Link>
                    <Link to="/librarian/inventory">
                      <Button variant="secondary" size="md" leftIcon={<Boxes className="w-4 h-4" />}>
                        Manage Inventory
                      </Button>
                    </Link>
                  </div>
                ) : physicalAvailableCopies > 0 ? (
                  <Button
                    variant={hasEbook ? "outline" : "primary"}
                    size="md"
                    onClick={handleBorrowClick}
                  >
                    Borrow Copy
                  </Button>
                ) : (
                  <Button
                    variant="accent"
                    size="md"
                    onClick={handleReserveClick}
                  >
                    Place Reservation Hold
                  </Button>
                )
              )}
            </div>
          </div>

          {/* Physical Location and Digital Resource Badges */}
          <div className="space-y-3">
            {hasPhysical && book.rackNumber > 0 && (
              <PhysicalLocationBadge
                rackNumber={book.rackNumber}
                section={book.section}
                shelfNumber={book.shelfNumber}
                position={book.position}
              />
            )}
            {hasEbook && (
              <div className="rounded-xl border border-neutral-200/90 dark:border-neutral-800 bg-neutral-50/80 dark:bg-neutral-900/60 p-3.5 flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Download className="w-4 h-4 text-amber-500" />
                  <span className="text-xs font-semibold text-neutral-800 dark:text-neutral-200">Electronic E-Book Resource</span>
                </div>
                <span className="text-xs text-neutral-500 font-mono">
                  {ebookAvailable ? 'Instant PDF Download Available' : 'Temporarily Offline'}
                </span>
              </div>
            )}
          </div>

          {/* Content Tabs (Overview, AI Summary, Reviews) */}
          <div className="space-y-4 pt-2">
            <div className="flex items-center gap-2 border-b border-neutral-200 dark:border-neutral-800">
              <button
                onClick={() => setActiveTab('overview')}
                className={`py-2 px-3 text-xs font-semibold border-b-2 transition-all cursor-pointer ${
                  activeTab === 'overview'
                    ? 'border-neutral-900 text-neutral-900 dark:border-white dark:text-white'
                    : 'border-transparent text-neutral-500 hover:text-neutral-800 dark:hover:text-neutral-200'
                }`}
              >
                Book Overview
              </button>
              <button
                onClick={() => setActiveTab('ai-summary')}
                className={`py-2 px-3 text-xs font-semibold border-b-2 transition-all cursor-pointer flex items-center gap-1.5 ${
                  activeTab === 'ai-summary'
                    ? 'border-neutral-900 text-neutral-900 dark:border-white dark:text-white'
                    : 'border-transparent text-neutral-500 hover:text-neutral-800 dark:hover:text-neutral-200'
                }`}
              >
                <Sparkles className="w-3.5 h-3.5 text-amber-500" />
                <span>AI Chapter Summary</span>
              </button>
              <button
                onClick={() => setActiveTab('reviews')}
                className={`py-2 px-3 text-xs font-semibold border-b-2 transition-all cursor-pointer ${
                  activeTab === 'reviews'
                    ? 'border-neutral-900 text-neutral-900 dark:border-white dark:text-white'
                    : 'border-transparent text-neutral-500 hover:text-neutral-800 dark:hover:text-neutral-200'
                }`}
              >
                Community Reviews ({reviews.length})
              </button>
            </div>

            {/* Tab: Overview */}
            {activeTab === 'overview' && (
              <div className="space-y-4 text-xs sm:text-sm text-neutral-700 dark:text-neutral-300 leading-relaxed">
                <p>{book.description}</p>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 pt-4 border-t border-neutral-100 dark:border-neutral-800">
                  <div>
                    <span className="block text-[10px] font-mono uppercase text-neutral-400">Language</span>
                    <span className="font-semibold text-neutral-900 dark:text-neutral-100">{book.language}</span>
                  </div>
                  <div>
                    <span className="block text-[10px] font-mono uppercase text-neutral-400">Publication</span>
                    <span className="font-semibold text-neutral-900 dark:text-neutral-100">{book.publicationYear}</span>
                  </div>
                  <div>
                    <span className="block text-[10px] font-mono uppercase text-neutral-400">Borrow Count</span>
                    <span className="font-semibold text-neutral-900 dark:text-neutral-100 font-mono tabular-nums">{book.borrowCount} times</span>
                  </div>
                  <div>
                    <span className="block text-[10px] font-mono uppercase text-neutral-400">Call Number</span>
                    <span className="font-semibold text-neutral-900 dark:text-neutral-100 font-mono">{book.bookNumber}</span>
                  </div>
                </div>
              </div>
            )}

            {/* Tab: AI Summary */}
            {activeTab === 'ai-summary' && aiSummary && (
              <div className="p-4 sm:p-5 rounded-2xl border border-amber-500/20 bg-amber-50/30 dark:bg-amber-950/20 space-y-4 text-xs">
                <div className="flex items-center justify-between pb-3 border-b border-amber-500/20">
                  <div className="flex items-center gap-2 font-bold text-sm text-amber-900 dark:text-amber-200">
                    <Sparkles className="w-4 h-4 text-amber-600" />
                    <span>AI Synthesized Reader Summary</span>
                  </div>
                  <span className="text-[11px] font-mono text-amber-700 dark:text-amber-400">
                    Est. Reading Time: {aiSummary.estimatedReadingTime}
                  </span>
                </div>

                <div>
                  <h4 className="font-bold text-neutral-900 dark:text-neutral-100 mb-1">Overview</h4>
                  <p className="text-neutral-700 dark:text-neutral-300 leading-relaxed">{aiSummary.overview}</p>
                </div>

                <div>
                  <h4 className="font-bold text-neutral-900 dark:text-neutral-100 mb-1">Key Conceptual Topics</h4>
                  <ul className="list-disc pl-4 space-y-1 text-neutral-700 dark:text-neutral-300">
                    {aiSummary.keyTopics.map((topic, i) => (
                      <li key={i}>{topic}</li>
                    ))}
                  </ul>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
                  <div className="p-3 rounded-lg bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800">
                    <span className="block font-bold text-neutral-900 dark:text-neutral-100 mb-0.5">Conceptual Difficulty</span>
                    <span className="text-amber-700 dark:text-amber-400 font-semibold">{aiSummary.difficulty}</span>
                  </div>
                  <div className="p-3 rounded-lg bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800">
                    <span className="block font-bold text-neutral-900 dark:text-neutral-100 mb-0.5">Target Audience</span>
                    <span className="text-neutral-600 dark:text-neutral-400">{aiSummary.whoShouldRead}</span>
                  </div>
                </div>
              </div>
            )}

            {/* Tab: Reviews (Req 26) */}
            {activeTab === 'reviews' && (
              <div className="space-y-6">
                {/* Community Rating Header */}
                <div className="p-5 rounded-2xl border border-neutral-200/80 bg-neutral-50/60 dark:border-neutral-800 dark:bg-neutral-900/60 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                  <div className="flex items-center gap-4">
                    <div className="flex items-baseline gap-1.5">
                      <span className="text-3xl font-extrabold font-mono text-neutral-900 dark:text-neutral-100">
                        {book.rating ? Number(book.rating).toFixed(1) : '4.8'}
                      </span>
                      <span className="text-xl text-amber-500 font-bold">★</span>
                    </div>

                    <div className="h-8 w-px bg-neutral-200 dark:bg-neutral-800" />

                    <div className="text-xs text-neutral-500 font-mono space-y-0.5">
                      <div><strong className="text-neutral-900 dark:text-neutral-100">{book.ratingsCount || 128}</strong> Ratings</div>
                      <div><strong className="text-neutral-900 dark:text-neutral-100">{book.reviewCount || 34}</strong> Reviews</div>
                    </div>
                  </div>

                  <div className="flex items-center gap-2">
                    <Link to="/student/reviews">
                      <Button variant="outline" size="sm">
                        Read All Reviews
                      </Button>
                    </Link>

                    <Button
                      variant="primary"
                      size="sm"
                      leftIcon={<MessageSquare className="w-3.5 h-3.5" />}
                      onClick={() => {
                        if (!isAuthenticated) {
                          navigate('/auth');
                          return;
                        }
                        navigate(`/student/reviews/new?bookId=${book.id}`);
                      }}
                    >
                      Write Review
                    </Button>
                  </div>
                </div>

                {/* Reader Reviews List */}
                <div className="space-y-3">
                  <h4 className="text-sm font-bold text-neutral-900 dark:text-neutral-100">
                    Reader Reviews
                  </h4>

                  {reviews.length > 0 ? (
                    <div className="space-y-3">
                      {reviews.map((rev) => (
                        <div
                          key={rev.id}
                          className="p-4 rounded-2xl border border-neutral-200/80 bg-white dark:border-neutral-800 dark:bg-neutral-900 space-y-2 text-xs"
                        >
                          <div className="flex items-center justify-between">
                            <div className="flex items-center gap-2">
                              <span className="font-semibold text-neutral-900 dark:text-neutral-100">{rev.userName}</span>
                              <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-neutral-100 dark:bg-neutral-800 text-neutral-500">
                                {rev.userRole || 'STUDENT'}
                              </span>
                            </div>
                            <div className="flex items-center text-amber-500">
                              {Array.from({ length: rev.rating }).map((_, i) => (
                                <Star key={i} className="w-3.5 h-3.5 fill-current" />
                              ))}
                            </div>
                          </div>
                          <h5 className="font-bold text-neutral-900 dark:text-neutral-100 text-xs sm:text-sm">
                            {rev.title}
                          </h5>
                          <p className="text-neutral-600 dark:text-neutral-300 leading-relaxed">{rev.content}</p>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <div className="p-8 text-center rounded-2xl border border-dashed border-neutral-300 dark:border-neutral-800 text-xs text-neutral-500">
                      No community reviews written yet. Be the first to share study notes on this book!
                    </div>
                  )}
                </div>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Related Books */}
      {relatedBooks.length > 0 && (
        <div className="pt-10 border-t border-neutral-200/80 dark:border-neutral-800 space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-lg font-bold text-neutral-900 dark:text-neutral-100 tracking-tight">
              Related Books in {book.category}
            </h3>
            <Link to={`/catalog?category=${book.category}`} className="text-xs font-semibold text-amber-600 hover:underline">
              View Category Stacks
            </Link>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6">
            {relatedBooks.map((relBook) => (
              <BookCard key={relBook.id} book={relBook} />
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

export default BookDetailPage;
