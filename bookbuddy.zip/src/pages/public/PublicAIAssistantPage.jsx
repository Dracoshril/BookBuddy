import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../../hooks/useAuth';
import { Button } from '../../components/common/Button';
import { Sparkles, Send, Lock, ArrowRight, BookOpen, Compass, CheckCircle2 } from 'lucide-react';
import ReactMarkdown from 'react-markdown';

export const PublicAIAssistantPage = () => {
  const { isAuthenticated, role } = useAuth();
  const navigate = useNavigate();

  const [demoQuery, setDemoQuery] = useState('');
  const [messages, setMessages] = useState([
    {
      role: 'assistant',
      content: `### Welcome to BookBuddy AI Assistant
I can help you search physical library stacks, check book availability, explore learning concepts, or find recommended literature.

*Try asking:*
* *"Where is Clean Code located in the library?"*
* *"What are foundational books for learning Data Structures & Algorithms?"*
* *"Give me a summary of Designing Data-Intensive Applications"*`,
    },
  ]);

  const handleSend = (text) => {
    const q = (text || demoQuery).trim();
    if (!q) return;

    const userMsg = { role: 'user', content: q };
    let aiResponse = '';

    if (q.toLowerCase().includes('clean code')) {
      aiResponse = `### Clean Code: Physical Stack Location
* **Author**: Robert C. Martin (Call No: BK-0001)
* **Location**: **Floor 2, Rack 2, Section: Software Engineering, Shelf 1, Position 14**
* **Availability**: 3 of 5 copies currently on the shelf ready for immediate loan.`;
    } else if (q.toLowerCase().includes('dsa') || q.toLowerCase().includes('algorithm')) {
      aiResponse = `### Algorithms & Problem Solving Holdings
* **Grokking Algorithms** (Aditya Bhargava) — Rack 1, Shelf 2
* **Introduction to Algorithms (CLRS)** (Cormen et al.) — Rack 1, Shelf 3
* **Cracking the Coding Interview** (Gayle Laakmann McDowell) — Rack 1, Shelf 1`;
    } else {
      aiResponse = `### BookBuddy Catalog Search Result
I found several matching titles in our collection for "${q}":
* **Designing Data-Intensive Applications** (Martin Kleppmann) — Rack 3, Shelf 2
* **System Design Interview** (Alex Xu) — Rack 3, Shelf 1

*Note: Sign in with your student account to access personalized reading progress and one-click hold reservations!*`;
    }

    setMessages((prev) => [...prev, userMsg, { role: 'assistant', content: aiResponse }]);
    setDemoQuery('');
  };

  const handlePersonalizedClick = () => {
    if (isAuthenticated) {
      if (role === 'student') {
        navigate('/student/ai-assistant');
      } else {
        navigate('/librarian/dashboard');
      }
    } else {
      navigate('/auth', { state: { from: { pathname: '/student/ai-assistant' } } });
    }
  };

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 py-10 space-y-8">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-6 border-b border-neutral-200 dark:border-neutral-800">
        <div>
          <div className="inline-flex items-center gap-1.5 text-xs text-amber-600 dark:text-amber-400 font-semibold mb-1">
            <Sparkles className="w-3.5 h-3.5" />
            <span>Campus Library Knowledge Engine</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight text-neutral-900 dark:text-neutral-100">
            BookBuddy AI Assistant
          </h1>
          <p className="text-xs sm:text-sm text-neutral-500 mt-1">
            Public preview: search physical shelf coordinates, look up availability, and explore book topics.
          </p>
        </div>

        <Button
          variant="primary"
          size="md"
          leftIcon={<Sparkles className="w-4 h-4 text-amber-400" />}
          onClick={handlePersonalizedClick}
        >
          {isAuthenticated ? 'Open Student AI Assistant' : 'Sign In for Personalized AI'}
        </Button>
      </div>

      {/* Feature Value Props Banner */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs">
        <div className="p-4 rounded-2xl border border-neutral-200/80 bg-white dark:border-neutral-800 dark:bg-neutral-900 flex items-start gap-3">
          <Compass className="w-4 h-4 text-amber-500 shrink-0 mt-0.5" />
          <div>
            <strong className="block text-neutral-900 dark:text-neutral-100 mb-0.5">Physical Stack Locator</strong>
            <span className="text-neutral-500">Locates real rack, shelf, and spine positions in library stacks.</span>
          </div>
        </div>

        <div className="p-4 rounded-2xl border border-neutral-200/80 bg-white dark:border-neutral-800 dark:bg-neutral-900 flex items-start gap-3">
          <BookOpen className="w-4 h-4 text-sky-500 shrink-0 mt-0.5" />
          <div>
            <strong className="block text-neutral-900 dark:text-neutral-100 mb-0.5">Holdings Availability</strong>
            <span className="text-neutral-500">Live checks on total vs available copies for checkout.</span>
          </div>
        </div>

        <div className="p-4 rounded-2xl border border-neutral-200/80 bg-white dark:border-neutral-800 dark:bg-neutral-900 flex items-start gap-3">
          <CheckCircle2 className="w-4 h-4 text-emerald-500 shrink-0 mt-0.5" />
          <div>
            <strong className="block text-neutral-900 dark:text-neutral-100 mb-0.5">Curriculum Roadmaps</strong>
            <span className="text-neutral-500">Sequential study progressions tied to department syllabi.</span>
          </div>
        </div>
      </div>

      {/* Interactive Public Preview Chat Box */}
      <div className="rounded-3xl border border-neutral-200/80 bg-white dark:border-neutral-800 dark:bg-neutral-900 shadow-sm overflow-hidden flex flex-col h-[480px]">
        {/* Messages */}
        <div className="flex-1 overflow-y-auto p-6 space-y-4 text-xs sm:text-sm">
          {messages.map((m, i) => (
            <div
              key={i}
              className={`flex gap-3 ${m.role === 'user' ? 'justify-end' : 'justify-start'}`}
            >
              {m.role !== 'user' && (
                <div className="w-7 h-7 rounded-lg bg-amber-600 text-white flex items-center justify-center font-bold text-xs shrink-0">
                  AI
                </div>
              )}
              <div
                className={`max-w-[85%] rounded-2xl p-4 leading-relaxed ${
                  m.role === 'user'
                    ? 'bg-neutral-900 text-white dark:bg-white dark:text-neutral-900'
                    : 'bg-neutral-50 dark:bg-neutral-800/80 border border-neutral-200/60 dark:border-neutral-700/60 text-neutral-800 dark:text-neutral-200'
                }`}
              >
                <div className="prose prose-xs dark:prose-invert max-w-none">
                  <ReactMarkdown>{m.content}</ReactMarkdown>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Suggested Queries */}
        <div className="px-6 py-2 border-t border-neutral-100 dark:border-neutral-800 flex items-center gap-2 overflow-x-auto text-xs">
          <span className="text-[10px] font-mono text-neutral-400 shrink-0">Try asking:</span>
          {['Where is Clean Code?', 'DSA book recommendations', 'Java beginner books'].map((p, idx) => (
            <button
              key={idx}
              onClick={() => handleSend(p)}
              className="px-2.5 py-1 rounded-full border border-neutral-200 dark:border-neutral-700 hover:border-neutral-400 text-[11px] whitespace-nowrap cursor-pointer"
            >
              {p}
            </button>
          ))}
        </div>

        {/* Input */}
        <form
          onSubmit={(e) => {
            e.preventDefault();
            handleSend();
          }}
          className="p-4 border-t border-neutral-200 dark:border-neutral-800 flex items-center gap-2 bg-neutral-50/50 dark:bg-neutral-900"
        >
          <input
            type="text"
            value={demoQuery}
            onChange={(e) => setDemoQuery(e.target.value)}
            placeholder="Type a public query... (e.g. 'Where is Clean Code located?')"
            className="flex-1 h-11 rounded-xl border border-neutral-300 bg-white px-4 text-xs text-neutral-900 placeholder:text-neutral-400 focus:outline-none focus:ring-2 focus:ring-neutral-900 dark:border-neutral-700 dark:bg-neutral-800 dark:text-neutral-100"
          />
          <Button type="submit" variant="primary" size="md">
            Ask AI
          </Button>
        </form>
      </div>

      {/* Personalized CTA Box */}
      <div className="p-6 rounded-3xl bg-neutral-900 text-white dark:bg-neutral-900 dark:border dark:border-neutral-800 flex flex-col sm:flex-row items-center justify-between gap-4">
        <div className="space-y-1">
          <h4 className="font-bold text-sm">Want personalized borrowing-aware AI assistance?</h4>
          <p className="text-xs text-neutral-400">
            Sign in as a student to link your loan limits, active holds, personal reading diary, and semester roadmaps.
          </p>
        </div>
        <Button variant="accent" size="sm" onClick={handlePersonalizedClick}>
          Start Personalized Assistant →
        </Button>
      </div>
    </div>
  );
};

export default PublicAIAssistantPage;
