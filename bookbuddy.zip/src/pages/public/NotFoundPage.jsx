import React from 'react';
import { Link } from 'react-router-dom';
import { Button } from '../../components/common/Button';
import { BookOpen, Compass, Home } from 'lucide-react';

export const NotFoundPage = () => {
  return (
    <div className="min-h-[70vh] flex items-center justify-center p-6 text-center">
      <div className="max-w-md w-full p-8 rounded-2xl border border-neutral-200/80 bg-white dark:border-neutral-800 dark:bg-neutral-900 shadow-xl space-y-4">
        <div className="w-14 h-14 rounded-2xl bg-neutral-100 dark:bg-neutral-800 text-neutral-800 dark:text-neutral-200 flex items-center justify-center mx-auto text-xl font-bold font-mono">
          404
        </div>
        <h2 className="text-xl font-bold text-neutral-900 dark:text-neutral-100 tracking-tight">
          Page Not Found in Library Index
        </h2>
        <p className="text-xs text-neutral-500 dark:text-neutral-400 leading-relaxed">
          The requested shelf URL or resource could not be found in our university catalog.
        </p>
        <div className="flex items-center justify-center gap-3 pt-2">
          <Link to="/">
            <Button variant="outline" size="sm" leftIcon={<Home className="w-4 h-4" />}>
              Back to BookBuddy
            </Button>
          </Link>
          <Link to="/explore">
            <Button variant="primary" size="sm" leftIcon={<Compass className="w-4 h-4" />}>
              Explore Books
            </Button>
          </Link>
        </div>
      </div>
    </div>
  );
};

export default NotFoundPage;
